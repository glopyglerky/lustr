"git" "-C" "/home/runner/work/_temp/lustr-regression-source" "rev-parse" "HEAD" "HEAD^{tree}"
