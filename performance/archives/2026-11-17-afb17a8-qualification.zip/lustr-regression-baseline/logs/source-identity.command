cd "/home/runner/work/_temp/lustr-regression-source" && "/home/runner/work/_temp/lustr-regression-baseline/work/source-guard" "--candidate"
