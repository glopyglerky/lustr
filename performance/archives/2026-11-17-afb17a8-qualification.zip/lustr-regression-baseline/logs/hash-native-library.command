"sha256sum" "/home/runner/work/_temp/lustr-regression-baseline/toolchain/lib/liblustr_native_core.so"
