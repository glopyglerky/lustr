"sha256sum" "/home/runner/work/_temp/lustr-regression-baseline/toolchain/bin/lust"
