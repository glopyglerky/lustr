use proc_macro::TokenStream;
#[proc_macro]
pub fn general(_:TokenStream)->TokenStream{"async fn general(x:u64)->u64{kernel(x) as u64}".parse().unwrap()}
