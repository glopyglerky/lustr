#![no_std]
extern crate alloc;
pub fn adjustment()->u64{alloc::vec![0u64].iter().sum()}
