use fixture_macro::general;
general!();
fn kernel(x:u64)->u64{x ^ 17}
fn main(){let w=std::task::Waker::noop();let mut f=std::pin::pin!(general(42+portable::adjustment()));let mut cx=std::task::Context::from_waker(w);match std::future::Future::poll(f.as_mut(),&mut cx){std::task::Poll::Ready(v)=>println!("{v}"),std::task::Poll::Pending=>panic!("unexpected pending")}}
#[test]
fn scalar_contract(){assert_eq!(kernel(42),59);}
