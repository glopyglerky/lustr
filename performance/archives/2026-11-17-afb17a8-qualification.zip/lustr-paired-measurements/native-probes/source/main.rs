fn kernel(x:u64)->u64{x ^ 19}
fn main(){println!("{}",kernel(42));}
#[test]
fn scalar_contract(){assert_eq!(kernel(42),59);}
