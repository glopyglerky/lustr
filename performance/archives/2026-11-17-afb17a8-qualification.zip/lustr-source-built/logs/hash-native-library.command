"sha256sum" "/home/runner/work/_temp/lustr-source-built/toolchain/lib/liblustr_native_core.so"
