"sha256sum" "/home/runner/work/_temp/lustr-source-built/toolchain/bin/cargo-lustr"
