"git" "-C" "/home/runner/work/lustr/lustr" "rev-parse" "HEAD" "HEAD^{tree}"
