cd "/home/runner/work/lustr/lustr" && "/home/runner/work/_temp/lustr-source-built/work/source-guard" "--candidate"
