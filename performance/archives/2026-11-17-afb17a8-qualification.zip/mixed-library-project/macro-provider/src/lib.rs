use proc_macro::TokenStream;
#[proc_macro]
pub fn general(_:TokenStream)->TokenStream{"pub async fn general(x:i64)->i64{native(x)+portable::adjustment()}".parse().unwrap()}
