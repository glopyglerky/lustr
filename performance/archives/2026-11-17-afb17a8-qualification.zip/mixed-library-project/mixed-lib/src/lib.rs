#![no_std]
use macro_provider::general;
general!();
pub fn native(x:i64)->i64{x ^ 17}
pub fn arithmetic(x:u64)->u64{x.wrapping_add(17)}
pub struct Pair{pub left:i64,pub right:i64}
pub fn pair(x:i64)->Pair{Pair{left:native(x),right:portable::adjustment()}}
pub fn generic<T:Copy>(x:T)->T{x}
