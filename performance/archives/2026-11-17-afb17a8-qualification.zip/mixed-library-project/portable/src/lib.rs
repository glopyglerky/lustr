#![no_std]
extern crate alloc;
pub fn adjustment()->i64{alloc::vec![2i64,3].iter().sum()}
