; ModuleID = 'oracle.424ebdcbad77f0d8-cgu.0'
source_filename = "oracle.424ebdcbad77f0d8-cgu.0"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-apple-macosx10.12.0"

; Function Attrs: uwtable
define i64 @align_0() unnamed_addr #0 !guid !4 {
start:
  ret i64 8
}

; Function Attrs: uwtable
define i64 @align_1() unnamed_addr #0 !guid !5 {
start:
  ret i64 8
}

; Function Attrs: uwtable
define i64 @align_10() unnamed_addr #0 !guid !6 {
start:
  ret i64 8
}

; Function Attrs: uwtable
define i64 @align_11() unnamed_addr #0 !guid !7 {
start:
  ret i64 8
}

; Function Attrs: uwtable
define i64 @align_12() unnamed_addr #0 !guid !8 {
start:
  ret i64 8
}

; Function Attrs: uwtable
define i64 @align_2() unnamed_addr #0 !guid !9 {
start:
  ret i64 8
}

; Function Attrs: uwtable
define i64 @align_3() unnamed_addr #0 !guid !10 {
start:
  ret i64 16
}

; Function Attrs: uwtable
define i64 @align_4() unnamed_addr #0 !guid !11 {
start:
  ret i64 8
}

; Function Attrs: uwtable
define i64 @align_5() unnamed_addr #0 !guid !12 {
start:
  ret i64 8
}

; Function Attrs: uwtable
define i64 @align_6() unnamed_addr #0 !guid !13 {
start:
  ret i64 8
}

; Function Attrs: uwtable
define i64 @align_7() unnamed_addr #0 !guid !14 {
start:
  ret i64 16
}

; Function Attrs: uwtable
define i64 @align_8() unnamed_addr #0 !guid !15 {
start:
  ret i64 8
}

; Function Attrs: uwtable
define i64 @align_9() unnamed_addr #0 !guid !16 {
start:
  ret i64 8
}

; Function Attrs: uwtable
define i64 @size_0() unnamed_addr #0 !guid !17 {
start:
  ret i64 16
}

; Function Attrs: uwtable
define i64 @size_1() unnamed_addr #0 !guid !18 {
start:
  ret i64 16
}

; Function Attrs: uwtable
define i64 @size_10() unnamed_addr #0 !guid !19 {
start:
  ret i64 16
}

; Function Attrs: uwtable
define i64 @size_11() unnamed_addr #0 !guid !20 {
start:
  ret i64 24
}

; Function Attrs: uwtable
define i64 @size_12() unnamed_addr #0 !guid !21 {
start:
  ret i64 48
}

; Function Attrs: uwtable
define i64 @size_2() unnamed_addr #0 !guid !22 {
start:
  ret i64 24
}

; Function Attrs: uwtable
define i64 @size_3() unnamed_addr #0 !guid !23 {
start:
  ret i64 32
}

; Function Attrs: uwtable
define i64 @size_4() unnamed_addr #0 !guid !24 {
start:
  ret i64 24
}

; Function Attrs: uwtable
define i64 @size_5() unnamed_addr #0 !guid !25 {
start:
  ret i64 16
}

; Function Attrs: uwtable
define i64 @size_6() unnamed_addr #0 !guid !26 {
start:
  ret i64 16
}

; Function Attrs: uwtable
define i64 @size_7() unnamed_addr #0 !guid !27 {
start:
  ret i64 32
}

; Function Attrs: uwtable
define i64 @size_8() unnamed_addr #0 !guid !28 {
start:
  ret i64 8
}

; Function Attrs: uwtable
define i64 @size_9() unnamed_addr #0 !guid !29 {
start:
  ret i64 16
}

attributes #0 = { uwtable "frame-pointer"="all" "probe-stack"="inline-asm" "target-cpu"="penryn" }

!llvm.module.flags = !{!0, !1, !2}
!llvm.ident = !{!3}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 7, !"uwtable", i32 2}
!2 = !{i32 7, !"frame-pointer", i32 2}
!3 = !{!"rustc version 1.102.0-nightly (5b7b37aef 2026-11-08)"}
!4 = !{i64 -2059905596568001918}
!5 = !{i64 3697589427516770306}
!6 = !{i64 -8107591314177247718}
!7 = !{i64 -5880941993495822804}
!8 = !{i64 -1376853775431349653}
!9 = !{i64 2204441158137535742}
!10 = !{i64 6270513525251814317}
!11 = !{i64 3071562664170902965}
!12 = !{i64 5849311242919914600}
!13 = !{i64 1696595445684170380}
!14 = !{i64 4761156301917331629}
!15 = !{i64 255333772436335401}
!16 = !{i64 1757733519126736946}
!17 = !{i64 8066865119197247812}
!18 = !{i64 4202187199279510285}
!19 = !{i64 9215323538930347835}
!20 = !{i64 -8339169029722605314}
!21 = !{i64 -4259880747757298968}
!22 = !{i64 2533692228644865349}
!23 = !{i64 -4145677419438453084}
!24 = !{i64 8993249761052582604}
!25 = !{i64 2509402006528403408}
!26 = !{i64 1383708392427406386}
!27 = !{i64 8871621536020247781}
!28 = !{i64 399738786833091978}
!29 = !{i64 -9151692243858459248}
