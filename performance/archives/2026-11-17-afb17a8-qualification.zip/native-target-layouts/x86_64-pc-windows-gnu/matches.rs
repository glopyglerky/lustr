#![allow(dead_code)]
const _: () = assert!(std::mem::size_of::<std::sync::Mutex<()>>() == 2);
const _: () = assert!(std::mem::align_of::<std::sync::Mutex<()>>() == 1);
const _: () = assert!(std::mem::size_of::<std::sync::Mutex<u8>>() == 3);
const _: () = assert!(std::mem::align_of::<std::sync::Mutex<u8>>() == 1);
const _: () = assert!(std::mem::size_of::<std::sync::Mutex<u64>>() == 16);
const _: () = assert!(std::mem::align_of::<std::sync::Mutex<u64>>() == 8);
const _: () = assert!(std::mem::size_of::<std::sync::Mutex<u128>>() == 32);
const _: () = assert!(std::mem::align_of::<std::sync::Mutex<u128>>() == 16);
const _: () = assert!(std::mem::size_of::<Option<std::sync::Mutex<bool>>>() == 4);
const _: () = assert!(std::mem::align_of::<Option<std::sync::Mutex<bool>>>() == 1);
const _: () = assert!(std::mem::size_of::<std::sync::RwLock<()>>() == 12);
const _: () = assert!(std::mem::align_of::<std::sync::RwLock<()>>() == 4);
const _: () = assert!(std::mem::size_of::<std::sync::RwLock<u8>>() == 12);
const _: () = assert!(std::mem::align_of::<std::sync::RwLock<u8>>() == 4);
const _: () = assert!(std::mem::size_of::<std::sync::RwLock<u128>>() == 32);
const _: () = assert!(std::mem::align_of::<std::sync::RwLock<u128>>() == 16);
const _: () = assert!(std::mem::size_of::<std::sync::OnceLock<core::convert::Infallible>>() == 4);
const _: () = assert!(std::mem::align_of::<std::sync::OnceLock<core::convert::Infallible>>() == 4);
const _: () = assert!(std::mem::size_of::<std::sync::OnceLock<u8>>() == 8);
const _: () = assert!(std::mem::align_of::<std::sync::OnceLock<u8>>() == 4);
const _: () = assert!(std::mem::size_of::<std::sync::Condvar>() == 4);
const _: () = assert!(std::mem::align_of::<std::sync::Condvar>() == 4);
const _: () = assert!(std::mem::size_of::<Option<std::sync::Condvar>>() == 8);
const _: () = assert!(std::mem::align_of::<Option<std::sync::Condvar>>() == 4);
const _: () = assert!(std::mem::size_of::<std::sync::Barrier>() == 40);
const _: () = assert!(std::mem::align_of::<std::sync::Barrier>() == 8);
fn main() {}
