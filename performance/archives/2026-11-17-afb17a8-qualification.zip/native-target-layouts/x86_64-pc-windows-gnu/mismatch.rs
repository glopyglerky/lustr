const _: () = assert!(std::mem::size_of::<std::sync::Mutex<()>>() == 3);
fn main() {}
