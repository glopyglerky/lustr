const _: () = assert!(std::mem::size_of::<std::sync::Mutex<()>>() == 9);
fn main() {}
