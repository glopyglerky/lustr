#![allow(dead_code)]
const _: () = assert!(std::mem::size_of::<std::sync::Mutex<()>>() == 16);
const _: () = assert!(std::mem::align_of::<std::sync::Mutex<()>>() == 8);
const _: () = assert!(std::mem::size_of::<std::sync::Mutex<u8>>() == 16);
const _: () = assert!(std::mem::align_of::<std::sync::Mutex<u8>>() == 8);
const _: () = assert!(std::mem::size_of::<std::sync::Mutex<u64>>() == 24);
const _: () = assert!(std::mem::align_of::<std::sync::Mutex<u64>>() == 8);
const _: () = assert!(std::mem::size_of::<std::sync::Mutex<u128>>() == 32);
const _: () = assert!(std::mem::align_of::<std::sync::Mutex<u128>>() == 16);
const _: () = assert!(std::mem::size_of::<Option<std::sync::Mutex<bool>>>() == 24);
const _: () = assert!(std::mem::align_of::<Option<std::sync::Mutex<bool>>>() == 8);
const _: () = assert!(std::mem::size_of::<std::sync::RwLock<()>>() == 16);
const _: () = assert!(std::mem::align_of::<std::sync::RwLock<()>>() == 8);
const _: () = assert!(std::mem::size_of::<std::sync::RwLock<u8>>() == 16);
const _: () = assert!(std::mem::align_of::<std::sync::RwLock<u8>>() == 8);
const _: () = assert!(std::mem::size_of::<std::sync::RwLock<u128>>() == 32);
const _: () = assert!(std::mem::align_of::<std::sync::RwLock<u128>>() == 16);
const _: () = assert!(std::mem::size_of::<std::sync::OnceLock<core::convert::Infallible>>() == 8);
const _: () = assert!(std::mem::align_of::<std::sync::OnceLock<core::convert::Infallible>>() == 8);
const _: () = assert!(std::mem::size_of::<std::sync::OnceLock<u8>>() == 16);
const _: () = assert!(std::mem::align_of::<std::sync::OnceLock<u8>>() == 8);
const _: () = assert!(std::mem::size_of::<std::sync::Condvar>() == 16);
const _: () = assert!(std::mem::align_of::<std::sync::Condvar>() == 8);
const _: () = assert!(std::mem::size_of::<Option<std::sync::Condvar>>() == 24);
const _: () = assert!(std::mem::align_of::<Option<std::sync::Condvar>>() == 8);
const _: () = assert!(std::mem::size_of::<std::sync::Barrier>() == 48);
const _: () = assert!(std::mem::align_of::<std::sync::Barrier>() == 8);
fn main() {}
