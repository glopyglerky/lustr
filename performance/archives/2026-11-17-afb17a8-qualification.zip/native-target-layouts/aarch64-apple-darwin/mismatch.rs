const _: () = assert!(std::mem::size_of::<std::sync::Mutex<()>>() == 17);
fn main() {}
