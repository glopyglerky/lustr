use proc_macro::TokenStream;
#[proc_macro]
pub fn general(_:TokenStream)->TokenStream{"async fn general()->i64{checked_lib::boundary(2)}".parse().unwrap()}
