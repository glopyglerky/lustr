#![no_std]
extern crate alloc;
pub fn general()->i64{alloc::vec![0i64].iter().sum()}
