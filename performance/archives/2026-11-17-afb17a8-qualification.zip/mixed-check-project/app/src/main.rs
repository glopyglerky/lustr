#![deny(dead_code)]
use macro_source::general;
general!();
fn kernel(x:i64)->i64{x ^ 17}
fn main(){let _future=general();println!("{}",kernel(checked_lib::boundary(portable::general())));}
fn unused_warning(){}
