pub fn boundary(x:i64)->i64{x ^ 17}
