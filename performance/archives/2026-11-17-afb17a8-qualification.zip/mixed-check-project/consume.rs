pub fn consume()->i64{checked_lib::boundary(0)}
