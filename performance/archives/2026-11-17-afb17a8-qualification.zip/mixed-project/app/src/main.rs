#![deny(dead_code)]
use mixed_macro::general;
#[allow(non_camel_case_types)] type u64=i64;
mod core{pub mod mem{pub fn size_of<T>()->usize{1}}}
mod nested{pub fn kernel(x:i64)->i64{x ^ 31}}
fn projected_size()->usize{core::mem::size_of::<u64>()}
fn signed_alias(x:std::primitive::i64)->std::primitive::i64{if (x as u64)<0{1}else{2}}
general!();
fn kernel(x:u64)->u64{x ^ 19}
fn choose(x:u64)->u64{if x & 1 == 0 {x ^ 1024} else {x | 2048}}
trait Counterfeit{fn wrapping_add(self,rhs:u64)->u64;}
impl Counterfeit for bool{fn wrapping_add(self,_:u64)->u64{99}}
fn fake_wrapping(x:u64)->u64{(x==0).wrapping_add(17)}
fn arithmetic(x:std::primitive::u64)->std::primitive::u64{x.wrapping_add(17)}
fn rotation(x:std::primitive::u64)->std::primitive::u64{x.wrapping_sub(5).wrapping_mul(3).wrapping_neg().wrapping_shl(65).wrapping_shr(64).rotate_left(7).rotate_right(9)}
fn signed_rotation(x:std::primitive::i64)->std::primitive::i64{x.wrapping_add(17).wrapping_sub(5).wrapping_mul(3).wrapping_neg().wrapping_shl(65).wrapping_shr(64).rotate_left(7).rotate_right(9)}
fn main(){assert_eq!(fake_wrapping(0),99);let literal=std::env::var("MIXED_ARITH_LITERAL").unwrap_or_else(|_|"17".into()).parse::<std::primitive::u64>().unwrap();for value in [0,1,42,std::primitive::u64::MAX]{assert_eq!(arithmetic(value),value.wrapping_add(literal));assert_eq!(rotation(value),value.wrapping_sub(5).wrapping_mul(3).wrapping_neg().wrapping_shl(65).wrapping_shr(64).rotate_left(7).rotate_right(9));}for value in [std::primitive::i64::MIN,-1,0,1,std::primitive::i64::MAX]{assert_eq!(signed_rotation(value),value.wrapping_add(17).wrapping_sub(5).wrapping_mul(3).wrapping_neg().wrapping_shl(65).wrapping_shr(64).rotate_left(7).rotate_right(9));}assert_eq!(projected_size(),1);assert_eq!(signed_alias(-1),1);assert_eq!(nested::kernel(0),31);let w=std::task::Waker::noop();let mut f=std::pin::pin!(general((42+tiny_core::adjustment()) as _));let mut cx=std::task::Context::from_waker(w);match std::future::Future::poll(f.as_mut(),&mut cx){std::task::Poll::Ready(v)=>println!("{v}"),std::task::Poll::Pending=>panic!("unexpected pending")}}

fn unused_warning(){}
