use proc_macro::TokenStream;
#[proc_macro]
pub fn general(_:TokenStream)->TokenStream{"async fn general(x:u64)->u64{kernel(choose(x)) ^ 1}".parse().unwrap()}
