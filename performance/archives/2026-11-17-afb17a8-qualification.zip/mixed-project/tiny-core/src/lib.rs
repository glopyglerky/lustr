#![no_std]
extern crate alloc;
pub fn adjustment()->u64{let v=alloc::vec::Vec::from([1u64]);v.iter().sum()}
