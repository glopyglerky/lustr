# Mixed compiler phase attribution

Instrumented execution of the existing mixed Cargo qualification. This is a separate diagnostic run, not paired speed evidence.

Each cell sums one named phase across the compiler processes for that command, in milliseconds. Spans can nest and crates can run concurrently; columns must not be added into command wall time. Dynamic loading before driver entry and final process teardown are outside these spans. All original records and qualification stdout/stderr/status/trace files remain in this directory.

| Command | Compiler invocations | driver | context-fingerprint | native-compile | native-request-setup | native-daemon-roundtrip | native-symbol-rename | temporary-link-copies | original-linker | edited-native-object-sync | publish-certificate |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| cold | 8 | 141.640 | 0.330 | 20.310 | 0.434 | 16.343 | 0.303 | 0.000 | 0.000 | 0.000 | 0.638 |
| body | 1 | 31.603 | 0.436 | 2.527 | 0.101 | 2.420 | 0.059 | 0.300 | 18.261 | 0.228 | 0.762 |
| arithmetic-edit | 1 | 34.798 | 0.440 | 3.087 | 0.117 | 2.952 | 0.075 | 0.432 | 20.011 | 0.322 | 0.852 |
| invalid | 1 | 22.486 | 0.437 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |
| recovery | 1 | 32.570 | 0.440 | 2.628 | 0.109 | 2.512 | 0.062 | 0.311 | 18.626 | 0.274 | 0.842 |
| link-failure | 1 | 15.478 | 0.422 | 2.442 | 0.097 | 2.338 | 0.074 | 0.332 | 2.656 | 0.271 | 0.000 |
| link-failure-recovery | 1 | 28.466 | 0.446 | 0.000 | 0.000 | 0.000 | 0.000 | 0.330 | 18.464 | 0.000 | 0.881 |
| versioned-object | 1 | 31.960 | 0.457 | 2.285 | 0.108 | 2.171 | 0.069 | 0.354 | 18.447 | 0.237 | 0.763 |
| versioned-object-noop | 1 | 28.106 | 0.447 | 0.000 | 0.000 | 0.000 | 0.000 | 0.315 | 18.398 | 0.000 | 0.846 |
| signature | 2 | 112.604 | 0.621 | 13.991 | 0.406 | 13.562 | 0.321 | 0.000 | 0.000 | 0.000 | 0.773 |
| dependency | 3 | 128.996 | 0.622 | 13.575 | 0.424 | 13.125 | 0.295 | 0.000 | 0.000 | 0.000 | 0.726 |
| macro | 2 | 111.542 | 0.615 | 13.424 | 0.365 | 13.036 | 0.283 | 0.000 | 0.000 | 0.000 | 0.788 |
| warning-cold | 1 | 67.905 | 0.647 | 13.671 | 0.391 | 13.257 | 0.282 | 0.000 | 0.000 | 0.000 | 0.000 |
| warning-edit | 1 | 74.187 | 0.648 | 18.248 | 0.393 | 17.834 | 0.295 | 0.000 | 0.000 | 0.000 | 0.000 |
| warning-denied | 1 | 18.305 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |

The full JSON includes every named phase, per-process success/reuse/check state, exact compiler identities and record hashes. A zero in this table means no recorded duration for that phase. These observations do not isolate a before/after optimization effect or establish a compiler speedup.

## Native emitter durations

These durations come from the daemon response, separately from the driver clock. Each record is bound to its actual client request and successful protocol exchange, checked against that exchange's elapsed time, and matched to the original diagnostic trace. The daemon's sequential phase durations cover its emitter total; they do not partition the enclosing driver span.

Roundtrip outside emitter remains unattributed. It includes protocol transport and queueing, native frontend and generated-code work before the emitter, retained-state work after it, guard handling, and response production. It is not a frontend or codegen measurement. Client request setup is recorded separately; retries and daemon startup can also occupy the enclosing request.

| Command | Responses / measured / unavailable failures | emitter total | c-prepare | output-prepare | c-write | libtcc | symbol-check | rename | file-sync | directory-sync | roundtrip outside emitter |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| cold | 5 / 5 / 0 | 3.625 | 0.015 | 0.096 | 0.151 | 1.243 | 0.073 | 0.063 | 1.948 | 0.037 | 12.670 |
| body | 1 / 1 / 0 | 0.682 | 0.004 | 0.017 | 0.030 | 0.220 | 0.014 | 0.011 | 0.381 | 0.005 | 1.737 |
| arithmetic-edit | 1 / 1 / 0 | 0.757 | 0.005 | 0.020 | 0.034 | 0.269 | 0.018 | 0.014 | 0.390 | 0.009 | 2.195 |
| invalid | 0 / 0 / 0 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |
| recovery | 1 / 1 / 0 | 0.718 | 0.004 | 0.019 | 0.039 | 0.217 | 0.014 | 0.014 | 0.402 | 0.009 | 1.794 |
| link-failure | 1 / 1 / 0 | 0.630 | 0.004 | 0.017 | 0.037 | 0.192 | 0.014 | 0.014 | 0.344 | 0.007 | 1.708 |
| link-failure-recovery | 0 / 0 / 0 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |
| versioned-object | 1 / 1 / 0 | 0.692 | 0.008 | 0.018 | 0.037 | 0.195 | 0.014 | 0.014 | 0.398 | 0.007 | 1.479 |
| versioned-object-noop | 0 / 0 / 0 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |
| signature | 5 / 5 / 0 | 3.280 | 0.015 | 0.099 | 0.170 | 1.054 | 0.070 | 0.059 | 1.643 | 0.172 | 10.282 |
| dependency | 5 / 5 / 0 | 2.884 | 0.015 | 0.085 | 0.139 | 0.980 | 0.064 | 0.054 | 1.504 | 0.044 | 10.241 |
| macro | 5 / 5 / 0 | 2.764 | 0.014 | 0.083 | 0.130 | 0.865 | 0.064 | 0.054 | 1.524 | 0.030 | 10.272 |
| warning-cold | 5 / 5 / 0 | 3.114 | 0.015 | 0.090 | 0.134 | 0.952 | 0.064 | 0.054 | 1.778 | 0.028 | 10.142 |
| warning-edit | 5 / 5 / 0 | 7.531 | 0.015 | 0.087 | 0.133 | 1.021 | 0.064 | 0.054 | 6.125 | 0.032 | 10.303 |
| warning-denied | 0 / 0 / 0 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |

Values are milliseconds summed only across the measured successful responses. Failed native responses retain their original error diagnostics, actual response code and complete client intervals, with emitter detail and outside-emitter residual explicitly unavailable. Their remote durations are null, never zero. Timing text must not alter the daemon's byte-for-byte comparison of failed warm/fresh responses. Missing success detail or unexpected failure decoration fails profiling qualification. Version 1 archives did not collect these records and remain labeled not recorded. The single-unit libtcc span includes its in-process compiler setup, compilation, object write and teardown; symbol-check reads and validates the bounded ELF object in process, with no symbol-tool child. Emitter schema 2 names this operation separately from historical nm spans. Rename and both synchronization operations remain unchanged.
