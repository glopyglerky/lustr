# Mixed compiler phase attribution

Instrumented execution of the existing mixed Cargo qualification. This is a separate diagnostic run, not paired speed evidence.

Each cell sums one named phase across the compiler processes for that command, in milliseconds. Spans can nest and crates can run concurrently; columns must not be added into command wall time. Dynamic loading before driver entry and final process teardown are outside these spans. All original records and qualification stdout/stderr/status/trace files remain in this directory.

| Command | Compiler invocations | driver | context-fingerprint | native-compile | native-request-setup | native-daemon-roundtrip | native-symbol-rename | temporary-link-copies | original-linker | edited-native-object-sync | publish-certificate |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| cold | 8 | 307.062 | 0.245 | 186.962 | 0.427 | 182.891 | 6.913 | 0.000 | 0.000 | 0.000 | 0.604 |
| body | 1 | 65.557 | 0.491 | 37.681 | 0.120 | 37.551 | 1.370 | 0.159 | 16.721 | 0.288 | 0.545 |
| arithmetic-edit | 1 | 63.064 | 0.461 | 35.722 | 0.087 | 35.623 | 1.353 | 0.157 | 16.869 | 0.202 | 0.504 |
| invalid | 1 | 21.530 | 0.483 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |
| recovery | 1 | 63.179 | 0.451 | 35.219 | 0.092 | 35.114 | 1.333 | 0.164 | 17.275 | 0.225 | 0.559 |
| link-failure | 1 | 48.052 | 0.461 | 35.062 | 0.091 | 34.962 | 1.330 | 0.187 | 2.743 | 0.243 | 0.000 |
| link-failure-recovery | 1 | 26.178 | 0.593 | 0.000 | 0.000 | 0.000 | 0.000 | 0.154 | 17.130 | 0.000 | 0.618 |
| versioned-object | 1 | 63.104 | 0.479 | 35.430 | 0.136 | 35.286 | 1.331 | 0.161 | 16.838 | 0.260 | 0.607 |
| versioned-object-noop | 1 | 24.914 | 0.479 | 0.000 | 0.000 | 0.000 | 0.000 | 0.160 | 16.702 | 0.000 | 0.604 |
| signature | 2 | 277.462 | 0.713 | 176.701 | 0.377 | 176.283 | 6.537 | 0.000 | 0.000 | 0.000 | 0.553 |
| dependency | 3 | 287.367 | 0.720 | 173.534 | 0.395 | 173.082 | 6.396 | 0.000 | 0.000 | 0.000 | 0.578 |
| macro | 2 | 275.456 | 0.728 | 174.888 | 0.417 | 174.420 | 6.590 | 0.000 | 0.000 | 0.000 | 0.583 |
| warning-cold | 1 | 235.853 | 0.679 | 177.011 | 0.398 | 176.567 | 6.653 | 0.000 | 0.000 | 0.000 | 0.000 |
| warning-edit | 1 | 233.039 | 0.711 | 175.170 | 0.408 | 174.715 | 6.369 | 0.000 | 0.000 | 0.000 | 0.000 |
| warning-denied | 1 | 17.018 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |

The full JSON includes every named phase, per-process success/reuse/check state, exact compiler identities and record hashes. A zero in this table means no recorded duration for that phase. These observations do not isolate a before/after optimization effect or establish a compiler speedup.

## Native emitter durations

These durations come from the daemon response, separately from the driver clock. Each record is bound to its actual client request and successful protocol exchange, checked against that exchange's elapsed time, and matched to the original diagnostic trace. The daemon's sequential phase durations cover its emitter total; they do not partition the enclosing driver span.

Roundtrip outside emitter remains unattributed. It includes protocol transport and queueing, native frontend and generated-code work before the emitter, retained-state work after it, guard handling, and response production. It is not a frontend or codegen measurement. Client request setup is recorded separately; retries and daemon startup can also occupy the enclosing request.

| Command | Responses / measured / unavailable failures | emitter total | c-prepare | output-prepare | c-write | libtcc | nm | rename | file-sync | directory-sync | roundtrip outside emitter |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| cold | 5 / 5 / 0 | 167.050 | 0.021 | 0.070 | 0.128 | 1.577 | 163.100 | 0.205 | 1.916 | 0.034 | 15.784 |
| body | 1 / 1 / 0 | 35.258 | 0.005 | 0.019 | 0.032 | 0.198 | 34.545 | 0.041 | 0.409 | 0.009 | 2.293 |
| arithmetic-edit | 1 / 1 / 0 | 33.832 | 0.004 | 0.016 | 0.032 | 0.198 | 33.114 | 0.042 | 0.417 | 0.009 | 1.791 |
| invalid | 0 / 0 / 0 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |
| recovery | 1 / 1 / 0 | 33.473 | 0.004 | 0.020 | 0.038 | 0.198 | 32.739 | 0.041 | 0.427 | 0.007 | 1.641 |
| link-failure | 1 / 1 / 0 | 33.175 | 0.004 | 0.018 | 0.040 | 0.197 | 32.473 | 0.038 | 0.397 | 0.008 | 1.788 |
| link-failure-recovery | 0 / 0 / 0 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |
| versioned-object | 1 / 1 / 0 | 33.830 | 0.009 | 0.018 | 0.041 | 0.198 | 33.173 | 0.042 | 0.340 | 0.008 | 1.456 |
| versioned-object-noop | 0 / 0 / 0 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |
| signature | 5 / 5 / 0 | 162.980 | 0.022 | 0.083 | 0.128 | 2.016 | 158.645 | 0.159 | 1.888 | 0.039 | 13.303 |
| dependency | 5 / 5 / 0 | 161.469 | 0.022 | 0.093 | 0.111 | 1.277 | 157.907 | 0.170 | 1.850 | 0.039 | 11.613 |
| macro | 5 / 5 / 0 | 161.648 | 0.029 | 0.066 | 0.102 | 1.259 | 158.253 | 0.167 | 1.737 | 0.035 | 12.772 |
| warning-cold | 5 / 5 / 0 | 164.188 | 0.021 | 0.064 | 0.120 | 1.313 | 160.451 | 0.186 | 1.998 | 0.036 | 12.380 |
| warning-edit | 5 / 5 / 0 | 162.135 | 0.022 | 0.071 | 0.102 | 1.502 | 158.501 | 0.180 | 1.727 | 0.029 | 12.581 |
| warning-denied | 0 / 0 / 0 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |

Values are milliseconds summed only across the measured successful responses. Failed native responses retain their original error diagnostics, actual response code and complete client intervals, with emitter detail and outside-emitter residual explicitly unavailable. Their remote durations are null, never zero. Timing text must not alter the daemon's byte-for-byte comparison of failed warm/fresh responses. Missing success detail or unexpected failure decoration fails profiling qualification. Version 1 archives did not collect these records and remain labeled not recorded. The single-unit libtcc span includes its in-process compiler setup, compilation, object write and teardown; nm includes its child process. Rename and both synchronization operations remain unchanged.
