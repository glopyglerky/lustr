# Mixed compiler phase attribution

Instrumented execution of the existing mixed Cargo qualification. This is a separate diagnostic run, not paired speed evidence.

Each cell sums one named phase across the compiler processes for that command, in milliseconds. Spans can nest and crates can run concurrently; columns must not be added into command wall time. Dynamic loading before driver entry and final process teardown are outside these spans. All original records and qualification stdout/stderr/status/trace files remain in this directory.

| Command | Compiler invocations | driver | context-fingerprint | native-compile | native-request-setup | native-daemon-roundtrip | native-symbol-rename | temporary-link-copies | original-linker | edited-native-object-sync | publish-certificate |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| cold | 8 | 129.987 | 0.236 | 21.435 | 0.378 | 18.771 | 0.273 | 0.000 | 0.000 | 0.000 | 0.477 |
| body | 1 | 25.208 | 0.430 | 1.821 | 0.078 | 1.735 | 0.043 | 0.144 | 15.320 | 0.180 | 0.413 |
| arithmetic-edit | 1 | 24.624 | 0.450 | 1.919 | 0.075 | 1.838 | 0.038 | 0.126 | 14.775 | 0.133 | 0.456 |
| invalid | 1 | 19.086 | 0.421 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |
| recovery | 1 | 24.353 | 0.369 | 2.018 | 0.081 | 1.927 | 0.044 | 0.148 | 14.840 | 0.185 | 0.367 |
| link-failure | 1 | 10.694 | 0.395 | 1.946 | 0.087 | 1.851 | 0.037 | 0.154 | 1.908 | 0.164 | 0.000 |
| link-failure-recovery | 1 | 20.773 | 0.362 | 0.000 | 0.000 | 0.000 | 0.000 | 0.161 | 14.338 | 0.000 | 0.374 |
| versioned-object | 1 | 23.224 | 0.350 | 1.653 | 0.078 | 1.567 | 0.038 | 0.142 | 14.415 | 0.160 | 0.413 |
| versioned-object-noop | 1 | 20.507 | 0.343 | 0.000 | 0.000 | 0.000 | 0.000 | 0.147 | 14.164 | 0.000 | 0.449 |
| signature | 2 | 91.946 | 0.527 | 12.434 | 0.215 | 12.205 | 0.158 | 0.000 | 0.000 | 0.000 | 0.450 |
| dependency | 3 | 102.246 | 0.497 | 12.024 | 0.294 | 11.699 | 0.203 | 0.000 | 0.000 | 0.000 | 0.440 |
| macro | 2 | 92.537 | 0.534 | 12.608 | 0.235 | 12.353 | 0.148 | 0.000 | 0.000 | 0.000 | 0.436 |
| warning-cold | 1 | 58.415 | 0.532 | 12.765 | 0.221 | 12.529 | 0.169 | 0.000 | 0.000 | 0.000 | 0.000 |
| warning-edit | 1 | 58.924 | 0.537 | 11.805 | 0.228 | 11.562 | 0.174 | 0.000 | 0.000 | 0.000 | 0.000 |
| warning-denied | 1 | 14.940 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |

The full JSON includes every named phase, per-process success/reuse/check state, exact compiler identities and record hashes. A zero in this table means no recorded duration for that phase. These observations do not isolate a before/after optimization effect or establish a compiler speedup.

## Native emitter durations

These durations come from the daemon response, separately from the driver clock. Each record is bound to its actual client request and successful protocol exchange, checked against that exchange's elapsed time, and matched to the original diagnostic trace. The daemon's sequential phase durations cover its emitter total; they do not partition the enclosing driver span.

Roundtrip outside emitter remains unattributed. It includes protocol transport and queueing, native frontend and generated-code work before the emitter, retained-state work after it, guard handling, and response production. It is not a frontend or codegen measurement. Client request setup is recorded separately; retries and daemon startup can also occupy the enclosing request.

| Command | Responses / measured / unavailable failures | emitter total | c-prepare | output-prepare | c-write | libtcc | symbol-check | rename | file-sync | directory-sync | roundtrip outside emitter |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| cold | 5 / 5 / 0 | 3.094 | 0.019 | 0.084 | 0.133 | 1.187 | 0.054 | 0.042 | 1.546 | 0.030 | 15.660 |
| body | 1 / 1 / 0 | 0.465 | 0.004 | 0.016 | 0.028 | 0.164 | 0.008 | 0.007 | 0.234 | 0.005 | 1.270 |
| arithmetic-edit | 1 / 1 / 0 | 0.469 | 0.003 | 0.015 | 0.027 | 0.162 | 0.008 | 0.007 | 0.242 | 0.004 | 1.369 |
| invalid | 0 / 0 / 0 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |
| recovery | 1 / 1 / 0 | 0.557 | 0.010 | 0.023 | 0.029 | 0.173 | 0.009 | 0.023 | 0.284 | 0.005 | 1.370 |
| link-failure | 1 / 1 / 0 | 0.539 | 0.003 | 0.035 | 0.034 | 0.172 | 0.009 | 0.007 | 0.273 | 0.005 | 1.312 |
| link-failure-recovery | 0 / 0 / 0 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |
| versioned-object | 1 / 1 / 0 | 0.495 | 0.007 | 0.015 | 0.028 | 0.172 | 0.009 | 0.008 | 0.252 | 0.004 | 1.072 |
| versioned-object-noop | 0 / 0 / 0 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |
| signature | 5 / 5 / 0 | 2.303 | 0.015 | 0.056 | 0.097 | 1.102 | 0.041 | 0.032 | 0.943 | 0.016 | 9.902 |
| dependency | 5 / 5 / 0 | 2.029 | 0.014 | 0.056 | 0.087 | 0.844 | 0.040 | 0.048 | 0.923 | 0.016 | 9.670 |
| macro | 5 / 5 / 0 | 2.421 | 0.032 | 0.055 | 0.099 | 1.072 | 0.041 | 0.032 | 1.070 | 0.019 | 9.933 |
| warning-cold | 5 / 5 / 0 | 2.676 | 0.014 | 0.057 | 0.091 | 1.314 | 0.041 | 0.032 | 1.110 | 0.017 | 9.854 |
| warning-edit | 5 / 5 / 0 | 2.188 | 0.014 | 0.056 | 0.089 | 0.818 | 0.041 | 0.031 | 1.121 | 0.017 | 9.375 |
| warning-denied | 0 / 0 / 0 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |

Values are milliseconds summed only across the measured successful responses. Failed native responses retain their original error diagnostics, actual response code and complete client intervals, with emitter detail and outside-emitter residual explicitly unavailable. Their remote durations are null, never zero. Timing text must not alter the daemon's byte-for-byte comparison of failed warm/fresh responses. Missing success detail or unexpected failure decoration fails profiling qualification. Version 1 archives did not collect these records and remain labeled not recorded. The single-unit libtcc span includes its in-process compiler setup, compilation, object write and teardown; symbol-check reads and validates the bounded ELF object in process, with no symbol-tool child. Emitter schema 2 names this operation separately from historical nm spans. Rename and both synchronization operations remain unchanged.
