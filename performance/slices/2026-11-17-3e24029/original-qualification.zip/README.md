# Public upstream slice performance

Status: **completed**.

Pinned public goport-util-small slice, upstream driver, no source edits between samples.

One public pruned/adapted slice; not unchanged full ts-rust, full Rust, fastest Rust setup, resources or release admission.

Times are medians and nearest-rank p95 in milliseconds. Ratio is paired baseline/candidate geometric mean with a conditional bootstrap 95% interval.
Below one favors the reference. These exploratory intervals do not establish equivalence. Twelve-pair p95 is the maximum.

| Scenario | Comparison | Reference median | Candidate median | Reference p95 | Candidate p95 | Ratio [95% interval] |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| cold-check | pristine → integrated | 157.952 | 158.589 | 261.421 | 161.922 | 1.045 [0.992, 1.147] |
| cold-check | pristine → entry | 157.952 | 192.505 | 261.421 | 198.755 | 0.853 [0.810, 0.935] |
| cold-check | cargo → entry | 290.058 | 192.505 | 347.888 | 198.755 | 1.516 [1.475, 1.571] |
| no-op-check | pristine → integrated | 1.565 | 1.587 | 1.747 | 1.814 | 0.993 [0.948, 1.044] |
| no-op-check | pristine → entry | 1.565 | 35.689 | 1.747 | 36.780 | 0.044 [0.043, 0.045] |
| no-op-check | cargo → entry | 10.409 | 35.689 | 10.946 | 36.780 | 0.293 [0.288, 0.298] |
| cold-build | pristine → integrated | 310.660 | 311.700 | 317.637 | 315.834 | 0.998 [0.991, 1.006] |
| cold-build | pristine → entry | 310.660 | 348.570 | 317.637 | 407.842 | 0.882 [0.856, 0.899] |
| cold-build | cargo → entry | 391.988 | 348.570 | 545.081 | 407.842 | 1.153 [1.100, 1.231] |
| no-op-build | pristine → integrated | 4.029 | 3.952 | 4.281 | 4.232 | 1.022 [0.999, 1.047] |
| no-op-build | pristine → entry | 4.029 | 38.231 | 4.281 | 39.230 | 0.106 [0.104, 0.107] |
| no-op-build | cargo → entry | 10.669 | 38.231 | 11.596 | 39.230 | 0.283 [0.278, 0.288] |
| compile-plus-run | pristine → integrated | 5.236 | 5.161 | 5.367 | 5.360 | 1.016 [1.003, 1.030] |
| compile-plus-run | pristine → entry | 5.236 | 39.771 | 5.367 | 41.150 | 0.132 [0.130, 0.133] |
| compile-plus-run | cargo → entry | 11.521 | 39.771 | 12.435 | 41.150 | 0.294 [0.287, 0.302] |
| runtime | pristine → integrated | 1.158 | 1.248 | 1.300 | 1.341 | 0.983 [0.925, 1.046] |
| runtime | pristine → entry | 1.158 | 1.099 | 1.300 | 1.248 | 1.043 [0.977, 1.113] |
| runtime | cargo → entry | 0.800 | 1.099 | 0.941 | 1.248 | 0.742 [0.709, 0.780] |

Application dev opt0/debug0/unwind/overflow+debug assertions; Cargo incremental enabled; native TinyCC dev.

New owned lane directories; native daemon/disk cache disabled; OS caches not flushed.

Retained native daemons versus Cargo Fresh; unchanged source; no body/signature-edit claim.

Command wall time with 100us wait polling; compile-plus-run sums its two child command spans, excluding bookkeeping between them.
