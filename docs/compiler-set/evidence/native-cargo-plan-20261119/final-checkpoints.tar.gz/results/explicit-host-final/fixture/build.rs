fn main() { println!("cargo:rustc-env=BUILD_VALUE=host"); println!("cargo:rustc-env=BUILD_JOBS={}", std::env::var("NUM_JOBS").unwrap()); println!("cargo:rerun-if-env-changed=PLAN_CONTROL"); }
