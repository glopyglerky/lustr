fn main() { println!("{}:{}:{}", env!("BUILD_VALUE"), env!("BUILD_JOBS"), renamed::value()); }
