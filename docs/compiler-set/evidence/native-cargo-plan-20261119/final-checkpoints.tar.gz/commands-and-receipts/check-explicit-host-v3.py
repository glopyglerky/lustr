from pathlib import Path
import hashlib, json, os, subprocess

base = Path('/tmp/lustr-cargo-plan-build')
package = base/'package-v3'
sdk = Path('/workspace/scratch/bf3e8280f86b/tooling/rustup/toolchains/nightly-2026-11-09-x86_64-unknown-linux-gnu')
output = base/'explicit-host-v3'
output.mkdir(exist_ok=False)
project = output/'project'
(project/'src').mkdir(parents=True)
(project/'helper/src').mkdir(parents=True)
files = {
    'Cargo.toml':'[package]\nname="explicit-native-host"\nversion="0.1.0"\nedition="2024"\n[workspace]\nmembers=["helper"]\nresolver="3"\n[dependencies]\nrenamed={package="helper",path="helper"}\n',
    'helper/Cargo.toml':'[package]\nname="helper"\nversion="0.1.0"\nedition="2024"\n',
    'helper/src/lib.rs':'pub fn value()->i32 { 42 }\n',
    'build.rs':'fn main() { println!("cargo:rustc-env=BUILD_VALUE=host"); println!("cargo:rustc-env=BUILD_JOBS={}", std::env::var("NUM_JOBS").unwrap()); println!("cargo:rerun-if-env-changed=PLAN_CONTROL"); }\n',
    'src/main.rs':'fn main() { println!("{}:{}:{}", env!("BUILD_VALUE"), env!("BUILD_JOBS"), renamed::value()); }\n',
}
for name, data in files.items(): (project/name).write_text(data)
for name in ['home','cargo-home']: (output/name).mkdir()
environment = {'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':str(output/'home'),
    'CARGO_HOME':str(output/'cargo-home'),'CARGO_TARGET_DIR':str(output/'oracle-target'),
    'CARGO_BUILD_BUILD_DIR':str(output/'oracle-build'),'CARGO_NET_OFFLINE':'true',
    'CARGO_BUILD_JOBS':'2','LANG':'C','LC_ALL':'C','LUST_NO_DAEMON':'1',
    'LUST_CACHE_DIR':str(output/'native-cache')}
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
report = {'scope':'Actual cold public explicit-package path graph and native host script; no retained or speed claim',
    'package':json.loads((base/'package-v3-identity.json').read_text()),
    'runner_sha256':digest(__file__),'source_sha256':{n:digest(project/n) for n in files},
    'environment':environment,'oracle_sha256':digest(sdk/'bin/rustc'),'commands':[],'passed':False}
def save(): (output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label, argv, env=environment):
    result = subprocess.run(list(map(str,argv)),cwd=project,env=env,capture_output=True,timeout=60)
    (output/(label+'.stdout')).write_bytes(result.stdout)
    (output/(label+'.stderr')).write_bytes(result.stderr)
    report['commands'].append({'label':label,'argv':list(map(str,argv)),'exit':result.returncode,
        'cwd':str(project),'env':env,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),
        'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()}); save()
    assert result.returncode == 0, (label,result.returncode,result.stderr)
    return result
try:
    artifact = project/'native-out'
    for operation in ['check','build']:
        run('candidate-'+operation,[package/'bin/lustr',operation,'src/main.rs','--manifest-path','Cargo.toml',
            '--package','explicit-native-host@0.1.0','--offline','-o',artifact])
    native_hash = digest(artifact)
    actual = run('candidate-program',[artifact])
    assert digest(artifact) == native_hash
    oracle = run('oracle-build',[sdk/'bin/cargo','build','--offline','--package','explicit-native-host@0.1.0',
        '--bin','explicit-native-host','--message-format=json'],dict(environment,RUSTC=str(sdk/'bin/rustc')))
    rows = [json.loads(line) for line in oracle.stdout.splitlines()]
    executables = [row['executable'] for row in rows if row.get('reason')=='compiler-artifact' and row.get('executable') and 'bin' in row.get('target',{}).get('kind',[])]
    assert len(executables)==1
    oracle_hash = digest(executables[0])
    expected = run('oracle-program',[executables[0]])
    assert digest(executables[0]) == oracle_hash
    assert (actual.returncode,actual.stdout,actual.stderr)==(expected.returncode,expected.stdout,expected.stderr)==(0,b'host:2:42\n',b'')
    assert report['source_sha256']=={n:digest(project/n) for n in files}
    report.update(passed=True,native_artifact_sha256=native_hash,oracle_artifact_sha256=oracle_hash)
except Exception as error:
    report['failure']=repr(error)
save()
print(json.dumps({k:report.get(k) for k in ['passed','failure','native_artifact_sha256','oracle_artifact_sha256']},indent=2))
raise SystemExit(0 if report['passed'] else 1)
