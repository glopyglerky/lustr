from pathlib import Path
import hashlib, json, os, shutil, subprocess

base = Path('/tmp/lustr-cargo-plan-build')
root = Path('/tmp/lustr-implementation-20261119')
sdk = Path('/workspace/scratch/bf3e8280f86b/tooling/rustup/toolchains/nightly-2026-11-09-x86_64-unknown-linux-gnu')
tcc = Path('/workspace/scratch/102133405d21/tinycc-codesign-pic-build/install')
package = base / 'package-v3'
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
before = json.loads((base / 'v3-approved-source-inputs-before-build.json').read_text())
assert before == {p:digest(root/p) for p in before}
core = base/'target/debug/lust-core'
identity = subprocess.check_output([str(core), '--lustr-runtime-identity'], text=True)
build = dict(line.split('=',1) for line in identity.splitlines() if '=' in line)['build']
receipts = [p for p in (base/'build/debug/build/lust').glob('*/run/stdout') if f'cargo:rustc-env=LUST_BUILD_HASH={build}\n' in p.read_text()]
assert receipts, build
receipt = receipts[0]
(package/'bin').mkdir(parents=True, exist_ok=False)
(package/'lib/lust').mkdir(parents=True)
for name in ['lust','lust-core']: shutil.copy2(base/'target/debug'/name, package/'bin'/name)
(package/'bin/cargo').symlink_to(sdk/'bin/cargo')
(package/'bin/rustc').symlink_to('lustr')
(package/'lib/lust/library').symlink_to(root/'compiler/native/library')
(package/'lib/lust/tcc').symlink_to(tcc)
(package/'lib/tcc').symlink_to(tcc)
(package/'PARTIAL-NATIVE-COMPILER').write_text('Fresh public entry and native executables from the recorded composed source. No dynamic native library was built. This manually assembled local package is not the guarded constructor or a full Rust compiler.\n')
spec = json.loads((base/'entry-build-v2-command.json').read_text())
spec['env']['LUSTR_LUST_ROOT'] = str(package)
spec['env']['LUSTR_NATIVE_BUILD_OUTPUT'] = str(receipt)
spec['source_inputs'] = before
spec['native_receipt_sha256'] = digest(receipt)
spec['native_binary_sha256'] = {name:digest(package/'bin'/name) for name in ['lust','lust-core']}
spec['base_commit'] = '62da158b33740279947c85f3fc425df6d1623c9f'
(base/'entry-build-v3-command.json').write_text(json.dumps(spec,indent=2)+'\n')
env = os.environ.copy(); env.update(spec['env'])
for key in spec['unset']: env.pop(key,None)
with (base/'entry-build-v3.log').open('wb') as log:
    result = subprocess.run(spec['argv'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
spec['exit'] = result.returncode
(base/'entry-build-v3-command.json').write_text(json.dumps(spec,indent=2)+'\n')
assert result.returncode == 0, 'public entry build failed'
shutil.copy2(base/'entry-target/debug/lustr',package/'bin/lustr')
argv = [str(base/'selection-receipt'),str(package)]
with (base/'package-v3-receipt.stdout').open('wb') as out,(base/'package-v3-receipt.stderr').open('wb') as err:
    result = subprocess.run(argv,stdout=out,stderr=err)
assert result.returncode == 0, 'query receipt failed'
(base/'package-v3-receipt-command.json').write_text(json.dumps({'argv':argv,'exit':result.returncode,
    'helper_sha256':digest(base/'selection-receipt'),
    'helper_source':'tools/selection-toolchain-receipt.rs',
    'helper_source_sha256':digest(root/'tools/selection-toolchain-receipt.rs')},indent=2)+'\n')
assert before == {p:digest(root/p) for p in before}
report = {'scope':'Source-built partial package v3, no dynamic library or guarded constructor',
          'base_commit':'62da158b33740279947c85f3fc425df6d1623c9f',
          'build':build,'source_inputs':before,'native_receipt':str(receipt),
          'native_receipt_sha256':digest(receipt),
          'binary_sha256':{name:digest(package/'bin'/name) for name in ['lustr','lust','lust-core','cargo']},
          'query_receipt_sha256':digest(package/'lib/lustr-selection-tools.txt'),
          'runtime_library_source':{str(p.relative_to(root)):digest(p) for p in (root/'compiler/native/library').rglob('*') if p.is_file()},
          'entry_build_command':'entry-build-v3-command.json',
          'native_build_command':'native-build-command.json',
          'native_build_log':'native-build-v3-approved.log'}
(base/'package-v3-identity.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='runtime_library_source'},indent=2),flush=True)
