#!/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3
import json,os,sys
args=sys.argv[1:]
allowed=args in [['-vV'], ['-', '--crate-name', '___', '--print=file-names', '--crate-type', 'bin', '--crate-type', 'rlib', '--crate-type', 'dylib', '--crate-type', 'cdylib', '--crate-type', 'staticlib', '--crate-type', 'proc-macro', '--print=sysroot', '--print=split-debuginfo', '--print=crate-name', '--print=cfg', '-Wwarnings'], ['-', '--crate-name', '___', '--print=file-names', '--target', 'x86_64-unknown-linux-gnu', '--crate-type', 'bin', '--crate-type', 'rlib', '--crate-type', 'dylib', '--crate-type', 'cdylib', '--crate-type', 'staticlib', '--crate-type', 'proc-macro', '--print=sysroot', '--print=split-debuginfo', '--print=crate-name', '--print=cfg', '-Wwarnings']]
allowed=allowed and ("-" not in args or sys.stdin.buffer.read(1)==b"")
with open('/tmp/lustr-cargo-plan-build/query-spy-cold-v3/compiler-queries.jsonl','a') as f: f.write(json.dumps(dict(argv=args,query_only=allowed,control=os.environ.get('LUSTR_QUERY_CONTROL'))) + '\n')
if not allowed: print("compiler invocation refused by qualification query spy",file=sys.stderr);sys.exit(47)
os.execv('/tmp/lustr-cargo-plan-build/query-spy-cold-v3/query-spy-package/bin/lustr-entry',['lustr',*args])
