from pathlib import Path
import subprocess,os,json,hashlib
base=Path('/tmp/lustr-cargo-plan-build');out=base/'selection-execution-controls';out.mkdir(exist_ok=False);project=out/'project';(project/'src').mkdir(parents=True)
entry=base/'package/bin/lustr';manifest=project/'Cargo.toml';src=project/'src/main.rs';other=project/'src/other.rs';artifact=project/'out';foreign=out/'foreign.rs'
original='[package]\nname="binding-control"\nversion="0.1.0"\nedition="2024"\n[workspace]\n'
manifest.write_text(original);src.write_text('fn main(){println!("42");}\n');foreign.write_text('fn main(){println!("wrong");}\n')
env={'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':str(out/'home'),'CARGO_HOME':str(out/'cargo-home'),'CARGO_NET_OFFLINE':'true','CARGO_TARGET_DIR':str(out/'target'),'CARGO_BUILD_BUILD_DIR':str(out/'build'),'LANG':'C','LC_ALL':'C','LUST_NO_DAEMON':'1','LUST_CACHE_DIR':str(out/'cache')}
Path(env['HOME']).mkdir();Path(env['CARGO_HOME']).mkdir()
report={'package_binaries':{n:hashlib.sha256((base/'package/bin'/n).read_bytes()).hexdigest() for n in ['lustr','lust','lust-core']},'controls':[],'commands':[],'passed':False}
def save():(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def request(label,source,flags=(),operation='build',expect=2,message=None):
 argv=[str(entry),operation,str(source),'--manifest-path',str(manifest),'--offline',*flags,'-o',str(artifact)]
 r=subprocess.run(argv,cwd=project,env=env,capture_output=True,timeout=60)
 (out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr)
 report['commands'].append({'label':label,'argv':argv,'cwd':str(project),'env':env,'exit':r.returncode});save()
 assert r.returncode==expect,(label,r.returncode,r.stderr)
 if message is not None:assert message.encode() in r.stderr,(label,r.stderr)
 report['controls'].append({'label':label,'status':r.returncode});save();return r
try:
 request('initial',src,expect=0);old=artifact.read_bytes()
 other.write_text('compile_error!("unselected body");\n');manifest.write_text(original+'[[bin]]\nname="other"\npath="src/other.rs"\n')
 script=project/'build.rs';script.write_text('fn main(){std::fs::write("must-not-run","bad").unwrap();}\n')
 for label,source,flags in [('wrong-target',src,['--bin','other']),('missing-target',src,['--bin','absent']),('foreign-source',foreign,[])]:
  request(label,source,flags,message='do not identify exactly one Cargo target');assert not(project/'must-not-run').exists();assert artifact.read_bytes()==old
 script.unlink();other.unlink();other.symlink_to('main.rs');request('ambiguous-source',src,message='do not identify exactly one Cargo target');assert artifact.read_bytes()==old
 request('explicit-alias',src,['--bin','other'],expect=0);r=subprocess.run([artifact],capture_output=True);assert(r.returncode,r.stdout,r.stderr)==(0,b'42\n',b'')
 other.unlink();manifest.write_text(original+'[lib]\npath="src/shared.rs"\n');library=project/'src/shared.rs';library.write_text('pub fn value()->i32{7}\nfn main(){}\n')
 request('inferred-library-check',library,operation='check',expect=0)
 request('inferred-library-build',library,message='library artifact')
 library.unlink();manifest.write_text(original);request('recovery',src,expect=0)
 report['passed']=True
except Exception as e:report['failure']=repr(e)
save();print(json.dumps(report['controls'],indent=2));print('passed',report['passed'],report.get('failure'))
