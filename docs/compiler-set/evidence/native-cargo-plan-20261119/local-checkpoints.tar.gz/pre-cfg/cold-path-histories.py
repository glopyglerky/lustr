import hashlib,importlib.util,json,os,shutil,subprocess,sys,time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
ROOT=Path('/tmp/lustr-implementation-20261119'); WORK=Path('/tmp/lustr-cargo-plan-build/cold-path-histories'); PACKAGE=Path('/tmp/lustr-cargo-plan-build/package'); SDK=Path('/workspace/scratch/bf3e8280f86b/tooling/rustup/toolchains/nightly-2026-11-09-x86_64-unknown-linux-gnu')
WORK.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'compiler/native/scripts'))
spec=importlib.util.spec_from_file_location('donor',ROOT/'compiler/native/scripts/test-daemon-scenarios.py');donor=importlib.util.module_from_spec(spec);spec.loader.exec_module(donor)
spec=importlib.util.spec_from_file_location('qualifier','/tmp/lustr-retained-followup/tools/qualify-retained-results.py');qualifier=importlib.util.module_from_spec(spec);spec.loader.exec_module(qualifier)
NAMES=['h9ms_depsig','h9ms_genmacro','h9ms_glob','h9ms_late_shadow','h9ms_late_vec','h9ms_late_vec2','h9ms_late_vec3','h9ms_rename','h9ms_shadow','h9ms_subglob','h9ms_xcrate_names','mb01_dep_macro_body_edits','mb02_main_macro_body_edits']
def run_case(name):
 out=WORK/name;out.mkdir();project=out/'project';project.mkdir();source=ROOT/'compiler/native/tests/daemon'/name
 (out/'home').mkdir();(out/'cargo-home').mkdir()
 env={'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':str(out/'home'),'CARGO_HOME':str(out/'cargo-home'),'CARGO_NET_OFFLINE':'true','CARGO_TARGET_DIR':str(out/'cargo-target'),'CARGO_BUILD_BUILD_DIR':str(out/'cargo-build'),'LANG':'C','LC_ALL':'C','RUST_BACKTRACE':'0','LUST_NO_DAEMON':'1','LUST_CACHE_DIR':str(out/'native-cache')}
 report={'case':name,'scope':'cold public check/build and exact independent Cargo program results; no retained-state or speed qualification','commands':[],'versions':[],'passed':False}
 def save(): (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 def execute(argv,context,role):
  prefix=f'{len(report["commands"]):03d}-{role}';r=subprocess.run(list(map(str,argv)),cwd=project,env=context,capture_output=True,timeout=60)
  (out/(prefix+'.stdout')).write_bytes(r.stdout);(out/(prefix+'.stderr')).write_bytes(r.stderr)
  result={'argv':list(map(str,argv)),'role':role,'cwd':str(project),'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
  report['commands'].append({**{k:v for k,v in result.items() if k not in ('stdout','stderr')},'env':context,'stdout_file':prefix+'.stdout','stderr_file':prefix+'.stderr'});save();return result
 cmd=(source/'cargo').read_text().split();mtime=int(time.time())
 try:
  for version in sorted(p for p in source.iterdir() if p.name.startswith('v') and p.is_dir()):
   mtime=max(mtime+2,int(time.time())+2);new_cmd,changes=donor.apply_overlay(version,project,mtime);cmd=new_cmd or cmd;context={**env,**changes}
   root=cmd[0];flags=['--manifest-path','Cargo.toml',*cmd[1:]]
   checks=execute([PACKAGE/'bin/lustr','check',root,*flags],context,'candidate-check')
   artifact=project/'native-out';artifact.unlink(missing_ok=True)
   built=execute([PACKAGE/'bin/lustr','build',root,*flags,'-o',artifact],context,'candidate-build')
   oracle_env={**context,'RUSTC':str(SDK/'bin/rustc')}
   oracle=execute([SDK/'bin/cargo','build','-q','--offline',*[f for f in cmd[1:] if f!='--offline'],'--message-format=json'],oracle_env,'oracle-build')
   if oracle['exit']==0:
    assert checks['exit']==built['exit']==0,(version.name,checks['exit'],built['exit'],built['stderr'])
    artifacts=[json.loads(line) for line in oracle['stdout'].splitlines() if line]
    targets=[row['executable'] for row in artifacts if row.get('reason')=='compiler-artifact' and row.get('executable') and 'bin' in row.get('target',{}).get('kind',[])]
    assert len(targets)==1,targets
    actual=execute([artifact],context,'candidate-program');expected=execute([targets[0]],context,'oracle-program')
    assert (actual['exit'],actual['stdout'],actual['stderr'])==(expected['exit'],expected['stdout'],expected['stderr']),(version.name,actual,expected)
    report['versions'].append({'version':version.name,'result':'exact-program-match','artifact_sha256':hashlib.sha256(artifact.read_bytes()).hexdigest()})
   else:
    semantic=execute([SDK/'bin/cargo','check','-q','--offline',*[f for f in cmd[1:] if f!='--offline'],'--message-format=json'],oracle_env,'oracle-source-check')
    assert qualifier.source_rejection(semantic,project,cargo=True),(version.name,semantic)
    assert checks['exit']==built['exit']==1 and b'error[L' in checks['stderr'] and b'error[L' in built['stderr'],(version.name,checks,built)
    assert not artifact.exists()
    report['versions'].append({'version':version.name,'result':'source-rejection-match'})
   save()
  report['passed']=True
 except Exception as e: report['failure']=repr(e)
 save();return {'case':name,'passed':report['passed'],'versions':len(report['versions']),'failure':report.get('failure')}
with ThreadPoolExecutor(max_workers=2) as pool:
 results=list(pool.map(run_case,NAMES))
(WORK/'summary.json').write_text(json.dumps({'binary_sha256':{n:hashlib.sha256((PACKAGE/'bin'/n).read_bytes()).hexdigest() for n in ['lustr','lust','lust-core']},'results':results},indent=2)+'\n')
print(json.dumps(results,indent=2))
