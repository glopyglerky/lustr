//! Cargo-planned host scripts compiled by the ordinary native pipeline.
//!
//! The planner supplies the original host unit, not a probe result. Only this
//! module owns its compile/run attempt. Daemon routing never executes scripts.
//! Old Cargo/rustc replay records are deliberately not accepted here.
use super::*;
use crate::driver::{Cmd, Preparation, Request, Session, SessionKey};
use crate::resolve::cargo::BuildScriptUnit;
use std::collections::BTreeMap;
use std::fs::OpenOptions;
use std::io::Write;
use std::process::{Command, Stdio};
use std::sync::Arc;

const MAGIC: &str = "LBS-native-1\n";

fn plan_key(plan: &BuildScriptUnit) -> u64 {
    let mut h = FxHasher::default();
    MAGIC.hash(&mut h);
    plan.hash(&mut h);
    // The native compiler reads its own process settings. User variables read
    // by the script at run time are tracked separately, against ClientEnv.
    static COMPILER: std::sync::OnceLock<u64> = std::sync::OnceLock::new();
    COMPILER.get_or_init(|| {
        let mut h = FxHasher::default();
        crate::driver::cache::compiler_id().hash(&mut h);
        let mut settings: Vec<_> = std::env::vars().filter(|(k, _)| k.starts_with("LUST_")).collect();
        settings.sort(); settings.hash(&mut h); h.finish()
    }).hash(&mut h);
    h.finish()
}

fn env_value(value: Option<&str>) -> String {
    value.map_or_else(|| "N".to_string(), |v| format!("S{v}"))
}

fn compile_env(plan: &BuildScriptUnit, client: ClientEnv) -> Result<Vec<(String, String)>, String> {
    let mut env: BTreeMap<_, _> = client.map_or_else(|| std::env::vars().collect(), |e| e.iter().cloned().collect());
    env.extend(plan.cargo_env.iter().cloned());
    let executable = std::env::current_exe().map_err(|e| format!("cannot locate native toolchain: {e}"))?;
    env.insert("RUSTC".into(), executable.with_file_name("rustc").to_string_lossy().into_owned());
    env.insert("CARGO".into(), executable.with_file_name("cargo").to_string_lossy().into_owned());
    Ok(env.into_iter().collect())
}

fn runtime_env(plan: &BuildScriptUnit, client: ClientEnv, out_dir: &Path) -> Result<Vec<(String, String)>, String> {
    if client_var(client, "CARGO_BUILD_JOBS").is_some_and(|v| !v.is_empty()) {
        return Err("native build-script integration does not yet represent custom Cargo job counts".into());
    }
    if client_var(client, "CARGO_MAKEFLAGS").is_some_and(|v| !v.is_empty()) {
        return Err("native build-script integration does not yet transfer a client jobserver".into());
    }
    let mut env: BTreeMap<_, _> = client.map_or_else(|| std::env::vars().collect(), |e| e.iter().cloned().collect());
    // Cargo adds crate/bin names only to the compiler command. At script run
    // time a caller's versions (and inactive cfg/feature entries) stay inherited.
    env.extend(plan.cargo_env.iter().filter(|(name, _)| !matches!(name.as_str(), "CARGO_CRATE_NAME" | "CARGO_BIN_NAME")).cloned());
    let target = if plan.target_triple.is_empty() { crate::protocol::host_triple() } else { &plan.target_triple };
    let cfg = crate::resolve::cfg::CfgEnv::new(target, &[], false, plan.target_profile);
    for flag in cfg.flags {
        env.insert(format!("CARGO_CFG_{}", flag.to_uppercase()), String::new());
    }
    let mut pairs: BTreeMap<String, Vec<String>> = BTreeMap::new();
    for (key, value) in cfg.pairs { pairs.entry(key).or_default().push(value); }
    for (key, mut values) in pairs {
        values.sort(); values.dedup();
        env.insert(format!("CARGO_CFG_{}", key.to_uppercase()), values.join(","));
    }
    for feature in &plan.target_features {
        env.insert(format!("CARGO_FEATURE_{}", feature.replace('-', "_").to_uppercase()), "1".into());
    }
    let mut features = plan.target_features.clone(); features.sort(); features.dedup();
    env.insert("CARGO_CFG_FEATURE".into(), features.join(","));
    let executable = std::env::current_exe().map_err(|e| format!("cannot locate native toolchain: {e}"))?;
    let compiler = executable.with_file_name("rustc");
    let cargo = executable.with_file_name("cargo");
    if !compiler.is_file() || !cargo.is_file() {
        return Err("native build-script integration needs the installed Lustr compiler and Cargo entries".into());
    }
    env.extend([
        ("HOST".into(), crate::protocol::host_triple().into()),
        ("TARGET".into(), target.into()),
        ("OUT_DIR".into(), out_dir.to_string_lossy().into_owned()),
        ("OPT_LEVEL".into(), plan.target_opt_level.clone()),
        ("PROFILE".into(), "debug".into()),
        ("DEBUG".into(), plan.target_debug.to_string()),
        ("NUM_JOBS".into(), std::thread::available_parallelism().map_or(1, usize::from).to_string()),
        ("RUSTC".into(), compiler.to_string_lossy().into_owned()),
        ("CARGO".into(), cargo.to_string_lossy().into_owned()),
        ("CARGO_ENCODED_RUSTFLAGS".into(), String::new()),
    ]);
    Ok(env.into_iter().collect())
}

fn read_record(path: &Path) -> Option<Record> {
    let text = std::fs::read_to_string(path).ok()?;
    let body = text.strip_prefix(MAGIC)?;
    let record = Record::decode(&format!("LBS5\n{body}"))?;
    (record.rustc.is_none() && record.compile.is_some()).then_some(record)
}

fn write_record(path: &Path, record: &Record) -> Result<(), String> {
    let encoded = record.encode();
    let mut bytes = MAGIC.as_bytes().to_vec();
    bytes.extend_from_slice(encoded.strip_prefix(b"LBS5\n").expect("record format"));
    let temporary = temporary_path(path, "record");
    let mut created = false;
    let result = (|| -> std::io::Result<()> {
        let mut file = OpenOptions::new().write(true).create_new(true).open(&temporary)?;
        created = true;
        file.write_all(&bytes)?;
        file.sync_all()?;
        std::fs::rename(&temporary, path)
    })();
    if result.is_err() && created { let _ = std::fs::remove_file(&temporary); }
    result.map_err(|e| format!("cannot publish native build-script record: {e}"))
}

fn temporary_path(path: &Path, kind: &str) -> PathBuf {
    static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
    let sequence = NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
    path.with_extension(format!("{kind}-{}-{sequence}.pending", std::process::id()))
}

/// Unlike the legacy recorder, an unreadable or missing output is not an empty
/// successful generation. Symlink outputs require a separate represented input
/// contract; following one here could escape the leased output directory.
fn checked_output_hash(output: &BuildOutput, directory: &Path) -> Result<u64, String> {
    let mut paths = vec![directory.to_path_buf()];
    let mut files = Vec::new();
    while let Some(path) = paths.pop() {
        let metadata = std::fs::symlink_metadata(&path).map_err(|e| format!("cannot inspect build-script output {}: {e}", path.display()))?;
        if metadata.file_type().is_symlink() {
            return Err("native build-script integration does not yet represent symlink outputs".into());
        }
        if metadata.is_dir() {
            for entry in std::fs::read_dir(&path).map_err(|e| format!("cannot read build-script output directory: {e}"))? {
                paths.push(entry.map_err(|e| format!("cannot read build-script output entry: {e}"))?.path());
            }
        } else if metadata.is_file() {
            let bytes = std::fs::read(&path).map_err(|e| format!("cannot read build-script output {}: {e}", path.display()))?;
            files.push((path, bytes));
        } else {
            return Err("native build-script integration requires ordinary output files".into());
        }
    }
    files.sort_by(|left, right| left.0.cmp(&right.0));
    let mut cfg = output.rustc_cfg.clone(); cfg.sort();
    let mut check_cfg = output.rustc_check_cfg.clone(); check_cfg.sort();
    let mut env = output.rustc_env.clone(); env.sort();
    let mut parts = vec![b"native-outputs-v1".to_vec(), format!("{cfg:?}{check_cfg:?}{env:?}").into_bytes()];
    for (path, bytes) in files {
        parts.push(path.to_string_lossy().as_bytes().to_vec());
        parts.push(bytes);
    }
    Ok(hash_parts(&parts.iter().map(Vec::as_slice).collect::<Vec<_>>()))
}

fn source_holds(record: &Record) -> bool {
    !record.sources.is_empty() && record.sources.iter().all(|(path, hash)| path.is_file() && file_hash(path) == *hash)
}

fn compile_holds(record: &Record, plan: &BuildScriptUnit, key: u64, binary: &Path, env: &[(String, String)]) -> bool {
    record.script == plan.script && record.setup == key && source_holds(record)
        && record.compile.as_ref().is_some_and(|c| {
            c.cwd == plan.manifest_dir && c.argv == ["native-v1".to_string(), binary.to_string_lossy().into_owned()]
                && binary.is_file() && file_hash(binary) == c.bin
                && c.vars.iter().all(|(name, value)| *value == env_value(env.iter().find(|(k, _)| k == name).map(|(_, v)| v.as_str())))
        })
}

fn run_holds(record: &Record, cache: &Path, client: ClientEnv, directory: &Path) -> bool {
    record.env_inputs.iter().all(|(name, value)| client_var(client, name) == *value)
        && record.inputs.iter().all(|input| input.hash == if input.package { package_hash(&input.path, cache) } else { path_hash(&input.path) })
        && record.out_dir.as_deref() == Some(directory)
        && checked_output_hash(&record.output, directory).is_ok_and(|hash| hash == record.output_hash)
}

fn compile_script(plan: &BuildScriptUnit, directory: &Path, binary: &Path, env: Vec<(String, String)>) -> Result<(Compile, Vec<(PathBuf, u64)>), String> {
    for tool in ["RUSTC", "CARGO"] {
        if !env.iter().any(|(name, value)| name == tool && Path::new(value).is_file()) {
            return Err("native build-script compilation needs the installed Lustr tool entries".into());
        }
    }
    let original = std::fs::read_to_string(&plan.script).map_err(|e| format!("cannot read build script: {e}"))?;
    let mut key = SessionKey::synthetic(&plan.script, false);
    key.krate.package_id = format!("native-host:{}", plan.package_id);
    key.krate.target_name = plan.crate_name.clone();
    key.krate.target_explicit = true;
    key.features = plan.features.clone();
    key.target_triple = crate::protocol::host_triple().into();
    key.profile = plan.host_profile;
    let temporary = temporary_path(binary, "host");
    let request = Request {
        cmd: Cmd::Build, session: key.clone(), file: plan.script.clone(), out: temporary.clone(),
        json: false, timings: false, debug: false, emit_c: None, max_errors: 0,
        run_args: None, harness: false, cc: false,
        client: crate::protocol::Client { env: Some(env.clone()), shown: Some(plan.script.strip_prefix(&plan.workspace_root).unwrap_or(&plan.script).to_path_buf()) },
    };
    let mut session = Session::new(directory.join("native-state"), false, key);
    let response = match crate::driver::prepare(&request, &mut session) {
        Preparation::Ready(prepared) => {
            if !prepared.source().starts_with(&original) {
                return Err("build-script source changed while native preparation read it".into());
            }
            prepared.emit()
        }
        Preparation::Complete(response) | Preparation::Rejected(response)
        | Preparation::Failed(response) | Preparation::IntegrationIncomplete(response) => response,
    };
    if response.code != 0 || response.ran || !temporary.is_file() {
        let _ = std::fs::remove_file(&temporary);
        return Err(format!("native build-script compilation failed: {}", response.stderr));
    }
    let observed = (|| -> Result<(Vec<(PathBuf, u64)>, Vec<(String, String)>), String> {
        if std::fs::read_to_string(&plan.script).ok().as_deref() != Some(original.as_str()) {
            return Err("build-script source changed during native compilation".into());
        }
        let mut sources = BTreeMap::from([(plan.script.clone(), hash_parts(&[original.as_bytes()]))]);
        let map = &session.front.map;
        for id in 0..map.file_count() {
            let id = crate::diag::FileId(id as u32);
            let path = PathBuf::from(map.path(id));
            if path == plan.script { continue; }
            let text = std::fs::read_to_string(&path).map_err(|e| format!("cannot bind native build-script source {}: {e}", path.display()))?;
            if crate::diag::text_hash(&text) != map.text_hash(id) { return Err("build-script source changed during native compilation".into()); }
            sources.insert(path, hash_parts(&[text.as_bytes()]));
        }
        let mut reads = BTreeMap::new();
        for chunk in &session.front.chunks {
            if crate::expand::deps_stale(&chunk.expand_deps, &session.front.client) {
                return Err("build-script expansion input changed during native compilation".into());
            }
            for dep in &chunk.expand_deps {
                match dep {
                    crate::expand::Dep::File { path, hash } => {
                        let bytes = std::fs::read(path).map_err(|e| format!("cannot bind build-script expansion input: {e}"))?;
                        let mut observed = FxHasher::default(); bytes.hash(&mut observed);
                        if observed.finish() != *hash { return Err("build-script expansion input changed during native compilation".into()); }
                        sources.insert(path.clone(), hash_parts(&[&bytes]));
                    }
                    crate::expand::Dep::Env { name, value } => { reads.insert(name.clone(), env_value(value.as_deref())); }
                    _ => {}
                }
            }
        }
        Ok((sources.into_iter().collect(), reads.into_iter().collect()))
    })();
    let (sources, vars) = match observed {
        Ok(reads) => reads,
        Err(error) => { let _ = std::fs::remove_file(&temporary); return Err(error); }
    };
    std::fs::rename(&temporary, binary).map_err(|e| format!("cannot publish native build-script executable: {e}"))?;
    Ok((Compile { cwd: plan.manifest_dir.clone(), vars, argv: vec!["native-v1".into(), binary.to_string_lossy().into_owned()], bin: file_hash(binary) }, sources))
}

fn directives(bytes: &[u8]) -> Result<BuildOutput, String> {
    let mut text = String::new();
    for raw in bytes.split(|b| *b == b'\n') {
        let line = match std::str::from_utf8(raw) {
            Ok(line) => line.trim(),
            Err(_) => {
                let raw = raw.trim_ascii_start();
                if raw.starts_with(b"cargo:") { return Err("non-UTF8 native build-script directive".into()); }
                continue;
            }
        };
        let Some(rest) = line.strip_prefix("cargo:") else { continue };
        let rest = rest.strip_prefix(':').unwrap_or(rest);
        let Some((key, value)) = rest.split_once('=') else { return Err("malformed build-script directive".into()); };
        if !matches!(key, "rerun-if-changed" | "rerun-if-env-changed" | "rustc-cfg" | "rustc-check-cfg" | "rustc-env") {
            return Err(format!("native build-script integration does not yet represent `{key}`"));
        }
        if value.contains('\0') || (key == "rustc-env" && value.split_once('=').is_none_or(|(name, _)| name.is_empty())) {
            return Err("malformed build-script directive value".into());
        }
        text.push_str(line); text.push('\n');
    }
    let mut output = parse_output(&text);
    // Command environments use the final assignment to each name. Do not let
    // reordering duplicate directives keep an old effective output hash.
    output.rustc_env = output.rustc_env.into_iter().collect::<BTreeMap<_, _>>().into_iter().collect();
    Ok(output)
}

fn unchanged_since(input: &Input, cache: &Path, start: std::time::SystemTime) -> Result<(), String> {
    let mut paths = vec![input.path.clone()];
    while let Some(path) = paths.pop() {
        if input.package && path != input.path {
            let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("");
            if matches!(name, ".git" | ".hg" | ".svn") || name.starts_with(".lust") || path == cache
                || path.is_dir() && (path.join("CACHEDIR.TAG").exists() || path.join("Cargo.toml").exists()) { continue; }
        }
        let metadata = match std::fs::symlink_metadata(&path) {
            Ok(metadata) => metadata,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                let ancestor = path.ancestors().skip(1).find(|p| p.exists()).ok_or("build-script input has no observable parent")?;
                std::fs::metadata(ancestor).map_err(|e| format!("cannot inspect missing build-script input: {e}"))?
            }
            Err(error) => return Err(format!("cannot inspect build-script input {}: {error}", path.display())),
        };
        if metadata.modified().map_err(|e| format!("cannot bind build-script input time: {e}"))? >= start {
            return Err(format!("build-script input changed during execution: {}", path.display()));
        }
        if metadata.file_type().is_symlink() {
            return Err("native build-script integration does not yet represent symlink runtime inputs".into());
        }
        if path.is_dir() {
            for entry in std::fs::read_dir(&path).map_err(|e| format!("cannot inspect build-script input directory: {e}"))? {
                paths.push(entry.map_err(|e| format!("cannot inspect build-script input entry: {e}"))?.path());
            }
        }
    }
    Ok(())
}

fn run_script(plan: &BuildScriptUnit, binary: &Path, directory: &Path, client: ClientEnv) -> Result<BuildOutput, String> {
    std::fs::create_dir_all(directory).map_err(|e| format!("cannot create native build-script OUT_DIR: {e}"))?;
    let env = runtime_env(plan, client, directory)?;
    execute(binary, &plan.manifest_dir, env)
}

fn execute(binary: &Path, cwd: &Path, env: Vec<(String, String)>) -> Result<BuildOutput, String> {
    let result = Command::new(binary).current_dir(cwd).env_clear().envs(env)
        .stdin(Stdio::null()).stdout(Stdio::piped()).stderr(Stdio::piped()).output()
        .map_err(|e| format!("cannot execute native build script: {e}"))?;
    if !result.status.success() {
        return Err(format!("native build script failed ({}): {}", result.status, String::from_utf8_lossy(&result.stderr)));
    }
    directives(&result.stdout)
}

/// The caller retains the returned lease in its checked native continuation.
/// Compilation, execution and record publication each have one terminal outcome;
/// a failure never falls back, retries, or exposes an old successful generation.
pub fn outputs(plan: &BuildScriptUnit, cache: &Path, request: &Request) -> Result<Option<Outputs>, String> {
    outputs_with(plan, cache, request, compile_script, run_script)
}

fn outputs_with<C, R>(plan: &BuildScriptUnit, cache: &Path, request: &Request, compile: C, run: R) -> Result<Option<Outputs>, String>
where
    C: FnOnce(&BuildScriptUnit, &Path, &Path, Vec<(String, String)>) -> Result<(Compile, Vec<(PathBuf, u64)>), String>,
    R: FnOnce(&BuildScriptUnit, &Path, &Path, ClientEnv) -> Result<BuildOutput, String>,
{
    if plan.edition != "2024" || plan.crate_name != "build_script_build" {
        return Err("native build-script integration requires the planned edition-2024 host unit".into());
    }
    if crate::protocol::source_override().is_some() {
        return Err("native build-script retained records require the pinned compiler library sources".into());
    }
    let key = plan_key(plan);
    let directory = cache.join(format!("native-buildscript-{key:016x}"));
    std::fs::create_dir_all(&directory).map_err(|e| format!("cannot create native build-script state: {e}"))?;
    let lock = OpenOptions::new().read(true).write(true).create(true).truncate(false).open(directory.join("lock"))
        .map_err(|e| format!("cannot open native build-script lease: {e}"))?;
    lock.lock().map_err(|e| format!("cannot acquire native build-script lease: {e}"))?;
    let lease = Arc::new(lock);
    let path = cache.join(format!("buildscript-native-{key:016x}.txt"));
    let binary = directory.join("build-script");
    let out_dir = directory.join("out");
    let client = request.client.env.as_deref();
    let env = compile_env(plan, client)?;
    let previous = read_record(&path).filter(|r| compile_holds(r, plan, key, &binary, &env));
    let record = if let Some(record) = previous.as_ref().filter(|r| run_holds(r, cache, client, &out_dir)) {
        return Ok(Some(Outputs { out_dir: record.out_dir.clone(), rustc_cfg: record.output.rustc_cfg.clone(),
            rustc_check_cfg: record.output.rustc_check_cfg.clone(), rustc_env: record.output.rustc_env.clone(), lease: Some(lease) }));
    } else {
        let (compile, sources) = if let Some(record) = previous {
            (record.compile.expect("validated native compile record"), record.sources)
        } else {
            compile(plan, &directory, &binary, env)?
        };
        let started = std::time::SystemTime::now();
        let output = run(plan, &binary, &out_dir, client)?;
        let mut inputs: Vec<_> = output.rerun_if_changed.iter().map(|p| {
            let path = if Path::new(p).is_absolute() { PathBuf::from(p) } else { plan.manifest_dir.join(p) };
            Input { package: false, hash: path_hash(&path), path }
        }).collect();
        if output.rerun_if_changed.is_empty() && output.rerun_if_env_changed.is_empty() {
            inputs.push(Input { package: true, path: plan.manifest_dir.clone(), hash: package_hash(&plan.manifest_dir, cache) });
        }
        inputs.extend(setup_files(&plan.manifest_dir, client).into_iter().map(|path| Input { package: false, hash: path_hash(&path), path }));
        for input in &inputs { unchanged_since(input, cache, started)?; }
        let mut env_inputs: Vec<_> = output.rerun_if_env_changed.iter().map(|name| (name.clone(), client_var(client, name))).collect();
        env_inputs.sort(); env_inputs.dedup();
        let record = Record { script: plan.script.clone(), sources, inputs, env_inputs, rustc: None, setup: key,
            output_hash: checked_output_hash(&output, &out_dir)?, out_dir: Some(out_dir), output, compile: Some(compile) };
        if !source_holds(&record) { return Err("native build-script source changed before output publication".into()); }
        write_record(&path, &record)?;
        record
    };
    Ok(Some(Outputs { out_dir: record.out_dir, rustc_cfg: record.output.rustc_cfg,
        rustc_check_cfg: record.output.rustc_check_cfg, rustc_env: record.output.rustc_env, lease: Some(lease) }))
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::cell::Cell;

    struct Fixture { root: PathBuf, plan: BuildScriptUnit, request: Request, compiled: Cell<usize>, ran: Cell<usize> }
    impl Fixture {
        fn new() -> Self {
            static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
            let id = NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            let root = std::env::temp_dir().join(format!("lustr-host-record-{}-{id}", std::process::id()));
            std::fs::create_dir(&root).unwrap();
            let script = root.join("build.rs");
            std::fs::write(&script, "fn main() {}\n").unwrap();
            std::fs::write(root.join("Cargo.toml"), "[package]\nname='host-control'\nversion='0.1.0'\nedition='2024'\n").unwrap();
            let plan = BuildScriptUnit { script: script.clone(), manifest_dir: root.clone(), workspace_root: root.clone(),
                package_id: "host-control@0.1.0".into(), crate_name: "build_script_build".into(), edition: "2024".into(),
                features: Vec::new(), host_profile: crate::protocol::ProfileFlags::DEV_UNWIND, target_triple: String::new(),
                target_profile: crate::protocol::ProfileFlags::DEV_UNWIND, target_features: Vec::new(), target_opt_level: "0".into(),
                target_debug: true, cargo_env: Vec::new(), planning_key: 1 };
            let request = Request { cmd: Cmd::Build, session: SessionKey::synthetic(&script, false), file: script, out: root.join("consumer"),
                json: false, timings: false, debug: false, emit_c: None, max_errors: 0, run_args: None, harness: false, cc: false,
                client: crate::protocol::Client { env: Some(Vec::new()), shown: None } };
            Self { root, plan, request, compiled: Cell::new(0), ran: Cell::new(0) }
        }
        fn cache(&self) -> PathBuf { self.root.join(".lust-cache") }
        fn record(&self) -> PathBuf { self.cache().join(format!("buildscript-native-{:016x}.txt", plan_key(&self.plan))) }
        // Synthetic boundary controls exercise the same record/attempt owner.
        // The public retained campaign separately compiles the real build.rs.
        fn compile(&self, plan: &BuildScriptUnit, _: &Path, binary: &Path, _: Vec<(String, String)>) -> Result<(Compile, Vec<(PathBuf, u64)>), String> {
            self.compiled.set(self.compiled.get() + 1);
            std::fs::write(binary, "native compiler control artifact").unwrap();
            Ok((Compile { cwd: plan.manifest_dir.clone(), argv: vec!["native-v1".into(), binary.to_string_lossy().into_owned()],
                vars: Vec::new(), bin: file_hash(binary) }, vec![(plan.script.clone(), file_hash(&plan.script))]))
        }
        fn run(&self, _: &BuildScriptUnit, _: &Path, directory: &Path, env: ClientEnv) -> Result<BuildOutput, String> {
            self.ran.set(self.ran.get() + 1);
            std::fs::create_dir_all(directory).unwrap();
            Ok(BuildOutput { rerun_if_env_changed: vec!["INPUT".into()], rustc_env: vec![("OBSERVED".into(), client_var(env, "INPUT").unwrap_or_else(|| "unset".into()))], ..Default::default() })
        }
        fn outputs(&self) -> Result<Outputs, String> {
            outputs_with(&self.plan, &self.cache(), &self.request, |p,d,b,e| self.compile(p,d,b,e), |p,b,d,e| self.run(p,b,d,e))
                .map(|out| out.unwrap())
        }
    }
    impl Drop for Fixture { fn drop(&mut self) { let _ = std::fs::remove_dir_all(&self.root); } }

    #[test]
    fn unchanged_records_do_no_compile_or_run_and_client_values_remain_distinct() {
        let mut fixture = Fixture::new();
        assert_eq!(fixture.outputs().unwrap().rustc_env, [("OBSERVED".into(), "unset".into())]);
        drop(fixture.outputs().unwrap());
        assert_eq!((fixture.compiled.get(), fixture.ran.get()), (1, 1));
        fixture.request.client.env = Some(vec![("LUSTR_TRACE_PATH".into(), "another-request.trace".into()), ("UNREAD".into(), "changed".into())]);
        drop(fixture.outputs().unwrap());
        assert_eq!((fixture.compiled.get(), fixture.ran.get()), (1, 1));
        fixture.request.client.env = Some(vec![("INPUT".into(), String::new())]);
        assert_eq!(fixture.outputs().unwrap().rustc_env, [("OBSERVED".into(), String::new())]);
        fixture.request.client.env = Some(vec![("INPUT".into(), "a".into())]);
        assert_eq!(fixture.outputs().unwrap().rustc_env, [("OBSERVED".into(), "a".into())]);
        assert_eq!((fixture.compiled.get(), fixture.ran.get()), (1, 3));
    }

    #[test]
    fn actual_compile_environment_reads_invalidate_without_unread_environment_noise() {
        let mut fixture = Fixture::new();
        let run = |fixture: &Fixture| {
            outputs_with(&fixture.plan, &fixture.cache(), &fixture.request, |p,d,b,env| {
                let read = env_value(env.iter().find(|(name, _)| name == "COMPILE_READ").map(|(_, value)| value.as_str()));
                let (mut compiled, sources) = fixture.compile(p,d,b,env)?;
                compiled.vars.push(("COMPILE_READ".into(), read));
                Ok((compiled, sources))
            }, |p,b,d,env| fixture.run(p,b,d,env))
        };
        drop(run(&fixture).unwrap());
        fixture.request.client.env = Some(vec![("LUSTR_TRACE_PATH".into(), "next.trace".into()), ("UNREAD".into(), "changed".into())]);
        drop(run(&fixture).unwrap());
        assert_eq!((fixture.compiled.get(), fixture.ran.get()), (1, 1));
        fixture.request.client.env = Some(vec![("COMPILE_READ".into(), String::new())]);
        drop(run(&fixture).unwrap());
        assert_eq!((fixture.compiled.get(), fixture.ran.get()), (2, 2));
    }

    #[test]
    fn unrepresented_jobserver_and_custom_job_counts_are_terminal_boundaries() {
        let fixture = Fixture::new();
        for (name, value, reason) in [("CARGO_MAKEFLAGS", "--jobserver-auth=3,4", "jobserver"), ("CARGO_BUILD_JOBS", "2", "job counts")] {
            let env = vec![(name.to_string(), value.to_string())];
            assert!(matches!(runtime_env(&fixture.plan, Some(&env), &fixture.root), Err(error) if error.contains(reason)));
        }
    }

    #[test]
    fn failed_run_has_one_attempt_and_keeps_prior_record_for_proven_recovery() {
        let mut fixture = Fixture::new();
        drop(fixture.outputs().unwrap());
        let before = std::fs::read(fixture.record()).unwrap();
        fixture.request.client.env = Some(vec![("INPUT".into(), "changed".into())]);
        let result = outputs_with(&fixture.plan, &fixture.cache(), &fixture.request,
            |_,_,_,_| panic!("runtime input change recompiled the script"),
            |_,_,_,_| { fixture.ran.set(fixture.ran.get() + 1); Err("original script failure".into()) });
        assert!(matches!(result, Err(error) if error == "original script failure"));
        assert_eq!(fixture.ran.get(), 2);
        assert_eq!(std::fs::read(fixture.record()).unwrap(), before);
        fixture.request.client.env = Some(Vec::new());
        drop(fixture.outputs().unwrap());
        assert_eq!((fixture.compiled.get(), fixture.ran.get()), (1, 2));
    }

    #[test]
    fn changed_source_cannot_be_rebound_to_old_compilation_after_a_run() {
        let fixture = Fixture::new();
        let result = outputs_with(&fixture.plan, &fixture.cache(), &fixture.request,
            |p,d,b,e| fixture.compile(p,d,b,e),
            |p,b,d,e| { let output = fixture.run(p,b,d,e)?; std::fs::write(&p.script, "fn main() { changed(); }\n").unwrap(); Ok(output) });
        assert!(matches!(result, Err(error) if error.contains("source changed")));
        assert!(!fixture.record().exists());
        assert_eq!((fixture.compiled.get(), fixture.ran.get()), (1, 1));
    }

    #[test]
    fn publication_failure_never_creates_a_success_record_or_retries() {
        let fixture = Fixture::new();
        std::fs::create_dir_all(fixture.record()).unwrap();
        let result = fixture.outputs();
        assert!(matches!(result, Err(error) if error.contains("cannot publish")));
        assert!(fixture.record().is_dir());
        assert_eq!((fixture.compiled.get(), fixture.ran.get()), (1, 1));
    }

    #[test]
    fn generated_output_lease_survives_clones_until_the_last_consumer_drops() {
        let fixture = Fixture::new();
        let output = fixture.outputs().unwrap();
        let clone = output.clone();
        let lock = OpenOptions::new().read(true).write(true).open(output.out_dir.as_ref().unwrap().parent().unwrap().join("lock")).unwrap();
        assert!(lock.try_lock().is_err());
        drop(output);
        assert!(lock.try_lock().is_err());
        drop(clone);
        lock.try_lock().unwrap();
    }

    #[test]
    fn malformed_or_unrepresented_directives_and_missing_outputs_fail_closed() {
        for stdout in [b"cargo::rustc-env=X=\xff".as_slice(), b"cargo::rustc-link-lib=missing", b"cargo::error=failed", b"cargo::rustc-env=NAME", b"cargo::rustc-cfg=a\0b"] {
            assert!(directives(stdout).is_err(), "{stdout:?}");
        }
        assert_eq!(directives(b"cargo::rustc-env=X=old\ncargo::rustc-env=X=new\n").unwrap().rustc_env, [("X".into(), "new".into())]);
        let fixture = Fixture::new();
        assert!(checked_output_hash(&BuildOutput::default(), &fixture.root.join("missing")).is_err());
        let old = Record { script: fixture.plan.script.clone(), sources: Vec::new(), inputs: Vec::new(), env_inputs: Vec::new(), rustc: None,
            setup: 0, output_hash: 0, out_dir: None, output: BuildOutput::default(), compile: None };
        let path = fixture.root.join("legacy"); std::fs::write(&path, old.encode()).unwrap();
        assert!(read_record(&path).is_none());
    }

    #[test]
    fn a_real_failed_script_executes_once_and_uses_only_the_supplied_environment() {
        use std::os::unix::fs::PermissionsExt;
        let fixture = Fixture::new();
        let script = fixture.root.join("script");
        std::fs::write(&script, "#!/bin/sh\nprintf 'x' >> count\nprintf '%s' \"${INPUT-unset}\" > observed\nexit 7\n").unwrap();
        std::fs::set_permissions(&script, std::fs::Permissions::from_mode(0o700)).unwrap();
        let result = execute(&script, &fixture.root, vec![("INPUT".into(), "request-value".into())]);
        assert!(matches!(result, Err(error) if error.contains("native build script failed")));
        assert_eq!(std::fs::read(fixture.root.join("count")).unwrap(), b"x");
        assert_eq!(std::fs::read(fixture.root.join("observed")).unwrap(), b"request-value");
    }
}
