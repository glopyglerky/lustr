#!/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3
import json,os,sys
args=sys.argv[1:]
allowed=args==["-vV"] or any(a=="--print" or a.startswith("--print=") for a in args)
with open('/tmp/lustr-cargo-plan-build/query-spy-cold-v2/compiler-queries.jsonl','a') as f: f.write(json.dumps(dict(argv=args,query_only=allowed))+'\n')
if not allowed: print("compiler invocation refused by qualification query spy",file=sys.stderr);sys.exit(47)
os.execv('/tmp/lustr-cargo-plan-build/query-spy-cold-v2/query-spy-package/bin/lustr-entry',['lustr',*args])
