#![no_std]
pub fn transform(value: u64) -> u64 { helper(value) ^ 85u64 }
fn helper(value: u64) -> u64 { value & 255u64 }
pub fn combine(left: u64, right: u64) -> u64 { left | right }
