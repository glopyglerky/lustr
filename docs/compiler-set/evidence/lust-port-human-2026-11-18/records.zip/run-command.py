#!/usr/bin/env python3
"""Bound a qualification command and retain its exact status and output."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument("--log", required=True)
p.add_argument("--cwd", required=True)
p.add_argument("--timeout", type=int, required=True)
p.add_argument("--set", action="append", default=[])
p.add_argument("--unset", action="append", default=[])
p.add_argument("command", nargs=argparse.REMAINDER)
a = p.parse_args()
assert a.command[0] == "--" and len(a.command) > 1
command = a.command[1:]
log = Path(a.log)
log.mkdir(parents=True, exist_ok=False)
env = os.environ.copy()
for name in a.unset:
    env.pop(name, None)
overrides = dict(item.split("=", 1) for item in a.set)
env.update(overrides)
record = {
    "argv": command, "cwd": str(Path(a.cwd).resolve()),
    "environment_overrides": overrides, "environment_removed": a.unset,
    "timeout_seconds": a.timeout, "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
}
(log / "command.json").write_text(json.dumps(record, indent=2) + "\n")
started = time.monotonic()
with (log / "stdout").open("xb") as out, (log / "stderr").open("xb") as err:
    child = subprocess.Popen(command, cwd=a.cwd, env=env, stdout=out, stderr=err, start_new_session=True)
    try:
        code = child.wait(timeout=a.timeout)
        timed_out = False
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(child.pid, signal.SIGKILL)
        code = child.wait()
status = {
    "returncode": code, "timed_out": timed_out, "wall_seconds": time.monotonic() - started,
    "finished_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "stdout_sha256": hashlib.sha256((log / "stdout").read_bytes()).hexdigest(),
    "stderr_sha256": hashlib.sha256((log / "stderr").read_bytes()).hexdigest(),
}
(log / "status.json").write_text(json.dumps(status, indent=2) + "\n")
print(json.dumps({"log": str(log), **status}), flush=True)
raise SystemExit(124 if timed_out else code if code >= 0 else 128 - code)
