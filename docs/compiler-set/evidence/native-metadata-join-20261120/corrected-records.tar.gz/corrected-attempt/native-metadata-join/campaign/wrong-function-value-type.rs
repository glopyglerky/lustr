fn main() { let _: fn(u32)->u64 = consumer::transform; }
