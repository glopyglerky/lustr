#![no_std]
pub fn invoke(value:u64)->u64 { consumer::transform(value) }
