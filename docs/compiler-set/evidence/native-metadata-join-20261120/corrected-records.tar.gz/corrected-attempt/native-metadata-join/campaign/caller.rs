fn main() {
    let transform: fn(u64) -> u64 = consumer::transform;
    let combine: fn(u64, u64) -> u64 = consumer::combine;
    for value in (0u64..65536).chain([u64::MAX, 1u64 << 63]) {
        assert_eq!(consumer::transform(value), (value & 255) ^ 85);
        assert_eq!(transform(value), (value & 255) ^ 85);
        assert_eq!(consumer::combine(value, 0x101), value | 0x101);
        assert_eq!(combine(value, 0x101), value | 0x101);
    }
    println!("rust-metadata-results=262152");
}
