fn main() { let _ = consumer::combine(1); }
