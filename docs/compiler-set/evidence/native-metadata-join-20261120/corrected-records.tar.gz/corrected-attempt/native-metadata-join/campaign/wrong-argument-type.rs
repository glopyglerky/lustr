fn main() { let _ = consumer::transform(true); }
