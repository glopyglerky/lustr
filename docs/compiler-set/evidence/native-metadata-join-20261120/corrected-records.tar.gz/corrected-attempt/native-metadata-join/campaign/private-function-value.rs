fn main() { let _: fn(u64)->u64 = consumer::helper; }
