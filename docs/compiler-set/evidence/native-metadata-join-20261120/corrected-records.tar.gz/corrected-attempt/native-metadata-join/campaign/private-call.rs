fn main() { let _ = consumer::helper(1); }
