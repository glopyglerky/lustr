fn main() { println!("cargo::rustc-cfg=mode=bare"); }
