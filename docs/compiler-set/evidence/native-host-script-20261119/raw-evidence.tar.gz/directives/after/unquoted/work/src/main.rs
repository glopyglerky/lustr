fn main() { println!("{}", cfg!(mode="bare")); }
