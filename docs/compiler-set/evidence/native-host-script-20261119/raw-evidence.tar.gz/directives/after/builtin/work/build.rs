fn main() { println!("cargo::rustc-cfg=target_os=\"other\""); }
