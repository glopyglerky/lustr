fn main() { println!("{}", cfg!(mode="a\nb")); }
