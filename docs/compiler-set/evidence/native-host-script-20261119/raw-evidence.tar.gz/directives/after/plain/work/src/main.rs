fn main() { println!("{}", cfg!(mode="a=b")); }
