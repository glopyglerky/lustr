fn main() { println!("cargo::rustc-cfg=mode=\"a=b\""); }
