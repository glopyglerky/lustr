fn main() { println!("cargo::rustc-cfg=abc xyz"); }
