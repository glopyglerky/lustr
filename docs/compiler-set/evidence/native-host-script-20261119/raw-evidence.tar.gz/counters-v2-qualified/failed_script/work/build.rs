fn main() {
    let out = std::env::var("OUT_DIR").unwrap();
    let path = format!("{out}/count");
    let old = std::fs::read_to_string(&path).unwrap_or_else(|_| String::new());
    let next = format!("{old}x");
    std::fs::write(&path, &next).unwrap();
    std::process::exit(7);
    println!("cargo::rustc-env=HOST_COUNT={next}");
}
