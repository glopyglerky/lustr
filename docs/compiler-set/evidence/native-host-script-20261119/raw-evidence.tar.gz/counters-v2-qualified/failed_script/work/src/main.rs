fn main() { println!("{}", counter_root::value()); }
