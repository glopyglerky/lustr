pub fn value() -> &'static str { env!("HOST_COUNT") }
