pub fn value() -> &'static str { shared::value() }
