fn main() { println!("{} {}", left::value(), right::value()); }
