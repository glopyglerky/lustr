#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import subprocess
import sys

package = Path(sys.argv[1]).resolve()
root = Path(sys.argv[2]).resolve()
phase = sys.argv[3]
assert phase in ('before', 'after')
root.mkdir(parents=True, exist_ok=False)
sdk = Path('/workspace/scratch/bf3e8280f86b/tooling/rustup/toolchains/nightly-2026-11-09-x86_64-unknown-linux-gnu')
entry = package / 'bin/lustr'
report = {'phase': phase, 'package': str(package), 'lustr_sha256': hashlib.sha256(entry.read_bytes()).hexdigest(), 'cases': []}


def save():
    (root / 'report.json').write_text(json.dumps(report, indent=2) + '\n')


def call(case, base, args, work, env):
    index = len(case['commands'])
    row = {'argv': list(map(str, args)), 'cwd': str(work), 'env': env}
    case['commands'].append(row)
    save()
    result = subprocess.run(row['argv'], cwd=work, env=env, capture_output=True, timeout=180)
    row['exit'] = result.returncode
    (base / f'{index:02d}.stdout').write_bytes(result.stdout)
    (base / f'{index:02d}.stderr').write_bytes(result.stderr)
    save()
    return result


for name, directive, main in [
    ('malformed', 'cargo::rustc-cfg=abc xyz', 'fn main() { println!("ran"); }\n'),
    ('unquoted', 'cargo::rustc-cfg=mode=bare', 'fn main() { println!("{}", cfg!(mode="bare")); }\n'),
    ('escaped', 'cargo::rustc-cfg=mode="a\\nb"', 'fn main() { println!("{}", cfg!(mode="a\\nb")); }\n'),
    ('builtin', 'cargo::rustc-cfg=target_os="other"', 'fn main() { println!("ran"); }\n'),
    ('plain', 'cargo::rustc-cfg=mode="a=b"', 'fn main() { println!("{}", cfg!(mode="a=b")); }\n'),
]:
    base = root / name
    work = base / 'work'
    (work / 'src').mkdir(parents=True)
    (work / 'Cargo.toml').write_text('[package]\nname="cfg_control"\nversion="0.1.0"\nedition="2024"\n')
    (work / 'build.rs').write_text('fn main() { println!(' + json.dumps(directive) + '); }\n')
    (work / 'src/main.rs').write_text(main)
    case = {'name': name, 'directive': directive, 'source_sha256': {f: hashlib.sha256((work / f).read_bytes()).hexdigest() for f in ['Cargo.toml', 'build.rs', 'src/main.rs']}, 'commands': []}
    report['cases'].append(case)
    env = {'PATH': '/usr/bin:/bin', 'HOME': str(base / 'home'), 'CARGO_HOME': str(base / 'cargo-home'),
           'CARGO_NET_OFFLINE': 'true', 'CARGO_TARGET_DIR': str(base / 'target'), 'CARGO_BUILD_BUILD_DIR': str(base / 'intermediates'),
           'LUST_NO_DAEMON': '1', 'LUST_CACHE_DIR': str(base / 'cache')}
    try:
        native = call(case, base, [entry, 'build', 'src/main.rs', '--manifest-path', 'Cargo.toml', '--bin', 'cfg_control', '--offline', '-o', base / 'native-program'], work, env)
        if native.returncode == 0:
            actual = call(case, base, [base / 'native-program'], work, env)
            case['native_runtime'] = {'exit': actual.returncode, 'stdout': actual.stdout.decode(), 'stderr': actual.stderr.decode()}
        oracle_env = dict(env, PATH=str(sdk / 'bin') + ':/usr/bin:/bin', RUSTC=str(sdk / 'bin/rustc'),
                          CARGO_TARGET_DIR=str(base / 'oracle-target'), CARGO_BUILD_BUILD_DIR=str(base / 'oracle-intermediates'))
        oracle = call(case, base, [sdk / 'bin/cargo', 'build', '--offline', '--message-format=json'], work, oracle_env)
        if oracle.returncode == 0:
            rows = [json.loads(line) for line in oracle.stdout.splitlines() if line.strip()]
            binaries = [row['executable'] for row in rows if row.get('reason') == 'compiler-artifact' and row.get('executable')]
            assert len(binaries) == 1
            expected = call(case, base, binaries, work, oracle_env)
            case['rust_runtime'] = {'exit': expected.returncode, 'stdout': expected.stdout.decode(), 'stderr': expected.stderr.decode()}
        if name == 'plain':
            assert native.returncode == oracle.returncode == 0
            assert case['native_runtime'] == case['rust_runtime'] == {'exit': 0, 'stdout': 'true\n', 'stderr': ''}
        elif phase == 'before':
            assert native.returncode == 0
            if name == 'escaped':
                assert oracle.returncode == 0 and case['native_runtime']['stdout'] == 'false\n' and case['rust_runtime']['stdout'] == 'true\n'
            else:
                assert oracle.returncode == 101
        else:
            assert native.returncode != 0 and b'does not yet represent' in native.stderr, native.stderr.decode(errors='replace')
            assert not (base / 'native-program').exists()
            assert oracle.returncode == (0 if name == 'escaped' else 101)
        case['observed_expected_boundary'] = True
        print(name, phase, 'observed expected result', flush=True)
    except Exception as error:
        case.update(observed_expected_boundary=False, failure=repr(error))
        print(name, phase, 'FAILED', repr(error), flush=True)
    save()
assert all(case['observed_expected_boundary'] for case in report['cases'])
