#!/usr/bin/env python3
"""Bounded cold public qualification; the unchanged donor applies all overlays."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

SOURCE = Path('/tmp/lustr-buildscript-20261119')
SDK = Path('/workspace/scratch/bf3e8280f86b/tooling/rustup/toolchains/nightly-2026-11-09-x86_64-unknown-linux-gnu')
PACKAGE = Path(sys.argv[1]).resolve()
ROOT = Path(sys.argv[2]).resolve()
ROOT.mkdir(parents=True, exist_ok=False)
ENTRY = PACKAGE / 'bin/lustr'
scripts = SOURCE / 'compiler/native/scripts'
sys.path.insert(0, str(scripts))
spec = importlib.util.spec_from_file_location('donor', scripts / 'test-daemon-scenarios.py')
donor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(donor)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


report = {
    'scope': 'cold public check/build and separate executable comparison; no retained daemon qualification',
    'package': str(PACKAGE),
    'binaries': {name: digest(PACKAGE / 'bin' / name) for name in ['lustr', 'lust', 'lust-core', 'rustc', 'cargo']},
    'rustc_sha256': digest(SDK / 'bin/rustc'),
    'cargo_sha256': digest(SDK / 'bin/cargo'),
    'donor_loader_sha256': digest(scripts / 'test-daemon-scenarios.py'),
    'histories': [],
}


def save():
    (ROOT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')


def environment(base):
    return {
        'PATH': '/usr/local/bin:/usr/bin:/bin',
        'HOME': str(base / 'home'),
        'CARGO_HOME': str(base / 'cargo-home'),
        'CARGO_NET_OFFLINE': 'true',
        'CARGO_BUILD_JOBS': '2',
        'CARGO_TARGET_DIR': str(base / 'native-target'),
        'CARGO_BUILD_BUILD_DIR': str(base / 'native-intermediates'),
        'LUST_NO_DAEMON': '1',
        'LUST_CACHE_DIR': str(base / 'native-cache'),
        'LANG': 'C', 'LC_ALL': 'C',
    }


def execute(base, rows, name, argv, cwd, env, timeout=180):
    prefix = base / f'{len(rows):03d}-{name}'
    call_env = dict(env)
    if str(argv[0]) == str(ENTRY):
        call_env['LUSTR_TRACE_PATH'] = str(prefix.with_suffix('.trace.jsonl'))
    row = {'name': name, 'argv': list(map(str, argv)), 'cwd': str(cwd), 'env': call_env}
    rows.append(row)
    save()
    started = time.monotonic()
    try:
        result = subprocess.run(row['argv'], cwd=cwd, env=call_env, capture_output=True, timeout=timeout)
        row.update(exit=result.returncode, duration_s=time.monotonic() - started)
        prefix.with_suffix('.stdout').write_bytes(result.stdout)
        prefix.with_suffix('.stderr').write_bytes(result.stderr)
        row.update(stdout_sha256=hashlib.sha256(result.stdout).hexdigest(), stderr_sha256=hashlib.sha256(result.stderr).hexdigest())
        if str(argv[0]) == str(ENTRY):
            trace = prefix.with_suffix('.trace.jsonl')
            row['trace'] = [json.loads(line) for line in trace.read_text().splitlines()]
            expected_engine = 'lust' if result.returncode == 0 else 'lust-failed'
            assert len(row['trace']) == 1 and row['trace'][0]['engine'] == expected_engine and row['trace'][0]['entry'] == 'upstream-process', row
        save()
        return result
    except Exception as error:
        row['failure'] = repr(error)
        save()
        raise


for name in ['cargo10_bs_env_rerun', 'cargo12_dep_bs_env']:
    base = ROOT / name
    work = base / 'work'
    work.mkdir(parents=True)
    fixture = SOURCE / 'compiler/native/tests/daemon' / name
    history = {'name': name, 'daemon_only_environment_not_exercised': donor.daemon_env(str(fixture)), 'commands': [], 'versions': []}
    report['histories'].append(history)
    native_env = environment(base)
    cmd = (fixture / 'cargo').read_text().split()
    stamp = int(time.time())
    try:
        for version in sorted(path for path in fixture.iterdir() if path.is_dir() and path.name.startswith('v')):
            stamp = max(stamp + 2, int(time.time()) + 2)
            replacement, variables = donor.apply_overlay(str(version), str(work), stamp)
            cmd = replacement or cmd
            env = dict(native_env, **variables)
            flags = ['--manifest-path', 'Cargo.toml', *cmd[1:]]
            check = execute(base, history['commands'], version.name + '-native-check', [ENTRY, 'check', cmd[0], *flags], work, env)
            assert check.returncode == 0, check.stderr.decode(errors='replace')
            binary = base / (version.name + '-native')
            build = execute(base, history['commands'], version.name + '-native-build', [ENTRY, 'build', cmd[0], *flags, '-o', binary], work, env)
            assert build.returncode == 0 and binary.is_file(), build.stderr.decode(errors='replace')
            actual = execute(base, history['commands'], version.name + '-native-program', [binary], work, env, 15)
            oracle_env = dict(env, PATH=str(SDK / 'bin') + ':/usr/bin:/bin', RUSTC=str(SDK / 'bin/rustc'),
                              CARGO_TARGET_DIR=str(base / 'rust-target'), CARGO_BUILD_BUILD_DIR=str(base / 'rust-intermediates'))
            oracle_env.pop('LUST_NO_DAEMON')
            oracle_env.pop('LUST_CACHE_DIR')
            selected = [flag for flag in cmd[1:] if flag != '--offline']
            oracle_build = execute(base, history['commands'], version.name + '-cargo-build',
                                   [SDK / 'bin/cargo', 'build', '--offline', '--message-format=json', *selected], work, oracle_env)
            assert oracle_build.returncode == 0, oracle_build.stderr.decode(errors='replace')
            artifacts = [json.loads(line) for line in oracle_build.stdout.splitlines() if line.strip()]
            binaries = [Path(row['executable']) for row in artifacts if row.get('reason') == 'compiler-artifact' and row.get('executable') and 'bin' in row.get('target', {}).get('kind', [])]
            assert len(binaries) == 1
            expected = execute(base, history['commands'], version.name + '-rust-program', [binaries[0]], work, oracle_env, 15)
            assert (actual.returncode, actual.stdout, actual.stderr) == (expected.returncode, expected.stdout, expected.stderr)
            compiled_scripts = list((base / 'native-cache').glob('native-buildscript-*/build-script'))
            assert len(compiled_scripts) == 1, compiled_scripts
            script = compiled_scripts[0]
            host = {'path': str(script), 'sha256': digest(script), 'mtime_ns': script.stat().st_mtime_ns, 'inode': script.stat().st_ino}
            if history['versions']:
                assert host == history['versions'][0]['host_executable'], 'runtime environment change recompiled the unchanged host unit'
            history['versions'].append({'version': version.name, 'passed': True, 'stdout': actual.stdout.decode(), 'exit': actual.returncode,
                                        'native_artifact_sha256': digest(binary), 'rust_artifact_sha256': digest(binaries[0]), 'host_executable': host})
            save()
            print(name, version.name, 'passed', repr(actual.stdout), flush=True)
        history['passed'] = True
    except Exception as error:
        history['passed'] = False
        history['failure'] = repr(error)
        save()
        print(name, 'FAILED', repr(error), flush=True)
save()
assert all(history.get('passed') for history in report['histories'])
