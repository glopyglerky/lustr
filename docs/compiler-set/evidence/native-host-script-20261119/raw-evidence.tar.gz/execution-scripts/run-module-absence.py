#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import subprocess
import sys

package = Path(sys.argv[1]).resolve()
root = Path(sys.argv[2]).resolve()
root.mkdir(parents=True, exist_ok=False)
work = root / 'work'
(work / 'src').mkdir(parents=True)
(work / 'Cargo.toml').write_text('[package]\nname="absence_control"\nversion="0.1.0"\nedition="2024"\n')
(work / 'build.rs').write_text('mod helper;\nfn main() { println!("cargo::rerun-if-env-changed=CONTROL"); println!("cargo::rustc-env=VALUE={}", helper::value()); }\n')
(work / 'helper.rs').write_text('pub fn value() -> &\'static str { "original" }\n')
(work / 'src/main.rs').write_text('fn main() { println!("{}", env!("VALUE")); }\n')
entry = package / 'bin/lustr'
sdk = Path('/workspace/scratch/bf3e8280f86b/tooling/rustup/toolchains/nightly-2026-11-09-x86_64-unknown-linux-gnu')
env = {'PATH': '/usr/bin:/bin', 'HOME': str(root / 'home'), 'CARGO_HOME': str(root / 'cargo-home'),
       'CARGO_NET_OFFLINE': 'true', 'CARGO_BUILD_JOBS': '2', 'CARGO_TARGET_DIR': str(root / 'target'),
       'CARGO_BUILD_BUILD_DIR': str(root / 'intermediates'), 'LUST_NO_DAEMON': '1', 'LUST_CACHE_DIR': str(root / 'cache')}
report = {'package': str(package), 'lustr_sha256': hashlib.sha256(entry.read_bytes()).hexdigest(), 'commands': []}


def save():
    (root / 'report.json').write_text(json.dumps(report, indent=2) + '\n')


def run(argv, environment):
    index = len(report['commands'])
    row = {'argv': list(map(str, argv)), 'cwd': str(work), 'env': dict(environment)}
    report['commands'].append(row)
    save()
    result = subprocess.run(row['argv'], cwd=work, env=environment, capture_output=True, timeout=180)
    row['exit'] = result.returncode
    (root / f'{index:02d}.stdout').write_bytes(result.stdout)
    (root / f'{index:02d}.stderr').write_bytes(result.stderr)
    save()
    return result


def build(label):
    return run([entry, 'build', 'src/main.rs', '--manifest-path', 'Cargo.toml', '--bin', 'absence_control', '--offline', '-o', root / label], env)


try:
    first = build('before')
    assert first.returncode == 0, first.stderr.decode(errors='replace')
    actual = run([root / 'before'], env)
    assert (actual.returncode, actual.stdout, actual.stderr) == (0, b'original\n', b'')
    records = list((root / 'cache').glob('buildscript-native-*.txt'))
    assert len(records) == 1 and 'absent ' in records[0].read_text()
    saved = records[0].read_bytes()
    (work / 'helper').mkdir()
    alternative = work / 'helper/mod.rs'
    alternative.write_text('pub fn value() -> &\'static str { "other" }\n')
    rejected = build('ambiguous')
    assert rejected.returncode != 0 and b'L0502' in rejected.stderr, rejected.stderr.decode(errors='replace')
    assert not (root / 'ambiguous').exists()
    assert records[0].read_bytes() == saved, 'failed native host check replaced successful record'
    oracle_env = dict(env, PATH=str(sdk / 'bin') + ':/usr/bin:/bin', RUSTC=str(sdk / 'bin/rustc'),
                      CARGO_TARGET_DIR=str(root / 'oracle-target'), CARGO_BUILD_BUILD_DIR=str(root / 'oracle-intermediates'))
    oracle = run([sdk / 'bin/cargo', 'build', '--offline', '--message-format=json'], oracle_env)
    assert oracle.returncode == 101 and b'E0761' in oracle.stdout
    alternative.unlink()
    recovered = build('recovered')
    assert recovered.returncode == 0, recovered.stderr.decode(errors='replace')
    actual = run([root / 'recovered'], env)
    assert (actual.returncode, actual.stdout, actual.stderr) == (0, b'original\n', b'')
    report['passed'] = True
except Exception as error:
    report.update(passed=False, failure=repr(error))
    raise
finally:
    save()
print('native negative module input and recovery passed', flush=True)
