#!/usr/bin/env python3
"""Two exact-source timestamp regressions; cold partial package, no speed claim."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/tmp/lustr-host-timestamp-review-v3')
PACKAGE = Path('/tmp/lustr-cargo-plan-build/package-v3')
SDK = Path('/workspace/scratch/bf3e8280f86b/tooling/rustup/toolchains/nightly-2026-11-09-x86_64-unknown-linux-gnu')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def binary_identity():
    return {str(p): sha(p) for p in [
        PACKAGE / 'bin/lustr', PACKAGE / 'bin/lust',
        PACKAGE / 'bin/lust-core', SDK / 'bin/cargo', SDK / 'bin/rustc',
    ]}


def host_identity(cache):
    paths = list(cache.glob('native-buildscript-*/build-script'))
    assert len(paths) == 1, paths
    p = paths[0]
    s = p.stat()
    return {'path': str(p), 'sha256': sha(p), 'mtime_ns': s.st_mtime_ns,
            'inode': s.st_ino, 'size': s.st_size}


def run_case(label, source, watched, binary):
    root = ROOT / label
    work = root / 'project'
    (work / 'src').mkdir(parents=True)
    files = ['Cargo.toml', 'build.rs', 'src/main.rs']
    if watched != 'build.rs':
        files.append(watched)
    for rel in files:
        shutil.copy2(source / rel, work / rel)
    source_hashes = {rel: sha(work / rel) for rel in files}
    original_hashes = {rel: sha(source / rel) for rel in files}
    assert source_hashes == original_hashes
    env = {
        'PATH': '/usr/bin:/bin', 'HOME': str(root / 'home'),
        'CARGO_HOME': str(root / 'cargo-home'), 'CARGO_NET_OFFLINE': 'true',
        'CARGO_BUILD_JOBS': '2', 'CARGO_TARGET_DIR': str(root / 'native-target'),
        'CARGO_BUILD_BUILD_DIR': str(root / 'native-intermediates'),
        'LUST_NO_DAEMON': '1', 'LUST_CACHE_DIR': str(root / 'native-cache'),
    }
    oracle_env = dict(env, PATH=f'{SDK}/bin:/usr/bin:/bin', RUSTC=str(SDK / 'bin/rustc'),
                      CARGO_TARGET_DIR=str(root / 'oracle-target'),
                      CARGO_BUILD_BUILD_DIR=str(root / 'oracle-intermediates'))
    commands = []
    def run(name, argv, command_env):
        result = subprocess.run([str(v) for v in argv], cwd=work, env=command_env,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                timeout=60)
        (root / (name + '.stdout')).write_bytes(result.stdout)
        (root / (name + '.stderr')).write_bytes(result.stderr)
        commands.append({'name': name, 'argv': [str(v) for v in argv], 'cwd': str(work),
                         'env': command_env, 'exit': result.returncode,
                         'stdout_file': name + '.stdout', 'stderr_file': name + '.stderr'})
        dump(root / 'commands.json', commands)
        assert result.returncode == 0, (label, name, result.returncode, result.stderr)
        return result

    now = int(time.time())
    stamps = [now - 10, now + 120]
    observed = []
    for phase, stamp in zip(['before', 'after'], stamps):
        os.utime(work / watched, ns=(stamp * 1_000_000_000, stamp * 1_000_000_000))
        phase_env = dict(env, LUSTR_TRACE_PATH=str(root / (phase + '.trace.jsonl')))
        artifact = root / (phase + '-native')
        run(phase + '-native-build', [PACKAGE / 'bin/lustr', 'build', 'src/main.rs',
            '--manifest-path', 'Cargo.toml', '--offline', '-o', artifact], phase_env)
        native = run(phase + '-native-run', [artifact], phase_env)
        run(phase + '-oracle-build', [SDK / 'bin/cargo', 'build', '--offline', '-q'], oracle_env)
        oracle = run(phase + '-oracle-run', [root / 'oracle-target/debug' / binary], oracle_env)
        expected = f'{stamp}\n'.encode()
        assert native.stdout == oracle.stdout == expected, (label, phase, native.stdout, oracle.stdout, expected)
        assert native.stderr == oracle.stderr == b''
        current_hashes = {rel: sha(work / rel) for rel in files}
        assert current_hashes == source_hashes
        records = {}
        for record in sorted((root / 'native-cache').glob('buildscript-native-*.txt')):
            saved = f'{phase}-{record.name}'
            shutil.copy2(record, root / saved)
            records[saved] = sha(record)
        observed.append({'phase': phase, 'watched_mtime_ns': (work / watched).stat().st_mtime_ns,
                         'expected_stdout': expected.decode(), 'native_stdout': native.stdout.decode(),
                         'oracle_stdout': oracle.stdout.decode(),
                         'host_binary': host_identity(root / 'native-cache'),
                         'native_artifact_sha256': sha(artifact), 'records': records})
    reused = observed[0]['host_binary'] == observed[1]['host_binary']
    assert reused, (label, 'host recompiled for timestamp-only change', observed)
    report = {'passed': True, 'scope': 'cold-only partial-package timestamp control; no daemon or speed claim',
              'source_origin': str(source), 'source_hashes': source_hashes, 'unchanged_source_bytes': True,
              'watched': watched, 'commands': len(commands), 'compiled_host_reused': reused,
              'observed': observed}
    dump(root / 'report.json', report)
    return report


ROOT.mkdir(exist_ok=False)
before = binary_identity()
reports = [
    run_case('explicit-input', Path('/tmp/lustr-host-mtime-review-v2/work'), 'watched', 'mtime_review'),
    run_case('implicit-source', Path('/tmp/lustr-host-source-mtime-review-v2/project'), 'build.rs', 'source-mtime-control'),
]
after = binary_identity()
assert before == after
summary = {'passed': all(v['passed'] for v in reports), 'package_unchanged': before == after,
           'tool_sha256': before, 'cases': reports}
dump(ROOT / 'review.json', summary)
print(json.dumps({'passed': summary['passed'], 'package_unchanged': summary['package_unchanged'],
                  'cases': [{'name': Path(r['source_origin']).parent.name,
                             'compiled_host_reused': r['compiled_host_reused'],
                             'outputs': [o['native_stdout'] for o in r['observed']]} for r in reports]}, indent=2))
