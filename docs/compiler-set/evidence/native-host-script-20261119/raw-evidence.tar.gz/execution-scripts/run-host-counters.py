#!/usr/bin/env python3
"""Actual public cold counters for shared host plans and request ownership."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

PACKAGE = Path(sys.argv[1]).resolve()
ROOT = Path(sys.argv[2]).resolve()
ROOT.mkdir(parents=True, exist_ok=False)
SDK = Path('/workspace/scratch/bf3e8280f86b/tooling/rustup/toolchains/nightly-2026-11-09-x86_64-unknown-linux-gnu')
ENTRY = PACKAGE / 'bin/lustr'
REPORT = {'scope': 'cold public request counters, not daemon retention or performance qualification',
          'package': str(PACKAGE), 'lustr_sha256': hashlib.sha256(ENTRY.read_bytes()).hexdigest(), 'cases': []}
SCRIPT = '''fn main() {
    let out = std::env::var("OUT_DIR").unwrap();
    let path = format!("{out}/count");
    let old = std::fs::read_to_string(&path).unwrap_or_else(|_| String::new());
    let next = format!("{old}x");
    std::fs::write(&path, &next).unwrap();
    println!("cargo::rerun-if-env-changed=COUNTER_INPUT");
    println!("cargo::rustc-env=HOST_COUNT={next}");
}
'''


def save():
    (ROOT / 'report.json').write_text(json.dumps(REPORT, indent=2) + '\n')


def write(root, path, text):
    target = root / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)


def env(base):
    return {'PATH': '/usr/local/bin:/usr/bin:/bin', 'HOME': str(base / 'home'), 'CARGO_HOME': str(base / 'cargo-home'),
            'CARGO_NET_OFFLINE': 'true', 'CARGO_BUILD_JOBS': '2', 'CARGO_TARGET_DIR': str(base / 'target'),
            'CARGO_BUILD_BUILD_DIR': str(base / 'intermediates'), 'LUST_NO_DAEMON': '1',
            'LUST_CACHE_DIR': str(base / 'cache'), 'LANG': 'C', 'LC_ALL': 'C'}


def call(case, base, argv, work, environment):
    ident = len(case['commands'])
    row = {'argv': list(map(str, argv)), 'cwd': str(work), 'env': dict(environment)}
    if str(argv[0]) == str(ENTRY):
        row['env']['LUSTR_TRACE_PATH'] = str(base / f'{ident:03d}.trace.jsonl')
    case['commands'].append(row)
    save()
    result = subprocess.run(row['argv'], cwd=work, env=row['env'], capture_output=True, timeout=180)
    (base / f'{ident:03d}.stdout').write_bytes(result.stdout)
    (base / f'{ident:03d}.stderr').write_bytes(result.stderr)
    row['exit'] = result.returncode
    if str(argv[0]) == str(ENTRY):
        row['trace'] = [json.loads(line) for line in Path(row['env']['LUSTR_TRACE_PATH']).read_text().splitlines()]
        expected_engine = 'lust' if result.returncode == 0 else 'lust-failed'
        assert len(row['trace']) == 1 and row['trace'][0]['engine'] == expected_engine and row['trace'][0]['entry'] == 'upstream-process'
    save()
    return result


def host_state(base):
    executables = list((base / 'cache').glob('native-buildscript-*/build-script'))
    assert len(executables) == 1, executables
    binary = executables[0]
    count = binary.parent / 'out/count'
    return {'binary': str(binary), 'binary_mtime_ns': binary.stat().st_mtime_ns,
            'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'count': count.read_text()}


for name in ['same_package', 'diamond', 'failed_script']:
    base = ROOT / name
    work = base / 'work'
    work.mkdir(parents=True)
    case = {'name': name, 'commands': [], 'observations': []}
    REPORT['cases'].append(case)
    package_name = 'counter_root'
    write(work, 'Cargo.toml', '[package]\nname="counter_root"\nversion="0.1.0"\nedition="2024"\n')
    if name == 'diamond':
        with (work / 'Cargo.toml').open('a') as stream:
            stream.write('[dependencies]\nleft={path="left"}\nright={path="right"}\n')
        write(work, 'src/main.rs', 'fn main() { println!("{} {}", left::value(), right::value()); }\n')
        for child in ['left', 'right']:
            write(work, child + '/Cargo.toml', f'[package]\nname="{child}"\nversion="0.1.0"\nedition="2024"\n[dependencies]\nshared={{path="../shared"}}\n')
            write(work, child + '/src/lib.rs', 'pub fn value() -> &\'static str { shared::value() }\n')
        write(work, 'shared/Cargo.toml', '[package]\nname="shared"\nversion="0.1.0"\nedition="2024"\n')
        write(work, 'shared/src/lib.rs', 'pub fn value() -> &\'static str { env!("HOST_COUNT") }\n')
        write(work, 'shared/build.rs', SCRIPT)
    else:
        write(work, 'build.rs', SCRIPT if name != 'failed_script' else SCRIPT.replace('    println!("cargo::rerun-if-env-changed=COUNTER_INPUT");', '    std::process::exit(7);'))
        write(work, 'src/lib.rs', 'pub fn value() -> &\'static str { env!("HOST_COUNT") }\n')
        write(work, 'src/main.rs', 'fn main() { println!("{}", counter_root::value()); }\n')
    environment = env(base)
    try:
        flags = ['src/main.rs', '--manifest-path', 'Cargo.toml', '--bin', package_name, '--offline']
        if name == 'failed_script':
            for index in range(2):
                result = call(case, base, [ENTRY, 'check', *flags], work, environment)
                assert result.returncode != 0 and b'native build script failed' in result.stderr
                state = host_state(base)
                assert state['count'] == 'x' * (index + 1), state
                case['observations'].append(state)
            assert not list((base / 'cache').glob('buildscript-native-*.txt')), 'failed script published a success record'
        else:
            first_binary = None
            for index, (mode, variable, count) in enumerate([('check', None, 'x'), ('build', None, 'x'), ('build', None, 'x'), ('check', 'changed', 'xx'), ('build', 'changed', 'xx')]):
                current_env = dict(environment, UNREAD=f'noise-{index}')
                if variable is not None:
                    current_env['COUNTER_INPUT'] = variable
                binary = base / f'program-{index}'
                argv = [ENTRY, mode, *flags, *(['-o', binary] if mode == 'build' else [])]
                result = call(case, base, argv, work, current_env)
                assert result.returncode == 0, result.stderr.decode(errors='replace')
                state = host_state(base)
                assert state['count'] == count, state
                identity = {key: value for key, value in state.items() if key != 'count'}
                if first_binary is None:
                    first_binary = identity
                assert identity == first_binary, 'run-only input edit recompiled the unchanged script'
                if mode == 'build':
                    executed = call(case, base, [binary], work, current_env)
                    wanted = (count + ' ' + count if name == 'diamond' else count) + '\n'
                    assert (executed.returncode, executed.stdout, executed.stderr) == (0, wanted.encode(), b'')
                case['observations'].append(state)
            # One independent Cargo build establishes the unchanged fixture's
            # initial consumer output. Counter reuse is a native owner control.
            oracle_env = dict(environment, PATH=str(SDK / 'bin') + ':/usr/bin:/bin', RUSTC=str(SDK / 'bin/rustc'),
                              CARGO_TARGET_DIR=str(base / 'oracle-target'), CARGO_BUILD_BUILD_DIR=str(base / 'oracle-intermediates'))
            result = call(case, base, [SDK / 'bin/cargo', 'build', '--offline', '--message-format=json'], work, oracle_env)
            assert result.returncode == 0, result.stderr.decode(errors='replace')
            artifacts = [json.loads(line) for line in result.stdout.splitlines() if line.strip()]
            targets = [row['executable'] for row in artifacts if row.get('reason') == 'compiler-artifact' and row.get('executable')]
            assert len(targets) == 1
            executed = call(case, base, targets, work, oracle_env)
            assert (executed.returncode, executed.stdout, executed.stderr) == (0, b'x x\n' if name == 'diamond' else b'x\n', b'')
        case['passed'] = True
        print(name, 'passed', flush=True)
    except Exception as error:
        case.update(passed=False, failure=repr(error))
        print(name, 'FAILED', repr(error), flush=True)
    save()
assert all(case.get('passed') for case in REPORT['cases'])
