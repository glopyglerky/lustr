from pathlib import Path
import gzip, hashlib, io, json, os, shutil, tarfile

REPO=Path('/tmp/lustr-buildscript-20261119')
DEST=REPO/'docs/compiler-set/evidence/native-host-script-20261119'
DEST.mkdir(parents=True,exist_ok=True)
BUILD=Path('/tmp/lustr-cargo-plan-build')
EXEC=Path('/tmp/lustr-buildscript-execution-review')
origins={}

def sha(data):return hashlib.sha256(data).hexdigest()
def dump(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
def copy(p,name):
 out=DEST/name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,out);origins[name]=str(p)

skip={'cache','native-cache','target','native-target','oracle-target','rust-target','intermediates','native-intermediates','oracle-intermediates','rust-intermediates','oracle-build','cargo-home','home','__pycache__','.git'}
allowed={'.json','.jsonl','.stdout','.stderr','.rs','.toml','.lock','.txt','.py','.log','.scen'}
def selected(root):
 for cur,dirs,files in os.walk(root):
  dirs[:]=sorted(d for d in dirs if d not in skip)
  for f in sorted(files):
   p=Path(cur)/f
   if p.suffix in allowed or p.name in {'watched','cargo'}:
    yield p,p.relative_to(root)

def direct_tree(src,name):
 for p,r in selected(src):copy(p,str(Path(name)/r))
 for cache in ['cache','native-cache']:
  for p in src.rglob(cache+'/buildscript-native-*.txt'):
   copy(p,str(Path(name)/'record-snapshots'/p.relative_to(src)))

for src,dst in [
 (Path('/tmp/lustr-host-mtime-review-v2'),'timestamps/explicit-v2'),
 (Path('/tmp/lustr-host-source-mtime-review-v2'),'timestamps/implicit-v2'),
 (Path('/tmp/lustr-host-timestamp-review-v3'),'timestamps/v3')]:
 direct_tree(src,dst)

for name in [
 'package-v2-identity.json','package-v3-identity.json','entry-build-v2-command.json','entry-build-v3-command.json',
 'native-build-command.json','v2-source-inputs-before-build.json','v3-approved-source-inputs-before-build.json',
 'v3-all-repository-inputs-before-build.json','v2-test-commands.json','v3-approved-host-controls-command.json',
 'native-build-v2.log','native-build-v3-approved.log','test-build-envelope-directives.log','test-build-approved-host.log',
 'v2-host-controls.log','v2-cfg-controls.log','v2-plan-controls.log','v2-selector-wire.log','v3-approved-host-controls.log']:
 copy(BUILD/name,'controls-and-identities/'+name)

owned=['compiler/native/src/driver/buildscript.rs','compiler/native/src/driver/buildscript/native.rs','compiler/native/src/driver/compile.rs','compiler/native/src/daemon.rs','compiler/native/src/resolve/cfg.rs']
dump(DEST/'source-inputs.json',{'base_commit':'62da158b33740279947c85f3fc425df6d1623c9f','required_planner_commit':'683bb8ef','owned_source_sha256':{p:sha((REPO/p).read_bytes()) for p in owned},'package_v3_build':'0390b1143f2d2e93'})

members={}
def add(p,name):
 data=p.read_bytes();assert len(data)<1_000_000,(p,len(data));assert not data.startswith(b'\x7fELF'),p
 assert name not in members,name
 members[name]=(data,str(p),p.stat().st_mtime_ns)
def archive_tree(src,name):
 for p,r in selected(src):add(p,str(Path(name)/r))
 for cache in ['cache','native-cache']:
  for p in src.rglob(cache+'/buildscript-native-*.txt'):
   add(p,str(Path(name)/'record-snapshots'/p.relative_to(src)))

for name in ['history-v2-qualified','counters-v2-qualified','module-absence-v2','history-v2','counters-v2','initial-harness']:
 archive_tree(EXEC/name,name)
for phase in ['before','after']:
 archive_tree(Path('/tmp/lustr-buildscript-directive-review')/phase,'directives/'+phase)
for p in sorted(EXEC.glob('run-*.py')):add(p,'execution-scripts/'+p.name)
add(Path(__file__),'execution-scripts/capture-evidence.py')
for n in ['cargo10_bs_env_rerun','cargo12_dep_bs_env']:
 for p in sorted((REPO/'compiler/native/tests/daemon'/n).rglob('*')):
  if p.is_file():add(p,'unchanged-donor/'+n+'/'+str(p.relative_to(REPO/'compiler/native/tests/daemon'/n)))
add(REPO/'compiler/native/scripts/test-daemon-scenarios.py','unchanged-donor/test-daemon-scenarios.py')

with (DEST/'raw-evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w') as tf:
   for name,(data,origin,mtime) in sorted(members.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644
    tf.addfile(info,io.BytesIO(data))
dump(DEST/'raw-evidence-index.json',{'archive_sha256':sha((DEST/'raw-evidence.tar.gz').read_bytes()),'members':[{'path':n,'sha256':sha(d),'bytes':len(d),'original_path':o,'original_mtime_ns':m} for n,(d,o,m) in sorted(members.items())]})

hist=json.loads((EXEC/'history-v2-qualified/report.json').read_text())
counters=json.loads((EXEC/'counters-v2-qualified/report.json').read_text())
times=json.loads((DEST/'timestamps/v3/review.json').read_text())
directives=json.loads(Path('/tmp/lustr-buildscript-directive-review/after/report.json').read_text())
results={
 'scope':'Bounded native host-script repair. Partial source-built Linux package; cold-only runtime witnesses. No full Rust, daemon-retention, near-stock performance or release qualification.',
 'source_base':'62da158b33740279947c85f3fc425df6d1623c9f',
 'initial_frozen_controls':{'passed':12,'failed':2,'cause':'native record envelope omitted original rerun directive lists; preserved initial-controls logs'},
 'package_v2':{'build':'a5d84827d9e89e28','host_controls':15,'cfg_controls':5,'planner_controls':8,'selector_wire_controls':1,
  'histories':[{'name':h['name'],'passed':h['passed'],'versions':len(h['versions']),'outputs':[v['stdout'] for v in h['versions']],
   'compiled_host_reused':all(v['host_executable']==h['versions'][0]['host_executable'] for v in h['versions']),
   'daemon_only_environment_not_exercised':h['daemon_only_environment_not_exercised']} for h in hist['histories']],
  'counter_cases':[{'name':c['name'],'passed':c['passed']} for c in counters['cases']],
  'module_absence_control_passed':json.loads((EXEC/'module-absence-v2/report.json').read_text())['passed'],
  'directive_after_cases':[{'name':c['name'],'observed_expected_boundary':c['observed_expected_boundary']} for c in directives['cases']]},
 'package_v3':{'build':'0390b1143f2d2e93','host_controls':17,'source_inputs_unchanged_during_build':514,
  'timestamp_controls_passed':times['passed'],'package_unchanged':times['package_unchanged'],
  'timestamp_review_sha256':sha((DEST/'timestamps/v3/review.json').read_bytes()),
  'timestamp_cases':[{'input':c['watched'],'compiled_host_reused':c['compiled_host_reused'],
   'outputs':[o['native_stdout'] for o in c['observed']]} for c in times['cases']],
  'other_final_regressions':'../native-host-review-20261119 records independent empty-directory and missing-marker native/oracle controls'},
 'release_admission':False,
}
dump(DEST/'results.json',results)
dump(DEST/'file-index.json',{'files':[{'path':str(p.relative_to(DEST)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'original_path':origins.get(str(p.relative_to(DEST)))} for p in sorted(DEST.rglob('*')) if p.is_file() and p.name not in {'file-index.json','README.md'}]})
print(json.dumps({'raw_archive_members':len(members),'raw_archive_bytes':(DEST/'raw-evidence.tar.gz').stat().st_size,'direct_files':sum(p.is_file() for p in DEST.rglob('*')),'timestamp_review_sha256':results['package_v3']['timestamp_review_sha256']},indent=2))
