fn main() { println!("{}", env!("VALUE")); }
