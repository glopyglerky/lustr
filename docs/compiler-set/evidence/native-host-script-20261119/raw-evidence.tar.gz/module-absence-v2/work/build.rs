mod helper;
fn main() { println!("cargo::rerun-if-env-changed=CONTROL"); println!("cargo::rustc-env=VALUE={}", helper::value()); }
