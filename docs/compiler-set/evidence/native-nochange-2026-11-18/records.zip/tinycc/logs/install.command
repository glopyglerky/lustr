cd "/workspace/scratch/3ff9b6fc98dd/warm-native-tinycc/source" && "make" "install"
