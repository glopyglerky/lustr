cd "/workspace/scratch/3ff9b6fc98dd/warm-native-tinycc/source" && "./configure" "--prefix=/workspace/scratch/3ff9b6fc98dd/warm-native-tinycc/install" "--extra-cflags=-Wall -O2 -fPIC"
