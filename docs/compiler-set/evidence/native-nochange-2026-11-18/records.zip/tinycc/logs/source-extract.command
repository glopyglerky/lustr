"tar" "-xf" "/workspace/scratch/3ff9b6fc98dd/warm-native-tinycc/source.tar" "--directory" "/workspace/scratch/3ff9b6fc98dd/warm-native-tinycc/source"
