"git" "-C" "/workspace/scratch/3ff9b6fc98dd/warm-tinycc-upstream" "rev-parse" "43c7708b85681a2fd4451c8a541af4494a8919b2^{commit}"
