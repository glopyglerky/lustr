"sha256sum" "/workspace/scratch/3ff9b6fc98dd/warm-native-tinycc/install/bin/tcc" "/workspace/scratch/3ff9b6fc98dd/warm-native-tinycc/install/lib/libtcc.a"
