"git" "-C" "$PRISTINE_TINYCC_CHECKOUT" "archive" "--format=tar" "43c7708b85681a2fd4451c8a541af4494a8919b2" "--output" "$FINAL_TINYCC_BUILD/source.tar"
