"cc" "-shared" "-Wl,--whole-archive" "$FINAL_TINYCC_BUILD/install/lib/libtcc.a" "-Wl,--no-whole-archive" "-ldl" "-lpthread" "-lm" "-o" "$FINAL_TINYCC_BUILD/libtcc-shared-check.so"
