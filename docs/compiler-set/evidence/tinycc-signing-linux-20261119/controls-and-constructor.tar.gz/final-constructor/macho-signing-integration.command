"python3" "$FINAL_TINYCC_BUILD/integration/tools/apply-tinycc-signing.py" "$FINAL_TINYCC_BUILD/source" "--receipt" "$FINAL_TINYCC_BUILD/logs/macho-signing-source.json"
