cd "$FINAL_TINYCC_BUILD/source" && "./configure" "--prefix=$FINAL_TINYCC_BUILD/install" "--extra-cflags=-Wall -O2 -fPIC"
