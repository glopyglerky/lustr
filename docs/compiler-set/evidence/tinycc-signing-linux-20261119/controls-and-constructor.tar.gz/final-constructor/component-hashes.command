"sha256sum" "$FINAL_TINYCC_BUILD/install/bin/tcc" "$FINAL_TINYCC_BUILD/install/lib/libtcc.a"
