cd "$FINAL_TINYCC_BUILD/source" && "make" "--jobs=2"
