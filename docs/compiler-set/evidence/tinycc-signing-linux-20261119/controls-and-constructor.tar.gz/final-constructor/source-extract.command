"tar" "-xf" "$FINAL_TINYCC_BUILD/source.tar" "--directory" "$FINAL_TINYCC_BUILD/source"
