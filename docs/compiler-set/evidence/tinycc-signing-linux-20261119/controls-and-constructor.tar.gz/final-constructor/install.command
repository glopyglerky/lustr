cd "$FINAL_TINYCC_BUILD/source" && "make" "install"
