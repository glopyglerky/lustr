#[path = r#"$REPOSITORY/compiler/native/src/tcc.rs"#]
mod tcc;

mod pool {
    pub fn threads() -> usize { panic!("one-unit publication control must not start workers") }
    pub fn stop() { panic!("publication control must not run a program in memory") }
}
#[link(name = "tcc", kind = "static")]
unsafe extern "C" {}
fn main() {
    let args: Vec<_> = std::env::args_os().collect();
    let source = std::path::PathBuf::from(&args[1]);
    let object = std::path::PathBuf::from(&args[2]);
    let output = std::path::PathBuf::from(&args[3]);
    tcc::compile_units(&[(object.clone(), std::fs::read_to_string(source).unwrap())], false).unwrap();
    let result = if args[4] == "shared" {
        tcc::link_shared(&[object], &output, false, Some("signing-control"))
    } else { tcc::link(&[object], &output, false) };
    match result {
        Ok(()) => println!("native-output-published"),
        Err(error) => { eprintln!("native-link-error-returned: {error}"); std::process::exit(17); }
    }
}
