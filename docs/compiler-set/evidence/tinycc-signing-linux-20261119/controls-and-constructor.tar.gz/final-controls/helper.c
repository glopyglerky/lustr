
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>
#include <sys/wait.h>
typedef int TCCState;
static TCCState test_state;
static void test_enter_state(TCCState *s1) { if (s1 != &test_state) abort(); }
static int errors, wait_calls;
static int test_error(const char *format, ...) {
    va_list args; va_start(args, format); vfprintf(stderr, format, args); va_end(args);
    fputc('\n', stderr); ++errors; return -1;
}
static pid_t observed_waitpid(pid_t pid, int *status, int options) {
    pid_t result;
    ++wait_calls;
    if (WAIT_MODE == 1 && wait_calls == 1) { errno = EINTR; return -1; }
    result = waitpid(pid, status, options);
    if (WAIT_MODE == 2 && result == pid) { errno = ECHILD; return -1; }
    return result;
}
#define waitpid observed_waitpid
#define tcc_error_noabort (test_enter_state(s1), test_error)
#define CONFIG_CODESIGN 1

#ifdef CONFIG_CODESIGN
#include <spawn.h>
#include <sys/wait.h>
#ifdef __APPLE__
#include <crt_externs.h>
#else
extern char **environ;
#endif

/* Lustr integration: pass the unchanged output path as one argument. */
static int tcc_codesign_file(TCCState *s1, const char *filename)
{
    pid_t pid, waited;
    int error, status;
    char *const argv[] = { "codesign", "-f", "-s", "-", "--", (char *)filename, NULL };
#ifdef __APPLE__
    char **environment = *_NSGetEnviron();
#else
    char **environment = environ;
#endif

    error = posix_spawnp(&pid, argv[0], NULL, NULL, argv, environment);
    if (error)
        return tcc_error_noabort("cannot start codesign for '%s': %s", filename, strerror(error));
    do {
        waited = waitpid(pid, &status, 0);
    } while (waited == -1 && errno == EINTR);
    if (waited < 0)
        return tcc_error_noabort("cannot wait for codesign for '%s': %s", filename, strerror(errno));
    if (waited != pid)
        return tcc_error_noabort("unexpected codesign wait result for '%s'", filename);
    if (WIFEXITED(status) && WEXITSTATUS(status) == 0)
        return 0;
    if (WIFEXITED(status))
        return tcc_error_noabort("codesign failed for '%s' (exit status %d)", filename, WEXITSTATUS(status));
    if (WIFSIGNALED(status))
        return tcc_error_noabort("codesign failed for '%s' (signal %d)", filename, WTERMSIG(status));
    return tcc_error_noabort("codesign failed for '%s' (unrecognized wait status)", filename);
}
#endif

int main(int argc, char **argv) {
    int result;
    if (argc != 2) return 90;
    result = tcc_codesign_file(&test_state, argv[1]);
    printf("returned=%d errors=%d waits=%d\n", result, errors, wait_calls);
    return result ? 21 : 0;
}
