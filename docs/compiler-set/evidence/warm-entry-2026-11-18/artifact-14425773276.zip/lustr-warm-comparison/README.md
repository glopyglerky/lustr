# Warm public-entry comparison

Status: completed.

Identical public slice with pinned baseline and candidate public entries, pristine Lust and Rust/Cargo.

Entry-only before/after comparison with identical native runtime and SDK. Broader compiler qualification remains separate.

All times are measured end-to-end command medians in milliseconds.

| Operation | Baseline Lustr | Candidate Lustr | Pristine Lust | rustc via Cargo |
| --- | ---: | ---: | ---: | ---: |
| cold-check | 248.112 | 248.792 | 202.650 | 372.742 |
| no-op-check | 44.963 | 2.519 | 1.834 | 12.741 |
| cold-build | 463.072 | 464.249 | 422.835 | 509.198 |
| no-op-build | 46.826 | 5.343 | 4.597 | 13.061 |

Each lane then primes its new warm state with three complete commands before the measured no-op. These costs remain visible below, in milliseconds. The first native prime can include daemon initialization and selection-cache population; this table does not isolate either component.

| Operation | Lane | First prime | Second prime | Third prime |
| --- | --- | ---: | ---: | ---: |
| check | baseline | 242.212 | 44.252 | 43.773 |
| check | entry | 241.824 | 2.713 | 2.352 |
| check | pristine | 196.632 | 2.026 | 1.750 |
| check | cargo | 12.827 | 12.611 | 12.508 |
| build | baseline | 519.778 | 47.227 | 47.270 |
| build | entry | 513.064 | 5.767 | 5.031 |
| build | pristine | 470.993 | 5.149 | 4.310 |
| build | cargo | 13.096 | 12.961 | 12.835 |

Ratios are paired reference/candidate geometric means; values above one favor the candidate.

| Operation | Reference | Candidate | Ratio | Conditional bootstrap 95% interval |
| --- | --- | --- | ---: | --- |
| cold-check | baseline | entry | 0.9964 | [0.9828, 1.0107] |
| cold-check | pristine | baseline | 0.8184 | [0.8094, 0.8276] |
| cold-check | pristine | entry | 0.8155 | [0.8045, 0.8268] |
| cold-check | cargo | entry | 1.5095 | [1.4941, 1.5252] |
| no-op-check | baseline | entry | 17.6409 | [17.2630, 17.9877] |
| no-op-check | pristine | baseline | 0.0412 | [0.0404, 0.0420] |
| no-op-check | pristine | entry | 0.7267 | [0.7134, 0.7407] |
| no-op-check | cargo | entry | 5.0146 | [4.9311, 5.0914] |
| cold-build | baseline | entry | 0.9962 | [0.9882, 1.0045] |
| cold-build | pristine | baseline | 0.9102 | [0.9024, 0.9181] |
| cold-build | pristine | entry | 0.9067 | [0.9007, 0.9125] |
| cold-build | cargo | entry | 1.0987 | [1.0875, 1.1104] |
| no-op-build | baseline | entry | 8.8421 | [8.6250, 9.0723] |
| no-op-build | pristine | baseline | 0.0968 | [0.0943, 0.0993] |
| no-op-build | pristine | entry | 0.8561 | [0.8376, 0.8752] |
| no-op-build | cargo | entry | 2.4738 | [2.4162, 2.5340] |

Warm target met: False.

Both warm modes: lower conditional paired-bootstrap 95% speed ratio >= 1.0; no equivalence claim from overlapping intervals.

Retained checks require zero generated C. Retained builds require zero body rechecks, dirty function units and newly compiled objects; they may reassemble launcher/support C whose object is served from cache. Full counters and exact runtime-output checks are retained in the raw evidence.

Intervals are conditional exploratory estimates on this runner. Overlap with one does not prove equality. Full compiler correctness and release admission are separate gates.
