# Same-host residual diagnostics

Status: completed.

Same-host residual diagnostics after the unchanged four-lane campaign.

These groups do not alter the primary measurements or its performance target.
The selector helper times full::select, excluding parsing and process startup.
Its executable identity differs from the public entry; components are not an
additive decomposition of independently measured whole-command durations.


All native lanes explicitly set __CARGO_TEMPORARY_BUILD_DIR_NEW_LAYOUT_OPT_OUT=1, matching the public parser injection. Lane state paths are separate.

Paired retained requests on held native daemons after three primes, with all six lane orders balanced in seeded blocks. No trace/stats in measured commands. Separate selector helper pairs follow.

| Operation | Public Lustr ms | Integrated Lust ms | Pristine Lust ms |
| --- | ---: | ---: | ---: |
| check | 1.952106 | 1.373917 | 1.301418 |
| build | 4.200103 | 3.613401 | 3.617593 |

Paired ratios are reference/candidate; above one favors the candidate.

| Operation | Reference | Candidate | Ratio | Bootstrap 95% |
| --- | --- | --- | ---: | --- |
| check | integrated | entry | 0.696389 | [0.678361, 0.716286] |
| check | pristine | integrated | 0.981614 | [0.958703, 1.005040] |
| check | pristine | entry | 0.683585 | [0.666829, 0.700895] |
| build | integrated | entry | 0.871131 | [0.859483, 0.882718] |
| build | pristine | integrated | 0.997367 | [0.981304, 1.013160] |
| build | pristine | entry | 0.868837 | [0.852309, 0.886203] |

Production full::select median: cached 0.554694 ms; cache disabled 33.124445 ms.
Paired disabled/cached ratio 59.857468, interval [58.710557, 61.054366].

The original four-lane campaign and strict target remain authoritative. These groups use their own warmed state and explicit environment alignment. Selector values exclude parser/startup and use the separately source-built helper identity; do not subtract them as a precise decomposition.
