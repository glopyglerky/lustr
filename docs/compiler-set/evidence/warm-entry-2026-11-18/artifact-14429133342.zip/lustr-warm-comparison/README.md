# Warm public-entry comparison

Status: completed.

Identical public slice with pinned baseline and candidate public entries, pristine Lust and Rust/Cargo.

Entry-only before/after comparison with identical native runtime and SDK. Broader compiler qualification remains separate.

All times are measured end-to-end command medians in milliseconds.

| Operation | Baseline Lustr | Candidate Lustr | Pristine Lust | rustc via Cargo |
| --- | ---: | ---: | ---: | ---: |
| cold-check | 196.058 | 195.155 | 159.552 | 298.984 |
| no-op-check | 35.658 | 2.195 | 1.481 | 10.325 |
| cold-build | 349.940 | 348.936 | 314.104 | 397.814 |
| no-op-build | 38.415 | 4.595 | 3.979 | 10.698 |

Each lane then primes its new warm state with three complete commands before the measured no-op. These costs remain visible below, in milliseconds. The first native prime can include daemon initialization and selection-cache population; this table does not isolate either component.

| Operation | Lane | First prime | Second prime | Third prime |
| --- | --- | ---: | ---: | ---: |
| check | baseline | 185.306 | 36.049 | 35.212 |
| check | entry | 185.567 | 2.443 | 1.977 |
| check | pristine | 150.257 | 1.799 | 1.458 |
| check | cargo | 10.470 | 10.024 | 9.898 |
| build | baseline | 378.913 | 39.410 | 37.839 |
| build | entry | 378.158 | 4.927 | 4.131 |
| build | pristine | 341.914 | 4.309 | 3.538 |
| build | cargo | 10.684 | 10.357 | 10.224 |

Ratios are paired reference/candidate geometric means; values above one favor the candidate.

| Operation | Reference | Candidate | Ratio | Conditional bootstrap 95% interval |
| --- | --- | --- | ---: | --- |
| cold-check | baseline | entry | 0.9443 | [0.8484, 1.0503] |
| cold-check | pristine | baseline | 0.8380 | [0.7553, 0.9229] |
| cold-check | pristine | entry | 0.7913 | [0.7238, 0.8582] |
| cold-check | cargo | entry | 1.4359 | [1.3100, 1.5405] |
| no-op-check | baseline | entry | 16.3963 | [16.1296, 16.6674] |
| no-op-check | pristine | baseline | 0.0421 | [0.0413, 0.0429] |
| no-op-check | pristine | entry | 0.6895 | [0.6782, 0.7012] |
| no-op-check | cargo | entry | 4.7395 | [4.6710, 4.8059] |
| cold-build | baseline | entry | 1.0213 | [0.9865, 1.0745] |
| cold-build | pristine | baseline | 0.8806 | [0.8367, 0.9139] |
| cold-build | pristine | entry | 0.8994 | [0.8819, 0.9185] |
| cold-build | cargo | entry | 1.1687 | [1.1315, 1.2247] |
| no-op-build | baseline | entry | 7.8689 | [6.8607, 8.4833] |
| no-op-build | pristine | baseline | 0.1032 | [0.1019, 0.1046] |
| no-op-build | pristine | entry | 0.8122 | [0.7090, 0.8757] |
| no-op-build | cargo | entry | 2.2567 | [2.0874, 2.3647] |

Warm target met: False.

Both warm modes: lower conditional paired-bootstrap 95% speed ratio >= 1.0; no equivalence claim from overlapping intervals.

Retained checks require zero generated C. Retained builds require zero body rechecks, dirty function units and newly compiled objects; they may reassemble launcher/support C whose object is served from cache. Full counters and exact runtime-output checks are retained in the raw evidence.

Before timing, actual public-entry selection-cache hits are exercised through a valid body edit, a type-error edit, and restoration. Check/build exit statuses match Rust/Cargo; successful edited builds match its exact runtime output. These are correctness gates, not edit-speed measurements.

Intervals are conditional exploratory estimates on this runner. Overlap with one does not prove equality. Full compiler correctness and release admission are separate gates.
