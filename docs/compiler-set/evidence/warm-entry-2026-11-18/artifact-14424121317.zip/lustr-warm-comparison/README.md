# Warm public-entry comparison

Status: failed.

Identical public slice with pinned baseline and candidate public entries, pristine Lust and Rust/Cargo.

Entry-only before/after comparison with identical native runtime and SDK. Broader compiler qualification remains separate.

No completed performance result. All original streams and failure records remain retained.
