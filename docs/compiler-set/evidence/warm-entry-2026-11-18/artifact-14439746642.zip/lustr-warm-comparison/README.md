# Warm public-entry comparison

Status: completed.

Identical public slice with pinned baseline and candidate public entries, pristine Lust and Rust/Cargo.

Entry-only before/after comparison with identical native runtime and SDK. Broader compiler qualification remains separate.

All times are measured end-to-end command medians in milliseconds.

Baseline public source: `d57f485eeb2b638d1f95a0594294d11e8001fe8e`. Both installed public launchers run their own source-built constructor tool initialization before the campaign; their separate seed records are retained.

| Operation | Baseline Lustr | Candidate Lustr | Pristine Lust | rustc via Cargo |
| --- | ---: | ---: | ---: | ---: |
| cold-check | 158.604 | 158.888 | 130.636 | 256.920 |
| no-op-check | 1.478 | 1.429 | 1.095 | 8.808 |
| cold-build | 290.764 | 289.293 | 262.363 | 357.744 |
| no-op-build | 3.410 | 3.411 | 3.139 | 8.670 |

Each lane then primes its new warm state with three complete commands before the measured no-op. These costs remain visible below, in milliseconds. The first native prime can include daemon initialization and selection-cache population; this table does not isolate either component.

| Operation | Lane | First prime | Second prime | Third prime |
| --- | --- | ---: | ---: | ---: |
| check | baseline | 165.830 | 1.729 | 1.462 |
| check | entry | 165.575 | 1.707 | 1.424 |
| check | pristine | 139.297 | 1.364 | 1.101 |
| check | cargo | 8.852 | 8.346 | 8.051 |
| build | baseline | 332.942 | 3.696 | 3.226 |
| build | entry | 329.797 | 3.672 | 3.142 |
| build | pristine | 301.387 | 3.394 | 2.815 |
| build | cargo | 8.763 | 8.289 | 8.183 |

Ratios are paired reference/candidate geometric means; values above one favor the candidate.

| Operation | Reference | Candidate | Ratio | Conditional bootstrap 95% interval |
| --- | --- | --- | ---: | --- |
| cold-check | baseline | entry | 0.9963 | [0.9881, 1.0043] |
| cold-check | pristine | baseline | 0.8280 | [0.8212, 0.8351] |
| cold-check | pristine | entry | 0.8249 | [0.8180, 0.8323] |
| cold-check | cargo | entry | 1.6282 | [1.6142, 1.6424] |
| no-op-check | baseline | entry | 1.0468 | [1.0075, 1.0884] |
| no-op-check | pristine | baseline | 0.7582 | [0.7188, 0.7988] |
| no-op-check | pristine | entry | 0.7938 | [0.7643, 0.8237] |
| no-op-check | cargo | entry | 6.1329 | [5.9856, 6.2864] |
| cold-build | baseline | entry | 1.0031 | [0.9970, 1.0094] |
| cold-build | pristine | baseline | 0.9043 | [0.8987, 0.9092] |
| cold-build | pristine | entry | 0.9072 | [0.9018, 0.9123] |
| cold-build | cargo | entry | 1.2296 | [1.2206, 1.2381] |
| no-op-build | baseline | entry | 1.0135 | [0.9753, 1.0533] |
| no-op-build | pristine | baseline | 0.9016 | [0.8523, 0.9498] |
| no-op-build | pristine | entry | 0.9138 | [0.8685, 0.9588] |
| no-op-build | cargo | entry | 2.6096 | [2.5342, 2.6941] |

Warm target met: False.

Both warm modes: lower conditional paired-bootstrap 95% speed ratio >= 1.0; no equivalence claim from overlapping intervals.

Retained checks require zero generated C. Retained builds require zero body rechecks, dirty function units and newly compiled objects; they may reassemble launcher/support C whose object is served from cache. Full counters and exact runtime-output checks are retained in the raw evidence.

Before timing, actual public-entry selection-cache hits are exercised through a valid body edit, a type-error edit, and restoration. Check/build exit statuses match Rust/Cargo; successful edited builds match its exact runtime output. These are correctness gates, not edit-speed measurements.

Intervals are conditional exploratory estimates on this runner. Overlap with one does not prove equality. Full compiler correctness and release admission are separate gates.
