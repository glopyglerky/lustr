# Same-host residual diagnostics

Status: completed.

Same-host residual diagnostics after the unchanged four-lane campaign.

These groups do not alter the primary measurements or its performance target.
The selector helper times full::select, excluding parsing and process startup.
Its executable identity differs from the public entry; components are not an
additive decomposition of independently measured whole-command durations.


All native lanes explicitly set __CARGO_TEMPORARY_BUILD_DIR_NEW_LAYOUT_OPT_OUT=1, matching the public parser injection. Lane state paths are separate.

Paired retained requests on held native daemons after three primes, with all six lane orders balanced in seeded blocks. No trace/stats in measured commands. Separate selector helper pairs follow.

| Operation | Public Lustr ms | Integrated Lust ms | Pristine Lust ms |
| --- | ---: | ---: | ---: |
| check | 1.220543 | 0.982789 | 0.895376 |
| build | 2.960649 | 2.685698 | 2.667775 |

Paired ratios are reference/candidate; above one favors the candidate.

| Operation | Reference | Candidate | Ratio | Bootstrap 95% |
| --- | --- | --- | ---: | --- |
| check | integrated | entry | 0.792874 | [0.762845, 0.823260] |
| check | pristine | integrated | 0.923887 | [0.888247, 0.958342] |
| check | pristine | entry | 0.732526 | [0.716411, 0.749012] |
| build | integrated | entry | 0.904125 | [0.891817, 0.916967] |
| build | pristine | integrated | 0.982339 | [0.961160, 1.003233] |
| build | pristine | entry | 0.888158 | [0.873229, 0.903325] |

Production full::select median: cached 0.264889 ms; cache disabled 23.825959 ms.
Paired disabled/cached ratio 90.220136, interval [88.638647, 91.748815].

The original four-lane campaign and strict target remain authoritative. These groups use their own warmed state and explicit environment alignment. Selector values exclude parser/startup and use the separately source-built helper identity; do not subtract them as a precise decomposition.
