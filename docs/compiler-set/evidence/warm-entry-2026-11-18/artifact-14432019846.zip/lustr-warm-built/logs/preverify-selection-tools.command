"/home/runner/work/_temp/lustr-warm-built/toolchain/bin/lustr" "--lustr-prime-selection-tools"
