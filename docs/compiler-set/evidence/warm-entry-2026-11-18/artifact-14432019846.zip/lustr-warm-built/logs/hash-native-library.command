"sha256sum" "/home/runner/work/_temp/lustr-warm-built/toolchain/lib/liblustr_native_core.so"
