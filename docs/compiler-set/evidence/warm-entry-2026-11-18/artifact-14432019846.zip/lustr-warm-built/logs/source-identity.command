cd "/home/runner/work/lustr/lustr" && "/home/runner/work/_temp/lustr-warm-built/work/source-guard" "--candidate"
