"sha256sum" "/home/runner/work/_temp/lustr-warm-built/toolchain/bin/lust-core"
