# Warm public-entry comparison

Status: completed.

Identical public slice with pinned baseline and candidate public entries, pristine Lust and Rust/Cargo.

Entry-only before/after comparison with identical native runtime and SDK. Broader compiler qualification remains separate.

All times are measured end-to-end command medians in milliseconds.

Baseline public source: `d57f485eeb2b638d1f95a0594294d11e8001fe8e`. Both installed public launchers run their own source-built constructor tool initialization before the campaign; their separate seed records are retained.

| Operation | Baseline Lustr | Candidate Lustr | Pristine Lust | rustc via Cargo |
| --- | ---: | ---: | ---: | ---: |
| cold-check | 160.705 | 161.955 | 135.153 | 264.047 |
| no-op-check | 1.492 | 1.450 | 1.143 | 8.897 |
| cold-build | 293.502 | 293.554 | 264.281 | 355.236 |
| no-op-build | 3.404 | 3.471 | 3.122 | 8.771 |

Each lane then primes its new warm state with three complete commands before the measured no-op. These costs remain visible below, in milliseconds. The first native prime can include daemon initialization and selection-cache population; this table does not isolate either component.

| Operation | Lane | First prime | Second prime | Third prime |
| --- | --- | ---: | ---: | ---: |
| check | baseline | 168.627 | 1.793 | 1.448 |
| check | entry | 165.889 | 1.739 | 1.424 |
| check | pristine | 141.068 | 1.379 | 1.124 |
| check | cargo | 8.964 | 8.398 | 8.177 |
| build | baseline | 334.499 | 3.772 | 3.260 |
| build | entry | 332.760 | 3.760 | 3.249 |
| build | pristine | 305.614 | 3.420 | 2.892 |
| build | cargo | 8.858 | 8.260 | 8.379 |

Ratios are paired reference/candidate geometric means; values above one favor the candidate.

| Operation | Reference | Candidate | Ratio | Conditional bootstrap 95% interval |
| --- | --- | --- | ---: | --- |
| cold-check | baseline | entry | 0.9917 | [0.9755, 1.0061] |
| cold-check | pristine | baseline | 0.8354 | [0.8266, 0.8442] |
| cold-check | pristine | entry | 0.8285 | [0.8187, 0.8370] |
| cold-check | cargo | entry | 1.6164 | [1.6005, 1.6326] |
| no-op-check | baseline | entry | 1.0427 | [1.0024, 1.0853] |
| no-op-check | pristine | baseline | 0.7833 | [0.7457, 0.8242] |
| no-op-check | pristine | entry | 0.8168 | [0.7889, 0.8463] |
| no-op-check | cargo | entry | 6.0618 | [5.9370, 6.1828] |
| cold-build | baseline | entry | 1.0058 | [0.9940, 1.0231] |
| cold-build | pristine | baseline | 0.8995 | [0.8942, 0.9045] |
| cold-build | pristine | entry | 0.9047 | [0.8953, 0.9189] |
| cold-build | cargo | entry | 1.2139 | [1.1934, 1.2319] |
| no-op-build | baseline | entry | 1.0130 | [0.9748, 1.0529] |
| no-op-build | pristine | baseline | 0.9074 | [0.8657, 0.9471] |
| no-op-build | pristine | entry | 0.9192 | [0.8792, 0.9622] |
| no-op-build | cargo | entry | 2.5923 | [2.5253, 2.6657] |

Warm target met: False.

Both warm modes: lower conditional paired-bootstrap 95% speed ratio >= 1.0; no equivalence claim from overlapping intervals.

Retained checks require zero generated C. Retained builds require zero body rechecks, dirty function units and newly compiled objects; they may reassemble launcher/support C whose object is served from cache. Full counters and exact runtime-output checks are retained in the raw evidence.

Before timing, actual public-entry selection-cache hits are exercised through a valid body edit, a type-error edit, and restoration. Check/build exit statuses match Rust/Cargo; successful edited builds match its exact runtime output. These are correctness gates, not edit-speed measurements.

Intervals are conditional exploratory estimates on this runner. Overlap with one does not prove equality. Full compiler correctness and release admission are separate gates.
