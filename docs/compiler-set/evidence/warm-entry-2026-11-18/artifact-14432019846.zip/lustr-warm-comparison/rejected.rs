fn main() { let _value: u32 = "not an integer"; }
