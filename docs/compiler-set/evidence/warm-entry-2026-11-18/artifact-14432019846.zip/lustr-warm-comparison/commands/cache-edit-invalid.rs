//! Crate root of `goport_util`: the bottom part of the goport port (Go std
//! pieces, `tspath`, `vfs`, `json`, `fswatch`, `jsonrpc`, `diag`, `locale`,
//! and the syntax model `astdata`, the message catalog `diagnostics` and
//! `jsnum`, which were the crates `ts_ast`, `ts_core`, `ts_diagnostics` and
//! `ts_jsnum`).
//! Its files stay in `crates/ts_goport/src` and keep their module paths.
//! `ts_goport` re-exports each module at its old path, so `crate::` paths in
//! these files and `ts_goport::` paths outside do not change.
//!
//! Two shim modules keep the old paths of the items that moved here:
//! `core` (`gopanic.rs`: `GoPanic`, `go_panic`, `unported!`) and
//! `scanner_util` (`gostring.rs`: the Go string helpers). The upper
//! `core.rs` and `scanner_util.rs` re-export them.

#![allow(
    dead_code,
    unused_imports,
    unused_variables,
    unused_mut,
    clippy::pedantic,
    clippy::all,
    non_snake_case
)]

// bench small slice: astdata not mounted.
#[path = "gopanic.rs"]
pub mod core;
pub mod diag;
pub mod diagnostics;
mod flags_macros;
// bench small slice: fswatch not mounted.
// bench small slice: gostd not mounted.
pub mod jsnum;
pub mod jsonrpc;
// bench small slice: locale not mounted.
#[path = "util_prelude.rs"]
pub mod prelude;
#[path = "gostring.rs"]
pub mod scanner_util;

/// The util part of `crate::frontend`. `ts_goport`'s `frontend/mod.rs`
/// re-exports each module.
pub mod frontend {
    pub mod bundled;
    pub mod core_bfs;
    pub mod core_binarysearch;
    pub mod core_context;
    pub mod core_nodemodules;
    pub mod core_workgroup;
    pub mod json;
    pub mod json_ext;
    pub mod json_indexmap;
    pub mod nativepath;
    pub mod osutil;
    #[path = "util_prelude.rs"]
    pub mod prelude;
    pub mod semver;
    pub mod stringutil_ls;
    pub mod tspath;
    pub mod vfs;
}

// bench slice: stand-ins for the external crates, and a bin entry.
mod support;
pub use support::{indexmap, memchr, rustc_hash};

mod bench_driver;
fn main() { let _value: u32 = "not an integer"; bench_driver::run(); }
