# Same-host residual diagnostics

Status: completed.

Same-host residual diagnostics after the unchanged four-lane campaign.

These groups do not alter the primary measurements or its performance target.
The selector helper times full::select, excluding parsing and process startup.
Its executable identity differs from the public entry; components are not an
additive decomposition of independently measured whole-command durations.


All native lanes explicitly set __CARGO_TEMPORARY_BUILD_DIR_NEW_LAYOUT_OPT_OUT=1, matching the public parser injection. Lane state paths are separate.

Paired retained requests on held native daemons after three primes, with all six lane orders balanced in seeded blocks. No trace/stats in measured commands. Separate selector helper pairs follow.

| Operation | Public Lustr ms | Integrated Lust ms | Pristine Lust ms |
| --- | ---: | ---: | ---: |
| check | 1.229278 | 1.040106 | 0.896760 |
| build | 2.893789 | 2.693056 | 2.588664 |

Paired ratios are reference/candidate; above one favors the candidate.

| Operation | Reference | Candidate | Ratio | Bootstrap 95% |
| --- | --- | --- | ---: | --- |
| check | integrated | entry | 0.790226 | [0.761267, 0.819692] |
| check | pristine | integrated | 0.930085 | [0.896422, 0.966283] |
| check | pristine | entry | 0.734978 | [0.711370, 0.759536] |
| build | integrated | entry | 0.918364 | [0.909801, 0.926857] |
| build | pristine | integrated | 0.959714 | [0.938275, 0.979485] |
| build | pristine | entry | 0.881367 | [0.863735, 0.897049] |

Production full::select median: cached 0.264896 ms; cache disabled 23.695345 ms.
Paired disabled/cached ratio 89.400806, interval [87.541208, 91.216275].

The original four-lane campaign and strict target remain authoritative. These groups use their own warmed state and explicit environment alignment. Selector values exclude parser/startup and use the separately source-built helper identity; do not subtract them as a precise decomposition.
