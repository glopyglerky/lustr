fn main(){let exists=std::path::Path::new("watched").exists();println!("cargo::rerun-if-changed=watched");println!("cargo::rustc-env=VALUE={}",exists);}
