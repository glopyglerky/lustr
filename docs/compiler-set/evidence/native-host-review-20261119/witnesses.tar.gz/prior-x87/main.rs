fn main() { println!("{}", cfg!(target_feature = "x87")); }
