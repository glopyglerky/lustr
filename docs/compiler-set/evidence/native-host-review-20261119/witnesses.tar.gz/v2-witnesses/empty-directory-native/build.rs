fn main(){let n=std::fs::read_dir("watched").unwrap().count();println!("cargo::rerun-if-changed=watched");println!("cargo::rustc-env=VALUE={}",n);}
