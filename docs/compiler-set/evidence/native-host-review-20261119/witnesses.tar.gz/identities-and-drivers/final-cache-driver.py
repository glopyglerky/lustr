from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,time
parser=argparse.ArgumentParser();parser.add_argument('--package',type=Path,required=True);parser.add_argument('--identity',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);a=parser.parse_args()
package=a.package.resolve(strict=True);base=a.output.absolute();base.mkdir(exist_ok=False)
sdk=Path('$PINNED_SDK/bin')
identity=json.loads(a.identity.read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name,digest in identity['binary_sha256'].items():assert sha(package/'bin'/name)==digest,(name,'package differs')
report={'schema':'lustr-native-cache-review-v1','scope':'Two actual public one-shot regressions on an immutable partial package, paired with pinned independent Cargo on the same unchanged sources; no warm, whole-compiler, constructor or performance claim','package':identity,'oracle':{'rustc_sha256':sha(sdk/'rustc'),'cargo_sha256':sha(sdk/'cargo')},'driver_sha256':sha(__file__),'commands':[],'cases':[],'passed':False}
def save():(base/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(case,label,argv,env):
 p=subprocess.run(list(map(str,argv)),cwd=case/'project',env=env,capture_output=True,timeout=60)
 (case/(label+'.stdout')).write_bytes(p.stdout);(case/(label+'.stderr')).write_bytes(p.stderr)
 report['commands'].append({'label':label,'argv':list(map(str,argv)),'cwd':str(case/'project'),'env':env.copy(),'exit':p.returncode,'stdout':str((case/(label+'.stdout')).relative_to(base)),'stderr':str((case/(label+'.stderr')).relative_to(base))});save();assert p.returncode==0,(label,p.returncode,p.stderr);return p
try:
 for name,old,expected in [('empty-directory',Path('$V2_WITNESSES/empty-directory-native'),[b'0\n',b'1\n']),('missing-marker',Path('$V2_MISSING_MARKER/native'),[b'false\n',b'true\n'])]:
  case=base/name;project=case/'project';(project/'src').mkdir(parents=True)
  for rel in ['Cargo.toml','build.rs','src/main.rs']:shutil.copyfile(old/rel,project/rel)
  sources={rel:sha(project/rel) for rel in ['Cargo.toml','build.rs','src/main.rs']}
  if name=='empty-directory':(project/'watched').mkdir()
  for folder in ['home','cargo-home']:(case/folder).mkdir()
  common={'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':str(case/'home'),'CARGO_HOME':str(case/'cargo-home'),'CARGO_NET_OFFLINE':'true','CARGO_BUILD_JOBS':'2','LANG':'C','LC_ALL':'C'}
  native_env=dict(common,LUST_NO_DAEMON='1',LUST_CACHE_DIR=str(case/'native-cache'),CARGO_TARGET_DIR=str(case/'native-target'),CARGO_BUILD_BUILD_DIR=str(case/'native-intermediates'))
  oracle_env=dict(common,PATH=str(sdk)+':/usr/bin:/bin',RUSTC=str(sdk/'rustc'),CARGO_TARGET_DIR=str(case/'oracle-target'),CARGO_BUILD_BUILD_DIR=str(case/'oracle-intermediates'))
  crate='empty_directory' if name=='empty-directory' else 'missing_marker';row={'case':name,'source_sha256':sources,'stages':[]}
  for stage in range(2):
   if stage:
    if name=='empty-directory':(project/'watched/empty').mkdir()
    else:(project/'watched').write_bytes(b'<missing>')
    future=time.time_ns()+2_000_000_000;os.utime(project/'watched',ns=(future,future))
   native_artifact=case/f'native-{stage}';trace=case/f'native-{stage}.trace.jsonl';native_env['LUSTR_TRACE_PATH']=str(trace)
   run(case,f'native-{stage}-build',[package/'bin/lustr','build','src/main.rs','--manifest-path','Cargo.toml','--bin',crate,'--offline','-o',native_artifact],native_env)
   events=[json.loads(line) for line in trace.read_text().splitlines()];assert len(events)==1 and events[0]['engine']=='lust',events
   native_hash=sha(native_artifact);actual=run(case,f'native-{stage}-run',[native_artifact],native_env);assert sha(native_artifact)==native_hash
   oracle_build=run(case,f'oracle-{stage}-build',[sdk/'cargo','build','--offline','--bin',crate,'--message-format=json'],oracle_env)
   messages=[json.loads(line) for line in oracle_build.stdout.splitlines()];executables=[r['executable'] for r in messages if r.get('reason')=='compiler-artifact' and r.get('executable') and 'bin' in r.get('target',{}).get('kind',[])];assert len(executables)==1
   oracle_artifact=Path(executables[0]);oracle_hash=sha(oracle_artifact);oracle=run(case,f'oracle-{stage}-run',[oracle_artifact],oracle_env);assert sha(oracle_artifact)==oracle_hash
   assert (actual.returncode,actual.stdout,actual.stderr)==(oracle.returncode,oracle.stdout,oracle.stderr)==(0,expected[stage],b''),(name,stage,actual,oracle)
   assert all(sha(project/rel)==digest for rel,digest in sources.items())
   scripts=list((case/'native-cache').glob('native-buildscript-*/build-script'));assert len(scripts)==1
   script=scripts[0];stat=script.stat();script_identity={'sha256':sha(script),'inode':stat.st_ino,'mtime_ns':stat.st_mtime_ns,'size':stat.st_size}
   for record in (case/'native-cache').glob('buildscript-native-*.txt'):shutil.copyfile(record,case/f'native-record-{stage}.txt')
   row['stages'].append({'stage':stage,'native_stdout':actual.stdout.decode(),'oracle_stdout':oracle.stdout.decode(),'native_artifact_sha256':native_hash,'oracle_artifact_sha256':oracle_hash,'compiled_script':script_identity,'owner_event':events[0]})
  assert row['stages'][0]['compiled_script']==row['stages'][1]['compiled_script'],'unchanged script binary was republished'
  row['passed']=True;row['compiled_script_unchanged']=True;report['cases'].append(row);save();print(json.dumps(row),flush=True)
 assert all(sha(package/'bin'/name)==digest for name,digest in identity['binary_sha256'].items())
 report.update(package_unchanged=True,passed=True)
except Exception as error:
 report['failure']=repr(error);raise
finally:save()
