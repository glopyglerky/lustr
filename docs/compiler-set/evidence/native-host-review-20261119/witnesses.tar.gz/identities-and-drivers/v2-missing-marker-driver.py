from pathlib import Path
import json,os,subprocess,time,hashlib
base=Path('$V2_MISSING_MARKER');base.mkdir()
package=Path('$PACKAGE_V2');sdk=Path('$PINNED_SDK/bin')
report={'scope':'public one-shot partial package-v2 vs pinned independent Cargo; deterministic absent/file identity collision','package_identity':json.loads(Path('$PACKAGE_V2-identity.json').read_text()),'commands':[],'results':{}}
def save():(base/'review.json').write_text(json.dumps(report,indent=2)+'\n')
for kind in ['native','oracle']:
 case=base/kind;(case/'src').mkdir(parents=True);(case/'home').mkdir();(case/'cargo-home').mkdir()
 (case/'Cargo.toml').write_text('[package]\nname="missing_marker"\nversion="0.1.0"\nedition="2024"\n')
 (case/'src/main.rs').write_text('fn main(){println!("{}",env!("VALUE"));}\n')
 (case/'build.rs').write_text('fn main(){let exists=std::path::Path::new("watched").exists();println!("cargo::rerun-if-changed=watched");println!("cargo::rustc-env=VALUE={}",exists);}\n')
 env={'PATH':str(sdk)+':/usr/bin:/bin' if kind=='oracle' else '/usr/local/bin:/usr/bin:/bin','HOME':str(case/'home'),'CARGO_HOME':str(case/'cargo-home'),'CARGO_NET_OFFLINE':'true','CARGO_TARGET_DIR':str(case/'target'),'CARGO_BUILD_BUILD_DIR':str(case/'intermediates'),'LANG':'C','LC_ALL':'C'}
 if kind=='oracle':env['RUSTC']=str(sdk/'rustc')
 else:env.update(LUST_NO_DAEMON='1',LUST_CACHE_DIR=str(case/'cache'))
 def run(label,argv):
  r=subprocess.run(list(map(str,argv)),cwd=case,env=env,capture_output=True,timeout=60);(case/(label+'.stdout')).write_bytes(r.stdout);(case/(label+'.stderr')).write_bytes(r.stderr);report['commands'].append({'argv':list(map(str,argv)),'cwd':str(case),'env':env.copy(),'exit':r.returncode,'stdout':label+'.stdout','stderr':label+'.stderr'});save();assert r.returncode==0,(label,r.stderr);return r
 values=[]
 for stage in range(2):
  if stage:
   (case/'watched').write_bytes(b'<missing>');future=time.time_ns()+2_000_000_000;os.utime(case/'watched',ns=(future,future))
  if kind=='native':
   output=case/f'program-{stage}';env['LUSTR_TRACE_PATH']=str(case/f'trace-{stage}.jsonl');argv=[package/'bin/lustr','build','src/main.rs','--manifest-path','Cargo.toml','--bin','missing_marker','--offline','-o',output]
  else:output=case/'target/debug/missing_marker';argv=[sdk/'cargo','build','--offline']
  run(f'build-{stage}',argv);values.append(run(f'program-{stage}',[output]).stdout.decode())
  if kind=='native':
   for p in (case/'cache').glob('buildscript-native-*.txt'):(case/f'record-{stage}.txt').write_bytes(p.read_bytes())
 report['results'][kind]=values;save()
print(json.dumps(report['results']))
