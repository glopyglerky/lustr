from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
base=Path('$V2_WITNESSES');base.mkdir()
package=Path('$PACKAGE_V2')
sdk=Path('$PINNED_SDK/bin')
identity=json.loads(Path('$PACKAGE_V2-identity.json').read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name,digest in identity['binary_sha256'].items():assert sha(package/'bin'/name)==digest
report={'scope':'Immutable partial package v2; public one-shot requests; not guarded construction, warm-session qualification, full compiler coverage or performance evidence','package':identity,'rustc_sha256':sha(sdk/'rustc'),'commands':[],'findings':{}}
def save(): (base/'review.json').write_text(json.dumps(report,indent=2)+'\n')
def run(case,label,argv,env,expected=0):
 result=subprocess.run(list(map(str,argv)),cwd=case,env=env,capture_output=True,timeout=60)
 (case/(label+'.stdout')).write_bytes(result.stdout);(case/(label+'.stderr')).write_bytes(result.stderr)
 row={'label':label,'argv':list(map(str,argv)),'env':env,'cwd':str(case),'exit':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()};report['commands'].append(row);save()
 if expected is not None:assert result.returncode==expected,(label,result.returncode,result.stderr)
 return result
def env_for(case,oracle=False):
 for name in ['home','cargo-home']: (case/name).mkdir(exist_ok=True)
 env={'PATH':str(sdk)+':/usr/bin:/bin' if oracle else '/usr/local/bin:/usr/bin:/bin','HOME':str(case/'home'),'CARGO_HOME':str(case/'cargo-home'),'CARGO_NET_OFFLINE':'true','CARGO_TARGET_DIR':str(case/'target'),'CARGO_BUILD_BUILD_DIR':str(case/'intermediates'),'LANG':'C','LC_ALL':'C'}
 if oracle:env['RUSTC']=str(sdk/'rustc')
 else:env.update(LUST_NO_DAEMON='1',LUST_CACHE_DIR=str(case/'cache'))
 return env
def native_build(case,name,env,label,features=None):
 output=case/(label+'.program');argv=[package/'bin/lustr','build','src/main.rs','--manifest-path','Cargo.toml','--bin',name,'--offline']
 if features:argv+=['--features',features]
 argv+=['-o',output];env=dict(env,LUSTR_TRACE_PATH=str(case/(label+'.trace.jsonl')));run(case,label+'-build',argv,env);return run(case,label+'-run',[output],env)
def fixture(case,name,build,main='fn main(){println!("{}",env!("VALUE"));}\n'):
 (case/'src').mkdir(parents=True);(case/'Cargo.toml').write_text(f'[package]\nname="{name}"\nversion="0.1.0"\nedition="2024"\n');(case/'src/main.rs').write_text(main);(case/'build.rs').write_text(build)
# Adding an empty subdirectory changes a declared directory input.
script='fn main(){let n=std::fs::read_dir("watched").unwrap().count();println!("cargo::rerun-if-changed=watched");println!("cargo::rustc-env=VALUE={}",n);}\n'
values={}
for kind in ['native','oracle']:
 case=base/('empty-directory-'+kind);fixture(case,'empty_directory',script);(case/'watched').mkdir();env=env_for(case,kind=='oracle');outputs=[]
 for stage in range(2):
  if stage:
   (case/'watched/empty').mkdir();future=time.time_ns()+2_000_000_000;os.utime(case/'watched',ns=(future,future))
  if kind=='native':result=native_build(case,'empty_directory',env,f'stage-{stage}')
  else:
   run(case,f'stage-{stage}-build',[sdk/'cargo','build','--offline'],env);result=run(case,f'stage-{stage}-run',[case/'target/debug/empty_directory'],env)
  outputs.append(result.stdout.decode())
  if kind=='native':
   for p in (case/'cache').glob('buildscript-native-*.txt'):shutil.copyfile(p,case/f'stage-{stage}-record.txt')
 values[kind]=outputs
report['findings']['empty_directory']=values;save();print('empty_directory='+json.dumps(values),flush=True)
# Target-feature selection from unchanged Rust source.
case=base/'x87';case.mkdir();shutil.copyfile('$PRIOR_X87/main.rs',case/'main.rs');env=env_for(case)
run(case,'native-build',[package/'bin/lustr','build','main.rs','-o',case/'native'],env);native=run(case,'native-run',[case/'native'],env)
run(case,'oracle-build',[sdk/'rustc','--edition=2024','main.rs','-o',case/'oracle'],env_for(case,True));oracle=run(case,'oracle-run',[case/'oracle'],env_for(case,True));assert native.stdout==oracle.stdout==b'true\n';report['findings']['x87']={'native':native.stdout.decode(),'oracle':oracle.stdout.decode()};save();print('x87=true/true',flush=True)
# Same compile/run environment witnesses as the preserved pinned Cargo runs.
for name in ['empty','sentinel-features','jobs-2']:
 old=Path('/tmp/lustr-buildscript-env-review')/name;case=base/name;(case/'src').mkdir(parents=True)
 for rel in ['Cargo.toml','build.rs','src/main.rs']:shutil.copyfile(old/rel,case/rel)
 env=env_for(case)
 if name=='jobs-2':env['CARGO_BUILD_JOBS']='2'
 if name=='sentinel-features':env.update(json.loads((old/'sentinels.json').read_text()))
 native_build(case,'env_review',env,'native','hyphen-name,sample' if name=='sentinel-features' else None)
 def rows(path):return {tuple(line.split('|',2)[:2]):line.split('|',2)[2] for line in path.read_text().splitlines()}
 actual=rows(case/'script-env.txt');expected=rows(old/'script-env.txt');differences=[]
 for key in sorted(actual.keys()|expected.keys()):
  if actual.get(key)!=expected.get(key):differences.append({'stage':key[0],'name':key[1],'native':actual.get(key),'oracle':expected.get(key)})
 (case/'differences.json').write_text(json.dumps(differences,indent=2)+'\n');report['findings'][name]={'differences':differences}
 if name=='jobs-2':assert actual[('compile','NUM_JOBS')]=='None' and actual[('runtime','NUM_JOBS')]=='"2"'
 save();print(name+' differences='+str(len(differences)),flush=True)
# Successful self-mutating script must not certify new bytes with old outputs.
case=base/'self-write';case.mkdir();old=Path('$PRIOR_SELF_WRITE_NATIVE');(case/'src').mkdir()
for rel in ['Cargo.toml','build.rs','src/main.rs']:shutil.copyfile(old/rel,case/rel)
(case/'input.txt').write_text('before');env=env_for(case);values=[]
for stage in range(2):
 result=native_build(case,'input_race',env,f'stage-{stage}');values.append(result.stdout.decode())
 for p in (case/'cache').glob('buildscript-native-*.txt'):shutil.copyfile(p,case/f'stage-{stage}-record.txt')
assert values==['before\n','after\n'];report['findings']['self_write']=values;save();print('self_write='+json.dumps(values),flush=True)
assert all(sha(package/'bin'/name)==digest for name,digest in identity['binary_sha256'].items());report['package_unchanged']=True;save()
