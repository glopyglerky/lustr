use std::io::Write;
fn main() {
 let mut out = std::fs::File::create("script-env.txt").unwrap();
 writeln!(out, "compile|OUT_DIR|{:?}", option_env!("OUT_DIR")).unwrap();
 writeln!(out, "compile|CARGO_MANIFEST_DIR|{:?}", option_env!("CARGO_MANIFEST_DIR")).unwrap();
 writeln!(out, "compile|CARGO_MANIFEST_PATH|{:?}", option_env!("CARGO_MANIFEST_PATH")).unwrap();
 writeln!(out, "compile|CARGO_PKG_NAME|{:?}", option_env!("CARGO_PKG_NAME")).unwrap();
 writeln!(out, "compile|CARGO_PKG_VERSION|{:?}", option_env!("CARGO_PKG_VERSION")).unwrap();
 writeln!(out, "compile|CARGO_CRATE_NAME|{:?}", option_env!("CARGO_CRATE_NAME")).unwrap();
 writeln!(out, "compile|CARGO_BIN_NAME|{:?}", option_env!("CARGO_BIN_NAME")).unwrap();
 writeln!(out, "compile|CARGO_CFG_FEATURE|{:?}", option_env!("CARGO_CFG_FEATURE")).unwrap();
 writeln!(out, "compile|CARGO_FEATURE_SAMPLE|{:?}", option_env!("CARGO_FEATURE_SAMPLE")).unwrap();
 writeln!(out, "compile|HOST|{:?}", option_env!("HOST")).unwrap();
 writeln!(out, "compile|TARGET|{:?}", option_env!("TARGET")).unwrap();
 writeln!(out, "compile|OPT_LEVEL|{:?}", option_env!("OPT_LEVEL")).unwrap();
 writeln!(out, "compile|PROFILE|{:?}", option_env!("PROFILE")).unwrap();
 writeln!(out, "compile|DEBUG|{:?}", option_env!("DEBUG")).unwrap();
 writeln!(out, "compile|NUM_JOBS|{:?}", option_env!("NUM_JOBS")).unwrap();
 writeln!(out, "compile|RUSTC|{:?}", option_env!("RUSTC")).unwrap();
 writeln!(out, "compile|CARGO|{:?}", option_env!("CARGO")).unwrap();
 let mut vars: Vec<_> = std::env::vars().filter(|(k, _)| k.starts_with("CARGO_CFG_") || k.starts_with("CARGO_FEATURE_") || ["OUT_DIR", "CARGO_MANIFEST_DIR", "CARGO_MANIFEST_PATH", "CARGO_PKG_NAME", "CARGO_PKG_VERSION", "CARGO_CRATE_NAME", "CARGO_BIN_NAME", "CARGO_CFG_FEATURE", "CARGO_FEATURE_SAMPLE", "HOST", "TARGET", "OPT_LEVEL", "PROFILE", "DEBUG", "NUM_JOBS", "RUSTC", "CARGO"].contains(&k.as_str())).collect();
 vars.sort();
 for (k,v) in vars { writeln!(out, "runtime|{}|{:?}", k, v).unwrap(); }
}
