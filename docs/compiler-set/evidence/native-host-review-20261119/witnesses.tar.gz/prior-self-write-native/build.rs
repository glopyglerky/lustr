fn main() {
 let value = std::fs::read_to_string("input.txt").unwrap();
 if value == "before" { std::fs::write("input.txt", "after").unwrap(); }
 println!("cargo::rerun-if-changed=input.txt");
 println!("cargo::rustc-env=VALUE={}", value);
}
