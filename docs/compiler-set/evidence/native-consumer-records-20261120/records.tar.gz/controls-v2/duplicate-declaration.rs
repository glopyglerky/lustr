#![no_std]
pub fn value(value:u64)->u64 { value }
pub fn value(value:u64)->u64 { value }
