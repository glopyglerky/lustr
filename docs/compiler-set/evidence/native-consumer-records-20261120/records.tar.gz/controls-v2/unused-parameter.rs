#![no_std]
pub fn value(unused:u64)->u64 { 1u64 }
