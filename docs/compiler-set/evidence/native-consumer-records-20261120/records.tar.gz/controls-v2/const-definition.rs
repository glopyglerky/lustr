#![no_std]
const VALUE:u64=1;
pub fn value(_input:u64)->u64 { VALUE }
