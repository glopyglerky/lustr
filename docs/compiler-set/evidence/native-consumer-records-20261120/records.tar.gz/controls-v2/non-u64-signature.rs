#![no_std]
pub fn value(input:u32)->u32 { input }
