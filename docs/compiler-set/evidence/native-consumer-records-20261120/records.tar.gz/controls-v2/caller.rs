unsafe extern "C" { #[link_name="f_cc9de038402fec68"] fn transform(value:u64)->u64; #[link_name="f_8db286a514821efc"] fn combine(left:u64,right:u64)->u64; }
fn main() { for value in (0u64..65536).chain([u64::MAX, 1u64<<63]) { assert_eq!(unsafe{transform(value)}, (value & 255)^85); assert_eq!(unsafe{combine(value, 0x101)}, value|0x101); } println!("native-body-results=131076"); }
