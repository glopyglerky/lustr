#![no_std]
pub fn BadName(value:u64)->u64 { value }
