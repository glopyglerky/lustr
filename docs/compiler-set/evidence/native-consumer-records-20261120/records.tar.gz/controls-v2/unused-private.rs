#![no_std]
pub fn visible(value:u64)->u64 { value }
fn hidden(value:u64)->u64 { value }
