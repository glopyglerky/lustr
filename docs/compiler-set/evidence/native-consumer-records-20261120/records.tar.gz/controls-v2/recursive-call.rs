#![no_std]
pub fn value(input:u64)->u64 { value(input) }
