"/workspace/scratch/9d482ba2ab85/sdk/rustup/toolchains/nightly-2026-11-09-x86_64-unknown-linux-gnu/bin/rustc" "-vV"
