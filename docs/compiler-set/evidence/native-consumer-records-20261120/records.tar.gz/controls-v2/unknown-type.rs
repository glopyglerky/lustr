#![no_std]
pub fn value(value:Missing)->u64 { 1 }
