"/workspace/scratch/9d482ba2ab85/metadata-verification-20261120/controls-v3/caller"
