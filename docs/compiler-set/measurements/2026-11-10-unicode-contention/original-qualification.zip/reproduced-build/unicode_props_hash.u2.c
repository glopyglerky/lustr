#define LUST_IMPL 1
/* Lust C runtime. Every compilation unit includes this text.
   - With LUST_IMPL defined (one unit per program): full function definitions.
   - Without it (all other units): declarations only, so those units stay small and parse fast.
   Rules: wrapping math is done in uint64_t, so C integer promotion never makes signed overflow;
   every check that Rust does in debug builds is done here and panics the same way. */
#include <stdint.h>
#include <stddef.h>
#ifdef LUST_IMPL
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
/* pthread key and once types (thread.c, panic.c, sync.c). The runtime
   hand-declares the pthread calls for tcc, whose <pthread.h> prototypes
   clash with them, and the hand types (unsigned int key, int once with
   0 as its init) match glibc and musl on Linux. On Darwin they are
   wrong (the key is an unsigned long, the once is a 16-byte struct
   whose valid init is not zero), so a Darwin build, which never uses
   tcc, takes the real <pthread.h> types instead. */
#ifdef _WIN32
/* A Fls index and an INIT_ONCE (a pointer word, zero-init). */
typedef unsigned int lust_pthread_key_t;
typedef int64_t lust_pthread_once_t;
#define LUST_PTHREAD_ONCE_INIT 0
#elif defined(__APPLE__)
#include <pthread.h>
#include <time.h>
typedef pthread_key_t lust_pthread_key_t;
typedef pthread_once_t lust_pthread_once_t;
#define LUST_PTHREAD_ONCE_INIT PTHREAD_ONCE_INIT
#else
typedef unsigned int lust_pthread_key_t;
typedef int lust_pthread_once_t;
#define LUST_PTHREAD_ONCE_INIT 0
#endif
#define LUST_BODY(...) __VA_ARGS__
#else
void free(void *);
void abort(void);
void *memset(void *, int, size_t);
void *memcpy(void *, const void *, size_t);
#define LUST_BODY(...) ;
#endif

/* std::hint::black_box: the value's slot escapes into an empty asm that may read and write
   memory, so an optimizer can assume nothing about the value or what it points at (rustc's
   form). tcc does not optimize: nothing to hide. */
#ifdef __TINYC__
#define lust_black_box(p) ((void)(p))
#else
#define lust_black_box(p) __asm__ __volatile__("" : : "r"(p) : "memory")
#endif

/* A byte copy whose length is known only at run time but is often one small value: an
   element of the runtime's type-erased Vec, hash table and sort, a short string, a Drain
   tail. Up to 32 bytes it is a few loads and stores with no call, every load before any
   store, so the ranges may overlap (a memmove); a longer copy calls memmove. tcc units
   call lust_memmove, as before. */
#ifdef __TINYC__
#define lust_copy_small(d, s, n) lust_memmove((d), (s), (n))
#else
static inline __attribute__((always_inline)) void lust_copy_small(void *d, const void *s, uint64_t n) {
    unsigned char *dp = (unsigned char *)d;
    const unsigned char *sp = (const unsigned char *)s;
    if (__builtin_expect(n > 32, 0)) {
        __builtin_memmove(d, s, (size_t)n);
    } else if (n > 16) {
        uint64_t a, b, c, e;
        __builtin_memcpy(&a, sp, 8);
        __builtin_memcpy(&b, sp + 8, 8);
        __builtin_memcpy(&c, sp + n - 16, 8);
        __builtin_memcpy(&e, sp + n - 8, 8);
        __builtin_memcpy(dp, &a, 8);
        __builtin_memcpy(dp + 8, &b, 8);
        __builtin_memcpy(dp + n - 16, &c, 8);
        __builtin_memcpy(dp + n - 8, &e, 8);
    } else if (n >= 8) {
        uint64_t a, e;
        __builtin_memcpy(&a, sp, 8);
        __builtin_memcpy(&e, sp + n - 8, 8);
        __builtin_memcpy(dp, &a, 8);
        __builtin_memcpy(dp + n - 8, &e, 8);
    } else if (n >= 4) {
        uint32_t a, e;
        __builtin_memcpy(&a, sp, 4);
        __builtin_memcpy(&e, sp + n - 4, 4);
        __builtin_memcpy(dp, &a, 4);
        __builtin_memcpy(dp + n - 4, &e, 4);
    } else if (n) {
        unsigned char a = sp[0], b = sp[n >> 1], c = sp[n - 1];
        dp[0] = a;
        dp[n >> 1] = b;
        dp[n - 1] = c;
    }
}
#endif

/* RawVec's size rule: `n` elements of `elem` bytes (elem != 0) fit when n * elem is at most
   isize::MAX. One multiply with an overflow test: `n <= isize::MAX / elem` divides, a 64-bit
   div of 10 or more cycles at every Vec allocation. An elem the compiler knows (a call site's
   sizeof) folds to one compare. tcc units keep the division. */
#ifdef __TINYC__
#define lust_vec_fits(n, elem) ((uint64_t)(n) <= 9223372036854775807ull / (uint64_t)(elem))
#else
static inline __attribute__((always_inline)) int lust_vec_fits(uint64_t n, uint64_t elem) {
    uint64_t bytes;
    if (__builtin_constant_p(elem)) return n <= 9223372036854775807ull / elem;
    return !__builtin_mul_overflow(n, elem, &bytes) && bytes <= 9223372036854775807ull;
}
#endif


#if defined(_WIN32) && defined(LUST_IMPL)
/* The Win32 thread layer (rel-win): the runtime names pthread calls
   with hand declarations (no <pthread.h>, as under tcc); on Windows
   those names are these small wrappers over CreateThread, FlsAlloc
   and InitOnceExecuteOnce. A thread handle rides in a uintptr_t (the
   JoinHdr word is uintptr_t for this: a HANDLE does not fit the
   32-bit Windows long). Fls destructors run at thread exit, as
   pthread key destructors do; the main thread runs its TLS
   destructors from lust_tls_exit, as on Linux. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
void _lock_file(FILE *);
void _unlock_file(FILE *);
#define flockfile _lock_file
#define funlockfile _unlock_file
static int lust_win_key_create(unsigned int *key, void (*dtor)(void *)) {
    DWORD i = FlsAlloc((PFLS_CALLBACK_FUNCTION)dtor);
    if (i == 0xFFFFFFFFu) return 1;
    *key = (unsigned int)i;
    return 0;
}
static void *lust_win_getspecific(unsigned int key) { return FlsGetValue((DWORD)key); }
static int lust_win_setspecific(unsigned int key, const void *v) { return FlsSetValue((DWORD)key, (void *)v) ? 0 : 1; }
typedef struct { void (*init)(void); } lust_win_once_arg;
static BOOL CALLBACK lust_win_once_cb(PINIT_ONCE o, void *p, void **c) {
    (void)o; (void)c;
    ((lust_win_once_arg *)p)->init();
    return TRUE;
}
static int lust_win_once(lust_pthread_once_t *once, void (*init)(void)) {
    lust_win_once_arg a = {init};
    return InitOnceExecuteOnce((PINIT_ONCE)once, lust_win_once_cb, &a, 0) ? 0 : 1;
}
typedef struct { void *(*start)(void *); void *arg; } lust_win_start;
static DWORD WINAPI lust_win_thread_cb(void *p) {
    lust_win_start s = *(lust_win_start *)p;
    free(p);
    s.start(s.arg);
    return 0;
}
static int lust_win_thread_create(uintptr_t *t, const void *attr, void *(*start)(void *), void *arg) {
    (void)attr;
    lust_win_start *s = (lust_win_start *)malloc(sizeof *s);
    if (!s) return 1;
    s->start = start;
    s->arg = arg;
    HANDLE h = CreateThread(0, 0, lust_win_thread_cb, s, 0, 0);
    if (!h) { free(s); return 1; }
    *t = (uintptr_t)h;
    return 0;
}
static int lust_win_thread_join(uintptr_t t, void **ret) {
    (void)ret;
    WaitForSingleObject((HANDLE)t, INFINITE);
    CloseHandle((HANDLE)t);
    return 0;
}
static int lust_win_thread_detach(uintptr_t t) { CloseHandle((HANDLE)t); return 0; }
static int lust_win_yield(void) { SwitchToThread(); return 0; }
#define pthread_key_create lust_win_key_create
#define pthread_getspecific lust_win_getspecific
#define pthread_setspecific lust_win_setspecific
#define pthread_once lust_win_once
#define pthread_create lust_win_thread_create
#define pthread_join lust_win_thread_join
#define pthread_detach lust_win_thread_detach
#define sched_yield lust_win_yield
#endif

/* 128-bit integers. tcc has no __int128 (spike K3-13), so codegen uses a
   two-word struct; _Alignas on the first member gives the type the
   16-byte alignment Rust u128/i128 have (spike K3-21), which a type-level
   aligned attribute cannot do in tcc. `lo` is the low word. Size 16. */
typedef struct { _Alignas(16) uint64_t lo; uint64_t hi; } lust_u128;
typedef struct { _Alignas(16) uint64_t lo; uint64_t hi; } lust_i128;

/* Rust `()`: a zero-sized C form, so aggregates with a direct unit
   field have the exact Rust size. Size 0 (GNU empty struct, in tcc
   as in gcc), align 1. */
typedef struct { } lust_Unit;
_Static_assert(sizeof(lust_Unit) == 0 && _Alignof(lust_Unit) == 1, "unit layout");

typedef struct { uint8_t *ptr; uint64_t len; } lust_str;
typedef struct { uint8_t *ptr; uint64_t len; uint64_t cap; } lust_String;
typedef struct { void *ptr; uint64_t len; uint64_t cap; } lust_Vec;
/* `vec::IntoIter<T>`: the moved-in Vec buffer; elements `front..len` are still owned. */
typedef struct { void *ptr; uint64_t len; uint64_t cap; uint64_t front; } lust_VecIter;
/* `vec::Drain<T>` and `string::Drain`: the drained container (a lust_Vec
   or a lust_String; both start with ptr, len, cap), the drain start, the
   elements still to yield (`front..back`, indexes into the container's
   buffer), and the tail after the drained range. A Vec's length is set
   to `start` while its Drain lives; the drop glue (cgen.rs) drops what
   was not yielded and moves the tail down to `start`. */
typedef struct { void *vec; uint64_t start; uint64_t front; uint64_t back; uint64_t tail_start; uint64_t tail_len; } lust_VecDrain;
/* `&dyn Trait` and `&mut dyn Trait` (ARCH 2.8): the data pointer and the
   vtable, an array of words: drop glue, size, align, one super vtable per
   supertrait, then one entry per method (see src/check/object.rs). */
typedef struct { void *data; const void *const *vt; } lust_dyn;

/* Program globals, defined in the runtime unit and set by main. */
extern int lust_argc;
extern char **lust_argv;
extern const char *lust_file;

/* Every function is called through this table (see cgen.rs). */
typedef void (*lust_fnptr)(void);
extern lust_fnptr lust_fns[];
/* One slot trampoline per slot (ARCH 4.5): stable addresses that
   forward through lust_fns, stored in fn pointer values. */
extern lust_fnptr lust_tramps[];
/* Entry for a `main` that returns `Result<(), E>`: set by the unit
   that holds main when it registers; NULL for a `()` main. */
extern int (*lust_main_entry_p)(void);
void lust_base_init(void);
/* catch_unwind under unwind tables (panic.c, lust_unwind_mode 2): runs f(ctx) under a
   catch point; 1 when a panic unwound to it. */
int32_t lust_unw_try(void (*f)(void *), void *ctx);
int32_t lust_unw_main_caught(void);
void lust_unw_dtry(void (*f)(void *), void *arg, void **ux);
void lust_unw_reraise(void *ux);

/* A source location: (function id << 40) | (line within the function << 20) | column, with
   20 bits each for the relative line and the column. Lines are relative to each function's
   first line (lust_fn_line), so the code for an unchanged function stays valid when code
   above it moves. A function id at or above 0xFFFF00 instead names a std source line
   (panic.c LUST_STD_SLOT), with absolute line and column. */
typedef uint64_t lust_loc;
/* A fn's location slot (`lust_so_<id>`, release C: the slot already shifted to its bits,
   slot << 40) read at a panic site: a volatile read, so the C compiler keeps the load in
   the cold panic path instead of hoisting it into the fn's hot path. A #[track_caller]
   call's location argument reads the slot plainly (cgen/names.rs `loc`, `hot_loc`). */
#define LUST_SO(x) (*(const volatile uint64_t *)&(x))
/* The slot of a location word with no fn slot (a numbered or std word): a #[track_caller]
   callee gets &lust_so_none and the whole word (cgen/names.rs `hot_loc`). */
extern const uint64_t lust_so_none;
extern const uint32_t *lust_fn_line;
/* thread_local! slots below this have their cell pointer in thread.c's native
   lust_tls_fast array, for the inline access (inl.h `lust_tls_cell`). */
#define LUST_TLS_FAST 512
#ifdef LUST_IMPL
const uint64_t lust_so_none = 0;
int lust_argc;
char **lust_argv;
const char *lust_file;
const uint32_t *lust_fn_line;
#endif

/* tcc predefines __STDC_VERSION__ as 199901L, so glibc hides the C11
   aligned_alloc declaration; without an explicit declaration tcc truncates
   its pointer return to int (spike K3-18). Declare both aligned entry
   points here. */
void *aligned_alloc(size_t alignment, size_t size);
int posix_memalign(void **memptr, size_t alignment, size_t size);

/* std's get_backtrace_style (panic.rs), read once per process: 1 Off
   (RUST_BACKTRACE unset or "0"), 2 Short (any other value), 3 Full
   ("full"). The default panic hook and the alloc error hook share it. */
#ifdef LUST_IMPL
static int32_t lust_bt_style_v;
#endif
int32_t lust_bt_style(void) LUST_BODY({
    int32_t s, zero = 0;
    __atomic_load(&lust_bt_style_v, &s, 0);
    if (s) return s;
    const char *e = getenv("RUST_BACKTRACE");
    s = !e || !strcmp(e, "0") ? 1 : !strcmp(e, "full") ? 3 : 2;
    if (!__atomic_compare_exchange(&lust_bt_style_v, &zero, &s, 0, 0, 0)) s = zero;
    return s;
})

/* The backtrace part of std's default hooks for `style`. lust has no
   frames, so Short and Full print only std's header (and Short its last
   note); difftest drops frame lines on both sides. Off prints the
   RUST_BACKTRACE note when `off_note` is set. */
void lust_bt_tail(int32_t style, int32_t off_note) LUST_BODY({
    if (style == 1 && off_note) fputs("note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n", stderr);
    else if (style == 2) fputs("stack backtrace:\nnote: Some details are omitted, run with `RUST_BACKTRACE=full` for a verbose backtrace.\n", stderr);
    else if (style == 3) fputs("stack backtrace:\n", stderr);
})

/* An allocation failure inside the runtime itself, where the size is not
   known. */
void lust_oom(void) LUST_BODY({
    fputs("memory allocation failed\n", stderr);
    lust_bt_tail(lust_bt_style(), 1);
    abort();
})

/* Rust's `capacity overflow` panic (RawVec, raw_vec/mod.rs:28:5): a requested byte size above
   isize::MAX, or a length sum that wraps usize. Defined before the
   String and Vec cores that call it. */
void lust_panic_std(const char *msg, const char *where); /* panic.c, included below */
void lust_panic_std_lit(const char *msg, const char *where);
void lust_vec_capacity_overflow(void) LUST_BODY({ lust_panic_std_lit("capacity overflow", "alloc/src/raw_vec/mod.rs:28:5"); })

/* std's rust_oom with the default alloc error hook (std/src/alloc.rs):
   `handle_alloc_error` for a layout of `n` bytes. The hook prints the
   RUST_BACKTRACE note on every call, not only the first. */
void lust_oom_size(uint64_t n) LUST_BODY({
    fprintf(stderr, "memory allocation of %llu bytes failed\n", (unsigned long long)n);
    lust_bt_tail(lust_bt_style(), 1);
    fflush(stderr);
    abort();
})

/* The `alloc(size, align)` intrinsic family (ARCH 3.2). `align` is a power
   of two, as Rust's Layout guarantees. Alignment up to 4 MiB works (the
   ts-rust jemalloc case). A zero size returns a dangling pointer with the
   requested alignment and allocates nothing; well-formed wrappers never
   ask for one, but the Vec core uses the same form for empty buffers.
   Every pointer these return can go to plain free(). */
void *lust_alloc(uint64_t size, uint64_t align) LUST_BODY({
    if (!size) return (void *)(uintptr_t)(align ? align : 1);
    void *p = 0;
#ifdef _WIN32
    p = align <= 16 ? malloc(size) : _aligned_malloc((size_t)size, (size_t)align);
#else
    if (align <= 16) p = malloc(size);
    else if ((size & (align - 1)) == 0) p = aligned_alloc(align, size);
    else if (posix_memalign(&p, align, size) != 0) p = 0;
#endif
    if (!p) lust_oom_size(size);
    return p;
})

/* std's System::alloc_zeroed: calloc when malloc's alignment is enough,
   so the pages stay untouched until used (`vec![0u8; n]` for a large n
   returns at once, as in Rust). */
void *lust_alloc_zeroed(uint64_t size, uint64_t align) LUST_BODY({
    if (!size) return (void *)(uintptr_t)(align ? align : 1);
    if (align <= 16) {
        void *p = calloc(size, 1);
        if (!p) lust_oom_size(size);
        return p;
    }
    void *p = lust_alloc(size, align);
    memset(p, 0, size);
    return p;
})

/* True when the `n` bytes at `p` are all zero. The `vec![x; n]` IsZero
   test for scalars and arrays of scalars (types without padding). */
int32_t lust_is_zeroed(const void *p, uint64_t n) LUST_BODY({
    const unsigned char *b = (const unsigned char *)p;
    for (uint64_t i = 0; i < n; i++) if (b[i]) return 0;
    return 1;
})

void lust_dealloc(void *ptr, uint64_t size, uint64_t align) LUST_BODY({
    if (!size) return;
#ifdef _WIN32
    if (align > 16) { _aligned_free(ptr); return; }
#endif
    (void)align;
    free(ptr);
})

/* An Rc/Arc count block's free (cgen `rc_head`): a unit that frees one may not know its
   value's size, and lust_dealloc reads no size but zero, which a count block never is. The
   same one call as lust_dealloc with the size. */
#define lust_rc_free(ptr, align) lust_dealloc((void *)(ptr), 1, (align))

/* realloc(ptr, old_size, align, new_size): the Rust GlobalAlloc argument
   order with Layout flattened. Always moves when the alignment exceeds
   what plain realloc promises; the copy is the smaller size. */
void *lust_realloc(void *ptr, uint64_t old_size, uint64_t align, uint64_t new_size) LUST_BODY({
    if (!new_size) {
        lust_dealloc(ptr, old_size, align);
        return (void *)(uintptr_t)(align ? align : 1);
    }
    if (!old_size) return lust_alloc(new_size, align);
    void *p = lust_alloc(new_size, align);
    memcpy(p, ptr, old_size < new_size ? old_size : new_size);
    lust_dealloc(ptr, old_size, align);
    return p;
})

/* Byte and raw-pointer intrinsics (ARCH 3.2). ptr_read and ptr_write are
   unaligned byte copies of `size` bytes: read is (dst, src, size), write
   is (dst, src, size), matching memcpy argument order. ptr_offset adds a
   signed byte offset carried in a usize. */
void lust_memcpy(void *dst, const void *src, uint64_t n) LUST_BODY({ memcpy(dst, src, n); })
void lust_memmove(void *dst, const void *src, uint64_t n) LUST_BODY({ memmove(dst, src, n); })
void lust_memset(void *dst, uint32_t byte, uint64_t n) LUST_BODY({ memset(dst, (int)byte, n); })
int32_t lust_memcmp(const void *a, const void *b, uint64_t n) LUST_BODY({ return memcmp(a, b, n); })
void lust_ptr_read(void *dst, const void *src, uint64_t size) LUST_BODY({ memcpy(dst, src, size); })
void lust_ptr_write(void *dst, const void *src, uint64_t size) LUST_BODY({ memcpy(dst, src, size); })
void *lust_ptr_offset(void *ptr, uint64_t offset) LUST_BODY({ return (char *)ptr + (int64_t)offset; })

/* ---------- Strings ---------- */

/* Empty buffers hold the dangling aligned pointer, never null, as in
   Rust: that is what makes the pointer-word niche of String and Vec
   valid (an empty value's pointer word is never a niche tag value). */
lust_String lust_string_new(void) LUST_BODY({ lust_String s = {(uint8_t *)(uintptr_t)1, 0, 0}; return s; })

/* String capacity follows the Vec<u8> RawVec rules below: minimum
   capacity 8, then max(cap * 2, len + extra) on the amortized path and
   exactly len + extra on the exact path. A len + extra sum that wraps
   usize, or a capacity above isize::MAX bytes, is a capacity overflow,
   as in the Vec core. */
void lust_string_reserve(lust_String *s, uint64_t extra) LUST_BODY({
    if (s->cap - s->len >= extra) return;
    uint64_t needed = s->len + extra;
    if (needed < s->len) { lust_vec_capacity_overflow(); return; }
    uint64_t cap = s->cap * 2;
    if (cap < needed) cap = needed;
    if (cap < 8) cap = 8;
    if (cap > (uint64_t)9223372036854775807ull) { lust_vec_capacity_overflow(); return; }
    s->ptr = lust_realloc(s->ptr, s->cap, 1, cap);
    s->cap = cap;
})

void lust_string_reserve_exact(lust_String *s, uint64_t extra) LUST_BODY({
    if (s->cap - s->len >= extra) return;
    uint64_t cap = s->len + extra;
    if (cap < s->len) { lust_vec_capacity_overflow(); return; }
    if (cap > (uint64_t)9223372036854775807ull) { lust_vec_capacity_overflow(); return; }
    s->ptr = lust_realloc(s->ptr, s->cap, 1, cap);
    s->cap = cap;
})

lust_String lust_string_with_capacity(uint64_t n) LUST_BODY({
    lust_String s = {(uint8_t *)(uintptr_t)1, 0, 0};
    if (n) {
        if (n > (uint64_t)9223372036854775807ull) { lust_vec_capacity_overflow(); return s; }
        s.ptr = lust_alloc(n, 1);
        s.cap = n;
    }
    return s;
})

void lust_string_push_bytes(lust_String *s, const void *p, uint64_t n) LUST_BODY({
    if (!n) return;
    lust_string_reserve(s, n);
    lust_copy_small(s->ptr + s->len, p, n);
    s->len += n;
})

void lust_string_push_str(lust_String *s, lust_str x) LUST_BODY({ lust_string_push_bytes(s, x.ptr, x.len); })

void lust_string_push_cstr(lust_String *s, const char *c) LUST_BODY({ lust_string_push_bytes(s, c, strlen(c)); })

void lust_string_push_char(lust_String *s, uint32_t c) LUST_BODY({
    uint8_t b[4];
    int n;
    if (c < 0x80) { b[0] = c; n = 1; }
    else if (c < 0x800) { b[0] = 0xC0 | (c >> 6); b[1] = 0x80 | (c & 0x3F); n = 2; }
    else if (c < 0x10000) { b[0] = 0xE0 | (c >> 12); b[1] = 0x80 | ((c >> 6) & 0x3F); b[2] = 0x80 | (c & 0x3F); n = 3; }
    else { b[0] = 0xF0 | (c >> 18); b[1] = 0x80 | ((c >> 12) & 0x3F); b[2] = 0x80 | ((c >> 6) & 0x3F); b[3] = 0x80 | (c & 0x3F); n = 4; }
    lust_string_push_bytes(s, b, n);
})

lust_String lust_string_from(lust_str x) LUST_BODY({
    lust_String s = lust_string_with_capacity(x.len);
    lust_string_push_str(&s, x);
    return s;
})

lust_str lust_string_as_str(lust_String *s) LUST_BODY({ lust_str r; r.ptr = s->ptr; r.len = s->len; return r; })
lust_String lust_string_clone(lust_String *s) LUST_BODY({ return lust_string_from(lust_string_as_str(s)); })
void lust_string_drop(lust_String *s) LUST_BODY({ lust_dealloc(s->ptr, s->cap, 1); })

int lust_str_cmp(lust_str a, lust_str b) LUST_BODY({
    uint64_t n = a.len < b.len ? a.len : b.len;
    int c = n ? memcmp(a.ptr, b.ptr, n) : 0;
    if (c) return c;
    return a.len < b.len ? -1 : a.len > b.len ? 1 : 0;
})
uint8_t lust_str_eq(lust_str a, lust_str b) LUST_BODY({ return a.len == b.len && (a.len == 0 || memcmp(a.ptr, b.ptr, a.len) == 0); })

/* ---------- Panics (abort mode) ----------
   Matches rustc 1.99 with -C panic=abort: the default hook prints
       \nthread '<name>' (<os tid>) panicked at <file>:<line>:<col>:\n<msg>\nnote: ...\n
   to stderr, then the process aborts (SIGABRT, shell status 134). Stdout
   is Rust's LineWriter (below): an abort loses the bytes it still holds. */

#ifdef LUST_IMPL
#ifndef _WIN32
#include <unistd.h>
#endif
#include <errno.h>
#include <signal.h>
#ifdef __APPLE__
#include <pthread.h>
#elif !defined(_WIN32)
#include <sys/syscall.h>
#endif

/* The OS thread id Rust's default hook prints (`thread::current_os_id`). */
static unsigned long long lust_os_tid(void) {
#ifdef _WIN32
    return (unsigned long long)GetCurrentThreadId();
#elif defined(__APPLE__)
    uint64_t t = 0;
    pthread_threadid_np(NULL, &t);
    return (unsigned long long)t;
#else
    return (unsigned long long)syscall(SYS_gettid);
#endif
}

/* Std source locations of panics that Rust raises inside std (no
   track_caller), as rustc 1.99 prints them. */
#define LUST_STD_SRC "/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4/library/"
#endif

/* ---------- Unwinding (panic=unwind, ARCH 7.2) ----------
   Explicit propagation: a panic runs the hook, then marks an exception
   pending on its thread and returns. Generated code checks after each
   call and each statement that can panic: when its thread has a pending
   exception, the frame takes it (`lust_unw_take`) into its own `ex`,
   runs its cleanup blocks (the drops of its live locals, as normal
   code), and gives it back (`lust_unw_resume`) as it returns. So while
   a frame cleans up, nothing is pending and the destructors it calls
   run normally. A destructor that ends with a new pending exception
   during cleanup aborts (`lust_unw_cleanup_abort`).
   `lust_unw_pending` counts threads with a pending exception: 0 in
   almost every run, so the fast path of every check is one load. No C
   TLS (tcc breaks it in shared objects): thread state is under a
   pthread key. A panic while its thread already has a pending exception
   comes from code that runs on after the first panic in the same C
   statement (it uses only safe placeholder values); it does nothing.
   `lust_unwind_mode` is 0 (panic=abort: every panic aborts, as before)
   unless main sets it. The runtime object is the same in both modes.
   Mode 2 (unwind tables, a clang or gcc build with -fexceptions; below)
   has no pending state: a panic throws a C++ exception (unwind.cc) that
   runs each frame's cleanup variable, and catch points catch it. */
typedef struct {
    uint32_t kind; /* LUST_EXC_STR, LUST_EXC_STRING, or LUST_EXC_BOX */
    lust_str s;    /* the message bytes; LUST_EXC_STRING owns them */
    lust_dyn box;  /* LUST_EXC_BOX: a Box<dyn Any + Send> */
} lust_exc;
#define LUST_EXC_STR 0u
#define LUST_EXC_STRING 1u
#define LUST_EXC_BOX 2u
extern int32_t lust_unwind_mode;
extern int32_t lust_unw_pending;
/* The checks codegen emits (cgen/unwind.rs): take a new exception and
   run the cleanup from block b, or abort inside cleanup. */
#define LUST_UNW(b) if (lust_unw_pending && lust_unw_take(&ex)) goto bb##b
#define LUST_UNW_ABORT() if (lust_unw_pending && lust_unw_mine()) lust_unw_cleanup_abort()
#ifdef LUST_IMPL
int32_t lust_unwind_mode;
int32_t lust_unw_pending;
/* Hand pthread declarations for tcc on Linux; on Darwin the real
   <pthread.h> is included above (runtime.h has the type spellings),
   and on Windows runtime.h maps these names to its Win32 wrappers. */
#if !defined(__APPLE__) && !defined(_WIN32)
int pthread_key_create(unsigned int *key, void (*dtor)(void *));
void *pthread_getspecific(unsigned int key);
int pthread_setspecific(unsigned int key, const void *v);
int pthread_once(int *once, void (*init)(void));
#endif

/* One thread's panic state. `count` is Rust's local panic count: it
   rises when a panic starts and falls when a catch takes it, so
   `thread::panicking()` is `count > 0`. */
typedef struct {
    int32_t count;
    int32_t in_hook;
    int32_t pending;
    lust_exc exc;
    /* A panic message with arguments is being formatted (std formats
       it lazily inside the panic, before the hook prints): a panic
       now is a panic in the hook, which prints the inner message
       (blank when `msg_dyn`: it has arguments) and aborts in both
       modes. */
    int32_t in_fmt;
    int32_t msg_dyn;
    /* While a custom hook runs: its panic's payload and location. */
    lust_dyn hook_payload;
    void *hook_loc;
    /* Mode 2: the innermost catch point, the innermost unwind in flight,
       and the unwind the last catch took. */
    struct lust_catch *top;
    struct lust_uexc *unwinding;
    struct lust_uexc *caught;
} lust_unw_state;
#ifndef __TINYC__
static void lust_unw_eh_raise(lust_unw_state *s, lust_exc *ex) __attribute__((noreturn));
#endif
static lust_pthread_key_t lust_unw_key;
static lust_pthread_once_t lust_unw_once = LUST_PTHREAD_ONCE_INIT;
/* Rust's FIRST_PANIC: the backtrace note prints for the first panic only. */
static int32_t lust_first_panic = 1;

/* Set once the key exists (as thread.c's lust_tls_ready). */
static int lust_unw_ready;
static void lust_unw_make_key(void) {
    if (pthread_key_create(&lust_unw_key, free) != 0) abort();
    int one = 1;
    __atomic_store(&lust_unw_ready, &one, 3);
}
static lust_unw_state *lust_unw_get(void) {
    pthread_once(&lust_unw_once, lust_unw_make_key);
    lust_unw_state *s = (lust_unw_state *)pthread_getspecific(lust_unw_key);
    if (!s) {
        s = (lust_unw_state *)calloc(1, sizeof *s);
        if (!s) abort();
        pthread_setspecific(lust_unw_key, s);
    }
    return s;
}
/* The calling thread's state, or NULL when it never panicked. */
static lust_unw_state *lust_unw_peek(void) {
    int ready;
    __atomic_load(&lust_unw_ready, &ready, 2);
    if (!ready) return 0;
    return (lust_unw_state *)pthread_getspecific(lust_unw_key);
}
/* A panic while a panic message formats (std formats it lazily, inside
   the panic): Rust's nested-panic abort, printing the inner message
   (blank when it has arguments: `msg_dyn`). Else clears `msg_dyn`. */
static void lust_fmt_nested_check(const uint8_t *msg, uint64_t len, const char *file, uint32_t line, uint32_t col) {
    lust_unw_state *st = lust_unw_peek();
    if (st && st->in_fmt) {
        fprintf(stderr, "panicked at %s:%u:%u:\n%.*s\nthread panicked while processing panic. aborting.\n", file, (unsigned)line, (unsigned)col,
                st->msg_dyn ? 0 : (int)len, (const char *)msg);
        fflush(stderr);
        abort();
    }
    if (st) st->msg_dyn = 0;
}

static void lust_unw_set_pending(lust_unw_state *s, lust_exc *ex) {
    s->exc = *ex;
    s->pending = 1;
    __atomic_add_fetch(&lust_unw_pending, 1, 5);
}

/* Rust's FIRST_PANIC swap: 1 for the process's first panic only. */
static int32_t lust_first_panic_take(void) {
    int32_t zero = 0, old;
    __atomic_exchange(&lust_first_panic, &zero, &old, 0);
    return old;
}

/* The calling thread's name (runtime/sync.c). */
static void lust_cur_thread_name(const uint8_t **p, uint64_t *n);

/* The default hook's text (std's default_hook) on the current thread. */
static void lust_default_hook(const uint8_t *msg, uint64_t len, const char *file, uint64_t flen, uint32_t line, uint32_t col, int32_t count) {
    const uint8_t *tn;
    uint64_t tl;
    lust_cur_thread_name(&tn, &tl);
    fprintf(stderr, "\nthread '%.*s' (%llu) panicked at %.*s:%u:%u:\n%.*s\n", (int)tl, (const char *)tn, lust_os_tid(), (int)flen, file, (unsigned)line, (unsigned)col, (int)len,
            (const char *)msg);
    /* A panic while panicking prints a full backtrace in Rust; FIRST_PANIC
       is only taken when the style is Off. */
    int32_t bt = count >= 2 ? 3 : lust_bt_style();
    lust_bt_tail(bt, bt == 1 && lust_first_panic_take());
    fflush(stderr);
}

/* The type ids of `&'static str` and `String` (check/any.rs) and the
   Box<dyn Any + Send> vtables of the two message payloads (drop, size,
   align, the two fmt shims (0 here: `Any` has no fmt supertrait), then
   the type id words at VT_ANY_ID: check/object.rs). Main sets them
   when the program unwinds or installs a hook (`lust_unw_init`). */
static uint64_t lust_any_ids[4];
static const void *lust_vt_str[7], *lust_vt_string[7];

/* `panic::set_hook` (std source, library/std/src/panic.rs): while a hook
   is installed, a panic calls the std runner with the payload and
   location, which calls the hook. Main registers the runner. */
typedef struct { lust_str file; uint32_t line, col; } lust_location;
static int32_t lust_hook_on;
static lust_Unit (*lust_hook_runner)(uint8_t can_unwind);

/* Runs the hook for a panic starting with payload `ex` (message text
   `msg`), as std's rust_panic_with_hook: a panic inside the hook aborts
   at once; else the custom hook, or the default text. */
static void lust_run_hook(lust_exc *ex, const uint8_t *msg, uint64_t len, const char *file, uint32_t line, uint32_t col, int32_t count, int32_t *in_hook) {
    if (*in_hook) {
        fprintf(stderr, "panicked at %s:%u:%u:\n%.*s\nthread panicked while processing panic. aborting.\n", file, (unsigned)line, (unsigned)col, (int)len, (const char *)msg);
        fflush(stderr);
        abort();
    }
    *in_hook = 1;
    if (lust_hook_on && lust_hook_runner) {
        lust_location loc;
        loc.file.ptr = (uint8_t *)file;
        loc.file.len = strlen(file);
        loc.line = line;
        loc.col = col;
        lust_str sv = ex->s;
        lust_String so;
        so.ptr = ex->s.ptr;
        so.len = ex->s.len;
        so.cap = ex->s.len;
        lust_dyn p;
        if (ex->kind == LUST_EXC_BOX) p = ex->box;
        else if (ex->kind == LUST_EXC_STR) { p.data = &sv; p.vt = lust_vt_str; }
        else { p.data = &so; p.vt = lust_vt_string; }
        lust_unw_state *st = lust_unw_get();
        st->hook_payload = p;
        st->hook_loc = &loc;
        lust_hook_runner(lust_unwind_mode ? 1 : 0);
        st->hook_loc = 0;
    } else {
        lust_default_hook(msg, len, file, strlen(file), line, col, count);
    }
    *in_hook = 0;
}

/* A panic under panic=abort with a hook installed: the hook, then abort
   (no hook: callers print the default text themselves). */
static void lust_abort_hooked(lust_exc *ex, const uint8_t *msg, uint64_t len, const char *file, uint32_t line, uint32_t col) {
    lust_unw_state *s = lust_unw_get();
    if (!s->in_hook) s->count++;
    lust_run_hook(ex, msg, len, file, line, col, s->count, &s->in_hook);
    fflush(stderr);
    abort();
}

/* Starts a panic in unwind mode: the hook (with `msg`, the payload's
   text), then `ex` pending. */
static void lust_unw_raise_exc(lust_exc *ex, const uint8_t *msg, uint64_t len, const char *file, uint32_t line, uint32_t col) {
    lust_unw_state *s = lust_unw_get();
    if (s->pending) return;
    if (!s->in_hook) s->count++;
    lust_run_hook(ex, msg, len, file, line, col, s->count, &s->in_hook);
#ifndef __TINYC__
    if (lust_unwind_mode == 2) lust_unw_eh_raise(s, ex);
#endif
    lust_unw_set_pending(s, ex);
}

/* A message panic: the payload is a `&'static str` (LUST_EXC_STR, when
   Rust's message is a literal) or a `String` with the message. A STR
   payload keeps its copy for the rest of the run, as a static does. */
/* The copies behind STR payloads: they live to the end of the run, on
   this list so they stay reachable. */
typedef struct lust_static_msg { struct lust_static_msg *next; uint8_t bytes[]; } lust_static_msg;
static lust_static_msg *lust_static_msgs;
static uint8_t *lust_static_copy(const uint8_t *msg, uint64_t len) {
    lust_static_msg *m = (lust_static_msg *)malloc(sizeof(lust_static_msg) + len + 1);
    if (!m) abort();
    if (len) memcpy(m->bytes, msg, len);
    lust_static_msg *head;
    do { __atomic_load(&lust_static_msgs, &head, 2); m->next = head; } while (!__atomic_compare_exchange(&lust_static_msgs, &head, &m, 0, 3, 2));
    return m->bytes;
}

static void lust_unw_raise(uint32_t kind, const uint8_t *msg, uint64_t len, const char *file, uint32_t line, uint32_t col) {
    lust_exc ex;
    ex.kind = kind;
    ex.box.data = 0;
    ex.box.vt = 0;
    if (!lust_unwind_mode) {
        ex.s.ptr = (uint8_t *)msg;
        ex.s.len = len;
        lust_abort_hooked(&ex, msg, len, file, line, col);
    }
    if (kind == LUST_EXC_STR) {
        ex.s.ptr = lust_static_copy(msg, len);
    } else {
        ex.s.ptr = (uint8_t *)lust_alloc(len, 1);
        if (len) memcpy(ex.s.ptr, msg, len);
    }
    ex.s.len = len;
    ex.box.data = 0;
    ex.box.vt = 0;
    lust_unw_raise_exc(&ex, msg, len, file, line, col);
}

/* The text of a payload, as std's default hook finds it: a `&str` or a
   `String`, else "Box<dyn Any>". */
static lust_str lust_exc_text(lust_exc *ex) {
    lust_str r = ex->s;
    if (ex->kind != LUST_EXC_BOX) return r;
    const void *const *vt = ex->box.vt;
    uint64_t lo = (uint64_t)(uintptr_t)vt[5], hi = (uint64_t)(uintptr_t)vt[6];
    if (lo == lust_any_ids[0] && hi == lust_any_ids[1]) return *(lust_str *)ex->box.data;
    if (lo == lust_any_ids[2] && hi == lust_any_ids[3]) return lust_string_as_str((lust_String *)ex->box.data);
    r.ptr = (uint8_t *)"Box<dyn Any>";
    r.len = 12;
    return r;
}

/* The payload as the Box<dyn Any + Send> a catch returns. */
static lust_dyn lust_exc_box(lust_exc *ex) {
    lust_dyn d;
    if (ex->kind == LUST_EXC_BOX) return ex->box;
    if (ex->kind == LUST_EXC_STR) {
        lust_str *p = (lust_str *)lust_alloc(sizeof(lust_str), 8);
        *p = ex->s;
        d.data = p;
        d.vt = lust_vt_str;
        return d;
    }
    lust_String *p = (lust_String *)lust_alloc(sizeof(lust_String), 8);
    p->ptr = ex->s.ptr;
    p->len = ex->s.len;
    p->cap = ex->s.len;
    d.data = p;
    d.vt = lust_vt_string;
    return d;
}

/* Frees an exception's payload (an uncaught one at a thread root). */
static void lust_exc_drop(lust_exc *ex) {
    if (ex->kind == LUST_EXC_STRING) lust_dealloc(ex->s.ptr, ex->s.len, 1);
    if (ex->kind == LUST_EXC_BOX) {
        if (ex->box.vt[0]) ((void (*)(void *))ex->box.vt[0])(ex->box.data);
        lust_dealloc(ex->box.data, (uint64_t)(uintptr_t)ex->box.vt[1], (uint64_t)(uintptr_t)ex->box.vt[2]);
    }
}
#endif

/* Takes the calling thread's pending exception into `ex` (a frame starts
   its cleanup): 1, or 0 when this thread has none. */
int32_t lust_unw_take(lust_exc *ex) LUST_BODY({
    lust_unw_state *s = lust_unw_peek();
    if (!s || !s->pending) return 0;
    *ex = s->exc;
    s->pending = 0;
    __atomic_sub_fetch(&lust_unw_pending, 1, 5);
    return 1;
})

/* Makes `ex` pending again: the frame's cleanup is done and it returns. */
void lust_unw_resume(lust_exc *ex) LUST_BODY({ lust_unw_set_pending(lust_unw_get(), ex); })

/* `thread::panicking()`: a panic started on this thread and no catch
   has taken it yet. */
uint8_t lust_unw_panicking(void) LUST_BODY({
    lust_unw_state *s = lust_unw_peek();
    return s && s->count > 0;
})

/* 1 when the calling thread has a pending exception. */
int32_t lust_unw_mine(void) LUST_BODY({
    lust_unw_state *s = lust_unw_peek();
    return s && s->pending;
})

/* A destructor that cleanup called ended with a new exception: Rust's
   nounwind "panic in a destructor during cleanup", then abort. */
void lust_unw_cleanup_abort(void) LUST_BODY({
    const uint8_t *tn;
    uint64_t tl;
    lust_cur_thread_name(&tn, &tl);
    fprintf(stderr, "\nthread '%.*s' (%llu) panicked at " LUST_STD_SRC "core/src/panicking.rs:233:5:\npanic in a destructor during cleanup\nthread caused non-unwinding panic. aborting.\n",
            (int)tl, (const char *)tn, lust_os_tid());
    fflush(stderr);
    abort();
})

/* One step of drop glue that keeps dropping after a panic (Rust drops the
   other fields and elements as cleanup): the first exception moves into
   `ex` and sets `*u`; one more aborts. The glue resumes `ex` at its end. */
void lust_unw_dstep(lust_exc *ex, int32_t *u) LUST_BODY({
    if (!lust_unw_mine()) return;
    if (*u) lust_unw_cleanup_abort();
    lust_unw_take(ex);
    *u = 1;
})

#ifdef LUST_IMPL
#ifndef __TINYC__
/* ---------- Unwind tables (lust_unwind_mode 2) ----------
   A clang or gcc build compiles every unit with -fexceptions. A frame
   with drops has one cleanup variable (cgen: the frame struct, with the
   locals its cleanup ladder reads and the ladder entry stored before
   each call that can unwind); builtins that own a value add small
   guards. A panic runs the hook, then throws a C++ exception of a
   private type (runtime/unwind.cc): the platform's C++ personality
   unwinds, running those cleanups frame by frame, to the innermost
   catch point (`lust_unw_try`: catch_unwind, a thread root, main), the
   only place that catches it. Nothing runs after a call to check for a
   panic, so a panic never returns. */
void lust_unw_cxx_throw(void *x) __attribute__((noreturn));
int32_t lust_unw_cxx_try(void (*f)(void *), void *ctx, void **caught);
/* Weak fallbacks for a build without the C++ unit (a release build with
   panic=abort or LUST_UNWIND_TABLES=0, gcc's sanitized builds): mode 2
   never runs there. runtime/unwind.cc's definitions replace them. */
__attribute__((weak, noreturn)) void lust_unw_cxx_throw(void *x) {
    (void)x;
    abort();
}
__attribute__((weak)) int32_t lust_unw_cxx_try(void (*f)(void *), void *ctx, void **caught) {
    (void)caught;
    f(ctx);
    return 0;
}
struct lust_catch { struct lust_catch *prev; int32_t in_glue; };
struct lust_uexc {
    lust_exc exc;
    struct lust_catch *target; /* the catch point this unwind goes to */
    struct lust_uexc *outer;   /* the unwind in flight when this one began */
};
/* The innermost catch point that is not drop glue's (`lust_unw_dtry`): a panic
   in a drop that cleanup runs aborts even when glue would catch it. */
static struct lust_catch *lust_unw_outer_catch(struct lust_catch *c) {
    while (c && c->in_glue) c = c->prev;
    return c;
}
/* Throws `x`. A panic that would leave the cleanup of an unwind in flight (no
   catch point began since that unwind did) is Rust's "panic in a destructor
   during cleanup": it aborts before the throw, so no exception ever leaves a
   cleanup variable's fn. */
static void lust_unw_eh_go(lust_unw_state *s, struct lust_uexc *x) __attribute__((noreturn));
static void lust_unw_eh_go(lust_unw_state *s, struct lust_uexc *x) {
    if (!s->top) abort();
    if (s->unwinding && lust_unw_outer_catch(s->top) == s->unwinding->target) lust_unw_cleanup_abort();
    x->target = s->top;
    x->outer = s->unwinding;
    s->unwinding = x;
    lust_unw_cxx_throw(x);
}
/* Raises `ex` (its hook already ran). */
static void lust_unw_eh_raise(lust_unw_state *s, lust_exc *ex) {
    struct lust_uexc *x = (struct lust_uexc *)calloc(1, sizeof *x);
    if (!x) abort();
    x->exc = *ex;
    lust_unw_eh_go(s, x);
}
/* Runs f(ctx) under a catch point (`in_glue` for drop glue's). A caught
   unwind is no longer in flight. */
static int32_t lust_unw_catch_at(void (*f)(void *), void *ctx, int32_t in_glue, struct lust_uexc **out) {
    lust_unw_state *s = lust_unw_get();
    struct lust_catch c;
    c.prev = s->top;
    c.in_glue = in_glue;
    s->top = &c;
    void *x = 0;
    int32_t r = lust_unw_cxx_try(f, ctx, &x);
    s->top = c.prev;
    if (r) {
        struct lust_uexc *u = (struct lust_uexc *)x;
        s->unwinding = u->outer;
        *out = u;
    }
    return r;
}
int32_t lust_unw_try(void (*f)(void *), void *ctx) {
    struct lust_uexc *u = 0;
    if (!lust_unw_catch_at(f, ctx, 0, &u)) return 0;
    lust_unw_get()->caught = u;
    return 1;
}
/* A drop in drop glue that can panic (a user Drop, a dyn drop): Rust drops
   the other fields as cleanup and passes the panic on at the glue's end
   (`lust_unw_reraise`). The first panic's record is kept in `*ux`; a second
   one in the same glue aborts. */
void lust_unw_dtry(void (*f)(void *), void *arg, void **ux) {
    struct lust_uexc *u = 0;
    if (!lust_unw_catch_at(f, arg, 1, &u)) return;
    if (*ux) lust_unw_cleanup_abort();
    *ux = u;
}
/* The end of drop glue that caught a panic: it unwinds on (no hook; the panic
   count stays). */
void lust_unw_reraise(void *ux) { lust_unw_eh_go(lust_unw_get(), (struct lust_uexc *)ux); }
static void lust_unw_eh_take(lust_exc *ex) {
    lust_unw_state *s = lust_unw_get();
    struct lust_uexc *x = s->caught;
    s->caught = 0;
    *ex = x->exc;
    free(x);
}
#else
int32_t lust_unw_try(void (*f)(void *), void *ctx) {
    f(ctx);
    return 0;
}
void lust_unw_dtry(void (*f)(void *), void *arg, void **ux) {
    (void)ux;
    f(arg);
}
void lust_unw_reraise(void *ux) {
    (void)ux;
    abort();
}
static void lust_unw_eh_take(lust_exc *ex) { (void)ex; abort(); }
#endif
/* A raise in either unwind mode: mode 2 never returns, mode 1 leaves the
   exception pending. */
static void lust_unw_raise_or_pend(lust_unw_state *s, lust_exc *ex) {
#ifndef __TINYC__
    if (lust_unwind_mode == 2) lust_unw_eh_raise(s, ex);
#endif
    lust_unw_set_pending(s, ex);
}
/* The exception a catch took: mode 2's caught one, else the pending one. */
static void lust_unw_take_any(lust_exc *ex) {
    if (lust_unwind_mode == 2) lust_unw_eh_take(ex);
    else lust_unw_take(ex);
}
#endif

/* Setup from main: the payload type ids (see lust_any_ids), and whether
   panics unwind. */
void lust_unw_init(int32_t unwind, uint64_t str_lo, uint64_t str_hi, uint64_t string_lo, uint64_t string_hi) LUST_BODY({
    lust_unwind_mode = unwind;
    lust_any_ids[0] = str_lo;
    lust_any_ids[1] = str_hi;
    lust_any_ids[2] = string_lo;
    lust_any_ids[3] = string_hi;
    lust_vt_str[0] = 0;
    lust_vt_str[1] = (const void *)(uintptr_t)sizeof(lust_str);
    lust_vt_str[2] = (const void *)(uintptr_t)8;
    lust_vt_str[3] = 0;
    lust_vt_str[4] = 0;
    lust_vt_str[5] = (const void *)(uintptr_t)str_lo;
    lust_vt_str[6] = (const void *)(uintptr_t)str_hi;
    lust_vt_string[0] = (const void *)lust_string_drop;
    lust_vt_string[1] = (const void *)(uintptr_t)sizeof(lust_String);
    lust_vt_string[2] = (const void *)(uintptr_t)8;
    lust_vt_string[3] = 0;
    lust_vt_string[4] = 0;
    lust_vt_string[5] = (const void *)(uintptr_t)string_lo;
    lust_vt_string[6] = (const void *)(uintptr_t)string_hi;
})

#ifdef LUST_IMPL
/* std's hook (`Option<Box<dyn Fn(&PanicHookInfo) + Sync + Send>>`, std
   source), stored here as bytes: all zero is None. */
static uint64_t lust_hook_bytes[4];
static int32_t lust_hook_lock;
#endif

/* `core::intrinsics::panic_hook_swap`: swaps `n` bytes at `v` with the
   hook slot. */
void lust_hook_swap(void *v, uint64_t n) LUST_BODY({
    int32_t one = 1, zero = 0, old;
    do { __atomic_exchange(&lust_hook_lock, &one, &old, 2); } while (old);
    uint8_t tmp[sizeof lust_hook_bytes];
    if (n > sizeof tmp) abort();
    memcpy(tmp, lust_hook_bytes, n);
    memcpy(lust_hook_bytes, v, n);
    memcpy(v, tmp, n);
    __atomic_store(&lust_hook_lock, &zero, 3);
})

/* `core::intrinsics::panic_hook_ref`: the hook slot. */
void *lust_hook_slot(void) LUST_BODY({ return lust_hook_bytes; })

/* Main registers set_hook's runner (`__lust_run_hook`'s slot). */
void lust_hook_set_runner(lust_fnptr f) LUST_BODY({ lust_hook_runner = (lust_Unit (*)(uint8_t))f; })

/* `core::intrinsics::panic_hook_payload` and `panic_hook_location`: the
   panic the calling thread's hook runs for. */
lust_dyn lust_hook_payload(void) LUST_BODY({ return lust_unw_get()->hook_payload; })
void *lust_hook_location(void) LUST_BODY({ return lust_unw_get()->hook_loc; })

/* `core::intrinsics::panic_hook_custom`: set_hook installed a hook (1),
   or take_hook removed it (0). */
void lust_hook_custom(uint8_t on) LUST_BODY({
    int32_t v = on;
    __atomic_store(&lust_hook_on, &v, 3);
})

/* `core::intrinsics::panic_default_hook`: std's default hook text, for a
   hook that `take_hook` returned (on the calling thread's panic). */
void lust_hook_default(lust_str file, uint32_t line, uint32_t col, lust_str msg) LUST_BODY({
    lust_unw_state *s = lust_unw_peek();
    lust_default_hook(msg.ptr, msg.len, (const char *)file.ptr, file.len, line, col, s ? s->count : 1);
})

/* `catch_unwind`'s Err: takes the calling thread's pending exception
   (the caller saw `lust_unw_mine`; in mode 2 the one its catch point
   caught), ends its panic (the count falls), and returns the payload as
   a Box<dyn Any + Send>. */
lust_dyn lust_unw_catch(void) LUST_BODY({
    lust_exc ex;
    lust_unw_take_any(&ex);
    lust_unw_get()->count--;
    return lust_exc_box(&ex);
})

/* Unwind tables: a builtin's cleanup variable for a value it owns (cgen
   `zc_guard`): the value drops when a panic unwinds before the builtin
   disarms it. */
struct lust_dguard { void (*drop)(void *); void *p; int32_t armed; };
void lust_dguard_end(struct lust_dguard *g) LUST_BODY({
    if (g->armed) g->drop(g->p);
})
/* `retain` under unwind tables: when the predicate or a rejected element's
   drop panics, the unprocessed rest moves down behind the kept elements
   (std's `BackshiftOnDrop`), so nothing is lost or dropped twice. */
struct lust_retain_guard { lust_Vec *v; uint64_t *r; uint64_t *w; uint64_t es; int32_t armed; };
void lust_retain_guard_end(struct lust_retain_guard *g) LUST_BODY({
    if (!g->armed) return;
    uint64_t r = *g->r, w = *g->w, n = g->v->len - r;
    if (n && w != r) memmove((char *)g->v->ptr + w * g->es, (char *)g->v->ptr + r * g->es, n * g->es);
    g->v->len = w + n;
})

/* Mode 2: after main's catch point caught a panic, std's lang_start drops
   the payload and the process exits with 101. */
int32_t lust_unw_main_caught(void) LUST_BODY({
    lust_exc ex;
    lust_unw_take_any(&ex);
    lust_exc_drop(&ex);
    return 101;
})

/* `resume_unwind(payload)`: the payload unwinds again with no hook. */
void lust_unw_resume_box(lust_dyn b) LUST_BODY({
    if (!lust_unwind_mode) abort();
    lust_unw_state *s = lust_unw_get();
    if (s->pending) return;
    s->count++;
    lust_exc ex;
    ex.kind = LUST_EXC_BOX;
    ex.box = b;
    ex.s.ptr = 0;
    ex.s.len = 0;
    lust_unw_raise_or_pend(s, &ex);
})

/* After `main` returns: 101 when it ended by a panic (std's lang_start
   catches it and drops the payload), else 0. */
int32_t lust_unw_main_exit(void) LUST_BODY({
    lust_exc ex;
    if (!lust_unw_pending || !lust_unw_take(&ex)) return 0;
    lust_exc_drop(&ex);
    return 101;
})

/* Prints the default hook text for `msg` at `file:line:col` and aborts;
   in unwind mode it raises the panic and returns. */
void lust_panic_at(const uint8_t *msg, uint64_t len, const char *file, uint32_t line, uint32_t col) LUST_BODY({
    lust_fmt_nested_check(msg, len, file, line, col);
    if (lust_unwind_mode || lust_hook_on) {
        lust_unw_raise(LUST_EXC_STRING, msg, len, file, line, col);
        return;
    }
    const uint8_t *tn;
    uint64_t tl;
    lust_cur_thread_name(&tn, &tl);
    fprintf(stderr, "\nthread '%.*s' (%llu) panicked at %s:%u:%u:\n%.*s\n", (int)tl, (const char *)tn, lust_os_tid(), file, (unsigned)line, (unsigned)col, (int)len,
            (const char *)msg);
    int32_t bt = lust_bt_style();
    lust_bt_tail(bt, bt == 1 && lust_first_panic_take());
    fflush(stderr);
    abort();
})

/* A std source location in a lust_loc (cgen's `std_loc`): the slot
   field (the top 24 bits) is LUST_STD_SLOT plus an index into
   lust_std_files, the line and col fields are absolute. Index bit
   LUST_STD_POW marks `pow`, whose overflow says "exponentiate" where
   its multiply says "multiply". */
#define LUST_STD_SLOT 0xFFFF00u
#define LUST_STD_POW 0x40u
#ifdef LUST_IMPL
static const char *const lust_std_files[] = {
    LUST_STD_SRC "core/src/num/mod.rs",
    LUST_STD_SRC "core/src/char/methods.rs",
    LUST_STD_SRC "core/src/char/convert.rs",
    LUST_STD_SRC "alloc/src/vec/mod.rs",
    LUST_STD_SRC "core/src/cmp.rs",
    LUST_STD_SRC "core/src/iter/adapters/step_by.rs",
    LUST_STD_SRC "alloc/src/vec/spec_from_iter_nested.rs",
    LUST_STD_SRC "core/src/iter/traits/accum.rs",
    LUST_STD_SRC "core/src/iter/range.rs",
    LUST_STD_SRC "core/src/cell.rs",
    LUST_STD_SRC "std/src/thread/local.rs",
    LUST_STD_SRC "core/src/ops/arith.rs",
    LUST_STD_SRC "core/src/slice/index.rs",
    LUST_STD_SRC "core/src/iter/traits/exact_size.rs",
    LUST_STD_SRC "core/src/slice/mod.rs",
    LUST_STD_SRC "core/src/ops/function.rs",
    LUST_STD_SRC "std/src/env.rs",
    /* The files of std source markers (src/stdloc.rs STD_FILES). */
    LUST_STD_SRC "core/src/time.rs",
    LUST_STD_SRC "std/src/time.rs",
    LUST_STD_SRC "alloc/src/collections/btree/search.rs",
    LUST_STD_SRC "alloc/src/collections/vec_deque/mod.rs",
    LUST_STD_SRC "std/src/path.rs",
    LUST_STD_SRC "std/src/panicking.rs",
    LUST_STD_SRC "core/src/cell/once.rs",
    LUST_STD_SRC "core/src/cell/lazy.rs",
    LUST_STD_SRC "std/src/sync/lazy_lock.rs",
    LUST_STD_SRC "core/src/io/write.rs",
    LUST_STD_SRC "alloc/src/io/read.rs",
    LUST_STD_SRC "alloc/src/io/impls.rs",
    LUST_STD_SRC "core/src/io/borrowed_buf.rs",
    LUST_STD_SRC "alloc/src/rc.rs",
    LUST_STD_SRC "alloc/src/sync.rs",
    LUST_STD_SRC "core/src/str/mod.rs",
    LUST_STD_SRC "std/src/os/unix/fs.rs",
    LUST_STD_SRC "alloc/src/str.rs",
};
#endif

/* Per-slot source files, set by the main unit when the crate has more
   than one file: slot s's fn lives in lust_files[lust_slot_file[s]].
   NULL for a one-file crate, which uses lust_file. */
extern const char *const *lust_files;
extern const uint32_t *lust_slot_file;
#ifdef LUST_IMPL
const char *const *lust_files;
const uint32_t *lust_slot_file;
#endif

#ifdef LUST_IMPL
/* A message panic at a packed location; `kind` is the unwind payload's
   type (LUST_EXC_STR or LUST_EXC_STRING), as Rust picks it per site.
   Under panic=unwind every lust_panic_* call returns with the exception
   pending, and the caller's frame unwinds at its next check. A runtime
   helper that panics must return at once, with no more writes: Rust
   leaves memory and output as they were at the panic. */
static void lust_panic_kind(uint32_t kind, const uint8_t *p, uint64_t n, lust_loc loc) {
    uint32_t slot = (uint32_t)(loc >> 40);
    const char *file;
    uint32_t line;
    if (slot >= LUST_STD_SLOT) {
        file = lust_std_files[(slot - LUST_STD_SLOT) & ~LUST_STD_POW];
        line = (loc >> 20) & 0xFFFFF;
    } else {
        file = lust_slot_file ? lust_files[lust_slot_file[slot]] : lust_file;
        line = lust_fn_line[slot] + ((loc >> 20) & 0xFFFFF);
    }
    if (lust_unwind_mode || lust_hook_on) {
        lust_fmt_nested_check(p, n, file, line, loc & 0xFFFFF);
        lust_unw_raise(kind, p, n, file, line, loc & 0xFFFFF);
        return;
    }
    lust_panic_at(p, n, file, line, loc & 0xFFFFF);
}
#endif

/* A panic with a formatted message (a `String` payload). Takes `msg`:
   the payload holds a copy, and in unwind mode the caller's temporary is
   freed here, as the code after the panic never runs. */
void lust_panic(lust_String *msg, lust_loc loc) LUST_BODY({
    lust_panic_kind(LUST_EXC_STRING, msg->ptr, msg->len, loc);
    lust_string_drop(msg);
})

/* A panic whose message Rust writes as a literal (a `&'static str`
   payload): `panic!("text")`, overflow, unwrap on None. Takes `msg`. */
void lust_panic_lit(lust_String *msg, lust_loc loc) LUST_BODY({
    lust_panic_kind(LUST_EXC_STR, msg->ptr, msg->len, loc);
    lust_string_drop(msg);
})

/* A panic whose message has arguments (`panic!("{}", x)`, assert_eq!,
   `Result::unwrap`): cgen calls lust_panic_begin before it formats the
   message and lust_panic_fmt with the result. */
void lust_panic_begin(lust_loc loc) LUST_BODY({
    lust_unw_state *st = lust_unw_get();
    if (st->in_fmt) {
        lust_String s = lust_string_new();
        st->msg_dyn = 1;
        lust_panic(&s, loc);
    }
    st->in_fmt = 1;
})

void lust_panic_fmt(lust_String *msg, lust_loc loc) LUST_BODY({
    lust_unw_get()->in_fmt = 0;
    lust_panic(msg, loc);
})

/* A runtime panic whose Rust message has arguments (bounds, slice
   ranges): as lust_panic, but blank when it happens in a panic. */
void lust_panic_dyn(lust_String *msg, lust_loc loc) LUST_BODY({
    lust_unw_get()->msg_dyn = 1;
    lust_panic(msg, loc);
})

void lust_panic_cstr_dyn(const char *msg, lust_loc loc) LUST_BODY({
    lust_String s = lust_string_new();
    lust_string_push_cstr(&s, msg);
    lust_panic_dyn(&s, loc);
})

void lust_panic_str(lust_str msg, lust_loc loc) LUST_BODY({
    lust_String s = lust_string_from(msg);
    lust_panic(&s, loc);
})

/* A literal message (a `&'static str` payload). */
void lust_panic_cstr(const char *msg, lust_loc loc) LUST_BODY({ lust_panic_kind(LUST_EXC_STR, (const uint8_t *)msg, strlen(msg), loc); })

/* A fixed message Rust formats at run time (a `String` payload: RefCell's
   borrow errors, `expect` texts). */
void lust_panic_cstr_owned(const char *msg, lust_loc loc) LUST_BODY({ lust_panic_kind(LUST_EXC_STRING, (const uint8_t *)msg, strlen(msg), loc); })

/* "attempt to <op> with overflow" (checked integer math). */
void lust_ovf(const char *op, lust_loc loc) LUST_BODY({
    uint32_t slot = (uint32_t)(loc >> 40);
    if (slot >= LUST_STD_SLOT && ((slot - LUST_STD_SLOT) & LUST_STD_POW)) op = "exponentiate";
    lust_String s = lust_string_new();
    lust_string_push_cstr(&s, "attempt to ");
    lust_string_push_cstr(&s, op);
    lust_string_push_cstr(&s, " with overflow");
    lust_panic_lit(&s, loc);
})

/* A panic Rust raises at a fixed line of its own std source: `where` is
   "path:line:col" under library/. */
#ifdef LUST_IMPL
static void lust_panic_std_kind(uint32_t kind, const char *msg, const char *where) {
    lust_unw_state *st = lust_unw_peek();
    if (st && st->in_fmt) {
        fprintf(stderr, "panicked at " LUST_STD_SRC "%s:\n%s\nthread panicked while processing panic. aborting.\n", where, msg);
        fflush(stderr);
        abort();
    }
    if (lust_unwind_mode || lust_hook_on) {
        /* `where` is "path:line:col"; split it for the hook. */
        const char *c2 = strrchr(where, ':'), *c1 = c2;
        while (c1 > where && c1[-1] != ':') c1--;
        char file[256];
        int n = snprintf(file, sizeof file, LUST_STD_SRC "%.*s", (int)(c1 - 1 - where), where);
        (void)n;
        lust_unw_raise(kind, (const uint8_t *)msg, strlen(msg), file, (uint32_t)strtoul(c1, 0, 10), (uint32_t)strtoul(c2 + 1, 0, 10));
        return;
    }
    const uint8_t *tn;
    uint64_t tl;
    lust_cur_thread_name(&tn, &tl);
    fprintf(stderr, "\nthread '%.*s' (%llu) panicked at " LUST_STD_SRC "%s:\n%s\n", (int)tl, (const char *)tn, lust_os_tid(), where, msg);
    int32_t bt = lust_bt_style();
    lust_bt_tail(bt, bt == 1 && lust_first_panic_take());
    fflush(stderr);
    abort();
}
#endif

/* A panic Rust raises with a formatted message (a `String` payload) at a
   fixed line of its own std source: `where` is "path:line:col" under
   library/. */
void lust_panic_std(const char *msg, const char *where) LUST_BODY({ lust_panic_std_kind(LUST_EXC_STRING, msg, where); })

/* As lust_panic_std, for a message std writes as a literal (a `&str`
   payload: RawVec's capacity overflow, the atomic ordering checks). */
void lust_panic_std_lit(const char *msg, const char *where) LUST_BODY({ lust_panic_std_kind(LUST_EXC_STR, msg, where); })

/* core 1.99's `BorrowedCursor::advance_checked` assert, as `io::copy`'s
   default `read_buf` hits it when `read` returns more than the buffer. */
void lust_panic_read_buf_overrun(void) LUST_BODY({ lust_panic_std_kind(LUST_EXC_STR, "assertion failed: n <= init_unfilled", "core/src/io/borrowed_buf.rs:287:9"); })

/* `panic_any(payload)`: the hook prints the payload's text, then it
   unwinds (abort mode: aborts). */
void lust_panic_box(lust_dyn b, lust_loc loc) LUST_BODY({
    lust_exc ex;
    ex.kind = LUST_EXC_BOX;
    ex.box = b;
    ex.s.ptr = 0;
    ex.s.len = 0;
    lust_str t = lust_exc_text(&ex);
    uint32_t slot = (uint32_t)(loc >> 40);
    const char *file = lust_slot_file ? lust_files[lust_slot_file[slot]] : lust_file;
    uint32_t line = lust_fn_line[slot] + ((loc >> 20) & 0xFFFFF);
    if (lust_unwind_mode) lust_unw_raise_exc(&ex, t.ptr, t.len, file, line, loc & 0xFFFFF);
    else if (lust_hook_on) lust_abort_hooked(&ex, t.ptr, t.len, file, line, loc & 0xFFFFF);
    else lust_panic_kind(LUST_EXC_STR, t.ptr, t.len, loc);
})

/* The file and line of a packed location, as the panic messages above
   print them: `Location::caller()` builds its value from these (cgen
   `B::LocationCaller`), so a lib fn's location names its own file. */
void lust_loc_where(lust_loc loc, const char **file, uint32_t *line) LUST_BODY({
    uint32_t slot = (uint32_t)(loc >> 40);
    if (slot >= LUST_STD_SLOT) {
        *file = lust_std_files[(slot - LUST_STD_SLOT) & ~LUST_STD_POW];
        *line = (loc >> 20) & 0xFFFFF;
    } else {
        *file = lust_slot_file ? lust_files[lust_slot_file[slot]] : lust_file;
        *line = lust_fn_line[slot] + ((loc >> 20) & 0xFFFFF);
    }
})

/* ---------- Stdout as Rust's LineWriter ----------
   Rust's stdout is a LineWriter with a 1024-byte buffer over fd 1, tty
   or not: a write that holds a newline sends everything up to its last
   newline at once, and only the tail stays buffered (BufWriter rules:
   a tail that does not fit flushes the buffer, one of 1024 bytes or
   more is written directly). So a panic=abort loses exactly the held
   tail, and stdout and stderr interleave as in Rust. `lust_print_out`
   gets one formatted string per print, where Rust writes piece by
   piece; the held bytes differ only when one partial line passes 1024
   bytes. SIGPIPE is ignored as in Rust, so a write to a closed pipe
   panics with Rust's message. */
#ifdef LUST_IMPL
static uint8_t lust_out_buf[1024];
static uint64_t lust_out_len;
/* io::Write on Stdout (sys.c) returns a write error where print! panics:
   in soft mode the first error lands in lust_out_err (errno, or EIO for
   a zero-byte write) and the held bytes are dropped. */
static int lust_out_soft, lust_out_err;

static void lust_out_raw(const uint8_t *p, uint64_t n) {
    while (n) {
#ifdef _WIN32
        DWORD done = 0;
        int64_t w = WriteFile(GetStdHandle((DWORD)-11), p, (DWORD)(n > 0x7fffffff ? 0x7fffffff : n), &done, 0) ? (int64_t)done : -1;
        if (w < 0) errno = (int)GetLastError();
#else
        ssize_t w = write(1, p, n);
#endif
        if (w < 0 && errno == EINTR) continue;
        if (w <= 0) {
            int e = w < 0 ? errno : 0;
            if (lust_out_soft) {
                if (!lust_out_err) lust_out_err = e ? e : EIO;
                lust_out_len = 0;
                return;
            }
            lust_String s = lust_string_new();
            lust_string_push_cstr(&s, "failed printing to stdout: ");
            if (e == EPIPE) lust_string_push_cstr(&s, "Broken pipe (os error 32)");
            else if (e == EBADF) lust_string_push_cstr(&s, "Bad file descriptor (os error 9)");
            else if (e == ENOSPC) lust_string_push_cstr(&s, "No space left on device (os error 28)");
            else if (e == 0) lust_string_push_cstr(&s, "failed to write whole buffer");
            else { char b[32]; snprintf(b, sizeof b, " (os error %d)", e); lust_string_push_cstr(&s, strerror(e)); lust_string_push_cstr(&s, b); }
            lust_out_len = 0;
            lust_panic_at(s.ptr, s.len, LUST_STD_SRC "std/src/io/stdio.rs", 1168, 9);
            return;
        }
        p += w;
        n -= (uint64_t)w;
    }
}

static void lust_out_flush_buf(void) {
    uint64_t n = lust_out_len;
    lust_out_len = 0;
    if (n) lust_out_raw(lust_out_buf, n);
}
#endif

/* LineWriterShim::write_all: the complete lines (through the last
   newline) go out after any held bytes; the tail then takes the
   BufWriter::write_all path. */
void lust_print_out(const uint8_t *p, uint64_t n) LUST_BODY({
    uint64_t k = n;
    while (k && p[k - 1] != '\n') k--;
    if (k) {
        lust_out_flush_buf();
        lust_out_raw(p, k);
        p += k;
        n -= k;
    } else if (lust_out_len && lust_out_buf[lust_out_len - 1] == '\n') {
        lust_out_flush_buf();
    }
    if (lust_out_len + n > sizeof lust_out_buf) lust_out_flush_buf();
    if (n >= sizeof lust_out_buf) lust_out_raw(p, n);
    else { memcpy(lust_out_buf + lust_out_len, p, n); lust_out_len += n; }
})

/* Flushes stdout: at exit and `process::exit` (Rust's rt::cleanup). */
void lust_print_flush(void) LUST_BODY({ lust_out_flush_buf(); })

/* `io::Write` for Stdout (sys.c): the same LineWriter as print!, so the
   two interleave in program order; 0 or an errno instead of a panic. */
int32_t lust_stdout_write_soft(const uint8_t *p, uint64_t n) LUST_BODY({
    lust_out_soft = 1;
    lust_out_err = 0;
    lust_print_out(p, n);
    lust_out_soft = 0;
    return lust_out_err;
})
int32_t lust_stdout_flush_soft(void) LUST_BODY({
    lust_out_soft = 1;
    lust_out_err = 0;
    lust_out_flush_buf();
    lust_out_soft = 0;
    return lust_out_err;
})

/* ---------- Stack overflow ----------
   Rust puts a SIGSEGV/SIGBUS handler on an alternate stack: a fault in
   the guard region below the thread's stack prints
       \nthread 'main' (<os tid>) has overflowed its stack\nfatal runtime error: stack overflow, aborting\n
   and aborts (134); any other fault gets the default action. The stack
   bounds come from pthread_getattr_np on Linux and from
   pthread_get_stackaddr_np on Darwin. The region counts 16
   MiB below the stack, as a tcc frame can step past one guard page. */
#if defined(LUST_IMPL) && (defined(__linux__) || defined(__APPLE__))
#ifdef __APPLE__
#include <sys/resource.h>
#else
/* No <pthread.h>: sync.c declares pthread_create with its own types.
   pthread_attr_t is opaque here (56 bytes on x86_64 and aarch64 glibc). */
typedef union { char bytes[64]; long align; } lust_pthread_attr;
unsigned long pthread_self(void);
int pthread_getattr_np(unsigned long, void *);
int pthread_attr_getstack(const void *, void **, size_t *);
int pthread_attr_destroy(void *);
#endif
static uintptr_t lust_guard_lo, lust_guard_hi;
static char lust_alt_stack[65536];
/* A spawned thread's guard window and name (sync.c): leaves the main
   thread's values when the caller is the main thread. */
static void lust_cur_thread_guard(uintptr_t *lo, uintptr_t *hi, const uint8_t **name, uint64_t *n);

static void lust_segv(int sig, siginfo_t *info, void *ctx) {
    (void)ctx;
    uintptr_t a = (uintptr_t)info->si_addr;
    uintptr_t lo = lust_guard_lo, hi = lust_guard_hi;
    const uint8_t *name = (const uint8_t *)"main";
    uint64_t name_len = 4;
    lust_cur_thread_guard(&lo, &hi, &name, &name_len);
    if (a >= lo && a < hi) {
        char tid[24];
        int n = 0;
        unsigned long long t = lust_os_tid();
        do { tid[n++] = (char)('0' + t % 10); t /= 10; } while (t);
        char msg[160 + 64];
        int m = 0;
        const char *head = "\nthread '", *mid = "' (", *tail = ") has overflowed its stack\nfatal runtime error: stack overflow, aborting\n";
        while (*head) msg[m++] = *head++;
        for (uint64_t i = 0; i < name_len && i < 64; i++) msg[m++] = (char)name[i];
        while (*mid) msg[m++] = *mid++;
        while (n) msg[m++] = tid[--n];
        while (*tail) msg[m++] = *tail++;
        if (write(2, msg, (size_t)m) < 0) {}
        abort();
    }
    /* Not a stack overflow: the default action on return re-runs the fault. */
    signal(sig, SIG_DFL);
}

/* The calling thread's guard window: one page above the stack's low end
   down to 16 MiB below it (see above). False when the bounds are unknown. */
static int lust_guard_window(uintptr_t *lo, uintptr_t *hi) {
    uintptr_t low;
#ifdef __APPLE__
    pthread_t self = pthread_self();
    void *top = pthread_get_stackaddr_np(self);
    if (!top) return 0;
    size_t size = pthread_get_stacksize_np(self);
    if (pthread_main_np()) {
        /* The main thread's size_np is not its stack size on macOS:
           std reads the main stack size from RLIMIT_STACK there. */
        struct rlimit rl;
        if (getrlimit(RLIMIT_STACK, &rl) == 0 && rl.rlim_cur != RLIM_INFINITY) size = (size_t)rl.rlim_cur;
    }
    if (!size || (uintptr_t)top < (uintptr_t)size) return 0;
    low = (uintptr_t)top - (uintptr_t)size;
#else
    lust_pthread_attr at;
    void *addr;
    size_t size;
    if (pthread_getattr_np(pthread_self(), &at) != 0) return 0;
    int ok = pthread_attr_getstack(&at, &addr, &size) == 0;
    pthread_attr_destroy(&at);
    if (!ok) return 0;
    low = (uintptr_t)addr;
#endif
    long page = sysconf(_SC_PAGESIZE);
    *hi = low + (uintptr_t)(page > 0 ? page : 4096);
    *lo = low > (16u << 20) ? low - (16u << 20) : 0;
    return 1;
}

/* A spawned thread's start (sync.c): its own guard window and alternate
   signal stack, as std's thread start sets them up, so an overflow there
   reports with the thread's name. `*alt` is freed by lust_thread_guard_fini. */
static void lust_thread_guard_init(uintptr_t *lo, uintptr_t *hi, void **alt) {
    if (!lust_guard_window(lo, hi)) return;
    stack_t ss;
    memset(&ss, 0, sizeof ss);
    ss.ss_sp = malloc(65536);
    if (!ss.ss_sp) return;
    ss.ss_size = 65536;
    if (sigaltstack(&ss, NULL) != 0) { free(ss.ss_sp); return; }
    *alt = ss.ss_sp;
}

static void lust_thread_guard_fini(void *alt) {
    if (!alt) return;
    stack_t ss;
    memset(&ss, 0, sizeof ss);
    ss.ss_flags = SS_DISABLE;
    sigaltstack(&ss, NULL);
    free(alt);
}

static void lust_stack_guard_init(void) {
    if (!lust_guard_window(&lust_guard_lo, &lust_guard_hi)) return;
    stack_t ss;
    memset(&ss, 0, sizeof ss);
    ss.ss_sp = lust_alt_stack;
    ss.ss_size = sizeof lust_alt_stack;
    if (sigaltstack(&ss, NULL) != 0) return;
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_sigaction = lust_segv;
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, NULL);
    sigaction(SIGBUS, &sa, NULL);
}
#elif defined(LUST_IMPL)
static void lust_stack_guard_init(void) {}
static void lust_thread_guard_init(uintptr_t *lo, uintptr_t *hi, void **alt) { (void)lo; (void)hi; (void)alt; }
static void lust_thread_guard_fini(void *alt) { (void)alt; }
#endif

/* Runtime setup before main: Rust ignores SIGPIPE and reports a stack
   overflow (above). */
void lust_rt_init(void) LUST_BODY({
#ifndef _WIN32
    signal(SIGPIPE, SIG_IGN);
#endif
    lust_stack_guard_init();
})

/* A print to stdout (`to_stderr` 0) or stderr whose fmt impl returned
   Err: Rust has already written the pieces before the failing one. */
void lust_print_failed(int to_stderr, lust_String *s) LUST_BODY({
    if (to_stderr) { if (s->len) fwrite(s->ptr, 1, s->len, stderr); fflush(stderr); }
    else lust_print_out(s->ptr, s->len);
    lust_panic_std("a formatting trait implementation returned an error when the underlying stream did not", "core/src/io/write.rs:411:17");
})
/* ---------- Thread-local keys (thread_local!, ARCH 7.3) ----------

   Storage is per thread from the start, through one pthread key: no C
   _Thread_local or __thread anywhere (tcc breaks TLS, spike K3). The key
   holds the thread's TLS block. The block has one cell per thread_local!
   static the thread touched, found by the static's slot, and the list of
   destructors to run when the thread ends.

   A `LocalKey` static is a `uint64_t` global holding the key's slot,
   1, 2, .. (collect numbers them). A cell is codegen's `(u8, T)` tuple:
   the state byte (0 initial, 1 alive, 2 destroyed) and the value. A new
   cell is all zero bytes.

   Destructors run newest first, as glibc's __cxa_thread_atexit_impl
   runs them (Rust std on Linux registers through it): a value that
   needs drop registers its destructor at its first access. A destructor
   can touch other keys, register new destructors (they run next), or
   find a destroyed key (codegen panics with Rust's AccessError message).
   Other threads run the list from the pthread key destructor; the main
   thread runs it at process exit, before stdout is flushed, from
   `main`'s return and from `lust_exit`, as glibc's exit() does. */

/* The calling thread's cell for the static `key`: `size` bytes with
   `align`, all zero (state initial) when the thread first asks. */
void *lust_tls_cell(uint64_t *key, uint64_t size, uint64_t align);
/* Queues `dtor(cell)` to run when the calling thread ends. */
void lust_tls_register(void *cell, void (*dtor)(void *));
/* Runs the calling thread's queued destructors, newest first, until none
   are left. The main thread calls it at process exit. */
void lust_tls_exit(void);

#ifdef LUST_IMPL
/* The pthread calls, declared as runtime/sync.c declares them: no
   <pthread.h>, whose prototypes clash with those under tcc. On glibc a
   pthread_key_t is an unsigned int and a pthread_once_t an int (0 is
   PTHREAD_ONCE_INIT). On Darwin runtime.h included the real header
   and the lust_pthread_* types are its types; on Windows they are
   a Fls index and an INIT_ONCE, and runtime.h maps the calls. */
#if !defined(__APPLE__) && !defined(_WIN32)
int pthread_key_create(unsigned int *key, void (*dtor)(void *));
void *pthread_getspecific(unsigned int key);
int pthread_setspecific(unsigned int key, const void *v);
int pthread_once(int *once, void (*init)(void));
#endif

typedef struct {
    void *cell;
    void (*dtor)(void *);
} lust_tls_dtor;

typedef struct {
    void **cells;
    uint64_t cap;
    lust_tls_dtor *dtors;
    uint64_t ndtors;
    uint64_t dcap;
} lust_tls_block;

static lust_pthread_key_t lust_tls_key;
static lust_pthread_once_t lust_tls_once = LUST_PTHREAD_ONCE_INIT;
/* Set once the key exists: the fast path reads it before the key, and a
   program that never touches TLS makes no key at exit. Read and written
   with the `__atomic` builtins (tcc has them; runtime/sync.c owns the
   fence shim, so no <stdatomic.h> here): 2 is acquire, 3 is release. */
static int lust_tls_ready;

#ifndef __TINYC__
/* The calling thread's block, as pthread_getspecific gives it: the fast
   path reads it with one native thread-local load (tcc has no native
   TLS, so its builds keep the pthread lookup). External: the release
   units' inline lust_tls_cell (runtime/inl.h) reads it too. */
__thread lust_tls_block *lust_tls_cur;
/* The calling thread's cell of slot s for s < LUST_TLS_FAST (runtime.h), as the block's
   cells[s - 1]: the release units' inline lust_tls_cell reads it with one indexed
   thread-local load. Only a cache of the block's cell pointers, so every access of a
   slot (tcc or not, inline or not) reaches the same cell. */
__thread void *lust_tls_fast[LUST_TLS_FAST];
#endif

static int lust_tls_is_ready(void) {
    int r;
    __atomic_load(&lust_tls_ready, &r, 2);
    return r;
}

static void lust_tls_run(lust_tls_block *b) {
    while (b->ndtors) {
        lust_tls_dtor d = b->dtors[--b->ndtors];
        /* Rust runs TLS destructors behind a no-unwind boundary (in mode 2,
           a catch point). */
        int32_t panicked;
        if (lust_unwind_mode == 2) {
            panicked = lust_unw_try(d.dtor, d.cell);
        } else {
            d.dtor(d.cell);
            panicked = lust_unwind_mode && lust_unw_mine();
        }
        if (panicked) {
            fputs("fatal runtime error: thread local panicked on drop, aborting\n", stderr);
            abort();
        }
    }
}

/* The pthread key destructor of a thread other than main. The key's value
   is cleared before this runs; destructors may touch TLS again, so the
   block goes back under the key until the list is empty. */
static void lust_tls_thread_end(void *p) {
    lust_tls_block *b = (lust_tls_block *)p;
    pthread_setspecific(lust_tls_key, b);
#ifndef __TINYC__
    lust_tls_cur = b;
#endif
    lust_tls_run(b);
    pthread_setspecific(lust_tls_key, 0);
#ifndef __TINYC__
    lust_tls_cur = 0;
#endif
    for (uint64_t i = 0; i < b->cap; i++) free(b->cells[i]);
#ifndef __TINYC__
    memset(lust_tls_fast, 0, sizeof lust_tls_fast);
#endif
    free(b->cells);
    free(b->dtors);
    free(b);
}

static void lust_tls_make_key(void) {
    if (pthread_key_create(&lust_tls_key, lust_tls_thread_end) != 0) abort();
    int one = 1;
    __atomic_store(&lust_tls_ready, &one, 3);
}

static lust_tls_block *lust_tls_block_get(void) {
    pthread_once(&lust_tls_once, lust_tls_make_key);
    lust_tls_block *b = (lust_tls_block *)pthread_getspecific(lust_tls_key);
    if (!b) {
        b = (lust_tls_block *)calloc(1, sizeof *b);
        if (!b) lust_oom();
        pthread_setspecific(lust_tls_key, b);
    }
#ifndef __TINYC__
    lust_tls_cur = b;
#endif
    return b;
}

/* The first access to slot `s` on this thread: grows the block and makes
   a zeroed cell. */
static void *lust_tls_cell_slow(uint64_t s, uint64_t size, uint64_t align) {
    lust_tls_block *b = lust_tls_block_get();
    if (s > b->cap) {
        uint64_t cap = b->cap ? b->cap : 8;
        while (cap < s) cap *= 2;
        void **cells = (void **)realloc(b->cells, cap * sizeof(void *));
        if (!cells) lust_oom();
        memset(cells + b->cap, 0, (cap - b->cap) * sizeof(void *));
        b->cells = cells;
        b->cap = cap;
    }
    void *c = b->cells[s - 1];
    if (!c) {
        /* Cells are freed with plain free() (see lust_alloc). */
        c = lust_alloc_zeroed(size ? size : 1, align);
        b->cells[s - 1] = c;
    }
#ifndef __TINYC__
    if (s < LUST_TLS_FAST) lust_tls_fast[s] = c;
#endif
    return c;
}
#endif

void *lust_tls_cell(uint64_t *key, uint64_t size, uint64_t align) LUST_BODY({
    /* Fast path: the ready flag (an acquire load, a plain read on x86),
       then plain reads (a key's slot never changes, and the block key
       exists before any block does). */
    uint64_t s = *key;
#ifndef __TINYC__
    lust_tls_block *b = lust_tls_cur;
    if (b && s <= b->cap && b->cells[s - 1]) return b->cells[s - 1];
#else
    if (lust_tls_is_ready()) {
        lust_tls_block *b = (lust_tls_block *)pthread_getspecific(lust_tls_key);
        if (b && s <= b->cap && b->cells[s - 1]) return b->cells[s - 1];
    }
#endif
    return lust_tls_cell_slow(s, size, align);
})

void lust_tls_register(void *cell, void (*dtor)(void *)) LUST_BODY({
    lust_tls_block *b = lust_tls_block_get();
    if (b->ndtors == b->dcap) {
        uint64_t cap = b->dcap ? b->dcap * 2 : 8;
        lust_tls_dtor *d = (lust_tls_dtor *)realloc(b->dtors, cap * sizeof *d);
        if (!d) lust_oom();
        b->dtors = d;
        b->dcap = cap;
    }
    b->dtors[b->ndtors].cell = cell;
    b->dtors[b->ndtors].dtor = dtor;
    b->ndtors++;
})

void lust_tls_exit(void) LUST_BODY({
    if (!lust_tls_is_ready()) return;
    lust_tls_block *b = (lust_tls_block *)pthread_getspecific(lust_tls_key);
    if (b) lust_tls_run(b);
})
/* ---------- Constant storage ----------
   rustc gives equal constants one address: promoted temps (`&1`),
   literals (`"ab"`, `b"ab"`), and the pointees of const and static
   values. A static itself is never shared. In one codegen unit, two
   constants share storage when their LLVM constants are equal: the same
   bytes, the same uninit runs, and pointers at the same places. The
   linker also merges 4, 8, 16 and 32 byte constants that hold no
   pointer by their bytes (an uninit byte is 0 in the object file), in
   any unit (LLVM's .rodata.cstN). A fully init constant whose only zero
   byte is its last one is a C string to LLVM (.rodata.str1.A), so it is
   not in that set. lust gives every constant of the program that address:
   each site interns its bytes here at its first run and keeps the
   canonical address in a slot of its own (cgen/kconst.rs), and the glue
   unit registers the pointees of statics at startup (lust_kreg, or
   lust_kreg_h with a hash codegen computed, which reads no byte of the
   pointee). Zero-sized constants never come here: their address is
   their alignment (cgen `const_zst_addr`).

   A site's layout descriptor (cgen `kdesc`) says which bytes of its
   value are init. Word 0 is the word count that follows; then ops:
     1 off n            n init bytes
     2 off              a pointer: a reloc when it is the address of a
                        constant here, else plain bytes (a dangling
                        zero-sized address, a static, a fn)
     3 off count stride sublen sub[sublen]       an array
     4 off size nvar disc[nvar] {sublen sub}*nvar
                        an enum with a tag of `size` bytes at off (a
                        16-byte tag takes two words per disc, low first)
     5 off noff nsize start first span dataful nvar {sublen sub}*nvar
                        (a 16-byte niche takes two words for start)
                        an enum whose tag is the niche scalar at off+noff:
                        value start+d is variant first+d for d < span,
                        any other value the dataful variant (layout.rs
                        `niche_tag_value`)
   Offsets in a sub-descriptor count from the element or enum start.
   A null descriptor means every byte is init. */

const void *lust_kintern(const void **cache, const void *p, uint64_t n, uint64_t align, const uint64_t *desc);
void lust_kreg(const void *p, uint64_t n, uint64_t align, const uint64_t *desc);
void lust_kreg_h(const void *p, uint64_t n, uint64_t align, uint64_t kind, uint64_t hash);

#ifdef LUST_IMPL
/* One interned constant: `kind` 1 is a mergeable 4/8/16/32 byte constant
   with no pointer that is not a C string (the key is its bytes), 0 any
   other (the key is its
   bytes, then its byte classes: 0 uninit, 1 init, 2 pointer). `align`
   is the alignment its storage guarantees. `at_addr`: the entry holds no
   copy of its key, which is the n bytes at `addr`, every one init (a
   static's pointee registered by lust_kreg_h). */
typedef struct lust_kent {
    uint64_t hash, n, align;
    const void *addr;
    uint8_t kind, at_addr;
    uint8_t key[];
} lust_kent;

static lust_kent **lust_ktab;
static uint64_t lust_ktab_cap, lust_ktab_len;
/* The addresses of the entries, to tell a reloc from plain bytes. */
static uintptr_t *lust_kaddr;
static uint64_t lust_kaddr_cap;
static int32_t lust_klock;

/* The table's hash of a key: 8 bytes per step, read little-endian, mixed so the low bits
   (the table index) see every byte. cgen/kconst.rs `khash` computes the same for the
   static pointees it registers by hash (lust_kreg_h): the two must agree. */
static uint64_t lust_khash(const uint8_t *b, uint64_t n, uint64_t h) {
    uint64_t i = 0;
    for (; i + 8 <= n; i += 8) {
        uint64_t w;
        memcpy(&w, b + i, 8);
#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
        w = __builtin_bswap64(w);
#endif
        h = (h ^ w) * 0x9e3779b97f4a7c15ull;
        h ^= h >> 32;
    }
    for (; i < n; i++) h = (h ^ b[i]) * 0x100000001b3ull;
    h ^= h >> 29;
    h *= 0xbf58476d1ce4e5b9ull;
    return h ^ (h >> 32);
}

static uint64_t lust_kaddr_slot(uintptr_t a) { return (uint64_t)((a >> 3) * 0x9e3779b97f4a7c15ull); }

static int lust_kis_entry(uintptr_t a) {
    if (!lust_kaddr_cap || !a) return 0;
    for (uint64_t i = lust_kaddr_slot(a) & (lust_kaddr_cap - 1);; i = (i + 1) & (lust_kaddr_cap - 1)) {
        if (lust_kaddr[i] == a) return 1;
        if (!lust_kaddr[i]) return 0;
    }
}

static void lust_kaddr_add(uintptr_t a) {
    if ((lust_ktab_len + 1) * 2 > lust_kaddr_cap) {
        uint64_t cap = lust_kaddr_cap ? lust_kaddr_cap * 2 : 64;
        uintptr_t *old = lust_kaddr;
        uint64_t old_cap = lust_kaddr_cap;
        lust_kaddr = (uintptr_t *)calloc(cap, sizeof(uintptr_t));
        if (!lust_kaddr) lust_oom();
        lust_kaddr_cap = cap;
        for (uint64_t i = 0; i < old_cap; i++)
            if (old[i]) lust_kaddr_add(old[i]);
        free(old);
    }
    uint64_t i = lust_kaddr_slot(a) & (lust_kaddr_cap - 1);
    while (lust_kaddr[i] && lust_kaddr[i] != a) i = (i + 1) & (lust_kaddr_cap - 1);
    lust_kaddr[i] = a;
}

static uint64_t lust_kread(const uint8_t *p, uint64_t size) {
    uint64_t v = 0;
    for (uint64_t i = 0; i < size && i < 8; i++) v |= (uint64_t)p[i] << (8 * i);
    return v;
}

/* Marks the byte classes of the value at `v + base` by descriptor ops
   `d[0..len)` into `cls`. */
static void lust_kwalk(const uint8_t *v, uint8_t *cls, const uint64_t *d, uint64_t len, uint64_t base) {
    uint64_t i = 0;
    while (i < len) {
        uint64_t op = d[i], off = base + d[i + 1];
        if (op == 1) {
            memset(cls + off, 1, d[i + 2]);
            i += 3;
        } else if (op == 2) {
            uintptr_t a;
            memcpy(&a, v + off, sizeof a);
            memset(cls + off, lust_kis_entry(a) ? 2 : 1, sizeof a);
            i += 2;
        } else if (op == 3) {
            uint64_t count = d[i + 2], stride = d[i + 3], sl = d[i + 4];
            for (uint64_t k = 0; k < count; k++) lust_kwalk(v, cls, d + i + 5, sl, off + k * stride);
            i += 5 + sl;
        } else {
            /* An enum: find the variant, mark its tag bytes, walk its fields. */
            uint64_t nvar, j, var = 0;
            if (op == 4) {
                /* A 16-byte tag compares two words per discriminant. */
                uint64_t size = d[i + 2], w = size == 16 ? 2 : 1;
                uint64_t lo = lust_kread(v + off, size >= 8 ? 8 : size), hi = w == 2 ? lust_kread(v + off + 8, 8) : 0;
                uint64_t mask = size >= 8 ? ~0ull : (1ull << (8 * size)) - 1;
                nvar = d[i + 3];
                for (uint64_t k = 0; k < nvar; k++)
                    if ((d[i + 4 + w * k] & mask) == lo && (w == 1 || d[i + 5 + w * k] == hi)) var = k;
                memset(cls + off, 1, size);
                j = i + 4 + w * nvar;
            } else {
                /* A 16-byte niche: `start` is two words, the distance is
                   taken over 128 bits. */
                uint64_t noff = d[i + 2], nsize = d[i + 3], w = nsize == 16 ? 2 : 1;
                uint64_t first = d[i + 4 + w], span = d[i + 5 + w], dataful = d[i + 6 + w];
                uint64_t mask = nsize >= 8 ? ~0ull : (1ull << (8 * nsize)) - 1;
                uint64_t lo = lust_kread(v + off + noff, nsize >= 8 ? 8 : nsize), rel = (lo - d[i + 4]) & mask, rhi = 0;
                if (w == 2) rhi = lust_kread(v + off + noff + 8, 8) - d[i + 5] - (lo < d[i + 4]);
                nvar = d[i + 7 + w];
                var = rhi == 0 && rel < span ? first + rel : dataful;
                if (var != dataful) memset(cls + off + noff, 1, nsize);
                j = i + 8 + w;
            }
            for (uint64_t k = 0; k < nvar; k++) {
                uint64_t sl = d[j];
                if (k == var) lust_kwalk(v, cls, d + j + 1, sl, off);
                j += 1 + sl;
            }
            i = j;
        }
    }
}

/* The key of the `n` bytes at `p` into `key` (2n bytes); returns the kind.
   `key[0..n)` are the bytes with uninit ones 0; for kind 0, `key[n..2n)`
   are the classes. A C string (`cstr`: all init, one zero byte, at the
   end) is kind 0, as LLVM puts it in a string section (getKindForGlobal).
   As rustc (const_alloc_to_llvm), a run of bytes
   between pointers with more than 16 init and uninit chunks is all init. */
static uint8_t lust_kkey(const void *p, uint64_t n, const uint64_t *desc, uint8_t *key) {
    uint8_t *cls = key + n;
    memcpy(key, p, n);
    if (!desc) {
        /* Every byte init and no pointer (most static pointees): a C string when its one
           zero byte is the last; no chunk rule applies. */
        memset(cls, 1, n);
        int cstr = memchr(key, 0, n) == (const void *)(key + n - 1);
        return !cstr && (n == 4 || n == 8 || n == 16 || n == 32);
    }
    memset(cls, 0, n);
    lust_kwalk((const uint8_t *)p, cls, desc + 1, desc[0], 0);
    int reloc = 0, uninit = 0;
    uint64_t zeros = 0;
    for (uint64_t i = 0; i < n; i++) {
        if (!cls[i]) key[i] = 0, uninit = 1;
        if (cls[i] == 2) reloc = 1;
        zeros += !key[i];
    }
    int cstr = !uninit && !reloc && zeros == 1 && !key[n - 1];
    if (!reloc && !cstr && (n == 4 || n == 8 || n == 16 || n == 32)) return 1;
    for (uint64_t s = 0; s < n;) {
        if (cls[s] == 2) {
            s++;
            continue;
        }
        uint64_t e = s, chunks = 1;
        while (e + 1 < n && cls[e + 1] != 2) {
            if (cls[e + 1] != cls[e]) chunks++;
            e++;
        }
        if (chunks > 16) memset(cls + s, 1, e + 1 - s);
        s = e + 1;
    }
    return 0;
}

/* True when entry `e` (of size n and kind) holds the key of the n bytes `b` with init classes
   `cls` (kind 0 only; null: every byte init). */
static int lust_keq(const lust_kent *e, const uint8_t *b, const uint8_t *cls) {
    if (memcmp(e->at_addr ? (const uint8_t *)e->addr : e->key, b, e->n)) return 0;
    if (e->kind) return 1;
    const uint8_t *ec = e->at_addr ? 0 : e->key + e->n;
    if (ec && cls) return !memcmp(ec, cls, e->n);
    const uint8_t *c = ec ? ec : cls;
    for (uint64_t i = 0; c && i < e->n; i++)
        if (c[i] != 1) return 0;
    return 1;
}

/* The entry with hash h, size n and kind `kind` that fits `align` and holds the key (b, cls)
   (lust_keq), or null with `*slot` the free slot for a new one. Grows the table first. */
static lust_kent *lust_kprobe(uint64_t h, uint64_t n, uint8_t kind, uint64_t align, const uint8_t *b, const uint8_t *cls, uint64_t *slot) {
    if ((lust_ktab_len + 1) * 2 > lust_ktab_cap) {
        uint64_t cap = lust_ktab_cap ? lust_ktab_cap * 2 : 64;
        lust_kent **t = (lust_kent **)calloc(cap, sizeof *t);
        if (!t) lust_oom();
        for (uint64_t i = 0; i < lust_ktab_cap; i++) {
            lust_kent *e = lust_ktab[i];
            if (!e) continue;
            uint64_t j = e->hash & (cap - 1);
            while (t[j]) j = (j + 1) & (cap - 1);
            t[j] = e;
        }
        free(lust_ktab);
        lust_ktab = t;
        lust_ktab_cap = cap;
    }
    uint64_t i = h & (lust_ktab_cap - 1);
    for (lust_kent *e; (e = lust_ktab[i]); i = (i + 1) & (lust_ktab_cap - 1))
        if (e->hash == h && e->n == n && e->kind == kind && e->align >= align && lust_keq(e, b, cls)) return e;
    *slot = i;
    return 0;
}

/* Puts the new entry `e` in the free slot `i` (lust_kprobe). */
static void lust_kput(lust_kent *e, uint64_t i) {
    lust_ktab[i] = e;
    lust_ktab_len++;
    lust_kaddr_add((uintptr_t)e->addr);
}

/* The entry for the constant at `p`, added when there is none that fits
   `align`: a copy (`copy`) or `p` itself (a static's pointee). */
static const void *lust_kfind(const void *p, uint64_t n, uint64_t align, const uint64_t *desc, int copy) {
    uint8_t small[256];
    uint8_t *key = 2 * n <= sizeof small ? small : (uint8_t *)malloc(2 * n);
    if (!key) lust_oom();
    uint8_t kind = lust_kkey(p, n, desc, key);
    uint64_t klen = kind ? n : 2 * n;
    uint64_t h = lust_khash(key, klen, 0xcbf29ce484222325ull ^ n ^ ((uint64_t)kind << 63));
    uint64_t i;
    lust_kent *e = lust_kprobe(h, n, kind, align, key, key + n, &i);
    if (e) {
        if (key != small) free(key);
        return e->addr;
    }
    e = (lust_kent *)malloc(sizeof *e + klen);
    if (!e) lust_oom();
    e->hash = h;
    e->n = n;
    e->kind = kind;
    e->at_addr = 0;
    memcpy(e->key, key, klen);
    if (copy) {
        /* At least 16-aligned, so a later site of a stricter type (up to
           16) finds this copy, as rustc raises a shared constant's
           alignment to its strictest use. */
        uint64_t al = align < 16 ? 16 : align;
#ifdef _WIN32
        void *c = _aligned_malloc((size_t)((n + al - 1) / al * al), (size_t)al);
#else
        void *c = aligned_alloc(al, (n + al - 1) / al * al);
#endif
        if (!c) lust_oom_size(n);
        memcpy(c, key, n);
        e->addr = c;
        e->align = al;
    } else {
        e->addr = p;
        e->align = align;
    }
    if (key != small) free(key);
    lust_kput(e, i);
    return e->addr;
}

/* A spin-wait hint: lets the core that holds the lock run, and stops the
   wait loop from filling the pipeline with loads. */
static void lust_kpause(void) {
#if !defined(__TINYC__) && (defined(__x86_64__) || defined(__i386__))
    __builtin_ia32_pause();
#elif !defined(__TINYC__) && defined(__aarch64__)
    __asm__ __volatile__("yield");
#endif
}

/* Takes the table lock, or returns 0 without it as soon as `*cache` (when
   given) holds an address, which another thread published for the same
   site. A waiter reads the lock word with a pause between reads (test and
   test-and-set): an exchange in a loop would take the cache line from the
   holder on every try. */
static int lust_klock_take(const void **cache, const void **r) {
    int32_t one = 1, old;
    /* Each load goes into a local: tcc's __atomic_load does not write through a result
       pointer that is not the address of a variable. */
    const void *v;
    for (;;) {
        if (cache) {
            __atomic_load(cache, &v, 2);
            if (v) return *r = v, 0;
        }
        __atomic_exchange(&lust_klock, &one, &old, 2);
        if (!old) return 1;
        do {
            lust_kpause();
            if (cache) {
                __atomic_load(cache, &v, 2);
                if (v) return *r = v, 0;
            }
            __atomic_load(&lust_klock, &old, 0);
        } while (old);
    }
}

static void lust_klock_give(void) {
    int32_t zero = 0;
    __atomic_store(&lust_klock, &zero, 3);
}
#endif

/* The canonical address of the `n` bytes at `p`
   (alignment `align`, descriptor `desc`), stored into `*cache`. Threads
   that run a site for the first time together all come here: one interns,
   and the others return its address once it is in the site's slot, without
   taking the lock. */
const void *lust_kintern(const void **cache, const void *p, uint64_t n, uint64_t align, const uint64_t *desc) LUST_BODY({
    const void *r;
    if (!lust_klock_take(cache, &r)) return r;
    __atomic_load(cache, &r, 0);
    if (!r) {
        r = lust_kfind(p, n, align, desc, 1);
        __atomic_store(cache, &r, 3);
    }
    lust_klock_give();
    return r;
})

/* A static's pointee of `n` bytes at `p`, as the canonical storage of
   its content (the glue unit's lust_kstatics_init, before main). */
void lust_kreg(const void *p, uint64_t n, uint64_t align, const uint64_t *desc) LUST_BODY({
    (void)lust_klock_take(0, 0);
    (void)lust_kfind(p, n, align, desc, 0);
    lust_klock_give();
})

/* As lust_kreg for a pointee whose bytes are all init and hold no pointer, by the kind and
   hash of its key that codegen computed (cgen/kconst.rs `khash`): the entry keeps no copy of
   the key, and its bytes are read only to compare with an entry of an equal hash. */
void lust_kreg_h(const void *p, uint64_t n, uint64_t align, uint64_t kind, uint64_t hash) LUST_BODY({
    (void)lust_klock_take(0, 0);
    uint64_t i;
    if (!lust_kprobe(hash, n, (uint8_t)kind, align, (const uint8_t *)p, 0, &i)) {
        lust_kent *e = (lust_kent *)malloc(sizeof *e);
        if (!e) lust_oom();
        e->hash = hash;
        e->n = n;
        e->align = align;
        e->addr = p;
        e->kind = (uint8_t)kind;
        e->at_addr = 1;
        lust_kput(e, i);
    }
    lust_klock_give();
})
/* ---------- Formatting ---------- */

void lust_fmt_u64(lust_String *out, uint64_t v) LUST_BODY({
    char b[24];
    int i = 24;
    do { b[--i] = '0' + v % 10; v /= 10; } while (v);
    lust_string_push_bytes(out, b + i, 24 - i);
})

void lust_fmt_i64(lust_String *out, int64_t v) LUST_BODY({
    if (v < 0) { lust_string_push_bytes(out, "-", 1); lust_fmt_u64(out, (uint64_t)0 - (uint64_t)v); }
    else lust_fmt_u64(out, (uint64_t)v);
})

void lust_fmt_bool(lust_String *out, uint8_t v) LUST_BODY({ lust_string_push_cstr(out, v ? "true" : "false"); })

#ifdef LUST_IMPL
/* Code point ranges that Rust's Debug for char and str escapes as
   \u{...}: every grapheme-extended or non-printable scalar (the
   escape_debug rules). Generated by probing rustc 1.99's
   format!("{:?}", c) over all scalar values. Do not edit. */
static const uint32_t lust_escape_ranges[][2] = {
    {0x1, 0x8},
    {0xb, 0xc},
    {0xe, 0x1f},
    {0x7f, 0xa0},
    {0xad, 0xad},
    {0x300, 0x36f},
    {0x378, 0x379},
    {0x380, 0x383},
    {0x38b, 0x38b},
    {0x38d, 0x38d},
    {0x3a2, 0x3a2},
    {0x483, 0x489},
    {0x530, 0x530},
    {0x557, 0x558},
    {0x58b, 0x58c},
    {0x590, 0x5bd},
    {0x5bf, 0x5bf},
    {0x5c1, 0x5c2},
    {0x5c4, 0x5c5},
    {0x5c7, 0x5cf},
    {0x5eb, 0x5ee},
    {0x5f5, 0x605},
    {0x610, 0x61a},
    {0x61c, 0x61c},
    {0x64b, 0x65f},
    {0x670, 0x670},
    {0x6d6, 0x6dd},
    {0x6df, 0x6e4},
    {0x6e7, 0x6e8},
    {0x6ea, 0x6ed},
    {0x70e, 0x70f},
    {0x711, 0x711},
    {0x730, 0x74c},
    {0x7a6, 0x7b0},
    {0x7b2, 0x7bf},
    {0x7eb, 0x7f3},
    {0x7fb, 0x7fd},
    {0x816, 0x819},
    {0x81b, 0x823},
    {0x825, 0x827},
    {0x829, 0x82f},
    {0x83f, 0x83f},
    {0x859, 0x85d},
    {0x85f, 0x85f},
    {0x86b, 0x86f},
    {0x890, 0x89f},
    {0x8ca, 0x902},
    {0x93a, 0x93a},
    {0x93c, 0x93c},
    {0x941, 0x948},
    {0x94d, 0x94d},
    {0x951, 0x957},
    {0x962, 0x963},
    {0x981, 0x981},
    {0x984, 0x984},
    {0x98d, 0x98e},
    {0x991, 0x992},
    {0x9a9, 0x9a9},
    {0x9b1, 0x9b1},
    {0x9b3, 0x9b5},
    {0x9ba, 0x9bc},
    {0x9be, 0x9be},
    {0x9c1, 0x9c6},
    {0x9c9, 0x9ca},
    {0x9cd, 0x9cd},
    {0x9cf, 0x9db},
    {0x9de, 0x9de},
    {0x9e2, 0x9e5},
    {0x9fe, 0xa02},
    {0xa04, 0xa04},
    {0xa0b, 0xa0e},
    {0xa11, 0xa12},
    {0xa29, 0xa29},
    {0xa31, 0xa31},
    {0xa34, 0xa34},
    {0xa37, 0xa37},
    {0xa3a, 0xa3d},
    {0xa41, 0xa58},
    {0xa5d, 0xa5d},
    {0xa5f, 0xa65},
    {0xa70, 0xa71},
    {0xa75, 0xa75},
    {0xa77, 0xa82},
    {0xa84, 0xa84},
    {0xa8e, 0xa8e},
    {0xa92, 0xa92},
    {0xaa9, 0xaa9},
    {0xab1, 0xab1},
    {0xab4, 0xab4},
    {0xaba, 0xabc},
    {0xac1, 0xac8},
    {0xaca, 0xaca},
    {0xacd, 0xacf},
    {0xad1, 0xadf},
    {0xae2, 0xae5},
    {0xaf2, 0xaf8},
    {0xafa, 0xb01},
    {0xb04, 0xb04},
    {0xb0d, 0xb0e},
    {0xb11, 0xb12},
    {0xb29, 0xb29},
    {0xb31, 0xb31},
    {0xb34, 0xb34},
    {0xb3a, 0xb3c},
    {0xb3e, 0xb3f},
    {0xb41, 0xb46},
    {0xb49, 0xb4a},
    {0xb4d, 0xb5b},
    {0xb5e, 0xb5e},
    {0xb62, 0xb65},
    {0xb78, 0xb82},
    {0xb84, 0xb84},
    {0xb8b, 0xb8d},
    {0xb91, 0xb91},
    {0xb96, 0xb98},
    {0xb9b, 0xb9b},
    {0xb9d, 0xb9d},
    {0xba0, 0xba2},
    {0xba5, 0xba7},
    {0xbab, 0xbad},
    {0xbba, 0xbbe},
    {0xbc0, 0xbc0},
    {0xbc3, 0xbc5},
    {0xbc9, 0xbc9},
    {0xbcd, 0xbcf},
    {0xbd1, 0xbe5},
    {0xbfb, 0xc00},
    {0xc04, 0xc04},
    {0xc0d, 0xc0d},
    {0xc11, 0xc11},
    {0xc29, 0xc29},
    {0xc3a, 0xc3c},
    {0xc3e, 0xc40},
    {0xc45, 0xc57},
    {0xc5b, 0xc5b},
    {0xc5e, 0xc5f},
    {0xc62, 0xc65},
    {0xc70, 0xc76},
    {0xc81, 0xc81},
    {0xc8d, 0xc8d},
    {0xc91, 0xc91},
    {0xca9, 0xca9},
    {0xcb4, 0xcb4},
    {0xcba, 0xcbc},
    {0xcbf, 0xcc0},
    {0xcc2, 0xcc2},
    {0xcc5, 0xcdb},
    {0xcdf, 0xcdf},
    {0xce2, 0xce5},
    {0xcf0, 0xcf0},
    {0xcf4, 0xd01},
    {0xd0d, 0xd0d},
    {0xd11, 0xd11},
    {0xd3b, 0xd3c},
    {0xd3e, 0xd3e},
    {0xd41, 0xd45},
    {0xd49, 0xd49},
    {0xd4d, 0xd4d},
    {0xd50, 0xd53},
    {0xd57, 0xd57},
    {0xd62, 0xd65},
    {0xd80, 0xd81},
    {0xd84, 0xd84},
    {0xd97, 0xd99},
    {0xdb2, 0xdb2},
    {0xdbc, 0xdbc},
    {0xdbe, 0xdbf},
    {0xdc7, 0xdcf},
    {0xdd2, 0xdd7},
    {0xddf, 0xde5},
    {0xdf0, 0xdf1},
    {0xdf5, 0xe00},
    {0xe31, 0xe31},
    {0xe34, 0xe3e},
    {0xe47, 0xe4e},
    {0xe5c, 0xe80},
    {0xe83, 0xe83},
    {0xe85, 0xe85},
    {0xe8b, 0xe8b},
    {0xea4, 0xea4},
    {0xea6, 0xea6},
    {0xeb1, 0xeb1},
    {0xeb4, 0xebc},
    {0xebe, 0xebf},
    {0xec5, 0xec5},
    {0xec7, 0xecf},
    {0xeda, 0xedb},
    {0xee0, 0xeff},
    {0xf18, 0xf19},
    {0xf35, 0xf35},
    {0xf37, 0xf37},
    {0xf39, 0xf39},
    {0xf48, 0xf48},
    {0xf6d, 0xf7e},
    {0xf80, 0xf84},
    {0xf86, 0xf87},
    {0xf8d, 0xfbd},
    {0xfc6, 0xfc6},
    {0xfcd, 0xfcd},
    {0xfdb, 0xfff},
    {0x102d, 0x1030},
    {0x1032, 0x1037},
    {0x1039, 0x103a},
    {0x103d, 0x103e},
    {0x1058, 0x1059},
    {0x105e, 0x1060},
    {0x1071, 0x1074},
    {0x1082, 0x1082},
    {0x1085, 0x1086},
    {0x108d, 0x108d},
    {0x109d, 0x109d},
    {0x10c6, 0x10c6},
    {0x10c8, 0x10cc},
    {0x10ce, 0x10cf},
    {0x115f, 0x1160},
    {0x1249, 0x1249},
    {0x124e, 0x124f},
    {0x1257, 0x1257},
    {0x1259, 0x1259},
    {0x125e, 0x125f},
    {0x1289, 0x1289},
    {0x128e, 0x128f},
    {0x12b1, 0x12b1},
    {0x12b6, 0x12b7},
    {0x12bf, 0x12bf},
    {0x12c1, 0x12c1},
    {0x12c6, 0x12c7},
    {0x12d7, 0x12d7},
    {0x1311, 0x1311},
    {0x1316, 0x1317},
    {0x135b, 0x135f},
    {0x137d, 0x137f},
    {0x139a, 0x139f},
    {0x13f6, 0x13f7},
    {0x13fe, 0x13ff},
    {0x1680, 0x1680},
    {0x169d, 0x169f},
    {0x16f9, 0x16ff},
    {0x1712, 0x171e},
    {0x1732, 0x1734},
    {0x1737, 0x173f},
    {0x1752, 0x175f},
    {0x176d, 0x176d},
    {0x1771, 0x177f},
    {0x17b4, 0x17b5},
    {0x17b7, 0x17bd},
    {0x17c6, 0x17c6},
    {0x17c9, 0x17d3},
    {0x17dd, 0x17df},
    {0x17ea, 0x17ef},
    {0x17fa, 0x17ff},
    {0x180b, 0x180f},
    {0x181a, 0x181f},
    {0x1879, 0x187f},
    {0x1885, 0x1886},
    {0x18a9, 0x18a9},
    {0x18ab, 0x18af},
    {0x18f6, 0x18ff},
    {0x191f, 0x1922},
    {0x1927, 0x1928},
    {0x192c, 0x192f},
    {0x1932, 0x1932},
    {0x1939, 0x193f},
    {0x1941, 0x1943},
    {0x196e, 0x196f},
    {0x1975, 0x197f},
    {0x19ac, 0x19af},
    {0x19ca, 0x19cf},
    {0x19db, 0x19dd},
    {0x1a17, 0x1a18},
    {0x1a1b, 0x1a1d},
    {0x1a56, 0x1a56},
    {0x1a58, 0x1a60},
    {0x1a62, 0x1a62},
    {0x1a65, 0x1a6c},
    {0x1a73, 0x1a7f},
    {0x1a8a, 0x1a8f},
    {0x1a9a, 0x1a9f},
    {0x1aae, 0x1b03},
    {0x1b34, 0x1b3d},
    {0x1b42, 0x1b44},
    {0x1b4d, 0x1b4d},
    {0x1b6b, 0x1b73},
    {0x1b80, 0x1b81},
    {0x1ba2, 0x1ba5},
    {0x1ba8, 0x1bad},
    {0x1be6, 0x1be6},
    {0x1be8, 0x1be9},
    {0x1bed, 0x1bed},
    {0x1bef, 0x1bfb},
    {0x1c2c, 0x1c33},
    {0x1c36, 0x1c3a},
    {0x1c4a, 0x1c4c},
    {0x1c8b, 0x1c8f},
    {0x1cbb, 0x1cbc},
    {0x1cc8, 0x1cd2},
    {0x1cd4, 0x1ce0},
    {0x1ce2, 0x1ce8},
    {0x1ced, 0x1ced},
    {0x1cf4, 0x1cf4},
    {0x1cf8, 0x1cf9},
    {0x1cfb, 0x1cff},
    {0x1dc0, 0x1dff},
    {0x1f16, 0x1f17},
    {0x1f1e, 0x1f1f},
    {0x1f46, 0x1f47},
    {0x1f4e, 0x1f4f},
    {0x1f58, 0x1f58},
    {0x1f5a, 0x1f5a},
    {0x1f5c, 0x1f5c},
    {0x1f5e, 0x1f5e},
    {0x1f7e, 0x1f7f},
    {0x1fb5, 0x1fb5},
    {0x1fc5, 0x1fc5},
    {0x1fd4, 0x1fd5},
    {0x1fdc, 0x1fdc},
    {0x1ff0, 0x1ff1},
    {0x1ff5, 0x1ff5},
    {0x1fff, 0x200f},
    {0x2028, 0x202f},
    {0x205f, 0x206f},
    {0x2072, 0x2073},
    {0x208f, 0x208f},
    {0x209d, 0x209f},
    {0x20c2, 0x20ff},
    {0x218c, 0x218f},
    {0x242a, 0x243f},
    {0x244b, 0x245f},
    {0x2b74, 0x2b75},
    {0x2cef, 0x2cf1},
    {0x2cf4, 0x2cf8},
    {0x2d26, 0x2d26},
    {0x2d28, 0x2d2c},
    {0x2d2e, 0x2d2f},
    {0x2d68, 0x2d6e},
    {0x2d71, 0x2d7f},
    {0x2d97, 0x2d9f},
    {0x2da7, 0x2da7},
    {0x2daf, 0x2daf},
    {0x2db7, 0x2db7},
    {0x2dbf, 0x2dbf},
    {0x2dc7, 0x2dc7},
    {0x2dcf, 0x2dcf},
    {0x2dd7, 0x2dd7},
    {0x2ddf, 0x2dff},
    {0x2e5e, 0x2e7f},
    {0x2e9a, 0x2e9a},
    {0x2ef4, 0x2eff},
    {0x2fd6, 0x2fef},
    {0x3000, 0x3000},
    {0x302a, 0x302f},
    {0x3040, 0x3040},
    {0x3097, 0x309a},
    {0x3100, 0x3104},
    {0x3130, 0x3130},
    {0x3164, 0x3164},
    {0x318f, 0x318f},
    {0x31e6, 0x31ee},
    {0x321f, 0x321f},
    {0xa48d, 0xa48f},
    {0xa4c7, 0xa4cf},
    {0xa62c, 0xa63f},
    {0xa66f, 0xa672},
    {0xa674, 0xa67d},
    {0xa69e, 0xa69f},
    {0xa6f0, 0xa6f1},
    {0xa6f8, 0xa6ff},
    {0xa7dd, 0xa7f0},
    {0xa802, 0xa802},
    {0xa806, 0xa806},
    {0xa80b, 0xa80b},
    {0xa825, 0xa826},
    {0xa82c, 0xa82f},
    {0xa83a, 0xa83f},
    {0xa878, 0xa87f},
    {0xa8c4, 0xa8cd},
    {0xa8da, 0xa8f1},
    {0xa8ff, 0xa8ff},
    {0xa926, 0xa92d},
    {0xa947, 0xa951},
    {0xa953, 0xa95e},
    {0xa97d, 0xa982},
    {0xa9b3, 0xa9b3},
    {0xa9b6, 0xa9b9},
    {0xa9bc, 0xa9bd},
    {0xa9c0, 0xa9c0},
    {0xa9ce, 0xa9ce},
    {0xa9da, 0xa9dd},
    {0xa9e5, 0xa9e5},
    {0xa9ff, 0xa9ff},
    {0xaa29, 0xaa2e},
    {0xaa31, 0xaa32},
    {0xaa35, 0xaa3f},
    {0xaa43, 0xaa43},
    {0xaa4c, 0xaa4c},
    {0xaa4e, 0xaa4f},
    {0xaa5a, 0xaa5b},
    {0xaa7c, 0xaa7c},
    {0xaab0, 0xaab0},
    {0xaab2, 0xaab4},
    {0xaab7, 0xaab8},
    {0xaabe, 0xaabf},
    {0xaac1, 0xaac1},
    {0xaac3, 0xaada},
    {0xaaec, 0xaaed},
    {0xaaf6, 0xab00},
    {0xab07, 0xab08},
    {0xab0f, 0xab10},
    {0xab17, 0xab1f},
    {0xab27, 0xab27},
    {0xab2f, 0xab2f},
    {0xab6c, 0xab6f},
    {0xabe5, 0xabe5},
    {0xabe8, 0xabe8},
    {0xabed, 0xabef},
    {0xabfa, 0xabff},
    {0xd7a4, 0xd7af},
    {0xd7c7, 0xd7ca},
    {0xd7fc, 0xd7ff},
    {0xe000, 0xf8ff},
    {0xfa6e, 0xfa6f},
    {0xfada, 0xfaff},
    {0xfb07, 0xfb12},
    {0xfb18, 0xfb1c},
    {0xfb1e, 0xfb1e},
    {0xfb37, 0xfb37},
    {0xfb3d, 0xfb3d},
    {0xfb3f, 0xfb3f},
    {0xfb42, 0xfb42},
    {0xfb45, 0xfb45},
    {0xfdd0, 0xfdef},
    {0xfe00, 0xfe0f},
    {0xfe1a, 0xfe2f},
    {0xfe53, 0xfe53},
    {0xfe67, 0xfe67},
    {0xfe6c, 0xfe6f},
    {0xfe75, 0xfe75},
    {0xfefd, 0xff00},
    {0xffa0, 0xffa0},
    {0xffbf, 0xffc1},
    {0xffc8, 0xffc9},
    {0xffd0, 0xffd1},
    {0xffd8, 0xffd9},
    {0xffdd, 0xffdf},
    {0xffe7, 0xffe7},
    {0xffef, 0xfffb},
    {0xfffe, 0xffff},
    {0x1000c, 0x1000c},
    {0x10027, 0x10027},
    {0x1003b, 0x1003b},
    {0x1003e, 0x1003e},
    {0x1004e, 0x1004f},
    {0x1005e, 0x1007f},
    {0x100fb, 0x100ff},
    {0x10103, 0x10106},
    {0x10134, 0x10136},
    {0x1018f, 0x1018f},
    {0x1019d, 0x1019f},
    {0x101a1, 0x101cf},
    {0x101fd, 0x1027f},
    {0x1029d, 0x1029f},
    {0x102d1, 0x102e0},
    {0x102fc, 0x102ff},
    {0x10324, 0x1032c},
    {0x1034b, 0x1034f},
    {0x10376, 0x1037f},
    {0x1039e, 0x1039e},
    {0x103c4, 0x103c7},
    {0x103d6, 0x103ff},
    {0x1049e, 0x1049f},
    {0x104aa, 0x104af},
    {0x104d4, 0x104d7},
    {0x104fc, 0x104ff},
    {0x10528, 0x1052f},
    {0x10564, 0x1056e},
    {0x1057b, 0x1057b},
    {0x1058b, 0x1058b},
    {0x10593, 0x10593},
    {0x10596, 0x10596},
    {0x105a2, 0x105a2},
    {0x105b2, 0x105b2},
    {0x105ba, 0x105ba},
    {0x105bd, 0x105bf},
    {0x105f4, 0x105ff},
    {0x10737, 0x1073f},
    {0x10756, 0x1075f},
    {0x10768, 0x1077f},
    {0x10786, 0x10786},
    {0x107b1, 0x107b1},
    {0x107bb, 0x107ff},
    {0x10806, 0x10807},
    {0x10809, 0x10809},
    {0x10836, 0x10836},
    {0x10839, 0x1083b},
    {0x1083d, 0x1083e},
    {0x10856, 0x10856},
    {0x1089f, 0x108a6},
    {0x108b0, 0x108df},
    {0x108f3, 0x108f3},
    {0x108f6, 0x108fa},
    {0x1091c, 0x1091e},
    {0x1093a, 0x1093e},
    {0x1095a, 0x1097f},
    {0x109b8, 0x109bb},
    {0x109d0, 0x109d1},
    {0x10a01, 0x10a0f},
    {0x10a14, 0x10a14},
    {0x10a18, 0x10a18},
    {0x10a36, 0x10a3f},
    {0x10a49, 0x10a4f},
    {0x10a59, 0x10a5f},
    {0x10aa0, 0x10abf},
    {0x10ae5, 0x10aea},
    {0x10af7, 0x10aff},
    {0x10b36, 0x10b38},
    {0x10b56, 0x10b57},
    {0x10b73, 0x10b77},
    {0x10b92, 0x10b98},
    {0x10b9d, 0x10ba8},
    {0x10bb0, 0x10bff},
    {0x10c49, 0x10c7f},
    {0x10cb3, 0x10cbf},
    {0x10cf3, 0x10cf9},
    {0x10d24, 0x10d2f},
    {0x10d3a, 0x10d3f},
    {0x10d66, 0x10d6d},
    {0x10d86, 0x10d8d},
    {0x10d90, 0x10e5f},
    {0x10e7f, 0x10e7f},
    {0x10eaa, 0x10eac},
    {0x10eae, 0x10eaf},
    {0x10eb2, 0x10ec1},
    {0x10ec8, 0x10ecf},
    {0x10ed9, 0x10eff},
    {0x10f28, 0x10f2f},
    {0x10f46, 0x10f50},
    {0x10f5a, 0x10f6f},
    {0x10f82, 0x10f85},
    {0x10f8a, 0x10faf},
    {0x10fcc, 0x10fdf},
    {0x10ff7, 0x10fff},
    {0x11001, 0x11001},
    {0x11038, 0x11046},
    {0x1104e, 0x11051},
    {0x11070, 0x11070},
    {0x11073, 0x11074},
    {0x11076, 0x11081},
    {0x110b3, 0x110b6},
    {0x110b9, 0x110ba},
    {0x110bd, 0x110bd},
    {0x110c2, 0x110cf},
    {0x110e9, 0x110ef},
    {0x110fa, 0x11102},
    {0x11127, 0x1112b},
    {0x1112d, 0x11135},
    {0x11148, 0x1114f},
    {0x11173, 0x11173},
    {0x11177, 0x11181},
    {0x111b6, 0x111be},
    {0x111c0, 0x111c0},
    {0x111c9, 0x111cc},
    {0x111cf, 0x111cf},
    {0x111e0, 0x111e0},
    {0x111f5, 0x111ff},
    {0x11212, 0x11212},
    {0x1122f, 0x11231},
    {0x11234, 0x11237},
    {0x1123e, 0x1123e},
    {0x11241, 0x1127f},
    {0x11287, 0x11287},
    {0x11289, 0x11289},
    {0x1128e, 0x1128e},
    {0x1129e, 0x1129e},
    {0x112aa, 0x112af},
    {0x112df, 0x112df},
    {0x112e3, 0x112ef},
    {0x112fa, 0x11301},
    {0x11304, 0x11304},
    {0x1130d, 0x1130e},
    {0x11311, 0x11312},
    {0x11329, 0x11329},
    {0x11331, 0x11331},
    {0x11334, 0x11334},
    {0x1133a, 0x1133c},
    {0x1133e, 0x1133e},
    {0x11340, 0x11340},
    {0x11345, 0x11346},
    {0x11349, 0x1134a},
    {0x1134d, 0x1134f},
    {0x11351, 0x1135c},
    {0x11364, 0x1137f},
    {0x1138a, 0x1138a},
    {0x1138c, 0x1138d},
    {0x1138f, 0x1138f},
    {0x113b6, 0x113b6},
    {0x113b8, 0x113b8},
    {0x113bb, 0x113c9},
    {0x113cb, 0x113cb},
    {0x113ce, 0x113d0},
    {0x113d2, 0x113d2},
    {0x113d6, 0x113d6},
    {0x113d9, 0x113ff},
    {0x11438, 0x1143f},
    {0x11442, 0x11444},
    {0x11446, 0x11446},
    {0x1145c, 0x1145c},
    {0x1145e, 0x1145e},
    {0x11462, 0x1147f},
    {0x114b0, 0x114b0},
    {0x114b3, 0x114b8},
    {0x114ba, 0x114ba},
    {0x114bd, 0x114bd},
    {0x114bf, 0x114c0},
    {0x114c2, 0x114c3},
    {0x114c8, 0x114cf},
    {0x114da, 0x1157f},
    {0x115af, 0x115af},
    {0x115b2, 0x115b7},
    {0x115bc, 0x115bd},
    {0x115bf, 0x115c0},
    {0x115dc, 0x115ff},
    {0x11633, 0x1163a},
    {0x1163d, 0x1163d},
    {0x1163f, 0x11640},
    {0x11645, 0x1164f},
    {0x1165a, 0x1165f},
    {0x1166d, 0x1167f},
    {0x116ab, 0x116ab},
    {0x116ad, 0x116ad},
    {0x116b0, 0x116b7},
    {0x116ba, 0x116bf},
    {0x116ca, 0x116cf},
    {0x116e4, 0x116ff},
    {0x1171b, 0x1171d},
    {0x1171f, 0x1171f},
    {0x11722, 0x11725},
    {0x11727, 0x1172f},
    {0x11747, 0x117ff},
    {0x1182f, 0x11837},
    {0x11839, 0x1183a},
    {0x1183c, 0x1189f},
    {0x118f3, 0x118fe},
    {0x11907, 0x11908},
    {0x1190a, 0x1190b},
    {0x11914, 0x11914},
    {0x11917, 0x11917},
    {0x11930, 0x11930},
    {0x11936, 0x11936},
    {0x11939, 0x1193e},
    {0x11943, 0x11943},
    {0x11947, 0x1194f},
    {0x1195a, 0x1199f},
    {0x119a8, 0x119a9},
    {0x119d4, 0x119db},
    {0x119e0, 0x119e0},
    {0x119e5, 0x119ff},
    {0x11a01, 0x11a0a},
    {0x11a33, 0x11a38},
    {0x11a3b, 0x11a3e},
    {0x11a47, 0x11a4f},
    {0x11a51, 0x11a56},
    {0x11a59, 0x11a5b},
    {0x11a8a, 0x11a96},
    {0x11a98, 0x11a99},
    {0x11aa3, 0x11aaf},
    {0x11af9, 0x11aff},
    {0x11b0a, 0x11b60},
    {0x11b62, 0x11b64},
    {0x11b66, 0x11b66},
    {0x11b68, 0x11bbf},
    {0x11be2, 0x11bef},
    {0x11bfa, 0x11bff},
    {0x11c09, 0x11c09},
    {0x11c30, 0x11c3d},
    {0x11c3f, 0x11c3f},
    {0x11c46, 0x11c4f},
    {0x11c6d, 0x11c6f},
    {0x11c90, 0x11ca8},
    {0x11caa, 0x11cb0},
    {0x11cb2, 0x11cb3},
    {0x11cb5, 0x11cff},
    {0x11d07, 0x11d07},
    {0x11d0a, 0x11d0a},
    {0x11d31, 0x11d45},
    {0x11d47, 0x11d4f},
    {0x11d5a, 0x11d5f},
    {0x11d66, 0x11d66},
    {0x11d69, 0x11d69},
    {0x11d8f, 0x11d92},
    {0x11d95, 0x11d95},
    {0x11d97, 0x11d97},
    {0x11d99, 0x11d9f},
    {0x11daa, 0x11daf},
    {0x11ddc, 0x11ddf},
    {0x11dea, 0x11edf},
    {0x11ef3, 0x11ef4},
    {0x11ef9, 0x11f01},
    {0x11f11, 0x11f11},
    {0x11f36, 0x11f3d},
    {0x11f40, 0x11f42},
    {0x11f5a, 0x11faf},
    {0x11fb1, 0x11fbf},
    {0x11ff2, 0x11ffe},
    {0x1239a, 0x123ff},
    {0x1246f, 0x1246f},
    {0x12475, 0x1247f},
    {0x12544, 0x12f8f},
    {0x12ff3, 0x12fff},
    {0x13430, 0x13440},
    {0x13447, 0x1345f},
    {0x143fb, 0x143ff},
    {0x14647, 0x160ff},
    {0x1611e, 0x16129},
    {0x1612d, 0x1612f},
    {0x1613a, 0x167ff},
    {0x16a39, 0x16a3f},
    {0x16a5f, 0x16a5f},
    {0x16a6a, 0x16a6d},
    {0x16abf, 0x16abf},
    {0x16aca, 0x16acf},
    {0x16aee, 0x16af4},
    {0x16af6, 0x16aff},
    {0x16b30, 0x16b36},
    {0x16b46, 0x16b4f},
    {0x16b5a, 0x16b5a},
    {0x16b62, 0x16b62},
    {0x16b78, 0x16b7c},
    {0x16b90, 0x16d3f},
    {0x16d7a, 0x16e3f},
    {0x16e9b, 0x16e9f},
    {0x16eb9, 0x16eba},
    {0x16ed4, 0x16eff},
    {0x16f4b, 0x16f4f},
    {0x16f88, 0x16f92},
    {0x16fa0, 0x16fdf},
    {0x16fe4, 0x16ff1},
    {0x16ff7, 0x16fff},
    {0x18cd6, 0x18cfe},
    {0x18d1f, 0x18d7f},
    {0x18df3, 0x1afef},
    {0x1aff4, 0x1aff4},
    {0x1affc, 0x1affc},
    {0x1afff, 0x1afff},
    {0x1b123, 0x1b131},
    {0x1b133, 0x1b14f},
    {0x1b153, 0x1b154},
    {0x1b156, 0x1b163},
    {0x1b168, 0x1b16f},
    {0x1b2fc, 0x1bbff},
    {0x1bc6b, 0x1bc6f},
    {0x1bc7d, 0x1bc7f},
    {0x1bc89, 0x1bc8f},
    {0x1bc9a, 0x1bc9b},
    {0x1bc9d, 0x1bc9e},
    {0x1bca0, 0x1cbff},
    {0x1ccfd, 0x1ccff},
    {0x1ceb4, 0x1ceb9},
    {0x1ced1, 0x1cedf},
    {0x1cef1, 0x1cf4f},
    {0x1cfc4, 0x1cfff},
    {0x1d0f6, 0x1d0ff},
    {0x1d127, 0x1d128},
    {0x1d165, 0x1d169},
    {0x1d16d, 0x1d182},
    {0x1d185, 0x1d18b},
    {0x1d1aa, 0x1d1ad},
    {0x1d1eb, 0x1d1ff},
    {0x1d242, 0x1d244},
    {0x1d246, 0x1d2bf},
    {0x1d2d4, 0x1d2df},
    {0x1d2f4, 0x1d2ff},
    {0x1d357, 0x1d35f},
    {0x1d379, 0x1d3ff},
    {0x1d455, 0x1d455},
    {0x1d49d, 0x1d49d},
    {0x1d4a0, 0x1d4a1},
    {0x1d4a3, 0x1d4a4},
    {0x1d4a7, 0x1d4a8},
    {0x1d4ad, 0x1d4ad},
    {0x1d4ba, 0x1d4ba},
    {0x1d4bc, 0x1d4bc},
    {0x1d4c4, 0x1d4c4},
    {0x1d506, 0x1d506},
    {0x1d50b, 0x1d50c},
    {0x1d515, 0x1d515},
    {0x1d51d, 0x1d51d},
    {0x1d53a, 0x1d53a},
    {0x1d53f, 0x1d53f},
    {0x1d545, 0x1d545},
    {0x1d547, 0x1d549},
    {0x1d551, 0x1d551},
    {0x1d6a6, 0x1d6a7},
    {0x1d7cc, 0x1d7cd},
    {0x1da00, 0x1da36},
    {0x1da3b, 0x1da6c},
    {0x1da75, 0x1da75},
    {0x1da84, 0x1da84},
    {0x1da8c, 0x1deff},
    {0x1df1f, 0x1df24},
    {0x1df2b, 0x1e02f},
    {0x1e06e, 0x1e0ff},
    {0x1e12d, 0x1e136},
    {0x1e13e, 0x1e13f},
    {0x1e14a, 0x1e14d},
    {0x1e150, 0x1e28f},
    {0x1e2ae, 0x1e2bf},
    {0x1e2ec, 0x1e2ef},
    {0x1e2fa, 0x1e2fe},
    {0x1e300, 0x1e4cf},
    {0x1e4ec, 0x1e4ef},
    {0x1e4fa, 0x1e5cf},
    {0x1e5ee, 0x1e5ef},
    {0x1e5fb, 0x1e5fe},
    {0x1e600, 0x1e6bf},
    {0x1e6df, 0x1e6df},
    {0x1e6e3, 0x1e6e3},
    {0x1e6e6, 0x1e6e6},
    {0x1e6ee, 0x1e6ef},
    {0x1e6f5, 0x1e6fd},
    {0x1e700, 0x1e7df},
    {0x1e7e7, 0x1e7e7},
    {0x1e7ec, 0x1e7ec},
    {0x1e7ef, 0x1e7ef},
    {0x1e7ff, 0x1e7ff},
    {0x1e8c5, 0x1e8c6},
    {0x1e8d0, 0x1e8ff},
    {0x1e944, 0x1e94a},
    {0x1e94c, 0x1e94f},
    {0x1e95a, 0x1e95d},
    {0x1e960, 0x1ec70},
    {0x1ecb5, 0x1ed00},
    {0x1ed3e, 0x1edff},
    {0x1ee04, 0x1ee04},
    {0x1ee20, 0x1ee20},
    {0x1ee23, 0x1ee23},
    {0x1ee25, 0x1ee26},
    {0x1ee28, 0x1ee28},
    {0x1ee33, 0x1ee33},
    {0x1ee38, 0x1ee38},
    {0x1ee3a, 0x1ee3a},
    {0x1ee3c, 0x1ee41},
    {0x1ee43, 0x1ee46},
    {0x1ee48, 0x1ee48},
    {0x1ee4a, 0x1ee4a},
    {0x1ee4c, 0x1ee4c},
    {0x1ee50, 0x1ee50},
    {0x1ee53, 0x1ee53},
    {0x1ee55, 0x1ee56},
    {0x1ee58, 0x1ee58},
    {0x1ee5a, 0x1ee5a},
    {0x1ee5c, 0x1ee5c},
    {0x1ee5e, 0x1ee5e},
    {0x1ee60, 0x1ee60},
    {0x1ee63, 0x1ee63},
    {0x1ee65, 0x1ee66},
    {0x1ee6b, 0x1ee6b},
    {0x1ee73, 0x1ee73},
    {0x1ee78, 0x1ee78},
    {0x1ee7d, 0x1ee7d},
    {0x1ee7f, 0x1ee7f},
    {0x1ee8a, 0x1ee8a},
    {0x1ee9c, 0x1eea0},
    {0x1eea4, 0x1eea4},
    {0x1eeaa, 0x1eeaa},
    {0x1eebc, 0x1eeef},
    {0x1eef2, 0x1efff},
    {0x1f02c, 0x1f02f},
    {0x1f094, 0x1f09f},
    {0x1f0af, 0x1f0b0},
    {0x1f0c0, 0x1f0c0},
    {0x1f0d0, 0x1f0d0},
    {0x1f0f6, 0x1f0ff},
    {0x1f1ae, 0x1f1e5},
    {0x1f203, 0x1f20f},
    {0x1f23c, 0x1f23f},
    {0x1f249, 0x1f24f},
    {0x1f252, 0x1f25f},
    {0x1f266, 0x1f2ff},
    {0x1f6d9, 0x1f6db},
    {0x1f6ed, 0x1f6ef},
    {0x1f6fd, 0x1f6ff},
    {0x1f7da, 0x1f7df},
    {0x1f7ec, 0x1f7ef},
    {0x1f7f1, 0x1f7ff},
    {0x1f80c, 0x1f80f},
    {0x1f848, 0x1f84f},
    {0x1f85a, 0x1f85f},
    {0x1f888, 0x1f88f},
    {0x1f8ae, 0x1f8af},
    {0x1f8bc, 0x1f8bf},
    {0x1f8c2, 0x1f8cf},
    {0x1f8d9, 0x1f8ff},
    {0x1fa58, 0x1fa5f},
    {0x1fa6e, 0x1fa6f},
    {0x1fa7d, 0x1fa7f},
    {0x1fa8b, 0x1fa8d},
    {0x1fac7, 0x1fac7},
    {0x1fac9, 0x1facc},
    {0x1fadd, 0x1fade},
    {0x1faeb, 0x1faee},
    {0x1faf9, 0x1faff},
    {0x1fb93, 0x1fb93},
    {0x1fbfb, 0x1ffff},
    {0x2a6e0, 0x2a6ff},
    {0x2b81e, 0x2b81f},
    {0x2ceae, 0x2ceaf},
    {0x2ebe1, 0x2ebef},
    {0x2ee5e, 0x2f7ff},
    {0x2fa1e, 0x2ffff},
    {0x3134b, 0x3134f},
    {0x3347a, 0x10ffff},
};

/* Unicode char predicate ranges, generated by tools/gen_unicode.rs as
   compiled by rustc 1.99.0 (b940084d7 2026-09-28) (Unicode 17.0.0, char::UNICODE_VERSION).
   Regenerate with scripts/gen-unicode.sh. Do not edit. */
static const uint32_t lust_uni_alphabetic_ranges[][2] = {
    {0x41, 0x5a}, {0x61, 0x7a}, {0xaa, 0xaa}, {0xb5, 0xb5}, {0xba, 0xba}, {0xc0, 0xd6}, 
    {0xd8, 0xf6}, {0xf8, 0x2c1}, {0x2c6, 0x2d1}, {0x2e0, 0x2e4}, {0x2ec, 0x2ec}, {0x2ee, 0x2ee}, 
    {0x345, 0x345}, {0x363, 0x374}, {0x376, 0x377}, {0x37a, 0x37d}, {0x37f, 0x37f}, {0x386, 0x386}, 
    {0x388, 0x38a}, {0x38c, 0x38c}, {0x38e, 0x3a1}, {0x3a3, 0x3f5}, {0x3f7, 0x481}, {0x48a, 0x52f}, 
    {0x531, 0x556}, {0x559, 0x559}, {0x560, 0x588}, {0x5b0, 0x5bd}, {0x5bf, 0x5bf}, {0x5c1, 0x5c2}, 
    {0x5c4, 0x5c5}, {0x5c7, 0x5c7}, {0x5d0, 0x5ea}, {0x5ef, 0x5f2}, {0x610, 0x61a}, {0x620, 0x657}, 
    {0x659, 0x65f}, {0x66e, 0x6d3}, {0x6d5, 0x6dc}, {0x6e1, 0x6e8}, {0x6ed, 0x6ef}, {0x6fa, 0x6fc}, 
    {0x6ff, 0x6ff}, {0x710, 0x73f}, {0x74d, 0x7b1}, {0x7ca, 0x7ea}, {0x7f4, 0x7f5}, {0x7fa, 0x7fa}, 
    {0x800, 0x817}, {0x81a, 0x82c}, {0x840, 0x858}, {0x860, 0x86a}, {0x870, 0x887}, {0x889, 0x88f}, 
    {0x897, 0x897}, {0x8a0, 0x8c9}, {0x8d4, 0x8df}, {0x8e3, 0x8e9}, {0x8f0, 0x93b}, {0x93d, 0x94c}, 
    {0x94e, 0x950}, {0x955, 0x963}, {0x971, 0x983}, {0x985, 0x98c}, {0x98f, 0x990}, {0x993, 0x9a8}, 
    {0x9aa, 0x9b0}, {0x9b2, 0x9b2}, {0x9b6, 0x9b9}, {0x9bd, 0x9c4}, {0x9c7, 0x9c8}, {0x9cb, 0x9cc}, 
    {0x9ce, 0x9ce}, {0x9d7, 0x9d7}, {0x9dc, 0x9dd}, {0x9df, 0x9e3}, {0x9f0, 0x9f1}, {0x9fc, 0x9fc}, 
    {0xa01, 0xa03}, {0xa05, 0xa0a}, {0xa0f, 0xa10}, {0xa13, 0xa28}, {0xa2a, 0xa30}, {0xa32, 0xa33}, 
    {0xa35, 0xa36}, {0xa38, 0xa39}, {0xa3e, 0xa42}, {0xa47, 0xa48}, {0xa4b, 0xa4c}, {0xa51, 0xa51}, 
    {0xa59, 0xa5c}, {0xa5e, 0xa5e}, {0xa70, 0xa75}, {0xa81, 0xa83}, {0xa85, 0xa8d}, {0xa8f, 0xa91}, 
    {0xa93, 0xaa8}, {0xaaa, 0xab0}, {0xab2, 0xab3}, {0xab5, 0xab9}, {0xabd, 0xac5}, {0xac7, 0xac9}, 
    {0xacb, 0xacc}, {0xad0, 0xad0}, {0xae0, 0xae3}, {0xaf9, 0xafc}, {0xb01, 0xb03}, {0xb05, 0xb0c}, 
    {0xb0f, 0xb10}, {0xb13, 0xb28}, {0xb2a, 0xb30}, {0xb32, 0xb33}, {0xb35, 0xb39}, {0xb3d, 0xb44}, 
    {0xb47, 0xb48}, {0xb4b, 0xb4c}, {0xb56, 0xb57}, {0xb5c, 0xb5d}, {0xb5f, 0xb63}, {0xb71, 0xb71}, 
    {0xb82, 0xb83}, {0xb85, 0xb8a}, {0xb8e, 0xb90}, {0xb92, 0xb95}, {0xb99, 0xb9a}, {0xb9c, 0xb9c}, 
    {0xb9e, 0xb9f}, {0xba3, 0xba4}, {0xba8, 0xbaa}, {0xbae, 0xbb9}, {0xbbe, 0xbc2}, {0xbc6, 0xbc8}, 
    {0xbca, 0xbcc}, {0xbd0, 0xbd0}, {0xbd7, 0xbd7}, {0xc00, 0xc0c}, {0xc0e, 0xc10}, {0xc12, 0xc28}, 
    {0xc2a, 0xc39}, {0xc3d, 0xc44}, {0xc46, 0xc48}, {0xc4a, 0xc4c}, {0xc55, 0xc56}, {0xc58, 0xc5a}, 
    {0xc5c, 0xc5d}, {0xc60, 0xc63}, {0xc80, 0xc83}, {0xc85, 0xc8c}, {0xc8e, 0xc90}, {0xc92, 0xca8}, 
    {0xcaa, 0xcb3}, {0xcb5, 0xcb9}, {0xcbd, 0xcc4}, {0xcc6, 0xcc8}, {0xcca, 0xccc}, {0xcd5, 0xcd6}, 
    {0xcdc, 0xcde}, {0xce0, 0xce3}, {0xcf1, 0xcf3}, {0xd00, 0xd0c}, {0xd0e, 0xd10}, {0xd12, 0xd3a}, 
    {0xd3d, 0xd44}, {0xd46, 0xd48}, {0xd4a, 0xd4c}, {0xd4e, 0xd4e}, {0xd54, 0xd57}, {0xd5f, 0xd63}, 
    {0xd7a, 0xd7f}, {0xd81, 0xd83}, {0xd85, 0xd96}, {0xd9a, 0xdb1}, {0xdb3, 0xdbb}, {0xdbd, 0xdbd}, 
    {0xdc0, 0xdc6}, {0xdcf, 0xdd4}, {0xdd6, 0xdd6}, {0xdd8, 0xddf}, {0xdf2, 0xdf3}, {0xe01, 0xe3a}, 
    {0xe40, 0xe46}, {0xe4d, 0xe4d}, {0xe81, 0xe82}, {0xe84, 0xe84}, {0xe86, 0xe8a}, {0xe8c, 0xea3}, 
    {0xea5, 0xea5}, {0xea7, 0xeb9}, {0xebb, 0xebd}, {0xec0, 0xec4}, {0xec6, 0xec6}, {0xecd, 0xecd}, 
    {0xedc, 0xedf}, {0xf00, 0xf00}, {0xf40, 0xf47}, {0xf49, 0xf6c}, {0xf71, 0xf83}, {0xf88, 0xf97}, 
    {0xf99, 0xfbc}, {0x1000, 0x1036}, {0x1038, 0x1038}, {0x103b, 0x103f}, {0x1050, 0x108f}, {0x109a, 0x109d}, 
    {0x10a0, 0x10c5}, {0x10c7, 0x10c7}, {0x10cd, 0x10cd}, {0x10d0, 0x10fa}, {0x10fc, 0x1248}, {0x124a, 0x124d}, 
    {0x1250, 0x1256}, {0x1258, 0x1258}, {0x125a, 0x125d}, {0x1260, 0x1288}, {0x128a, 0x128d}, {0x1290, 0x12b0}, 
    {0x12b2, 0x12b5}, {0x12b8, 0x12be}, {0x12c0, 0x12c0}, {0x12c2, 0x12c5}, {0x12c8, 0x12d6}, {0x12d8, 0x1310}, 
    {0x1312, 0x1315}, {0x1318, 0x135a}, {0x1380, 0x138f}, {0x13a0, 0x13f5}, {0x13f8, 0x13fd}, {0x1401, 0x166c}, 
    {0x166f, 0x167f}, {0x1681, 0x169a}, {0x16a0, 0x16ea}, {0x16ee, 0x16f8}, {0x1700, 0x1713}, {0x171f, 0x1733}, 
    {0x1740, 0x1753}, {0x1760, 0x176c}, {0x176e, 0x1770}, {0x1772, 0x1773}, {0x1780, 0x17b3}, {0x17b6, 0x17c8}, 
    {0x17d7, 0x17d7}, {0x17dc, 0x17dc}, {0x1820, 0x1878}, {0x1880, 0x18aa}, {0x18b0, 0x18f5}, {0x1900, 0x191e}, 
    {0x1920, 0x192b}, {0x1930, 0x1938}, {0x1950, 0x196d}, {0x1970, 0x1974}, {0x1980, 0x19ab}, {0x19b0, 0x19c9}, 
    {0x1a00, 0x1a1b}, {0x1a20, 0x1a5e}, {0x1a61, 0x1a74}, {0x1aa7, 0x1aa7}, {0x1abf, 0x1ac0}, {0x1acc, 0x1ace}, 
    {0x1b00, 0x1b33}, {0x1b35, 0x1b43}, {0x1b45, 0x1b4c}, {0x1b80, 0x1ba9}, {0x1bac, 0x1baf}, {0x1bba, 0x1be5}, 
    {0x1be7, 0x1bf1}, {0x1c00, 0x1c36}, {0x1c4d, 0x1c4f}, {0x1c5a, 0x1c7d}, {0x1c80, 0x1c8a}, {0x1c90, 0x1cba}, 
    {0x1cbd, 0x1cbf}, {0x1ce9, 0x1cec}, {0x1cee, 0x1cf3}, {0x1cf5, 0x1cf6}, {0x1cfa, 0x1cfa}, {0x1d00, 0x1dbf}, 
    {0x1dd3, 0x1df4}, {0x1e00, 0x1f15}, {0x1f18, 0x1f1d}, {0x1f20, 0x1f45}, {0x1f48, 0x1f4d}, {0x1f50, 0x1f57}, 
    {0x1f59, 0x1f59}, {0x1f5b, 0x1f5b}, {0x1f5d, 0x1f5d}, {0x1f5f, 0x1f7d}, {0x1f80, 0x1fb4}, {0x1fb6, 0x1fbc}, 
    {0x1fbe, 0x1fbe}, {0x1fc2, 0x1fc4}, {0x1fc6, 0x1fcc}, {0x1fd0, 0x1fd3}, {0x1fd6, 0x1fdb}, {0x1fe0, 0x1fec}, 
    {0x1ff2, 0x1ff4}, {0x1ff6, 0x1ffc}, {0x2071, 0x2071}, {0x207f, 0x207f}, {0x2090, 0x209c}, {0x2102, 0x2102}, 
    {0x2107, 0x2107}, {0x210a, 0x2113}, {0x2115, 0x2115}, {0x2119, 0x211d}, {0x2124, 0x2124}, {0x2126, 0x2126}, 
    {0x2128, 0x2128}, {0x212a, 0x212d}, {0x212f, 0x2139}, {0x213c, 0x213f}, {0x2145, 0x2149}, {0x214e, 0x214e}, 
    {0x2160, 0x2188}, {0x24b6, 0x24e9}, {0x2c00, 0x2ce4}, {0x2ceb, 0x2cee}, {0x2cf2, 0x2cf3}, {0x2d00, 0x2d25}, 
    {0x2d27, 0x2d27}, {0x2d2d, 0x2d2d}, {0x2d30, 0x2d67}, {0x2d6f, 0x2d6f}, {0x2d80, 0x2d96}, {0x2da0, 0x2da6}, 
    {0x2da8, 0x2dae}, {0x2db0, 0x2db6}, {0x2db8, 0x2dbe}, {0x2dc0, 0x2dc6}, {0x2dc8, 0x2dce}, {0x2dd0, 0x2dd6}, 
    {0x2dd8, 0x2dde}, {0x2de0, 0x2dff}, {0x2e2f, 0x2e2f}, {0x3005, 0x3007}, {0x3021, 0x3029}, {0x3031, 0x3035}, 
    {0x3038, 0x303c}, {0x3041, 0x3096}, {0x309d, 0x309f}, {0x30a1, 0x30fa}, {0x30fc, 0x30ff}, {0x3105, 0x312f}, 
    {0x3131, 0x318e}, {0x31a0, 0x31bf}, {0x31f0, 0x31ff}, {0x3400, 0x4dbf}, {0x4e00, 0xa48c}, {0xa4d0, 0xa4fd}, 
    {0xa500, 0xa60c}, {0xa610, 0xa61f}, {0xa62a, 0xa62b}, {0xa640, 0xa66e}, {0xa674, 0xa67b}, {0xa67f, 0xa6ef}, 
    {0xa717, 0xa71f}, {0xa722, 0xa788}, {0xa78b, 0xa7dc}, {0xa7f1, 0xa805}, {0xa807, 0xa827}, {0xa840, 0xa873}, 
    {0xa880, 0xa8c3}, {0xa8c5, 0xa8c5}, {0xa8f2, 0xa8f7}, {0xa8fb, 0xa8fb}, {0xa8fd, 0xa8ff}, {0xa90a, 0xa92a}, 
    {0xa930, 0xa952}, {0xa960, 0xa97c}, {0xa980, 0xa9b2}, {0xa9b4, 0xa9bf}, {0xa9cf, 0xa9cf}, {0xa9e0, 0xa9ef}, 
    {0xa9fa, 0xa9fe}, {0xaa00, 0xaa36}, {0xaa40, 0xaa4d}, {0xaa60, 0xaa76}, {0xaa7a, 0xaabe}, {0xaac0, 0xaac0}, 
    {0xaac2, 0xaac2}, {0xaadb, 0xaadd}, {0xaae0, 0xaaef}, {0xaaf2, 0xaaf5}, {0xab01, 0xab06}, {0xab09, 0xab0e}, 
    {0xab11, 0xab16}, {0xab20, 0xab26}, {0xab28, 0xab2e}, {0xab30, 0xab5a}, {0xab5c, 0xab69}, {0xab70, 0xabea}, 
    {0xac00, 0xd7a3}, {0xd7b0, 0xd7c6}, {0xd7cb, 0xd7fb}, {0xf900, 0xfa6d}, {0xfa70, 0xfad9}, {0xfb00, 0xfb06}, 
    {0xfb13, 0xfb17}, {0xfb1d, 0xfb28}, {0xfb2a, 0xfb36}, {0xfb38, 0xfb3c}, {0xfb3e, 0xfb3e}, {0xfb40, 0xfb41}, 
    {0xfb43, 0xfb44}, {0xfb46, 0xfbb1}, {0xfbd3, 0xfd3d}, {0xfd50, 0xfd8f}, {0xfd92, 0xfdc7}, {0xfdf0, 0xfdfb}, 
    {0xfe70, 0xfe74}, {0xfe76, 0xfefc}, {0xff21, 0xff3a}, {0xff41, 0xff5a}, {0xff66, 0xffbe}, {0xffc2, 0xffc7}, 
    {0xffca, 0xffcf}, {0xffd2, 0xffd7}, {0xffda, 0xffdc}, {0x10000, 0x1000b}, {0x1000d, 0x10026}, {0x10028, 0x1003a}, 
    {0x1003c, 0x1003d}, {0x1003f, 0x1004d}, {0x10050, 0x1005d}, {0x10080, 0x100fa}, {0x10140, 0x10174}, {0x10280, 0x1029c}, 
    {0x102a0, 0x102d0}, {0x10300, 0x1031f}, {0x1032d, 0x1034a}, {0x10350, 0x1037a}, {0x10380, 0x1039d}, {0x103a0, 0x103c3}, 
    {0x103c8, 0x103cf}, {0x103d1, 0x103d5}, {0x10400, 0x1049d}, {0x104b0, 0x104d3}, {0x104d8, 0x104fb}, {0x10500, 0x10527}, 
    {0x10530, 0x10563}, {0x10570, 0x1057a}, {0x1057c, 0x1058a}, {0x1058c, 0x10592}, {0x10594, 0x10595}, {0x10597, 0x105a1}, 
    {0x105a3, 0x105b1}, {0x105b3, 0x105b9}, {0x105bb, 0x105bc}, {0x105c0, 0x105f3}, {0x10600, 0x10736}, {0x10740, 0x10755}, 
    {0x10760, 0x10767}, {0x10780, 0x10785}, {0x10787, 0x107b0}, {0x107b2, 0x107ba}, {0x10800, 0x10805}, {0x10808, 0x10808}, 
    {0x1080a, 0x10835}, {0x10837, 0x10838}, {0x1083c, 0x1083c}, {0x1083f, 0x10855}, {0x10860, 0x10876}, {0x10880, 0x1089e}, 
    {0x108e0, 0x108f2}, {0x108f4, 0x108f5}, {0x10900, 0x10915}, {0x10920, 0x10939}, {0x10940, 0x10959}, {0x10980, 0x109b7}, 
    {0x109be, 0x109bf}, {0x10a00, 0x10a03}, {0x10a05, 0x10a06}, {0x10a0c, 0x10a13}, {0x10a15, 0x10a17}, {0x10a19, 0x10a35}, 
    {0x10a60, 0x10a7c}, {0x10a80, 0x10a9c}, {0x10ac0, 0x10ac7}, {0x10ac9, 0x10ae4}, {0x10b00, 0x10b35}, {0x10b40, 0x10b55}, 
    {0x10b60, 0x10b72}, {0x10b80, 0x10b91}, {0x10c00, 0x10c48}, {0x10c80, 0x10cb2}, {0x10cc0, 0x10cf2}, {0x10d00, 0x10d27}, 
    {0x10d4a, 0x10d65}, {0x10d69, 0x10d69}, {0x10d6f, 0x10d85}, {0x10e80, 0x10ea9}, {0x10eab, 0x10eac}, {0x10eb0, 0x10eb1}, 
    {0x10ec2, 0x10ec7}, {0x10efa, 0x10efc}, {0x10f00, 0x10f1c}, {0x10f27, 0x10f27}, {0x10f30, 0x10f45}, {0x10f70, 0x10f81}, 
    {0x10fb0, 0x10fc4}, {0x10fe0, 0x10ff6}, {0x11000, 0x11045}, {0x11071, 0x11075}, {0x11080, 0x110b8}, {0x110c2, 0x110c2}, 
    {0x110d0, 0x110e8}, {0x11100, 0x11132}, {0x11144, 0x11147}, {0x11150, 0x11172}, {0x11176, 0x11176}, {0x11180, 0x111bf}, 
    {0x111c1, 0x111c4}, {0x111ce, 0x111cf}, {0x111da, 0x111da}, {0x111dc, 0x111dc}, {0x11200, 0x11211}, {0x11213, 0x11234}, 
    {0x11237, 0x11237}, {0x1123e, 0x11241}, {0x11280, 0x11286}, {0x11288, 0x11288}, {0x1128a, 0x1128d}, {0x1128f, 0x1129d}, 
    {0x1129f, 0x112a8}, {0x112b0, 0x112e8}, {0x11300, 0x11303}, {0x11305, 0x1130c}, {0x1130f, 0x11310}, {0x11313, 0x11328}, 
    {0x1132a, 0x11330}, {0x11332, 0x11333}, {0x11335, 0x11339}, {0x1133d, 0x11344}, {0x11347, 0x11348}, {0x1134b, 0x1134c}, 
    {0x11350, 0x11350}, {0x11357, 0x11357}, {0x1135d, 0x11363}, {0x11380, 0x11389}, {0x1138b, 0x1138b}, {0x1138e, 0x1138e}, 
    {0x11390, 0x113b5}, {0x113b7, 0x113c0}, {0x113c2, 0x113c2}, {0x113c5, 0x113c5}, {0x113c7, 0x113ca}, {0x113cc, 0x113cd}, 
    {0x113d1, 0x113d1}, {0x113d3, 0x113d3}, {0x11400, 0x11441}, {0x11443, 0x11445}, {0x11447, 0x1144a}, {0x1145f, 0x11461}, 
    {0x11480, 0x114c1}, {0x114c4, 0x114c5}, {0x114c7, 0x114c7}, {0x11580, 0x115b5}, {0x115b8, 0x115be}, {0x115d8, 0x115dd}, 
    {0x11600, 0x1163e}, {0x11640, 0x11640}, {0x11644, 0x11644}, {0x11680, 0x116b5}, {0x116b8, 0x116b8}, {0x11700, 0x1171a}, 
    {0x1171d, 0x1172a}, {0x11740, 0x11746}, {0x11800, 0x11838}, {0x118a0, 0x118df}, {0x118ff, 0x11906}, {0x11909, 0x11909}, 
    {0x1190c, 0x11913}, {0x11915, 0x11916}, {0x11918, 0x11935}, {0x11937, 0x11938}, {0x1193b, 0x1193c}, {0x1193f, 0x11942}, 
    {0x119a0, 0x119a7}, {0x119aa, 0x119d7}, {0x119da, 0x119df}, {0x119e1, 0x119e1}, {0x119e3, 0x119e4}, {0x11a00, 0x11a32}, 
    {0x11a35, 0x11a3e}, {0x11a50, 0x11a97}, {0x11a9d, 0x11a9d}, {0x11ab0, 0x11af8}, {0x11b60, 0x11b67}, {0x11bc0, 0x11be0}, 
    {0x11c00, 0x11c08}, {0x11c0a, 0x11c36}, {0x11c38, 0x11c3e}, {0x11c40, 0x11c40}, {0x11c72, 0x11c8f}, {0x11c92, 0x11ca7}, 
    {0x11ca9, 0x11cb6}, {0x11d00, 0x11d06}, {0x11d08, 0x11d09}, {0x11d0b, 0x11d36}, {0x11d3a, 0x11d3a}, {0x11d3c, 0x11d3d}, 
    {0x11d3f, 0x11d41}, {0x11d43, 0x11d43}, {0x11d46, 0x11d47}, {0x11d60, 0x11d65}, {0x11d67, 0x11d68}, {0x11d6a, 0x11d8e}, 
    {0x11d90, 0x11d91}, {0x11d93, 0x11d96}, {0x11d98, 0x11d98}, {0x11db0, 0x11ddb}, {0x11ee0, 0x11ef6}, {0x11f00, 0x11f10}, 
    {0x11f12, 0x11f3a}, {0x11f3e, 0x11f40}, {0x11fb0, 0x11fb0}, {0x12000, 0x12399}, {0x12400, 0x1246e}, {0x12480, 0x12543}, 
    {0x12f90, 0x12ff0}, {0x13000, 0x1342f}, {0x13441, 0x13446}, {0x13460, 0x143fa}, {0x14400, 0x14646}, {0x16100, 0x1612e}, 
    {0x16800, 0x16a38}, {0x16a40, 0x16a5e}, {0x16a70, 0x16abe}, {0x16ad0, 0x16aed}, {0x16b00, 0x16b2f}, {0x16b40, 0x16b43}, 
    {0x16b63, 0x16b77}, {0x16b7d, 0x16b8f}, {0x16d40, 0x16d6c}, {0x16e40, 0x16e7f}, {0x16ea0, 0x16eb8}, {0x16ebb, 0x16ed3}, 
    {0x16f00, 0x16f4a}, {0x16f4f, 0x16f87}, {0x16f8f, 0x16f9f}, {0x16fe0, 0x16fe1}, {0x16fe3, 0x16fe3}, {0x16ff0, 0x16ff6}, 
    {0x17000, 0x18cd5}, {0x18cff, 0x18d1e}, {0x18d80, 0x18df2}, {0x1aff0, 0x1aff3}, {0x1aff5, 0x1affb}, {0x1affd, 0x1affe}, 
    {0x1b000, 0x1b122}, {0x1b132, 0x1b132}, {0x1b150, 0x1b152}, {0x1b155, 0x1b155}, {0x1b164, 0x1b167}, {0x1b170, 0x1b2fb}, 
    {0x1bc00, 0x1bc6a}, {0x1bc70, 0x1bc7c}, {0x1bc80, 0x1bc88}, {0x1bc90, 0x1bc99}, {0x1bc9e, 0x1bc9e}, {0x1d400, 0x1d454}, 
    {0x1d456, 0x1d49c}, {0x1d49e, 0x1d49f}, {0x1d4a2, 0x1d4a2}, {0x1d4a5, 0x1d4a6}, {0x1d4a9, 0x1d4ac}, {0x1d4ae, 0x1d4b9}, 
    {0x1d4bb, 0x1d4bb}, {0x1d4bd, 0x1d4c3}, {0x1d4c5, 0x1d505}, {0x1d507, 0x1d50a}, {0x1d50d, 0x1d514}, {0x1d516, 0x1d51c}, 
    {0x1d51e, 0x1d539}, {0x1d53b, 0x1d53e}, {0x1d540, 0x1d544}, {0x1d546, 0x1d546}, {0x1d54a, 0x1d550}, {0x1d552, 0x1d6a5}, 
    {0x1d6a8, 0x1d6c0}, {0x1d6c2, 0x1d6da}, {0x1d6dc, 0x1d6fa}, {0x1d6fc, 0x1d714}, {0x1d716, 0x1d734}, {0x1d736, 0x1d74e}, 
    {0x1d750, 0x1d76e}, {0x1d770, 0x1d788}, {0x1d78a, 0x1d7a8}, {0x1d7aa, 0x1d7c2}, {0x1d7c4, 0x1d7cb}, {0x1df00, 0x1df1e}, 
    {0x1df25, 0x1df2a}, {0x1e000, 0x1e006}, {0x1e008, 0x1e018}, {0x1e01b, 0x1e021}, {0x1e023, 0x1e024}, {0x1e026, 0x1e02a}, 
    {0x1e030, 0x1e06d}, {0x1e08f, 0x1e08f}, {0x1e100, 0x1e12c}, {0x1e137, 0x1e13d}, {0x1e14e, 0x1e14e}, {0x1e290, 0x1e2ad}, 
    {0x1e2c0, 0x1e2eb}, {0x1e4d0, 0x1e4eb}, {0x1e5d0, 0x1e5ed}, {0x1e5f0, 0x1e5f0}, {0x1e6c0, 0x1e6de}, {0x1e6e0, 0x1e6f5}, 
    {0x1e6fe, 0x1e6ff}, {0x1e7e0, 0x1e7e6}, {0x1e7e8, 0x1e7eb}, {0x1e7ed, 0x1e7ee}, {0x1e7f0, 0x1e7fe}, {0x1e800, 0x1e8c4}, 
    {0x1e900, 0x1e943}, {0x1e947, 0x1e947}, {0x1e94b, 0x1e94b}, {0x1ee00, 0x1ee03}, {0x1ee05, 0x1ee1f}, {0x1ee21, 0x1ee22}, 
    {0x1ee24, 0x1ee24}, {0x1ee27, 0x1ee27}, {0x1ee29, 0x1ee32}, {0x1ee34, 0x1ee37}, {0x1ee39, 0x1ee39}, {0x1ee3b, 0x1ee3b}, 
    {0x1ee42, 0x1ee42}, {0x1ee47, 0x1ee47}, {0x1ee49, 0x1ee49}, {0x1ee4b, 0x1ee4b}, {0x1ee4d, 0x1ee4f}, {0x1ee51, 0x1ee52}, 
    {0x1ee54, 0x1ee54}, {0x1ee57, 0x1ee57}, {0x1ee59, 0x1ee59}, {0x1ee5b, 0x1ee5b}, {0x1ee5d, 0x1ee5d}, {0x1ee5f, 0x1ee5f}, 
    {0x1ee61, 0x1ee62}, {0x1ee64, 0x1ee64}, {0x1ee67, 0x1ee6a}, {0x1ee6c, 0x1ee72}, {0x1ee74, 0x1ee77}, {0x1ee79, 0x1ee7c}, 
    {0x1ee7e, 0x1ee7e}, {0x1ee80, 0x1ee89}, {0x1ee8b, 0x1ee9b}, {0x1eea1, 0x1eea3}, {0x1eea5, 0x1eea9}, {0x1eeab, 0x1eebb}, 
    {0x1f130, 0x1f149}, {0x1f150, 0x1f169}, {0x1f170, 0x1f189}, {0x20000, 0x2a6df}, {0x2a700, 0x2b81d}, {0x2b820, 0x2cead}, 
    {0x2ceb0, 0x2ebe0}, {0x2ebf0, 0x2ee5d}, {0x2f800, 0x2fa1d}, {0x30000, 0x3134a}, {0x31350, 0x33479}, 
};
static const uint32_t lust_uni_numeric_ranges[][2] = {
    {0x30, 0x39}, {0xb2, 0xb3}, {0xb9, 0xb9}, {0xbc, 0xbe}, {0x660, 0x669}, {0x6f0, 0x6f9}, 
    {0x7c0, 0x7c9}, {0x966, 0x96f}, {0x9e6, 0x9ef}, {0x9f4, 0x9f9}, {0xa66, 0xa6f}, {0xae6, 0xaef}, 
    {0xb66, 0xb6f}, {0xb72, 0xb77}, {0xbe6, 0xbf2}, {0xc66, 0xc6f}, {0xc78, 0xc7e}, {0xce6, 0xcef}, 
    {0xd58, 0xd5e}, {0xd66, 0xd78}, {0xde6, 0xdef}, {0xe50, 0xe59}, {0xed0, 0xed9}, {0xf20, 0xf33}, 
    {0x1040, 0x1049}, {0x1090, 0x1099}, {0x1369, 0x137c}, {0x16ee, 0x16f0}, {0x17e0, 0x17e9}, {0x17f0, 0x17f9}, 
    {0x1810, 0x1819}, {0x1946, 0x194f}, {0x19d0, 0x19da}, {0x1a80, 0x1a89}, {0x1a90, 0x1a99}, {0x1b50, 0x1b59}, 
    {0x1bb0, 0x1bb9}, {0x1c40, 0x1c49}, {0x1c50, 0x1c59}, {0x2070, 0x2070}, {0x2074, 0x2079}, {0x2080, 0x2089}, 
    {0x2150, 0x2182}, {0x2185, 0x2189}, {0x2460, 0x249b}, {0x24ea, 0x24ff}, {0x2776, 0x2793}, {0x2cfd, 0x2cfd}, 
    {0x3007, 0x3007}, {0x3021, 0x3029}, {0x3038, 0x303a}, {0x3192, 0x3195}, {0x3220, 0x3229}, {0x3248, 0x324f}, 
    {0x3251, 0x325f}, {0x3280, 0x3289}, {0x32b1, 0x32bf}, {0xa620, 0xa629}, {0xa6e6, 0xa6ef}, {0xa830, 0xa835}, 
    {0xa8d0, 0xa8d9}, {0xa900, 0xa909}, {0xa9d0, 0xa9d9}, {0xa9f0, 0xa9f9}, {0xaa50, 0xaa59}, {0xabf0, 0xabf9}, 
    {0xff10, 0xff19}, {0x10107, 0x10133}, {0x10140, 0x10178}, {0x1018a, 0x1018b}, {0x102e1, 0x102fb}, {0x10320, 0x10323}, 
    {0x10341, 0x10341}, {0x1034a, 0x1034a}, {0x103d1, 0x103d5}, {0x104a0, 0x104a9}, {0x10858, 0x1085f}, {0x10879, 0x1087f}, 
    {0x108a7, 0x108af}, {0x108fb, 0x108ff}, {0x10916, 0x1091b}, {0x109bc, 0x109bd}, {0x109c0, 0x109cf}, {0x109d2, 0x109ff}, 
    {0x10a40, 0x10a48}, {0x10a7d, 0x10a7e}, {0x10a9d, 0x10a9f}, {0x10aeb, 0x10aef}, {0x10b58, 0x10b5f}, {0x10b78, 0x10b7f}, 
    {0x10ba9, 0x10baf}, {0x10cfa, 0x10cff}, {0x10d30, 0x10d39}, {0x10d40, 0x10d49}, {0x10e60, 0x10e7e}, {0x10f1d, 0x10f26}, 
    {0x10f51, 0x10f54}, {0x10fc5, 0x10fcb}, {0x11052, 0x1106f}, {0x110f0, 0x110f9}, {0x11136, 0x1113f}, {0x111d0, 0x111d9}, 
    {0x111e1, 0x111f4}, {0x112f0, 0x112f9}, {0x11450, 0x11459}, {0x114d0, 0x114d9}, {0x11650, 0x11659}, {0x116c0, 0x116c9}, 
    {0x116d0, 0x116e3}, {0x11730, 0x1173b}, {0x118e0, 0x118f2}, {0x11950, 0x11959}, {0x11bf0, 0x11bf9}, {0x11c50, 0x11c6c}, 
    {0x11d50, 0x11d59}, {0x11da0, 0x11da9}, {0x11de0, 0x11de9}, {0x11f50, 0x11f59}, {0x11fc0, 0x11fd4}, {0x12400, 0x1246e}, 
    {0x16130, 0x16139}, {0x16a60, 0x16a69}, {0x16ac0, 0x16ac9}, {0x16b50, 0x16b59}, {0x16b5b, 0x16b61}, {0x16d70, 0x16d79}, 
    {0x16e80, 0x16e96}, {0x16ff4, 0x16ff6}, {0x1ccf0, 0x1ccf9}, {0x1d2c0, 0x1d2d3}, {0x1d2e0, 0x1d2f3}, {0x1d360, 0x1d378}, 
    {0x1d7ce, 0x1d7ff}, {0x1e140, 0x1e149}, {0x1e2f0, 0x1e2f9}, {0x1e4f0, 0x1e4f9}, {0x1e5f1, 0x1e5fa}, {0x1e8c7, 0x1e8cf}, 
    {0x1e950, 0x1e959}, {0x1ec71, 0x1ecab}, {0x1ecad, 0x1ecaf}, {0x1ecb1, 0x1ecb4}, {0x1ed01, 0x1ed2d}, {0x1ed2f, 0x1ed3d}, 
    {0x1f100, 0x1f10c}, {0x1fbf0, 0x1fbf9}, 
};
static const uint32_t lust_uni_lowercase_ranges[][2] = {
    {0x61, 0x7a}, {0xaa, 0xaa}, {0xb5, 0xb5}, {0xba, 0xba}, {0xdf, 0xf6}, {0xf8, 0xff}, 
    {0x101, 0x101}, {0x103, 0x103}, {0x105, 0x105}, {0x107, 0x107}, {0x109, 0x109}, {0x10b, 0x10b}, 
    {0x10d, 0x10d}, {0x10f, 0x10f}, {0x111, 0x111}, {0x113, 0x113}, {0x115, 0x115}, {0x117, 0x117}, 
    {0x119, 0x119}, {0x11b, 0x11b}, {0x11d, 0x11d}, {0x11f, 0x11f}, {0x121, 0x121}, {0x123, 0x123}, 
    {0x125, 0x125}, {0x127, 0x127}, {0x129, 0x129}, {0x12b, 0x12b}, {0x12d, 0x12d}, {0x12f, 0x12f}, 
    {0x131, 0x131}, {0x133, 0x133}, {0x135, 0x135}, {0x137, 0x138}, {0x13a, 0x13a}, {0x13c, 0x13c}, 
    {0x13e, 0x13e}, {0x140, 0x140}, {0x142, 0x142}, {0x144, 0x144}, {0x146, 0x146}, {0x148, 0x149}, 
    {0x14b, 0x14b}, {0x14d, 0x14d}, {0x14f, 0x14f}, {0x151, 0x151}, {0x153, 0x153}, {0x155, 0x155}, 
    {0x157, 0x157}, {0x159, 0x159}, {0x15b, 0x15b}, {0x15d, 0x15d}, {0x15f, 0x15f}, {0x161, 0x161}, 
    {0x163, 0x163}, {0x165, 0x165}, {0x167, 0x167}, {0x169, 0x169}, {0x16b, 0x16b}, {0x16d, 0x16d}, 
    {0x16f, 0x16f}, {0x171, 0x171}, {0x173, 0x173}, {0x175, 0x175}, {0x177, 0x177}, {0x17a, 0x17a}, 
    {0x17c, 0x17c}, {0x17e, 0x180}, {0x183, 0x183}, {0x185, 0x185}, {0x188, 0x188}, {0x18c, 0x18d}, 
    {0x192, 0x192}, {0x195, 0x195}, {0x199, 0x19b}, {0x19e, 0x19e}, {0x1a1, 0x1a1}, {0x1a3, 0x1a3}, 
    {0x1a5, 0x1a5}, {0x1a8, 0x1a8}, {0x1aa, 0x1ab}, {0x1ad, 0x1ad}, {0x1b0, 0x1b0}, {0x1b4, 0x1b4}, 
    {0x1b6, 0x1b6}, {0x1b9, 0x1ba}, {0x1bd, 0x1bf}, {0x1c6, 0x1c6}, {0x1c9, 0x1c9}, {0x1cc, 0x1cc}, 
    {0x1ce, 0x1ce}, {0x1d0, 0x1d0}, {0x1d2, 0x1d2}, {0x1d4, 0x1d4}, {0x1d6, 0x1d6}, {0x1d8, 0x1d8}, 
    {0x1da, 0x1da}, {0x1dc, 0x1dd}, {0x1df, 0x1df}, {0x1e1, 0x1e1}, {0x1e3, 0x1e3}, {0x1e5, 0x1e5}, 
    {0x1e7, 0x1e7}, {0x1e9, 0x1e9}, {0x1eb, 0x1eb}, {0x1ed, 0x1ed}, {0x1ef, 0x1f0}, {0x1f3, 0x1f3}, 
    {0x1f5, 0x1f5}, {0x1f9, 0x1f9}, {0x1fb, 0x1fb}, {0x1fd, 0x1fd}, {0x1ff, 0x1ff}, {0x201, 0x201}, 
    {0x203, 0x203}, {0x205, 0x205}, {0x207, 0x207}, {0x209, 0x209}, {0x20b, 0x20b}, {0x20d, 0x20d}, 
    {0x20f, 0x20f}, {0x211, 0x211}, {0x213, 0x213}, {0x215, 0x215}, {0x217, 0x217}, {0x219, 0x219}, 
    {0x21b, 0x21b}, {0x21d, 0x21d}, {0x21f, 0x21f}, {0x221, 0x221}, {0x223, 0x223}, {0x225, 0x225}, 
    {0x227, 0x227}, {0x229, 0x229}, {0x22b, 0x22b}, {0x22d, 0x22d}, {0x22f, 0x22f}, {0x231, 0x231}, 
    {0x233, 0x239}, {0x23c, 0x23c}, {0x23f, 0x240}, {0x242, 0x242}, {0x247, 0x247}, {0x249, 0x249}, 
    {0x24b, 0x24b}, {0x24d, 0x24d}, {0x24f, 0x293}, {0x296, 0x2b8}, {0x2c0, 0x2c1}, {0x2e0, 0x2e4}, 
    {0x345, 0x345}, {0x371, 0x371}, {0x373, 0x373}, {0x377, 0x377}, {0x37a, 0x37d}, {0x390, 0x390}, 
    {0x3ac, 0x3ce}, {0x3d0, 0x3d1}, {0x3d5, 0x3d7}, {0x3d9, 0x3d9}, {0x3db, 0x3db}, {0x3dd, 0x3dd}, 
    {0x3df, 0x3df}, {0x3e1, 0x3e1}, {0x3e3, 0x3e3}, {0x3e5, 0x3e5}, {0x3e7, 0x3e7}, {0x3e9, 0x3e9}, 
    {0x3eb, 0x3eb}, {0x3ed, 0x3ed}, {0x3ef, 0x3f3}, {0x3f5, 0x3f5}, {0x3f8, 0x3f8}, {0x3fb, 0x3fc}, 
    {0x430, 0x45f}, {0x461, 0x461}, {0x463, 0x463}, {0x465, 0x465}, {0x467, 0x467}, {0x469, 0x469}, 
    {0x46b, 0x46b}, {0x46d, 0x46d}, {0x46f, 0x46f}, {0x471, 0x471}, {0x473, 0x473}, {0x475, 0x475}, 
    {0x477, 0x477}, {0x479, 0x479}, {0x47b, 0x47b}, {0x47d, 0x47d}, {0x47f, 0x47f}, {0x481, 0x481}, 
    {0x48b, 0x48b}, {0x48d, 0x48d}, {0x48f, 0x48f}, {0x491, 0x491}, {0x493, 0x493}, {0x495, 0x495}, 
    {0x497, 0x497}, {0x499, 0x499}, {0x49b, 0x49b}, {0x49d, 0x49d}, {0x49f, 0x49f}, {0x4a1, 0x4a1}, 
    {0x4a3, 0x4a3}, {0x4a5, 0x4a5}, {0x4a7, 0x4a7}, {0x4a9, 0x4a9}, {0x4ab, 0x4ab}, {0x4ad, 0x4ad}, 
    {0x4af, 0x4af}, {0x4b1, 0x4b1}, {0x4b3, 0x4b3}, {0x4b5, 0x4b5}, {0x4b7, 0x4b7}, {0x4b9, 0x4b9}, 
    {0x4bb, 0x4bb}, {0x4bd, 0x4bd}, {0x4bf, 0x4bf}, {0x4c2, 0x4c2}, {0x4c4, 0x4c4}, {0x4c6, 0x4c6}, 
    {0x4c8, 0x4c8}, {0x4ca, 0x4ca}, {0x4cc, 0x4cc}, {0x4ce, 0x4cf}, {0x4d1, 0x4d1}, {0x4d3, 0x4d3}, 
    {0x4d5, 0x4d5}, {0x4d7, 0x4d7}, {0x4d9, 0x4d9}, {0x4db, 0x4db}, {0x4dd, 0x4dd}, {0x4df, 0x4df}, 
    {0x4e1, 0x4e1}, {0x4e3, 0x4e3}, {0x4e5, 0x4e5}, {0x4e7, 0x4e7}, {0x4e9, 0x4e9}, {0x4eb, 0x4eb}, 
    {0x4ed, 0x4ed}, {0x4ef, 0x4ef}, {0x4f1, 0x4f1}, {0x4f3, 0x4f3}, {0x4f5, 0x4f5}, {0x4f7, 0x4f7}, 
    {0x4f9, 0x4f9}, {0x4fb, 0x4fb}, {0x4fd, 0x4fd}, {0x4ff, 0x4ff}, {0x501, 0x501}, {0x503, 0x503}, 
    {0x505, 0x505}, {0x507, 0x507}, {0x509, 0x509}, {0x50b, 0x50b}, {0x50d, 0x50d}, {0x50f, 0x50f}, 
    {0x511, 0x511}, {0x513, 0x513}, {0x515, 0x515}, {0x517, 0x517}, {0x519, 0x519}, {0x51b, 0x51b}, 
    {0x51d, 0x51d}, {0x51f, 0x51f}, {0x521, 0x521}, {0x523, 0x523}, {0x525, 0x525}, {0x527, 0x527}, 
    {0x529, 0x529}, {0x52b, 0x52b}, {0x52d, 0x52d}, {0x52f, 0x52f}, {0x560, 0x588}, {0x10d0, 0x10fa}, 
    {0x10fc, 0x10ff}, {0x13f8, 0x13fd}, {0x1c80, 0x1c88}, {0x1c8a, 0x1c8a}, {0x1d00, 0x1dbf}, {0x1e01, 0x1e01}, 
    {0x1e03, 0x1e03}, {0x1e05, 0x1e05}, {0x1e07, 0x1e07}, {0x1e09, 0x1e09}, {0x1e0b, 0x1e0b}, {0x1e0d, 0x1e0d}, 
    {0x1e0f, 0x1e0f}, {0x1e11, 0x1e11}, {0x1e13, 0x1e13}, {0x1e15, 0x1e15}, {0x1e17, 0x1e17}, {0x1e19, 0x1e19}, 
    {0x1e1b, 0x1e1b}, {0x1e1d, 0x1e1d}, {0x1e1f, 0x1e1f}, {0x1e21, 0x1e21}, {0x1e23, 0x1e23}, {0x1e25, 0x1e25}, 
    {0x1e27, 0x1e27}, {0x1e29, 0x1e29}, {0x1e2b, 0x1e2b}, {0x1e2d, 0x1e2d}, {0x1e2f, 0x1e2f}, {0x1e31, 0x1e31}, 
    {0x1e33, 0x1e33}, {0x1e35, 0x1e35}, {0x1e37, 0x1e37}, {0x1e39, 0x1e39}, {0x1e3b, 0x1e3b}, {0x1e3d, 0x1e3d}, 
    {0x1e3f, 0x1e3f}, {0x1e41, 0x1e41}, {0x1e43, 0x1e43}, {0x1e45, 0x1e45}, {0x1e47, 0x1e47}, {0x1e49, 0x1e49}, 
    {0x1e4b, 0x1e4b}, {0x1e4d, 0x1e4d}, {0x1e4f, 0x1e4f}, {0x1e51, 0x1e51}, {0x1e53, 0x1e53}, {0x1e55, 0x1e55}, 
    {0x1e57, 0x1e57}, {0x1e59, 0x1e59}, {0x1e5b, 0x1e5b}, {0x1e5d, 0x1e5d}, {0x1e5f, 0x1e5f}, {0x1e61, 0x1e61}, 
    {0x1e63, 0x1e63}, {0x1e65, 0x1e65}, {0x1e67, 0x1e67}, {0x1e69, 0x1e69}, {0x1e6b, 0x1e6b}, {0x1e6d, 0x1e6d}, 
    {0x1e6f, 0x1e6f}, {0x1e71, 0x1e71}, {0x1e73, 0x1e73}, {0x1e75, 0x1e75}, {0x1e77, 0x1e77}, {0x1e79, 0x1e79}, 
    {0x1e7b, 0x1e7b}, {0x1e7d, 0x1e7d}, {0x1e7f, 0x1e7f}, {0x1e81, 0x1e81}, {0x1e83, 0x1e83}, {0x1e85, 0x1e85}, 
    {0x1e87, 0x1e87}, {0x1e89, 0x1e89}, {0x1e8b, 0x1e8b}, {0x1e8d, 0x1e8d}, {0x1e8f, 0x1e8f}, {0x1e91, 0x1e91}, 
    {0x1e93, 0x1e93}, {0x1e95, 0x1e9d}, {0x1e9f, 0x1e9f}, {0x1ea1, 0x1ea1}, {0x1ea3, 0x1ea3}, {0x1ea5, 0x1ea5}, 
    {0x1ea7, 0x1ea7}, {0x1ea9, 0x1ea9}, {0x1eab, 0x1eab}, {0x1ead, 0x1ead}, {0x1eaf, 0x1eaf}, {0x1eb1, 0x1eb1}, 
    {0x1eb3, 0x1eb3}, {0x1eb5, 0x1eb5}, {0x1eb7, 0x1eb7}, {0x1eb9, 0x1eb9}, {0x1ebb, 0x1ebb}, {0x1ebd, 0x1ebd}, 
    {0x1ebf, 0x1ebf}, {0x1ec1, 0x1ec1}, {0x1ec3, 0x1ec3}, {0x1ec5, 0x1ec5}, {0x1ec7, 0x1ec7}, {0x1ec9, 0x1ec9}, 
    {0x1ecb, 0x1ecb}, {0x1ecd, 0x1ecd}, {0x1ecf, 0x1ecf}, {0x1ed1, 0x1ed1}, {0x1ed3, 0x1ed3}, {0x1ed5, 0x1ed5}, 
    {0x1ed7, 0x1ed7}, {0x1ed9, 0x1ed9}, {0x1edb, 0x1edb}, {0x1edd, 0x1edd}, {0x1edf, 0x1edf}, {0x1ee1, 0x1ee1}, 
    {0x1ee3, 0x1ee3}, {0x1ee5, 0x1ee5}, {0x1ee7, 0x1ee7}, {0x1ee9, 0x1ee9}, {0x1eeb, 0x1eeb}, {0x1eed, 0x1eed}, 
    {0x1eef, 0x1eef}, {0x1ef1, 0x1ef1}, {0x1ef3, 0x1ef3}, {0x1ef5, 0x1ef5}, {0x1ef7, 0x1ef7}, {0x1ef9, 0x1ef9}, 
    {0x1efb, 0x1efb}, {0x1efd, 0x1efd}, {0x1eff, 0x1f07}, {0x1f10, 0x1f15}, {0x1f20, 0x1f27}, {0x1f30, 0x1f37}, 
    {0x1f40, 0x1f45}, {0x1f50, 0x1f57}, {0x1f60, 0x1f67}, {0x1f70, 0x1f7d}, {0x1f80, 0x1f87}, {0x1f90, 0x1f97}, 
    {0x1fa0, 0x1fa7}, {0x1fb0, 0x1fb4}, {0x1fb6, 0x1fb7}, {0x1fbe, 0x1fbe}, {0x1fc2, 0x1fc4}, {0x1fc6, 0x1fc7}, 
    {0x1fd0, 0x1fd3}, {0x1fd6, 0x1fd7}, {0x1fe0, 0x1fe7}, {0x1ff2, 0x1ff4}, {0x1ff6, 0x1ff7}, {0x2071, 0x2071}, 
    {0x207f, 0x207f}, {0x2090, 0x209c}, {0x210a, 0x210a}, {0x210e, 0x210f}, {0x2113, 0x2113}, {0x212f, 0x212f}, 
    {0x2134, 0x2134}, {0x2139, 0x2139}, {0x213c, 0x213d}, {0x2146, 0x2149}, {0x214e, 0x214e}, {0x2170, 0x217f}, 
    {0x2184, 0x2184}, {0x24d0, 0x24e9}, {0x2c30, 0x2c5f}, {0x2c61, 0x2c61}, {0x2c65, 0x2c66}, {0x2c68, 0x2c68}, 
    {0x2c6a, 0x2c6a}, {0x2c6c, 0x2c6c}, {0x2c71, 0x2c71}, {0x2c73, 0x2c74}, {0x2c76, 0x2c7d}, {0x2c81, 0x2c81}, 
    {0x2c83, 0x2c83}, {0x2c85, 0x2c85}, {0x2c87, 0x2c87}, {0x2c89, 0x2c89}, {0x2c8b, 0x2c8b}, {0x2c8d, 0x2c8d}, 
    {0x2c8f, 0x2c8f}, {0x2c91, 0x2c91}, {0x2c93, 0x2c93}, {0x2c95, 0x2c95}, {0x2c97, 0x2c97}, {0x2c99, 0x2c99}, 
    {0x2c9b, 0x2c9b}, {0x2c9d, 0x2c9d}, {0x2c9f, 0x2c9f}, {0x2ca1, 0x2ca1}, {0x2ca3, 0x2ca3}, {0x2ca5, 0x2ca5}, 
    {0x2ca7, 0x2ca7}, {0x2ca9, 0x2ca9}, {0x2cab, 0x2cab}, {0x2cad, 0x2cad}, {0x2caf, 0x2caf}, {0x2cb1, 0x2cb1}, 
    {0x2cb3, 0x2cb3}, {0x2cb5, 0x2cb5}, {0x2cb7, 0x2cb7}, {0x2cb9, 0x2cb9}, {0x2cbb, 0x2cbb}, {0x2cbd, 0x2cbd}, 
    {0x2cbf, 0x2cbf}, {0x2cc1, 0x2cc1}, {0x2cc3, 0x2cc3}, {0x2cc5, 0x2cc5}, {0x2cc7, 0x2cc7}, {0x2cc9, 0x2cc9}, 
    {0x2ccb, 0x2ccb}, {0x2ccd, 0x2ccd}, {0x2ccf, 0x2ccf}, {0x2cd1, 0x2cd1}, {0x2cd3, 0x2cd3}, {0x2cd5, 0x2cd5}, 
    {0x2cd7, 0x2cd7}, {0x2cd9, 0x2cd9}, {0x2cdb, 0x2cdb}, {0x2cdd, 0x2cdd}, {0x2cdf, 0x2cdf}, {0x2ce1, 0x2ce1}, 
    {0x2ce3, 0x2ce4}, {0x2cec, 0x2cec}, {0x2cee, 0x2cee}, {0x2cf3, 0x2cf3}, {0x2d00, 0x2d25}, {0x2d27, 0x2d27}, 
    {0x2d2d, 0x2d2d}, {0xa641, 0xa641}, {0xa643, 0xa643}, {0xa645, 0xa645}, {0xa647, 0xa647}, {0xa649, 0xa649}, 
    {0xa64b, 0xa64b}, {0xa64d, 0xa64d}, {0xa64f, 0xa64f}, {0xa651, 0xa651}, {0xa653, 0xa653}, {0xa655, 0xa655}, 
    {0xa657, 0xa657}, {0xa659, 0xa659}, {0xa65b, 0xa65b}, {0xa65d, 0xa65d}, {0xa65f, 0xa65f}, {0xa661, 0xa661}, 
    {0xa663, 0xa663}, {0xa665, 0xa665}, {0xa667, 0xa667}, {0xa669, 0xa669}, {0xa66b, 0xa66b}, {0xa66d, 0xa66d}, 
    {0xa681, 0xa681}, {0xa683, 0xa683}, {0xa685, 0xa685}, {0xa687, 0xa687}, {0xa689, 0xa689}, {0xa68b, 0xa68b}, 
    {0xa68d, 0xa68d}, {0xa68f, 0xa68f}, {0xa691, 0xa691}, {0xa693, 0xa693}, {0xa695, 0xa695}, {0xa697, 0xa697}, 
    {0xa699, 0xa699}, {0xa69b, 0xa69d}, {0xa723, 0xa723}, {0xa725, 0xa725}, {0xa727, 0xa727}, {0xa729, 0xa729}, 
    {0xa72b, 0xa72b}, {0xa72d, 0xa72d}, {0xa72f, 0xa731}, {0xa733, 0xa733}, {0xa735, 0xa735}, {0xa737, 0xa737}, 
    {0xa739, 0xa739}, {0xa73b, 0xa73b}, {0xa73d, 0xa73d}, {0xa73f, 0xa73f}, {0xa741, 0xa741}, {0xa743, 0xa743}, 
    {0xa745, 0xa745}, {0xa747, 0xa747}, {0xa749, 0xa749}, {0xa74b, 0xa74b}, {0xa74d, 0xa74d}, {0xa74f, 0xa74f}, 
    {0xa751, 0xa751}, {0xa753, 0xa753}, {0xa755, 0xa755}, {0xa757, 0xa757}, {0xa759, 0xa759}, {0xa75b, 0xa75b}, 
    {0xa75d, 0xa75d}, {0xa75f, 0xa75f}, {0xa761, 0xa761}, {0xa763, 0xa763}, {0xa765, 0xa765}, {0xa767, 0xa767}, 
    {0xa769, 0xa769}, {0xa76b, 0xa76b}, {0xa76d, 0xa76d}, {0xa76f, 0xa778}, {0xa77a, 0xa77a}, {0xa77c, 0xa77c}, 
    {0xa77f, 0xa77f}, {0xa781, 0xa781}, {0xa783, 0xa783}, {0xa785, 0xa785}, {0xa787, 0xa787}, {0xa78c, 0xa78c}, 
    {0xa78e, 0xa78e}, {0xa791, 0xa791}, {0xa793, 0xa795}, {0xa797, 0xa797}, {0xa799, 0xa799}, {0xa79b, 0xa79b}, 
    {0xa79d, 0xa79d}, {0xa79f, 0xa79f}, {0xa7a1, 0xa7a1}, {0xa7a3, 0xa7a3}, {0xa7a5, 0xa7a5}, {0xa7a7, 0xa7a7}, 
    {0xa7a9, 0xa7a9}, {0xa7af, 0xa7af}, {0xa7b5, 0xa7b5}, {0xa7b7, 0xa7b7}, {0xa7b9, 0xa7b9}, {0xa7bb, 0xa7bb}, 
    {0xa7bd, 0xa7bd}, {0xa7bf, 0xa7bf}, {0xa7c1, 0xa7c1}, {0xa7c3, 0xa7c3}, {0xa7c8, 0xa7c8}, {0xa7ca, 0xa7ca}, 
    {0xa7cd, 0xa7cd}, {0xa7cf, 0xa7cf}, {0xa7d1, 0xa7d1}, {0xa7d3, 0xa7d3}, {0xa7d5, 0xa7d5}, {0xa7d7, 0xa7d7}, 
    {0xa7d9, 0xa7d9}, {0xa7db, 0xa7db}, {0xa7f1, 0xa7f4}, {0xa7f6, 0xa7f6}, {0xa7f8, 0xa7fa}, {0xab30, 0xab5a}, 
    {0xab5c, 0xab69}, {0xab70, 0xabbf}, {0xfb00, 0xfb06}, {0xfb13, 0xfb17}, {0xff41, 0xff5a}, {0x10428, 0x1044f}, 
    {0x104d8, 0x104fb}, {0x10597, 0x105a1}, {0x105a3, 0x105b1}, {0x105b3, 0x105b9}, {0x105bb, 0x105bc}, {0x10780, 0x10780}, 
    {0x10783, 0x10785}, {0x10787, 0x107b0}, {0x107b2, 0x107ba}, {0x10cc0, 0x10cf2}, {0x10d70, 0x10d85}, {0x118c0, 0x118df}, 
    {0x16e60, 0x16e7f}, {0x16ebb, 0x16ed3}, {0x1d41a, 0x1d433}, {0x1d44e, 0x1d454}, {0x1d456, 0x1d467}, {0x1d482, 0x1d49b}, 
    {0x1d4b6, 0x1d4b9}, {0x1d4bb, 0x1d4bb}, {0x1d4bd, 0x1d4c3}, {0x1d4c5, 0x1d4cf}, {0x1d4ea, 0x1d503}, {0x1d51e, 0x1d537}, 
    {0x1d552, 0x1d56b}, {0x1d586, 0x1d59f}, {0x1d5ba, 0x1d5d3}, {0x1d5ee, 0x1d607}, {0x1d622, 0x1d63b}, {0x1d656, 0x1d66f}, 
    {0x1d68a, 0x1d6a5}, {0x1d6c2, 0x1d6da}, {0x1d6dc, 0x1d6e1}, {0x1d6fc, 0x1d714}, {0x1d716, 0x1d71b}, {0x1d736, 0x1d74e}, 
    {0x1d750, 0x1d755}, {0x1d770, 0x1d788}, {0x1d78a, 0x1d78f}, {0x1d7aa, 0x1d7c2}, {0x1d7c4, 0x1d7c9}, {0x1d7cb, 0x1d7cb}, 
    {0x1df00, 0x1df09}, {0x1df0b, 0x1df1e}, {0x1df25, 0x1df2a}, {0x1e030, 0x1e06d}, {0x1e922, 0x1e943}, 
};
static const uint32_t lust_uni_uppercase_ranges[][2] = {
    {0x41, 0x5a}, {0xc0, 0xd6}, {0xd8, 0xde}, {0x100, 0x100}, {0x102, 0x102}, {0x104, 0x104}, 
    {0x106, 0x106}, {0x108, 0x108}, {0x10a, 0x10a}, {0x10c, 0x10c}, {0x10e, 0x10e}, {0x110, 0x110}, 
    {0x112, 0x112}, {0x114, 0x114}, {0x116, 0x116}, {0x118, 0x118}, {0x11a, 0x11a}, {0x11c, 0x11c}, 
    {0x11e, 0x11e}, {0x120, 0x120}, {0x122, 0x122}, {0x124, 0x124}, {0x126, 0x126}, {0x128, 0x128}, 
    {0x12a, 0x12a}, {0x12c, 0x12c}, {0x12e, 0x12e}, {0x130, 0x130}, {0x132, 0x132}, {0x134, 0x134}, 
    {0x136, 0x136}, {0x139, 0x139}, {0x13b, 0x13b}, {0x13d, 0x13d}, {0x13f, 0x13f}, {0x141, 0x141}, 
    {0x143, 0x143}, {0x145, 0x145}, {0x147, 0x147}, {0x14a, 0x14a}, {0x14c, 0x14c}, {0x14e, 0x14e}, 
    {0x150, 0x150}, {0x152, 0x152}, {0x154, 0x154}, {0x156, 0x156}, {0x158, 0x158}, {0x15a, 0x15a}, 
    {0x15c, 0x15c}, {0x15e, 0x15e}, {0x160, 0x160}, {0x162, 0x162}, {0x164, 0x164}, {0x166, 0x166}, 
    {0x168, 0x168}, {0x16a, 0x16a}, {0x16c, 0x16c}, {0x16e, 0x16e}, {0x170, 0x170}, {0x172, 0x172}, 
    {0x174, 0x174}, {0x176, 0x176}, {0x178, 0x179}, {0x17b, 0x17b}, {0x17d, 0x17d}, {0x181, 0x182}, 
    {0x184, 0x184}, {0x186, 0x187}, {0x189, 0x18b}, {0x18e, 0x191}, {0x193, 0x194}, {0x196, 0x198}, 
    {0x19c, 0x19d}, {0x19f, 0x1a0}, {0x1a2, 0x1a2}, {0x1a4, 0x1a4}, {0x1a6, 0x1a7}, {0x1a9, 0x1a9}, 
    {0x1ac, 0x1ac}, {0x1ae, 0x1af}, {0x1b1, 0x1b3}, {0x1b5, 0x1b5}, {0x1b7, 0x1b8}, {0x1bc, 0x1bc}, 
    {0x1c4, 0x1c4}, {0x1c7, 0x1c7}, {0x1ca, 0x1ca}, {0x1cd, 0x1cd}, {0x1cf, 0x1cf}, {0x1d1, 0x1d1}, 
    {0x1d3, 0x1d3}, {0x1d5, 0x1d5}, {0x1d7, 0x1d7}, {0x1d9, 0x1d9}, {0x1db, 0x1db}, {0x1de, 0x1de}, 
    {0x1e0, 0x1e0}, {0x1e2, 0x1e2}, {0x1e4, 0x1e4}, {0x1e6, 0x1e6}, {0x1e8, 0x1e8}, {0x1ea, 0x1ea}, 
    {0x1ec, 0x1ec}, {0x1ee, 0x1ee}, {0x1f1, 0x1f1}, {0x1f4, 0x1f4}, {0x1f6, 0x1f8}, {0x1fa, 0x1fa}, 
    {0x1fc, 0x1fc}, {0x1fe, 0x1fe}, {0x200, 0x200}, {0x202, 0x202}, {0x204, 0x204}, {0x206, 0x206}, 
    {0x208, 0x208}, {0x20a, 0x20a}, {0x20c, 0x20c}, {0x20e, 0x20e}, {0x210, 0x210}, {0x212, 0x212}, 
    {0x214, 0x214}, {0x216, 0x216}, {0x218, 0x218}, {0x21a, 0x21a}, {0x21c, 0x21c}, {0x21e, 0x21e}, 
    {0x220, 0x220}, {0x222, 0x222}, {0x224, 0x224}, {0x226, 0x226}, {0x228, 0x228}, {0x22a, 0x22a}, 
    {0x22c, 0x22c}, {0x22e, 0x22e}, {0x230, 0x230}, {0x232, 0x232}, {0x23a, 0x23b}, {0x23d, 0x23e}, 
    {0x241, 0x241}, {0x243, 0x246}, {0x248, 0x248}, {0x24a, 0x24a}, {0x24c, 0x24c}, {0x24e, 0x24e}, 
    {0x370, 0x370}, {0x372, 0x372}, {0x376, 0x376}, {0x37f, 0x37f}, {0x386, 0x386}, {0x388, 0x38a}, 
    {0x38c, 0x38c}, {0x38e, 0x38f}, {0x391, 0x3a1}, {0x3a3, 0x3ab}, {0x3cf, 0x3cf}, {0x3d2, 0x3d4}, 
    {0x3d8, 0x3d8}, {0x3da, 0x3da}, {0x3dc, 0x3dc}, {0x3de, 0x3de}, {0x3e0, 0x3e0}, {0x3e2, 0x3e2}, 
    {0x3e4, 0x3e4}, {0x3e6, 0x3e6}, {0x3e8, 0x3e8}, {0x3ea, 0x3ea}, {0x3ec, 0x3ec}, {0x3ee, 0x3ee}, 
    {0x3f4, 0x3f4}, {0x3f7, 0x3f7}, {0x3f9, 0x3fa}, {0x3fd, 0x42f}, {0x460, 0x460}, {0x462, 0x462}, 
    {0x464, 0x464}, {0x466, 0x466}, {0x468, 0x468}, {0x46a, 0x46a}, {0x46c, 0x46c}, {0x46e, 0x46e}, 
    {0x470, 0x470}, {0x472, 0x472}, {0x474, 0x474}, {0x476, 0x476}, {0x478, 0x478}, {0x47a, 0x47a}, 
    {0x47c, 0x47c}, {0x47e, 0x47e}, {0x480, 0x480}, {0x48a, 0x48a}, {0x48c, 0x48c}, {0x48e, 0x48e}, 
    {0x490, 0x490}, {0x492, 0x492}, {0x494, 0x494}, {0x496, 0x496}, {0x498, 0x498}, {0x49a, 0x49a}, 
    {0x49c, 0x49c}, {0x49e, 0x49e}, {0x4a0, 0x4a0}, {0x4a2, 0x4a2}, {0x4a4, 0x4a4}, {0x4a6, 0x4a6}, 
    {0x4a8, 0x4a8}, {0x4aa, 0x4aa}, {0x4ac, 0x4ac}, {0x4ae, 0x4ae}, {0x4b0, 0x4b0}, {0x4b2, 0x4b2}, 
    {0x4b4, 0x4b4}, {0x4b6, 0x4b6}, {0x4b8, 0x4b8}, {0x4ba, 0x4ba}, {0x4bc, 0x4bc}, {0x4be, 0x4be}, 
    {0x4c0, 0x4c1}, {0x4c3, 0x4c3}, {0x4c5, 0x4c5}, {0x4c7, 0x4c7}, {0x4c9, 0x4c9}, {0x4cb, 0x4cb}, 
    {0x4cd, 0x4cd}, {0x4d0, 0x4d0}, {0x4d2, 0x4d2}, {0x4d4, 0x4d4}, {0x4d6, 0x4d6}, {0x4d8, 0x4d8}, 
    {0x4da, 0x4da}, {0x4dc, 0x4dc}, {0x4de, 0x4de}, {0x4e0, 0x4e0}, {0x4e2, 0x4e2}, {0x4e4, 0x4e4}, 
    {0x4e6, 0x4e6}, {0x4e8, 0x4e8}, {0x4ea, 0x4ea}, {0x4ec, 0x4ec}, {0x4ee, 0x4ee}, {0x4f0, 0x4f0}, 
    {0x4f2, 0x4f2}, {0x4f4, 0x4f4}, {0x4f6, 0x4f6}, {0x4f8, 0x4f8}, {0x4fa, 0x4fa}, {0x4fc, 0x4fc}, 
    {0x4fe, 0x4fe}, {0x500, 0x500}, {0x502, 0x502}, {0x504, 0x504}, {0x506, 0x506}, {0x508, 0x508}, 
    {0x50a, 0x50a}, {0x50c, 0x50c}, {0x50e, 0x50e}, {0x510, 0x510}, {0x512, 0x512}, {0x514, 0x514}, 
    {0x516, 0x516}, {0x518, 0x518}, {0x51a, 0x51a}, {0x51c, 0x51c}, {0x51e, 0x51e}, {0x520, 0x520}, 
    {0x522, 0x522}, {0x524, 0x524}, {0x526, 0x526}, {0x528, 0x528}, {0x52a, 0x52a}, {0x52c, 0x52c}, 
    {0x52e, 0x52e}, {0x531, 0x556}, {0x10a0, 0x10c5}, {0x10c7, 0x10c7}, {0x10cd, 0x10cd}, {0x13a0, 0x13f5}, 
    {0x1c89, 0x1c89}, {0x1c90, 0x1cba}, {0x1cbd, 0x1cbf}, {0x1e00, 0x1e00}, {0x1e02, 0x1e02}, {0x1e04, 0x1e04}, 
    {0x1e06, 0x1e06}, {0x1e08, 0x1e08}, {0x1e0a, 0x1e0a}, {0x1e0c, 0x1e0c}, {0x1e0e, 0x1e0e}, {0x1e10, 0x1e10}, 
    {0x1e12, 0x1e12}, {0x1e14, 0x1e14}, {0x1e16, 0x1e16}, {0x1e18, 0x1e18}, {0x1e1a, 0x1e1a}, {0x1e1c, 0x1e1c}, 
    {0x1e1e, 0x1e1e}, {0x1e20, 0x1e20}, {0x1e22, 0x1e22}, {0x1e24, 0x1e24}, {0x1e26, 0x1e26}, {0x1e28, 0x1e28}, 
    {0x1e2a, 0x1e2a}, {0x1e2c, 0x1e2c}, {0x1e2e, 0x1e2e}, {0x1e30, 0x1e30}, {0x1e32, 0x1e32}, {0x1e34, 0x1e34}, 
    {0x1e36, 0x1e36}, {0x1e38, 0x1e38}, {0x1e3a, 0x1e3a}, {0x1e3c, 0x1e3c}, {0x1e3e, 0x1e3e}, {0x1e40, 0x1e40}, 
    {0x1e42, 0x1e42}, {0x1e44, 0x1e44}, {0x1e46, 0x1e46}, {0x1e48, 0x1e48}, {0x1e4a, 0x1e4a}, {0x1e4c, 0x1e4c}, 
    {0x1e4e, 0x1e4e}, {0x1e50, 0x1e50}, {0x1e52, 0x1e52}, {0x1e54, 0x1e54}, {0x1e56, 0x1e56}, {0x1e58, 0x1e58}, 
    {0x1e5a, 0x1e5a}, {0x1e5c, 0x1e5c}, {0x1e5e, 0x1e5e}, {0x1e60, 0x1e60}, {0x1e62, 0x1e62}, {0x1e64, 0x1e64}, 
    {0x1e66, 0x1e66}, {0x1e68, 0x1e68}, {0x1e6a, 0x1e6a}, {0x1e6c, 0x1e6c}, {0x1e6e, 0x1e6e}, {0x1e70, 0x1e70}, 
    {0x1e72, 0x1e72}, {0x1e74, 0x1e74}, {0x1e76, 0x1e76}, {0x1e78, 0x1e78}, {0x1e7a, 0x1e7a}, {0x1e7c, 0x1e7c}, 
    {0x1e7e, 0x1e7e}, {0x1e80, 0x1e80}, {0x1e82, 0x1e82}, {0x1e84, 0x1e84}, {0x1e86, 0x1e86}, {0x1e88, 0x1e88}, 
    {0x1e8a, 0x1e8a}, {0x1e8c, 0x1e8c}, {0x1e8e, 0x1e8e}, {0x1e90, 0x1e90}, {0x1e92, 0x1e92}, {0x1e94, 0x1e94}, 
    {0x1e9e, 0x1e9e}, {0x1ea0, 0x1ea0}, {0x1ea2, 0x1ea2}, {0x1ea4, 0x1ea4}, {0x1ea6, 0x1ea6}, {0x1ea8, 0x1ea8}, 
    {0x1eaa, 0x1eaa}, {0x1eac, 0x1eac}, {0x1eae, 0x1eae}, {0x1eb0, 0x1eb0}, {0x1eb2, 0x1eb2}, {0x1eb4, 0x1eb4}, 
    {0x1eb6, 0x1eb6}, {0x1eb8, 0x1eb8}, {0x1eba, 0x1eba}, {0x1ebc, 0x1ebc}, {0x1ebe, 0x1ebe}, {0x1ec0, 0x1ec0}, 
    {0x1ec2, 0x1ec2}, {0x1ec4, 0x1ec4}, {0x1ec6, 0x1ec6}, {0x1ec8, 0x1ec8}, {0x1eca, 0x1eca}, {0x1ecc, 0x1ecc}, 
    {0x1ece, 0x1ece}, {0x1ed0, 0x1ed0}, {0x1ed2, 0x1ed2}, {0x1ed4, 0x1ed4}, {0x1ed6, 0x1ed6}, {0x1ed8, 0x1ed8}, 
    {0x1eda, 0x1eda}, {0x1edc, 0x1edc}, {0x1ede, 0x1ede}, {0x1ee0, 0x1ee0}, {0x1ee2, 0x1ee2}, {0x1ee4, 0x1ee4}, 
    {0x1ee6, 0x1ee6}, {0x1ee8, 0x1ee8}, {0x1eea, 0x1eea}, {0x1eec, 0x1eec}, {0x1eee, 0x1eee}, {0x1ef0, 0x1ef0}, 
    {0x1ef2, 0x1ef2}, {0x1ef4, 0x1ef4}, {0x1ef6, 0x1ef6}, {0x1ef8, 0x1ef8}, {0x1efa, 0x1efa}, {0x1efc, 0x1efc}, 
    {0x1efe, 0x1efe}, {0x1f08, 0x1f0f}, {0x1f18, 0x1f1d}, {0x1f28, 0x1f2f}, {0x1f38, 0x1f3f}, {0x1f48, 0x1f4d}, 
    {0x1f59, 0x1f59}, {0x1f5b, 0x1f5b}, {0x1f5d, 0x1f5d}, {0x1f5f, 0x1f5f}, {0x1f68, 0x1f6f}, {0x1fb8, 0x1fbb}, 
    {0x1fc8, 0x1fcb}, {0x1fd8, 0x1fdb}, {0x1fe8, 0x1fec}, {0x1ff8, 0x1ffb}, {0x2102, 0x2102}, {0x2107, 0x2107}, 
    {0x210b, 0x210d}, {0x2110, 0x2112}, {0x2115, 0x2115}, {0x2119, 0x211d}, {0x2124, 0x2124}, {0x2126, 0x2126}, 
    {0x2128, 0x2128}, {0x212a, 0x212d}, {0x2130, 0x2133}, {0x213e, 0x213f}, {0x2145, 0x2145}, {0x2160, 0x216f}, 
    {0x2183, 0x2183}, {0x24b6, 0x24cf}, {0x2c00, 0x2c2f}, {0x2c60, 0x2c60}, {0x2c62, 0x2c64}, {0x2c67, 0x2c67}, 
    {0x2c69, 0x2c69}, {0x2c6b, 0x2c6b}, {0x2c6d, 0x2c70}, {0x2c72, 0x2c72}, {0x2c75, 0x2c75}, {0x2c7e, 0x2c80}, 
    {0x2c82, 0x2c82}, {0x2c84, 0x2c84}, {0x2c86, 0x2c86}, {0x2c88, 0x2c88}, {0x2c8a, 0x2c8a}, {0x2c8c, 0x2c8c}, 
    {0x2c8e, 0x2c8e}, {0x2c90, 0x2c90}, {0x2c92, 0x2c92}, {0x2c94, 0x2c94}, {0x2c96, 0x2c96}, {0x2c98, 0x2c98}, 
    {0x2c9a, 0x2c9a}, {0x2c9c, 0x2c9c}, {0x2c9e, 0x2c9e}, {0x2ca0, 0x2ca0}, {0x2ca2, 0x2ca2}, {0x2ca4, 0x2ca4}, 
    {0x2ca6, 0x2ca6}, {0x2ca8, 0x2ca8}, {0x2caa, 0x2caa}, {0x2cac, 0x2cac}, {0x2cae, 0x2cae}, {0x2cb0, 0x2cb0}, 
    {0x2cb2, 0x2cb2}, {0x2cb4, 0x2cb4}, {0x2cb6, 0x2cb6}, {0x2cb8, 0x2cb8}, {0x2cba, 0x2cba}, {0x2cbc, 0x2cbc}, 
    {0x2cbe, 0x2cbe}, {0x2cc0, 0x2cc0}, {0x2cc2, 0x2cc2}, {0x2cc4, 0x2cc4}, {0x2cc6, 0x2cc6}, {0x2cc8, 0x2cc8}, 
    {0x2cca, 0x2cca}, {0x2ccc, 0x2ccc}, {0x2cce, 0x2cce}, {0x2cd0, 0x2cd0}, {0x2cd2, 0x2cd2}, {0x2cd4, 0x2cd4}, 
    {0x2cd6, 0x2cd6}, {0x2cd8, 0x2cd8}, {0x2cda, 0x2cda}, {0x2cdc, 0x2cdc}, {0x2cde, 0x2cde}, {0x2ce0, 0x2ce0}, 
    {0x2ce2, 0x2ce2}, {0x2ceb, 0x2ceb}, {0x2ced, 0x2ced}, {0x2cf2, 0x2cf2}, {0xa640, 0xa640}, {0xa642, 0xa642}, 
    {0xa644, 0xa644}, {0xa646, 0xa646}, {0xa648, 0xa648}, {0xa64a, 0xa64a}, {0xa64c, 0xa64c}, {0xa64e, 0xa64e}, 
    {0xa650, 0xa650}, {0xa652, 0xa652}, {0xa654, 0xa654}, {0xa656, 0xa656}, {0xa658, 0xa658}, {0xa65a, 0xa65a}, 
    {0xa65c, 0xa65c}, {0xa65e, 0xa65e}, {0xa660, 0xa660}, {0xa662, 0xa662}, {0xa664, 0xa664}, {0xa666, 0xa666}, 
    {0xa668, 0xa668}, {0xa66a, 0xa66a}, {0xa66c, 0xa66c}, {0xa680, 0xa680}, {0xa682, 0xa682}, {0xa684, 0xa684}, 
    {0xa686, 0xa686}, {0xa688, 0xa688}, {0xa68a, 0xa68a}, {0xa68c, 0xa68c}, {0xa68e, 0xa68e}, {0xa690, 0xa690}, 
    {0xa692, 0xa692}, {0xa694, 0xa694}, {0xa696, 0xa696}, {0xa698, 0xa698}, {0xa69a, 0xa69a}, {0xa722, 0xa722}, 
    {0xa724, 0xa724}, {0xa726, 0xa726}, {0xa728, 0xa728}, {0xa72a, 0xa72a}, {0xa72c, 0xa72c}, {0xa72e, 0xa72e}, 
    {0xa732, 0xa732}, {0xa734, 0xa734}, {0xa736, 0xa736}, {0xa738, 0xa738}, {0xa73a, 0xa73a}, {0xa73c, 0xa73c}, 
    {0xa73e, 0xa73e}, {0xa740, 0xa740}, {0xa742, 0xa742}, {0xa744, 0xa744}, {0xa746, 0xa746}, {0xa748, 0xa748}, 
    {0xa74a, 0xa74a}, {0xa74c, 0xa74c}, {0xa74e, 0xa74e}, {0xa750, 0xa750}, {0xa752, 0xa752}, {0xa754, 0xa754}, 
    {0xa756, 0xa756}, {0xa758, 0xa758}, {0xa75a, 0xa75a}, {0xa75c, 0xa75c}, {0xa75e, 0xa75e}, {0xa760, 0xa760}, 
    {0xa762, 0xa762}, {0xa764, 0xa764}, {0xa766, 0xa766}, {0xa768, 0xa768}, {0xa76a, 0xa76a}, {0xa76c, 0xa76c}, 
    {0xa76e, 0xa76e}, {0xa779, 0xa779}, {0xa77b, 0xa77b}, {0xa77d, 0xa77e}, {0xa780, 0xa780}, {0xa782, 0xa782}, 
    {0xa784, 0xa784}, {0xa786, 0xa786}, {0xa78b, 0xa78b}, {0xa78d, 0xa78d}, {0xa790, 0xa790}, {0xa792, 0xa792}, 
    {0xa796, 0xa796}, {0xa798, 0xa798}, {0xa79a, 0xa79a}, {0xa79c, 0xa79c}, {0xa79e, 0xa79e}, {0xa7a0, 0xa7a0}, 
    {0xa7a2, 0xa7a2}, {0xa7a4, 0xa7a4}, {0xa7a6, 0xa7a6}, {0xa7a8, 0xa7a8}, {0xa7aa, 0xa7ae}, {0xa7b0, 0xa7b4}, 
    {0xa7b6, 0xa7b6}, {0xa7b8, 0xa7b8}, {0xa7ba, 0xa7ba}, {0xa7bc, 0xa7bc}, {0xa7be, 0xa7be}, {0xa7c0, 0xa7c0}, 
    {0xa7c2, 0xa7c2}, {0xa7c4, 0xa7c7}, {0xa7c9, 0xa7c9}, {0xa7cb, 0xa7cc}, {0xa7ce, 0xa7ce}, {0xa7d0, 0xa7d0}, 
    {0xa7d2, 0xa7d2}, {0xa7d4, 0xa7d4}, {0xa7d6, 0xa7d6}, {0xa7d8, 0xa7d8}, {0xa7da, 0xa7da}, {0xa7dc, 0xa7dc}, 
    {0xa7f5, 0xa7f5}, {0xff21, 0xff3a}, {0x10400, 0x10427}, {0x104b0, 0x104d3}, {0x10570, 0x1057a}, {0x1057c, 0x1058a}, 
    {0x1058c, 0x10592}, {0x10594, 0x10595}, {0x10c80, 0x10cb2}, {0x10d50, 0x10d65}, {0x118a0, 0x118bf}, {0x16e40, 0x16e5f}, 
    {0x16ea0, 0x16eb8}, {0x1d400, 0x1d419}, {0x1d434, 0x1d44d}, {0x1d468, 0x1d481}, {0x1d49c, 0x1d49c}, {0x1d49e, 0x1d49f}, 
    {0x1d4a2, 0x1d4a2}, {0x1d4a5, 0x1d4a6}, {0x1d4a9, 0x1d4ac}, {0x1d4ae, 0x1d4b5}, {0x1d4d0, 0x1d4e9}, {0x1d504, 0x1d505}, 
    {0x1d507, 0x1d50a}, {0x1d50d, 0x1d514}, {0x1d516, 0x1d51c}, {0x1d538, 0x1d539}, {0x1d53b, 0x1d53e}, {0x1d540, 0x1d544}, 
    {0x1d546, 0x1d546}, {0x1d54a, 0x1d550}, {0x1d56c, 0x1d585}, {0x1d5a0, 0x1d5b9}, {0x1d5d4, 0x1d5ed}, {0x1d608, 0x1d621}, 
    {0x1d63c, 0x1d655}, {0x1d670, 0x1d689}, {0x1d6a8, 0x1d6c0}, {0x1d6e2, 0x1d6fa}, {0x1d71c, 0x1d734}, {0x1d756, 0x1d76e}, 
    {0x1d790, 0x1d7a8}, {0x1d7ca, 0x1d7ca}, {0x1e900, 0x1e921}, {0x1f130, 0x1f149}, {0x1f150, 0x1f169}, {0x1f170, 0x1f189}, 
};
static const uint32_t lust_uni_whitespace_ranges[][2] = {
    {0x9, 0xd}, {0x20, 0x20}, {0x85, 0x85}, {0xa0, 0xa0}, {0x1680, 0x1680}, {0x2000, 0x200a}, 
    {0x2028, 0x2029}, {0x202f, 0x202f}, {0x205f, 0x205f}, {0x3000, 0x3000}, 
};
static const uint32_t lust_uni_control_ranges[][2] = {
    {0x0, 0x1f}, {0x7f, 0x9f}, 
};


/* Binary search over one generated Unicode range table. */
static int lust_uni_in(const uint32_t ranges[][2], uint32_t n, uint32_t c) {
    uint32_t lo = 0, hi = n;
    while (lo < hi) {
        uint32_t mid = (lo + hi) / 2;
        if (c < ranges[mid][0]) hi = mid;
        else if (c > ranges[mid][1]) lo = mid + 1;
        else return 1;
    }
    return 0;
}
#define LUST_UNI_IN(table, c) lust_uni_in(table, (uint32_t)(sizeof table / sizeof table[0]), c)

/* True when Rust's escape_debug writes this scalar as \u{...}:
   binary search over the generated range table. */
static int lust_escape_unicode(uint32_t c) {
    return LUST_UNI_IN(lust_escape_ranges, c);
}
#endif

/* Debug text of a function pointer: `0x` and the address in lowercase
   hex with no leading zeroes, as Rust prints it. */
void lust_fmt_fnptr_debug(lust_String *out, const void *p) LUST_BODY({
    uint64_t v = (uint64_t)(uintptr_t)p;
    char buf[16];
    int n = 0;
    lust_string_push_cstr(out, "0x");
    if (!v) {
        lust_string_push_cstr(out, "0");
        return;
    }
    while (v) {
        buf[n++] = "0123456789abcdef"[v & 15];
        v >>= 4;
    }
    while (n) lust_string_push_char(out, (uint32_t)buf[--n]);
})

void lust_fmt_escape(lust_String *out, uint32_t c, uint32_t quote) LUST_BODY({
    switch (c) {
    case '\t': lust_string_push_cstr(out, "\\t"); return;
    case '\r': lust_string_push_cstr(out, "\\r"); return;
    case '\n': lust_string_push_cstr(out, "\\n"); return;
    case '\\': lust_string_push_cstr(out, "\\\\"); return;
    case 0: lust_string_push_cstr(out, "\\0"); return;
    }
    if (c == quote) { lust_string_push_bytes(out, "\\", 1); lust_string_push_char(out, c); return; }
    if (lust_escape_unicode(c)) {
        char b[16];
        snprintf(b, sizeof b, "\\u{%x}", c);
        lust_string_push_cstr(out, b);
        return;
    }
    lust_string_push_char(out, c);
})

/* Decodes one UTF-8 scalar. Input is valid UTF-8 (all lust strings are). */
uint32_t lust_utf8_next(const uint8_t *p, uint64_t *i) LUST_BODY({
    uint8_t b = p[*i];
    if (b < 0x80) { *i += 1; return b; }
    if (b < 0xE0) { uint32_t c = ((b & 0x1F) << 6) | (p[*i + 1] & 0x3F); *i += 2; return c; }
    if (b < 0xF0) { uint32_t c = ((b & 0x0F) << 12) | ((p[*i + 1] & 0x3F) << 6) | (p[*i + 2] & 0x3F); *i += 3; return c; }
    uint32_t c = ((b & 0x07) << 18) | ((p[*i + 1] & 0x3F) << 12) | ((p[*i + 2] & 0x3F) << 6) | (p[*i + 3] & 0x3F);
    *i += 4;
    return c;
})

void lust_fmt_str_debug(lust_String *out, lust_str s) LUST_BODY({
    lust_string_push_bytes(out, "\"", 1);
    uint64_t i = 0;
    while (i < s.len) lust_fmt_escape(out, lust_utf8_next(s.ptr, &i), '"');
    lust_string_push_bytes(out, "\"", 1);
})

void lust_fmt_char_debug(lust_String *out, uint32_t c) LUST_BODY({
    lust_string_push_bytes(out, "'", 1);
    lust_fmt_escape(out, c, '\'');
    lust_string_push_bytes(out, "'", 1);
})

/* Stdout goes through Rust's LineWriter model (panic.c); stderr is unbuffered. */
void lust_write(int to_stderr, lust_String *s) LUST_BODY({
    if (!to_stderr) lust_print_out(s->ptr, s->len);
    else if (s->len) { fwrite(s->ptr, 1, s->len, stderr); fflush(stderr); }
    lust_dealloc(s->ptr, s->cap, 1);
})

void lust_flush(void) LUST_BODY({ lust_print_flush(); })

/* The `exit` intrinsic behind std::process::exit: flush the held stdout
   tail, as Rust's rt::cleanup does. Destructors on the stack do not run,
   as in Rust; the calling thread's thread-local destructors do (glibc's
   exit() runs them for Rust std). */
void lust_exit(int32_t code) LUST_BODY({ lust_tls_exit(); lust_print_flush(); exit(code); })

/* ---------- Vec ---------- */

/* Erased Vec core (ARCH 3.3): capacity rules copy Rust 1.99 RawVec, so
   `capacity()` in the typed layer matches rustc byte for byte.
   - Minimum non-zero capacity: 8 elements when the element size is 1,
     4 when it is 2 to 1024, 1 above 1024.
   - Amortized reserve grows to max(cap * 2, len + extra, minimum).
   - Exact reserve and with_capacity take exactly the requested count.
   - A zero-sized element never allocates and stores capacity 0, as
     RawVec does: the stored word stays inside Cap's valid range
     0..=isize::MAX, so enum niches above it are free. The typed layer
     reports capacity UINT64_MAX (usize::MAX) for it (cgen vec_cap), and
     a reserve past usize::MAX elements is a capacity overflow.
   - A byte size above isize::MAX is a capacity overflow, as in Rust.
   The typed layer owns the shrink_to length assert; this core clamps
   the target at len, which is the same end state. */
void lust_vec_grow_to(lust_Vec *v, uint64_t new_cap, uint64_t elem, uint64_t align) LUST_BODY({
    if (!lust_vec_fits(new_cap, elem)) { lust_vec_capacity_overflow(); return; }
    v->ptr = lust_realloc(v->ptr, v->cap * elem, align, new_cap * elem);
    v->cap = new_cap;
})

void lust_vec_set_zst(lust_Vec *v, uint64_t align) LUST_BODY({
    v->ptr = (void *)(uintptr_t)(align ? align : 1);
    v->cap = 0;
})

void lust_vec_reserve(lust_Vec *v, uint64_t extra, uint64_t elem, uint64_t align) LUST_BODY({
    if (!elem) { lust_vec_set_zst(v, align); if (extra > 18446744073709551615ull - v->len) lust_vec_capacity_overflow(); return; }
    if (v->cap - v->len >= extra) return;
    uint64_t needed = v->len + extra;
    if (needed < v->len) { lust_vec_capacity_overflow(); return; }
    uint64_t cap = v->cap * 2;
    if (cap < needed) cap = needed;
    uint64_t min_cap = elem == 1 ? 8 : elem <= 1024 ? 4 : 1;
    if (cap < min_cap) cap = min_cap;
    lust_vec_grow_to(v, cap, elem, align);
})

void lust_vec_reserve_exact(lust_Vec *v, uint64_t extra, uint64_t elem, uint64_t align) LUST_BODY({
    if (!elem) { lust_vec_set_zst(v, align); if (extra > 18446744073709551615ull - v->len) lust_vec_capacity_overflow(); return; }
    if (v->cap - v->len >= extra) return;
    uint64_t needed = v->len + extra;
    if (needed < v->len) { lust_vec_capacity_overflow(); return; }
    lust_vec_grow_to(v, needed, elem, align);
})

lust_Vec lust_vec_with_capacity(uint64_t n, uint64_t elem, uint64_t align) LUST_BODY({
    lust_Vec v = {(void *)(uintptr_t)(align ? align : 1), 0, 0};
    if (!elem) { lust_vec_set_zst(&v, align); return v; }
    if (n) {
        if (!lust_vec_fits(n, elem)) { lust_vec_capacity_overflow(); return v; }
        v.ptr = lust_alloc(n * elem, align);
        v.cap = n;
    }
    return v;
})

/* RawVec::with_capacity_zeroed: `vec![x; n]` for a value whose bytes
   are all zero (Rust's IsZero fast path). The same capacity overflow
   rule as lust_vec_with_capacity; the memory comes from calloc. */
lust_Vec lust_vec_with_capacity_zeroed(uint64_t n, uint64_t elem, uint64_t align) LUST_BODY({
    lust_Vec v = {(void *)(uintptr_t)(align ? align : 1), 0, 0};
    if (!elem) { lust_vec_set_zst(&v, align); return v; }
    if (n) {
        if (!lust_vec_fits(n, elem)) { lust_vec_capacity_overflow(); return v; }
        v.ptr = lust_alloc_zeroed(n * elem, align);
        v.cap = n;
    }
    return v;
})

void lust_vec_shrink_to(lust_Vec *v, uint64_t min_cap, uint64_t elem, uint64_t align) LUST_BODY({
    if (!elem) return;
    uint64_t target = min_cap > v->len ? min_cap : v->len;
    if (v->cap <= target) return;
    if (!target) {
        free(v->ptr);
        v->ptr = (void *)(uintptr_t)(align ? align : 1);
        v->cap = 0;
        return;
    }
    v->ptr = lust_realloc(v->ptr, v->cap * elem, align, target * elem);
    v->cap = target;
})

void *lust_vec_push_slot(lust_Vec *v, uint64_t elem, uint64_t align) LUST_BODY({
    lust_vec_reserve(v, 1, elem, align);
    return (char *)v->ptr + (v->len++) * elem;
})

/* Panics with "<a><n><b><m><c>": the shape of Rust's index and range
   messages ("removal index (is 5) should be < len (is 3)"). */
void lust_panic_nn(const char *a, uint64_t n, const char *b, uint64_t m, const char *c, lust_loc loc) LUST_BODY({
    lust_String s = lust_string_new();
    lust_string_push_cstr(&s, a);
    lust_fmt_u64(&s, n);
    lust_string_push_cstr(&s, b);
    lust_fmt_u64(&s, m);
    lust_string_push_cstr(&s, c);
    lust_panic_dyn(&s, loc);
})

/* The end of a slice range, checked in Rust 1.99's order: the start
   against the length, the end against the length (an inclusive end
   prints as written; u64::MAX always fails), then start against end. */
uint64_t lust_slice_range(uint64_t lo, uint64_t hi, int inclusive, uint64_t len, lust_loc loc) LUST_BODY({
    if (lo > len) { lust_panic_nn("range start index ", lo, " out of range for slice of length ", len, "", loc); return lo; }
    if (inclusive ? hi >= len : hi > len) { lust_panic_nn("range end index ", hi, " out of range for slice of length ", len, "", loc); return lo; }
    uint64_t end = inclusive ? hi + 1 : hi;
    if (lo > end) { lust_panic_nn("slice index starts at ", lo, " but ends at ", end, "", loc); return lo; }
    return end;
})

#ifdef LUST_IMPL
/* Panics because byte `i` of `ptr` is not a char boundary: names the
   char it falls in, as Rust 1.99 does. */
static void lust_str_boundary_fail(const char *which, const uint8_t *ptr, uint64_t i, lust_loc loc) {
    uint64_t a = i;
    while (a > 0 && (ptr[a] & 0xC0) == 0x80) a--;
    uint64_t b = a;
    uint32_t c = lust_utf8_next(ptr, &b);
    lust_String s = lust_string_new();
    lust_string_push_cstr(&s, which);
    lust_fmt_u64(&s, i);
    lust_string_push_cstr(&s, " is not a char boundary; it is inside ");
    lust_fmt_char_debug(&s, c);
    lust_string_push_cstr(&s, " (bytes ");
    lust_fmt_u64(&s, a);
    lust_string_push_cstr(&s, "..");
    lust_fmt_u64(&s, b);
    lust_string_push_cstr(&s, " of string)");
    lust_panic_dyn(&s, loc);
}
#endif

/* The end of a str slice range, checked in Rust 1.99's order
   (`slice_error_fail_rt`): start and end against the length, start
   against end, then both on UTF-8 char boundaries (the end of the string
   or a byte that is not a continuation byte). An inclusive end at the
   length stays as written, so its boundary checks come first and its
   own out-of-bounds message last, as in core. */
uint64_t lust_str_range(const uint8_t *ptr, uint64_t lo, uint64_t hi, int inclusive, uint64_t len, lust_loc loc) LUST_BODY({
    if (lo > len) { lust_panic_nn("start byte index ", lo, " is out of bounds for string of length ", len, "", loc); return lo; }
    if (hi > len) { lust_panic_nn("end byte index ", hi, " is out of bounds for string of length ", len, "", loc); return lo; }
    uint64_t end = inclusive && hi < len ? hi + 1 : hi;
    if (lo > end) { lust_panic_nn("byte range starts at ", lo, " but ends at ", end, "", loc); return lo; }
    if (lo < len && (ptr[lo] & 0xC0) == 0x80) { lust_str_boundary_fail("start byte index ", ptr, lo, loc); return lo; }
    if (end < len && (ptr[end] & 0xC0) == 0x80) { lust_str_boundary_fail("end byte index ", ptr, end, loc); return lo; }
    if (inclusive && hi == len) { lust_panic_nn("end byte index ", hi, " is out of bounds for string of length ", len, "", loc); return lo; }
    return end;
})

/* A `lust_loc` for a line of std source (panic.c's `lust_std_files`
   index, line, col), for a panic rustc reports there. */
static lust_loc lust_std_loc(uint32_t file, uint32_t line, uint32_t col) {
    return (((uint64_t)(LUST_STD_SLOT + file)) << 40) | ((uint64_t)line << 20) | (uint64_t)col;
}

/* The `start..end` of a `RangeBounds<usize>` argument (tags: 0 Included,
   1 Excluded, 2 Unbounded), checked the way core checks it for
   `Vec::drain` and `String::drain`: the end bound against the length
   first, then the start bound, then their order, with core's exact
   panic texts. An excluded start at the end index fails with the end
   message, as in core. The panics report core's own sites in
   slice/index.rs (`into_slice_range`, std file 12), not the caller:
   `slice::range` is track_caller to there, and `Vec::drain` is not
   track_caller at all. */
static void lust_range_bounds_check(uint64_t len, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, uint64_t *out_s, uint64_t *out_e) LUST_BODY({
    uint64_t end;
    if (e_tag == 0) {
        if (e_val >= len) {
            lust_String s = lust_string_new();
            lust_string_push_cstr(&s, "range end index ");
            lust_fmt_u64(&s, e_val);
            lust_string_push_cstr(&s, " out of range for slice of length ");
            lust_fmt_u64(&s, len);
            lust_panic(&s, lust_std_loc(12, 1005, 52));
        }
        end = e_val + 1;
    } else if (e_tag == 1) {
        if (e_val > len) {
            lust_String s = lust_string_new();
            lust_string_push_cstr(&s, "range end index ");
            lust_fmt_u64(&s, e_val);
            lust_string_push_cstr(&s, " out of range for slice of length ");
            lust_fmt_u64(&s, len);
            lust_panic(&s, lust_std_loc(12, 1009, 51));
        }
        end = e_val;
    } else {
        end = len;
    }
    uint64_t start;
    if (s_tag == 2) {
        start = 0;
    } else {
        /* Core's start match: Excluded fails at index.rs:1016,
           Included at 1020, for every start failure. */
        lust_loc start_loc = s_tag == 1 ? lust_std_loc(12, 1016, 56) : lust_std_loc(12, 1020, 55);
        if (s_val > len) {
            lust_String s = lust_string_new();
            lust_string_push_cstr(&s, "range start index ");
            lust_fmt_u64(&s, s_val);
            lust_string_push_cstr(&s, " out of range for slice of length ");
            lust_fmt_u64(&s, len);
            lust_panic(&s, start_loc);
        }
        if (s_tag == 1 && s_val == end) {
            lust_String s = lust_string_new();
            lust_string_push_cstr(&s, "range end index ");
            lust_fmt_u64(&s, s_val);
            lust_string_push_cstr(&s, " out of range for slice of length ");
            lust_fmt_u64(&s, len);
            lust_panic(&s, start_loc);
        }
        if (s_val > end) {
            lust_String s = lust_string_new();
            lust_string_push_cstr(&s, "slice index starts at ");
            lust_fmt_u64(&s, s_val);
            lust_string_push_cstr(&s, " but ends at ");
            lust_fmt_u64(&s, end);
            lust_panic(&s, start_loc);
        }
        start = s_tag == 1 ? s_val + 1 : s_val;
    }
    *out_s = start;
    *out_e = end;
})

/* `Vec::drain`: the Vec keeps its buffer and capacity; its length is the
   drain start while the Drain lives (a leaked Drain leaves it so). This form is for
   flag-mode unwinding (lust_unwind_mode 1), where a panic returns with the thread's
   panic pending; codegen calls lust_vec_drain_t in every other build. */
lust_VecDrain lust_vec_drain(lust_Vec *v, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, lust_loc loc) LUST_BODY({
    (void)loc; /* range panics report core's slice/index.rs sites */
    uint64_t start, end;
    lust_range_bounds_check(v->len, s_tag, s_val, e_tag, e_val, &start, &end);
    if (lust_unwind_mode && lust_unw_mine()) {
        /* The range panicked: the Vec stays as it is (an empty Drain at its end). */
        lust_VecDrain e = {v, v->len, v->len, v->len, v->len, 0};
        return e;
    }
    lust_VecDrain d = {v, start, start, end, end, v->len - end};
    v->len = start;
    return d;
})

/* `Vec::drain` where a panic never returns (panic=abort, or unwind tables: it throws):
   no check of the thread's pending panic, which is a thread-local lookup per drain. */
lust_VecDrain lust_vec_drain_t(lust_Vec *v, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, lust_loc loc) LUST_BODY({
    (void)loc;
    uint64_t start, end;
    lust_range_bounds_check(v->len, s_tag, s_val, e_tag, e_val, &start, &end);
    lust_VecDrain d = {v, start, start, end, end, v->len - end};
    v->len = start;
    return d;
})

/* `String::drain`: the same range checks over the byte length, then the
   char boundary asserts. The String is unchanged while the Drain lives
   (a leaked Drain leaves it whole); the drop glue removes the range. `flag`: flag-mode
   unwinding, where the range check's panic returns pending (lust_string_drain); 0 in
   every other build (lust_string_drain_t), where it never returns. */
static lust_VecDrain lust_string_drain_in(lust_String *v, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, lust_loc loc, int flag) LUST_BODY({
    uint64_t start, end;
    lust_range_bounds_check(v->len, s_tag, s_val, e_tag, e_val, &start, &end);
    lust_VecDrain e = {v, v->len, v->len, v->len, v->len, 0}; /* after a panic: an empty Drain at the end */
    if (flag && lust_unwind_mode && lust_unw_mine()) return e;
    if (!(start == v->len || (v->ptr[start] & 0xC0) != 0x80)) {
        lust_String s = lust_string_new();
        lust_string_push_cstr(&s, "assertion failed: self.is_char_boundary(start)");
        lust_panic(&s, loc);
        return e;
    }
    if (!(end == v->len || (v->ptr[end] & 0xC0) != 0x80)) {
        lust_String s = lust_string_new();
        lust_string_push_cstr(&s, "assertion failed: self.is_char_boundary(end)");
        lust_panic(&s, loc);
        return e;
    }
    lust_VecDrain d = {v, start, start, end, end, v->len - end};
    return d;
})

lust_VecDrain lust_string_drain(lust_String *v, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, lust_loc loc) LUST_BODY({
    return lust_string_drain_in(v, s_tag, s_val, e_tag, e_val, loc, 1);
})

lust_VecDrain lust_string_drain_t(lust_String *v, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, lust_loc loc) LUST_BODY({
    return lust_string_drain_in(v, s_tag, s_val, e_tag, e_val, loc, 0);
})

/* `slice::range(r, ..len)` for the callers outside this file
   (`Vec::extend_from_within`): drain's four range words checked at
   core's index.rs sites (`lust_range_bounds_check`). */
void lust_range_check(uint64_t len, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, uint64_t *out_s, uint64_t *out_e) LUST_BODY({
    lust_range_bounds_check(len, s_tag, s_val, e_tag, e_val, out_s, out_e);
})

/* `[u8]::eq_ignore_ascii_case`: equal lengths and every byte pair equal
   after ASCII lowercasing. */
uint8_t lust_bytes_eq_ignore_ascii_case(const uint8_t *a, uint64_t an, const uint8_t *b, uint64_t bn) LUST_BODY({
    if (an != bn) return 0;
    for (uint64_t i = 0; i < an; i++) {
        uint8_t x = a[i], y = b[i];
        if (x >= 'A' && x <= 'Z') x += 32;
        if (y >= 'A' && y <= 'Z') y += 32;
        if (x != y) return 0;
    }
    return 1;
})

/* `[u8]::is_ascii` and `str::is_ascii`: no byte at or above 0x80. A clang or gcc build for
   x86_64 tests 32 bytes a step (two 16-byte loads, one sign-bit mask) and ends with one
   16-byte load at the last byte (it may test some bytes twice); other builds test 8 bytes a
   word. It never reads outside the n bytes. */
#if !defined(__TINYC__) && defined(__x86_64__) && defined(__SSE2__)
typedef char lust_v16_ __attribute__((vector_size(16)));
typedef char lust_v16u_ __attribute__((vector_size(16), aligned(1)));
#endif
uint8_t lust_bytes_is_ascii(const uint8_t *p, uint64_t n) LUST_BODY({
#if !defined(__TINYC__) && defined(__x86_64__) && defined(__SSE2__)
    if (n >= 16) {
        const uint8_t *q = p, *last = p + n - 16;
        for (; q + 16 < last; q += 32) {
            lust_v16_ a = *(const lust_v16u_ *)(const void *)q, b = *(const lust_v16u_ *)(const void *)(q + 16);
            if (__builtin_ia32_pmovmskb128(a | b)) return 0;
        }
        if (q < last) {
            lust_v16_ a = *(const lust_v16u_ *)(const void *)q;
            if (__builtin_ia32_pmovmskb128(a)) return 0;
        }
        lust_v16_ z = *(const lust_v16u_ *)(const void *)last;
        return !__builtin_ia32_pmovmskb128(z);
    }
#endif
    uint64_t i = 0;
    for (; i + 8 <= n; i += 8) {
        uint64_t w;
        memcpy(&w, p + i, 8);
        if (w & 0x8080808080808080ull) return 0;
    }
    for (; i < n; i++)
        if (p[i] >= 0x80) return 0;
    return 1;
})

/* `[T]::rotate_left(mid)` over `len` elements of `elem` bytes, after the
   caller's assert: three reversals, elements moved as bytes. */
void lust_slice_rotate_left(void *ptr, uint64_t len, uint64_t elem, uint64_t mid) LUST_BODY({
    uint8_t *p = (uint8_t *)ptr;
    uint64_t spans[3][2] = {{0, mid}, {mid, len}, {0, len}};
    for (int k = 0; k < 3; k++) {
        uint64_t lo = spans[k][0], hi = spans[k][1];
        while (lo + 1 < hi) {
            hi--;
            for (uint64_t b = 0; b < elem; b++) {
                uint8_t t = p[lo * elem + b];
                p[lo * elem + b] = p[hi * elem + b];
                p[hi * elem + b] = t;
            }
            lo++;
        }
    }
})

/* `[T]::copy_within` over a byte buffer of `len` elements of `elem`
   bytes: core checks the range as for drain (`lust_range_bounds_check`,
   core's own panic sites), then the destination against the space
   the copied range leaves (`dest is out of bounds` at the caller,
   core's `#[track_caller]` assert), then moves the bytes, overlap
   included. */
/* One `Utf8Chunks` step (core's `str::lossy` scan, byte for byte):
   writes the valid prefix length and the total inspected length
   (valid + the broken sequence, at most 3 more bytes) of `p[..len]`.
   The caller guarantees `len > 0`. A read past the end answers 0,
   which fails every continuation test, as core's `safe_get` does. */
void lust_utf8_chunk_step(const uint8_t *p, uint64_t len, uint64_t *valid, uint64_t *used) LUST_BODY({
    uint64_t i = 0;
    uint64_t valid_up_to = 0;
    while (i < len) {
        uint8_t byte = p[i];
        i += 1;
        if (byte >= 128) {
            uint8_t b1 = i < len ? p[i] : 0;
            if (byte >= 0xC2 && byte <= 0xDF) {
                if ((b1 & 192) != 128) break;
                i += 1;
            } else if (byte >= 0xE0 && byte <= 0xEF) {
                int ok = (byte == 0xE0 && b1 >= 0xA0 && b1 <= 0xBF) || (byte >= 0xE1 && byte <= 0xEC && b1 >= 0x80 && b1 <= 0xBF) ||
                         (byte == 0xED && b1 >= 0x80 && b1 <= 0x9F) || (byte >= 0xEE && b1 >= 0x80 && b1 <= 0xBF);
                if (!ok) break;
                i += 1;
                if (((i < len ? p[i] : 0) & 192) != 128) break;
                i += 1;
            } else if (byte >= 0xF0 && byte <= 0xF4) {
                int ok = (byte == 0xF0 && b1 >= 0x90 && b1 <= 0xBF) || (byte >= 0xF1 && byte <= 0xF3 && b1 >= 0x80 && b1 <= 0xBF) ||
                         (byte == 0xF4 && b1 >= 0x80 && b1 <= 0x8F);
                if (!ok) break;
                i += 1;
                if (((i < len ? p[i] : 0) & 192) != 128) break;
                i += 1;
                if (((i < len ? p[i] : 0) & 192) != 128) break;
                i += 1;
            } else {
                break;
            }
        }
        valid_up_to = i;
    }
    *valid = valid_up_to;
    *used = i;
})

/* The `start..end` of a `SliceIndex` range argument (same tags as
   `lust_range_bounds_check`), or 0 when core's `get` would answer
   `None`: the end bound against the length first, then the start
   bound, then their order (core's `try_into_slice_range`). */
int lust_range_bounds_get(uint64_t len, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, uint64_t *out_s, uint64_t *out_e) LUST_BODY({
    uint64_t end;
    if (e_tag == 0) {
        if (e_val >= len) return 0;
        end = e_val + 1;
    } else if (e_tag == 1) {
        if (e_val > len) return 0;
        end = e_val;
    } else {
        end = len;
    }
    uint64_t start;
    if (s_tag == 2) {
        start = 0;
    } else if (s_tag == 1) {
        if (s_val >= end) return 0;
        start = s_val + 1;
    } else {
        if (s_val > end) return 0;
        start = s_val;
    }
    *out_s = start;
    *out_e = end;
    return 1;
})

void lust_slice_copy_within(void *ptr, uint64_t len, uint64_t elem, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, uint64_t dest, lust_loc loc) LUST_BODY({
    uint64_t start, end;
    lust_range_bounds_check(len, s_tag, s_val, e_tag, e_val, &start, &end);
    if (lust_unwind_mode && lust_unw_mine()) return;
    if (dest > len - (end - start)) {
        lust_panic_cstr("dest is out of bounds", loc);
        return;
    }
    memmove((char *)ptr + dest * elem, (char *)ptr + start * elem, (end - start) * elem);
})

/* Exact float remainder (Rust `%`, truncating division), computed on the
   mantissa integers so no libm link is needed. The algorithm is the
   standard normalize-and-subtract loop over the exponent difference. */
double lust_fmod_f64(double x, double y) LUST_BODY({
    union { double f; uint64_t i; } ux, uy;
    ux.f = x;
    uy.f = y;
    int ex = (int)((ux.i >> 52) & 0x7ff);
    int ey = (int)((uy.i >> 52) & 0x7ff);
    uint64_t sx = ux.i >> 63;
    uint64_t ax = ux.i & (UINT64_MAX >> 1);
    uint64_t ay = uy.i & (UINT64_MAX >> 1);
    ux.i &= (1ULL << 52) - 1;
    uy.i &= (1ULL << 52) - 1;
    if (ay == 0 || ex == 0x7ff || (ey == 0x7ff && (ay & ((1ULL << 52) - 1)) != 0) || ax > 0x7ff0000000000000ULL) {
        return (x * y) / (x * y); /* NaN */
    }
    if (ax <= ay) {
        if (ax == ay) {
            ux.f = 0.0;
            ux.i |= sx << 63;
            return ux.f;
        }
        return x;
    }
    /* Normalize both mantissas to 53-bit integers. */
    if (ex == 0) {
        uint64_t i = ux.i;
        for (; !(i >> 52); i <<= 1) ex--;
        ux.i = i;
        ex += 1;
    } else {
        ux.i |= 1ULL << 52;
    }
    if (ey == 0) {
        uint64_t i = uy.i;
        for (; !(i >> 52); i <<= 1) ey--;
        uy.i = i;
        ey += 1;
    } else {
        uy.i |= 1ULL << 52;
    }
    for (; ex > ey; ex--) {
        if (ux.i >= uy.i) {
            ux.i -= uy.i;
            if (ux.i == 0) {
                ux.f = 0.0;
                ux.i |= sx << 63;
                return ux.f;
            }
        }
        ux.i <<= 1;
    }
    if (ux.i >= uy.i) {
        ux.i -= uy.i;
        if (ux.i == 0) {
            ux.f = 0.0;
            ux.i |= sx << 63;
            return ux.f;
        }
    }
    while (!(ux.i >> 52)) {
        ux.i <<= 1;
        ey--;
    }
    if (ey > 0) {
        ux.i -= 1ULL << 52;
        ux.i |= (uint64_t)ey << 52;
    } else {
        ux.i >>= (uint64_t)(1 - ey);
    }
    ux.i |= sx << 63;
    return ux.f;
})

float lust_fmod_f32(float x, float y) LUST_BODY({
    /* The f64 remainder of two f32 values is exact, and its result is an
       f32 value, so one rounding at the end is exact. */
    return (float)lust_fmod_f64((double)x, (double)y);
})

uint64_t lust_bounds(uint64_t i, uint64_t len, lust_loc loc) LUST_BODY({
    if (i >= len) {
        lust_String s = lust_string_new();
        lust_string_push_cstr(&s, "index out of bounds: the len is ");
        lust_fmt_u64(&s, len);
        lust_string_push_cstr(&s, " but the index is ");
        lust_fmt_u64(&s, i);
        lust_panic_dyn(&s, loc);
    }
    return i;
})

/* ---------- Checked integer math ---------- */

#define LUST_OVF(op) lust_ovf(op, loc)

/* Narrow signed types: compute exactly in int64_t, then range check. */
#define LUST_SIGNED_NARROW(T, N, MINV, MAXV) \
T lust_add_##N(T a, T b, lust_loc loc) LUST_BODY({ int64_t r = (int64_t)a + b; if (r < MINV || r > MAXV) LUST_OVF("add"); return (T)r; }) \
T lust_sub_##N(T a, T b, lust_loc loc) LUST_BODY({ int64_t r = (int64_t)a - b; if (r < MINV || r > MAXV) LUST_OVF("subtract"); return (T)r; }) \
T lust_mul_##N(T a, T b, lust_loc loc) LUST_BODY({ int64_t r = (int64_t)a * b; if (r < MINV || r > MAXV) LUST_OVF("multiply"); return (T)r; }) \
T lust_neg_##N(T a, lust_loc loc) LUST_BODY({ if (a == MINV) { LUST_OVF("negate"); return a; } return (T)-a; }) \
T lust_div_##N(T a, T b, lust_loc loc) LUST_BODY({ if (b == 0) { lust_panic_cstr("attempt to divide by zero", loc); return 0; } if (a == MINV && b == -1) { LUST_OVF("divide"); return 0; } return (T)(a / b); }) \
T lust_rem_##N(T a, T b, lust_loc loc) LUST_BODY({ if (b == 0) { lust_panic_cstr("attempt to calculate the remainder with a divisor of zero", loc); return 0; } if (a == MINV && b == -1) { LUST_OVF("calculate the remainder"); return 0; } return (T)(a % b); })

#define LUST_UNSIGNED_NARROW(T, N, MAXV) \
T lust_add_##N(T a, T b, lust_loc loc) LUST_BODY({ uint64_t r = (uint64_t)a + b; if (r > MAXV) LUST_OVF("add"); return (T)r; }) \
T lust_sub_##N(T a, T b, lust_loc loc) LUST_BODY({ if (b > a) LUST_OVF("subtract"); return (T)(a - b); }) \
T lust_mul_##N(T a, T b, lust_loc loc) LUST_BODY({ uint64_t r = (uint64_t)a * (uint64_t)b; if (r > MAXV) LUST_OVF("multiply"); return (T)r; }) \
T lust_div_##N(T a, T b, lust_loc loc) LUST_BODY({ if (b == 0) { lust_panic_cstr("attempt to divide by zero", loc); return 0; } return (T)(a / b); }) \
T lust_rem_##N(T a, T b, lust_loc loc) LUST_BODY({ if (b == 0) { lust_panic_cstr("attempt to calculate the remainder with a divisor of zero", loc); return 0; } return (T)(a % b); })

LUST_SIGNED_NARROW(int8_t, i8, -128, 127)
LUST_SIGNED_NARROW(int16_t, i16, -32768, 32767)
LUST_SIGNED_NARROW(int32_t, i32, -2147483647 - 1, 2147483647)
LUST_UNSIGNED_NARROW(uint8_t, u8, 255u)
LUST_UNSIGNED_NARROW(uint16_t, u16, 65535u)
LUST_UNSIGNED_NARROW(uint32_t, u32, 4294967295u)

int64_t lust_add_i64(int64_t a, int64_t b, lust_loc loc) LUST_BODY({
    int64_t r = (int64_t)((uint64_t)a + (uint64_t)b);
    if (((a ^ r) & (b ^ r)) < 0) LUST_OVF("add");
    return r;
})
int64_t lust_sub_i64(int64_t a, int64_t b, lust_loc loc) LUST_BODY({
    int64_t r = (int64_t)((uint64_t)a - (uint64_t)b);
    if (((a ^ b) & (a ^ r)) < 0) LUST_OVF("subtract");
    return r;
})
int64_t lust_mul_i64(int64_t a, int64_t b, lust_loc loc) LUST_BODY({
    if (a == 0 || b == 0) return 0;
    if ((a == -1 && b == INT64_MIN) || (b == -1 && a == INT64_MIN)) LUST_OVF("multiply");
    int64_t r = (int64_t)((uint64_t)a * (uint64_t)b);
    if (r / b != a) LUST_OVF("multiply");
    return r;
})
int64_t lust_neg_i64(int64_t a, lust_loc loc) LUST_BODY({ if (a == INT64_MIN) { LUST_OVF("negate"); return a; } return -a; })
int64_t lust_div_i64(int64_t a, int64_t b, lust_loc loc) LUST_BODY({
    if (b == 0) { lust_panic_cstr("attempt to divide by zero", loc); return 0; }
    if (a == INT64_MIN && b == -1) { LUST_OVF("divide"); return 0; }
    return a / b;
})
int64_t lust_rem_i64(int64_t a, int64_t b, lust_loc loc) LUST_BODY({
    if (b == 0) { lust_panic_cstr("attempt to calculate the remainder with a divisor of zero", loc); return 0; }
    if (a == INT64_MIN && b == -1) { LUST_OVF("calculate the remainder"); return 0; }
    return a % b;
})
uint64_t lust_add_u64(uint64_t a, uint64_t b, lust_loc loc) LUST_BODY({ uint64_t r = a + b; if (r < a) LUST_OVF("add"); return r; })
uint64_t lust_sub_u64(uint64_t a, uint64_t b, lust_loc loc) LUST_BODY({ if (b > a) LUST_OVF("subtract"); return a - b; })
uint64_t lust_mul_u64(uint64_t a, uint64_t b, lust_loc loc) LUST_BODY({ uint64_t r = a * b; if (a != 0 && r / a != b) LUST_OVF("multiply"); return r; })
uint64_t lust_div_u64(uint64_t a, uint64_t b, lust_loc loc) LUST_BODY({ if (b == 0) { lust_panic_cstr("attempt to divide by zero", loc); return 0; } return a / b; })
uint64_t lust_rem_u64(uint64_t a, uint64_t b, lust_loc loc) LUST_BODY({ if (b == 0) { lust_panic_cstr("attempt to calculate the remainder with a divisor of zero", loc); return 0; } return a % b; })

uint32_t lust_shift_amount(uint64_t b, uint32_t bits, const char *op, lust_loc loc) LUST_BODY({
    if (b >= bits) {
        lust_String s = lust_string_new();
        lust_string_push_cstr(&s, "attempt to shift ");
        lust_string_push_cstr(&s, op);
        lust_string_push_cstr(&s, " with overflow");
        lust_panic_lit(&s, loc);
        return 0;
    }
    return (uint32_t)b;
})

#define LUST_POW(T, N) \
T lust_pow_##N(T a, uint32_t e, lust_loc loc) LUST_BODY({ \
    T r = 1; \
    while (e) { if (e & 1) r = lust_mul_##N(r, a, loc); e >>= 1; if (e) a = lust_mul_##N(a, a, loc); } \
    return r; \
})
#define LUST_ABS(T, N) T lust_abs_##N(T a, lust_loc loc) LUST_BODY({ return a < 0 ? lust_neg_##N(a, loc) : a; })
LUST_POW(int8_t, i8) LUST_POW(int16_t, i16) LUST_POW(int32_t, i32) LUST_POW(int64_t, i64)
LUST_POW(uint8_t, u8) LUST_POW(uint16_t, u16) LUST_POW(uint32_t, u32) LUST_POW(uint64_t, u64)
LUST_ABS(int8_t, i8) LUST_ABS(int16_t, i16) LUST_ABS(int32_t, i32) LUST_ABS(int64_t, i64)

/* ---------- Checked, saturating, and bit ops on 64-bit words ----------
   One generic form for the checked_* and overflowing_* methods:
   operands arrive masked to the operand width (sign bits above the
   width are the caller's to mask off first), the result leaves
   masked the same way. Returns 1 on success, 0 on overflow (the
   wrapping result is still in *out), and -1 for division by zero.
   Ops: 0 add, 1 sub, 2 mul, 3 div, 4 rem. */

static uint64_t lust_mask64(unsigned bits) LUST_BODY({
    return bits >= 64 ? ~0ull : ((1ull << bits) - 1ull);
})
static int64_t lust_sext64(uint64_t v, unsigned bits) LUST_BODY({
    if (bits >= 64) return (int64_t)v;
    if (v & (1ull << (bits - 1))) return (int64_t)(v | ~lust_mask64(bits));
    return (int64_t)v;
})

int lust_checked_op(uint64_t a, uint64_t b, unsigned bits, int is_signed, int op, uint64_t *out) LUST_BODY({
    uint64_t mask = lust_mask64(bits);
    a &= mask;
    b &= mask;
    if (is_signed) {
        int64_t sa = lust_sext64(a, bits), sb = lust_sext64(b, bits);
        int64_t minv = bits >= 64 ? INT64_MIN : -(1ll << (bits - 1));
        int64_t maxv = bits >= 64 ? INT64_MAX : ((1ll << (bits - 1)) - 1);
        int64_t r = 0;
        int ok = 1;
        switch (op) {
            case 0:
                r = (int64_t)((uint64_t)sa + (uint64_t)sb);
                ok = bits < 64 ? (r >= minv && r <= maxv) : !(((sa ^ r) & (sb ^ r)) < 0);
                break;
            case 1:
                r = (int64_t)((uint64_t)sa - (uint64_t)sb);
                ok = bits < 64 ? (r >= minv && r <= maxv) : !(((sa ^ sb) & (sa ^ r)) < 0);
                break;
            case 2:
                r = (int64_t)((uint64_t)sa * (uint64_t)sb);
                if (bits < 64) {
                    ok = (r >= minv && r <= maxv);
                } else if (sa == 0 || sb == 0) {
                    ok = 1;
                } else if ((sa == -1 && sb == INT64_MIN) || (sb == -1 && sa == INT64_MIN)) {
                    ok = 0;
                } else {
                    ok = (r / sb == sa);
                }
                break;
            case 3:
            case 4:
                if (sb == 0) return -1;
                if (sa == minv && sb == -1) {
                    *out = (op == 3 ? (uint64_t)sa : 0ull) & mask;
                    return 0;
                }
                r = op == 3 ? sa / sb : sa % sb;
                break;
            default:
                return 0;
        }
        *out = (uint64_t)r & mask;
        return ok;
    }
    {
        uint64_t r = 0;
        int ok = 1;
        switch (op) {
            case 0:
                r = a + b;
                ok = bits < 64 ? (r <= mask) : (r >= a);
                break;
            case 1:
                r = a - b;
                ok = (a >= b);
                break;
            case 2:
                r = a * b;
                ok = bits < 64 ? (r <= mask) : (a == 0 || r / a == b);
                break;
            case 3:
                if (b == 0) return -1;
                r = a / b;
                break;
            case 4:
                if (b == 0) return -1;
                r = a % b;
                break;
            default:
                return 0;
        }
        *out = r & mask;
        return ok;
    }
})

/* checked_pow on the same representation: squaring loop, and the
   final unused square is not computed, as in core. */
int lust_checked_pow(uint64_t a, uint32_t e, unsigned bits, int is_signed, uint64_t *out) LUST_BODY({
    uint64_t r = 1, x = a & lust_mask64(bits), t;
    while (e) {
        if (e & 1) {
            if (!lust_checked_op(r, x, bits, is_signed, 2, &t)) {
                *out = t;
                return 0;
            }
            r = t;
        }
        e >>= 1;
        if (!e) break;
        if (!lust_checked_op(x, x, bits, is_signed, 2, &t)) {
            *out = t;
            return 0;
        }
        x = t;
    }
    *out = r;
    return 1;
})

/* wrapping_pow on the same representation: no checks at all. */
uint64_t lust_wrapping_pow(uint64_t a, uint32_t e, unsigned bits) LUST_BODY({
    uint64_t mask = lust_mask64(bits);
    uint64_t r = 1, x = a & mask;
    while (e) {
        if (e & 1) r = (r * x) & mask;
        e >>= 1;
        if (!e) break;
        x = (x * x) & mask;
    }
    return r & mask;
})

/* Euclid division: the quotient rounds toward negative infinity,
   the remainder is never negative. Both panic exactly as the plain
   operators do for a zero divisor and for MIN / -1. */
/* Unsigned ceiling division (div_ceil): a / b rounded up. The
   quotient-plus-remainder form cannot overflow. */
uint64_t lust_div_ceil(uint64_t a, uint64_t b, unsigned bits, lust_loc loc) LUST_BODY({
    uint64_t mask = lust_mask64(bits);
    a &= mask;
    b &= mask;
    if (b == 0) { lust_panic_cstr("attempt to divide by zero", loc); return 0; }
    return a / b + (a % b != 0);
})

uint64_t lust_div_euclid(uint64_t a, uint64_t b, unsigned bits, int is_signed, lust_loc loc) LUST_BODY({
    uint64_t mask = lust_mask64(bits);
    a &= mask;
    b &= mask;
    if (!is_signed) {
        if (b == 0) { lust_panic_cstr("attempt to divide by zero", loc); return 0; }
        return a / b;
    }
    {
        int64_t sa = lust_sext64(a, bits), sb = lust_sext64(b, bits);
        int64_t minv = bits >= 64 ? INT64_MIN : -(1ll << (bits - 1));
        int64_t q;
        if (sb == 0) { lust_panic_cstr("attempt to divide by zero", loc); return 0; }
        if (sa == minv && sb == -1) { LUST_OVF("divide"); return 0; }
        q = sa / sb;
        if (sa % sb < 0) q += sb > 0 ? -1 : 1;
        return (uint64_t)q & mask;
    }
})
uint64_t lust_rem_euclid(uint64_t a, uint64_t b, unsigned bits, int is_signed, lust_loc loc) LUST_BODY({
    uint64_t mask = lust_mask64(bits);
    a &= mask;
    b &= mask;
    if (!is_signed) {
        if (b == 0) { lust_panic_cstr("attempt to calculate the remainder with a divisor of zero", loc); return 0; }
        return a % b;
    }
    {
        int64_t sa = lust_sext64(a, bits), sb = lust_sext64(b, bits);
        int64_t minv = bits >= 64 ? INT64_MIN : -(1ll << (bits - 1));
        int64_t r;
        if (sb == 0) { lust_panic_cstr("attempt to calculate the remainder with a divisor of zero", loc); return 0; }
        if (sa == minv && sb == -1) { LUST_OVF("calculate the remainder"); return 0; }
        r = sa % sb;
        if (r < 0) r += sb > 0 ? sb : -sb;
        return (uint64_t)r & mask;
    }
})

uint64_t lust_isqrt64(uint64_t v) LUST_BODY({
    uint64_t r = 1ull << 32, n;
    if (v < 2) return v;
    for (;;) {
        n = (r + v / r) / 2;
        if (n >= r) return r;
        r = n;
    }
})
uint32_t lust_count_ones64(uint64_t v) LUST_BODY({
    v = v - ((v >> 1) & 0x5555555555555555ull);
    v = (v & 0x3333333333333333ull) + ((v >> 2) & 0x3333333333333333ull);
    v = (v + (v >> 4)) & 0x0F0F0F0F0F0F0F0Full;
    return (uint32_t)((v * 0x0101010101010101ull) >> 56);
})
uint32_t lust_leading_zeros64(uint64_t v, unsigned bits) LUST_BODY({
    uint32_t n = 0;
    int i;
    if (v == 0) return bits;
    for (i = 63; i >= 0 && !((v >> i) & 1ull); i--) n++;
    return n - (64 - bits);
})
uint32_t lust_trailing_zeros64(uint64_t v, unsigned bits) LUST_BODY({
    uint32_t n = 0;
    unsigned i;
    if (v == 0) return bits;
    for (i = 0; i < bits && !((v >> i) & 1ull); i++) n++;
    return n;
})

/* ---------- 128-bit integers ---------- */

/* Two-word helpers over lust_u128/lust_i128. Division is Knuth's
   Algorithm D over 32-bit limbs (the spike's bit-by-bit divider took
   1673 ns; this one is two orders of magnitude less), and formatting
   divides by 10^19 chunks through the 128-by-64 fast path. Checked
   wrappers panic with the same texts as the narrow types above. */

lust_u128 lust_u128_from_i128(lust_i128 a) LUST_BODY({ lust_u128 r; r.lo = a.lo; r.hi = a.hi; return r; })
lust_i128 lust_i128_from_u128(lust_u128 a) LUST_BODY({ lust_i128 r; r.lo = a.lo; r.hi = a.hi; return r; })

lust_u128 lust_u128_add(lust_u128 a, lust_u128 b) LUST_BODY({
    lust_u128 r;
    r.lo = a.lo + b.lo;
    r.hi = a.hi + b.hi + (r.lo < a.lo);
    return r;
})
lust_u128 lust_u128_sub(lust_u128 a, lust_u128 b) LUST_BODY({
    lust_u128 r;
    r.lo = a.lo - b.lo;
    r.hi = a.hi - b.hi - (a.lo < b.lo);
    return r;
})
lust_i128 lust_i128_add(lust_i128 a, lust_i128 b) LUST_BODY({ return lust_i128_from_u128(lust_u128_add(lust_u128_from_i128(a), lust_u128_from_i128(b))); })
lust_i128 lust_i128_sub(lust_i128 a, lust_i128 b) LUST_BODY({ return lust_i128_from_u128(lust_u128_sub(lust_u128_from_i128(a), lust_u128_from_i128(b))); })

int32_t lust_u128_cmp(lust_u128 a, lust_u128 b) LUST_BODY({
    if (a.hi != b.hi) return a.hi < b.hi ? -1 : 1;
    if (a.lo != b.lo) return a.lo < b.lo ? -1 : 1;
    return 0;
})
int32_t lust_i128_cmp(lust_i128 a, lust_i128 b) LUST_BODY({
    int64_t ah = (int64_t)a.hi, bh = (int64_t)b.hi;
    if (ah != bh) return ah < bh ? -1 : 1;
    if (a.lo != b.lo) return a.lo < b.lo ? -1 : 1;
    return 0;
})

lust_u128 lust_u128_and(lust_u128 a, lust_u128 b) LUST_BODY({ lust_u128 r; r.lo = a.lo & b.lo; r.hi = a.hi & b.hi; return r; })
lust_u128 lust_u128_or(lust_u128 a, lust_u128 b) LUST_BODY({ lust_u128 r; r.lo = a.lo | b.lo; r.hi = a.hi | b.hi; return r; })
lust_u128 lust_u128_xor(lust_u128 a, lust_u128 b) LUST_BODY({ lust_u128 r; r.lo = a.lo ^ b.lo; r.hi = a.hi ^ b.hi; return r; })
lust_u128 lust_u128_not(lust_u128 a) LUST_BODY({ lust_u128 r; r.lo = ~a.lo; r.hi = ~a.hi; return r; })
lust_i128 lust_i128_and(lust_i128 a, lust_i128 b) LUST_BODY({ return lust_i128_from_u128(lust_u128_and(lust_u128_from_i128(a), lust_u128_from_i128(b))); })
lust_i128 lust_i128_or(lust_i128 a, lust_i128 b) LUST_BODY({ return lust_i128_from_u128(lust_u128_or(lust_u128_from_i128(a), lust_u128_from_i128(b))); })
lust_i128 lust_i128_xor(lust_i128 a, lust_i128 b) LUST_BODY({ return lust_i128_from_u128(lust_u128_xor(lust_u128_from_i128(a), lust_u128_from_i128(b))); })
lust_i128 lust_i128_not(lust_i128 a) LUST_BODY({ return lust_i128_from_u128(lust_u128_not(lust_u128_from_i128(a))); })

/* Full 64x64->128 product through 32-bit halves. Returns the low word;
   the high word goes to *hi. */
uint64_t lust_u128_mul64(uint64_t a, uint64_t b, uint64_t *hi) LUST_BODY({
    uint64_t al = a & 0xFFFFFFFFull, ah = a >> 32;
    uint64_t bl = b & 0xFFFFFFFFull, bh = b >> 32;
    uint64_t ll = al * bl, lh = al * bh, hl = ah * bl, hh = ah * bh;
    uint64_t mid = lh + (ll >> 32) + (hl & 0xFFFFFFFFull);
    *hi = hh + (hl >> 32) + (mid >> 32);
    return (mid << 32) | (ll & 0xFFFFFFFFull);
})

lust_u128 lust_u128_mul(lust_u128 a, lust_u128 b) LUST_BODY({
    lust_u128 r;
    uint64_t hi;
    r.lo = lust_u128_mul64(a.lo, b.lo, &hi);
    r.hi = hi + a.lo * b.hi + a.hi * b.lo;
    return r;
})
lust_i128 lust_i128_mul(lust_i128 a, lust_i128 b) LUST_BODY({ return lust_i128_from_u128(lust_u128_mul(lust_u128_from_i128(a), lust_u128_from_i128(b))); })

lust_u128 lust_u128_shl(lust_u128 a, uint32_t n) LUST_BODY({
    lust_u128 r;
    if (n >= 64) { r.lo = 0; r.hi = a.lo << (n - 64); }
    else if (n) { r.lo = a.lo << n; r.hi = (a.hi << n) | (a.lo >> (64 - n)); }
    else r = a;
    return r;
})
lust_u128 lust_u128_shr(lust_u128 a, uint32_t n) LUST_BODY({
    lust_u128 r;
    if (n >= 64) { r.lo = a.hi >> (n - 64); r.hi = 0; }
    else if (n) { r.lo = (a.lo >> n) | (a.hi << (64 - n)); r.hi = a.hi >> n; }
    else r = a;
    return r;
})
lust_i128 lust_i128_shl(lust_i128 a, uint32_t n) LUST_BODY({ return lust_i128_from_u128(lust_u128_shl(lust_u128_from_i128(a), n)); })
lust_i128 lust_i128_shr(lust_i128 a, uint32_t n) LUST_BODY({
    lust_i128 r;
    if (n >= 64) { r.lo = (uint64_t)((int64_t)a.hi >> (n - 64)); r.hi = (uint64_t)((int64_t)a.hi >> 63); }
    else if (n) { r.lo = (a.lo >> n) | (a.hi << (64 - n)); r.hi = (uint64_t)((int64_t)a.hi >> n); }
    else r = a;
    return r;
})

uint32_t lust_u128_clz32(uint32_t x) LUST_BODY({
    uint32_t n = 0;
    if (!(x >> 16)) { n += 16; x <<= 16; }
    if (!(x >> 24)) { n += 8; x <<= 8; }
    if (!(x >> 28)) { n += 4; x <<= 4; }
    if (!(x >> 30)) { n += 2; x <<= 2; }
    if (!(x >> 31)) n += 1;
    return n;
})

/* Unsigned 128/128. The caller guarantees b != 0. A one-limb divisor
   takes the schoolbook loop; wider divisors take Knuth's Algorithm D
   in base 2^32. */
lust_u128 lust_u128_divmod(lust_u128 a, lust_u128 b, lust_u128 *rem) LUST_BODY({
    if (lust_u128_cmp(a, b) < 0) {
        if (rem) *rem = a;
        lust_u128 z = {0, 0};
        return z;
    }
    uint32_t bl[4] = {(uint32_t)b.lo, (uint32_t)(b.lo >> 32), (uint32_t)b.hi, (uint32_t)(b.hi >> 32)};
    uint32_t al[4] = {(uint32_t)a.lo, (uint32_t)(a.lo >> 32), (uint32_t)a.hi, (uint32_t)(a.hi >> 32)};
    if (!bl[1] && !bl[2] && !bl[3]) {
        uint64_t d = bl[0], r = 0;
        uint32_t q[4];
        for (int i = 3; i >= 0; i--) {
            uint64_t t = (r << 32) | al[i];
            q[i] = (uint32_t)(t / d);
            r = t - (uint64_t)q[i] * d;
        }
        if (rem) { rem->lo = r; rem->hi = 0; }
        lust_u128 out;
        out.lo = (uint64_t)q[0] | ((uint64_t)q[1] << 32);
        out.hi = (uint64_t)q[2] | ((uint64_t)q[3] << 32);
        return out;
    }
    uint32_t u[5], v[4], q[4] = {0, 0, 0, 0};
    int n = bl[3] ? 4 : bl[2] ? 3 : 2;
    int m = 4;
    uint32_t s = lust_u128_clz32(bl[n - 1]);
    for (int i = n - 1; i > 0; i--) v[i] = s ? (bl[i] << s) | (bl[i - 1] >> (32 - s)) : bl[i];
    v[0] = bl[0] << s;
    u[4] = s ? al[3] >> (32 - s) : 0;
    for (int i = 3; i > 0; i--) u[i] = s ? (al[i] << s) | (al[i - 1] >> (32 - s)) : al[i];
    u[0] = al[0] << s;
    for (int j = m - n; j >= 0; j--) {
        uint64_t num = ((uint64_t)u[j + n] << 32) | u[j + n - 1];
        uint64_t qhat = num / v[n - 1];
        uint64_t rhat = num - qhat * v[n - 1];
        for (;;) {
            if (qhat > 0xFFFFFFFFull || qhat * v[n - 2] > ((rhat << 32) | u[j + n - 2])) {
                qhat--;
                rhat += v[n - 1];
                if (rhat <= 0xFFFFFFFFull) continue;
            }
            break;
        }
        int64_t borrow = 0;
        uint64_t carry = 0;
        for (int k = 0; k < n; k++) {
            uint64_t p = qhat * v[k] + carry;
            carry = p >> 32;
            int64_t t = (int64_t)u[j + k] - borrow - (int64_t)(uint32_t)p;
            u[j + k] = (uint32_t)t;
            borrow = t < 0 ? 1 : 0;
        }
        int64_t t = (int64_t)u[j + n] - borrow - (int64_t)carry;
        u[j + n] = (uint32_t)t;
        q[j] = (uint32_t)qhat;
        if (t < 0) {
            q[j]--;
            uint64_t c = 0;
            for (int k = 0; k < n; k++) {
                uint64_t sum = (uint64_t)u[j + k] + v[k] + c;
                u[j + k] = (uint32_t)sum;
                c = sum >> 32;
            }
            u[j + n] = (uint32_t)((uint64_t)u[j + n] + c);
        }
    }
    if (rem) {
        uint32_t r[4] = {0, 0, 0, 0};
        for (int i = 0; i < n; i++) r[i] = s ? (u[i] >> s) | (u[i + 1] << (32 - s)) : u[i];
        rem->lo = (uint64_t)r[0] | ((uint64_t)r[1] << 32);
        rem->hi = (uint64_t)r[2] | ((uint64_t)r[3] << 32);
    }
    lust_u128 out;
    out.lo = (uint64_t)q[0] | ((uint64_t)q[1] << 32);
    out.hi = (uint64_t)q[2] | ((uint64_t)q[3] << 32);
    return out;
})

/* 128 divided by a one-word divisor (b != 0); the format path. */
lust_u128 lust_u128_divmod64(lust_u128 a, uint64_t b, uint64_t *rem) LUST_BODY({
    lust_u128 d = {b, 0}, r;
    lust_u128 q = lust_u128_divmod(a, d, &r);
    if (rem) *rem = r.lo;
    return q;
})

lust_u128 lust_add_u128(lust_u128 a, lust_u128 b, lust_loc loc) LUST_BODY({
    lust_u128 r = lust_u128_add(a, b);
    if (lust_u128_cmp(r, a) < 0) LUST_OVF("add");
    return r;
})
lust_u128 lust_sub_u128(lust_u128 a, lust_u128 b, lust_loc loc) LUST_BODY({
    if (lust_u128_cmp(b, a) > 0) LUST_OVF("subtract");
    return lust_u128_sub(a, b);
})
lust_u128 lust_mul_u128(lust_u128 a, lust_u128 b, lust_loc loc) LUST_BODY({
    lust_u128 r = lust_u128_mul(a, b);
    if ((a.lo || a.hi) && lust_u128_cmp(lust_u128_divmod(r, a, 0), b) != 0) LUST_OVF("multiply");
    return r;
})
lust_u128 lust_div_u128(lust_u128 a, lust_u128 b, lust_loc loc) LUST_BODY({
    if (!b.lo && !b.hi) { lust_panic_cstr("attempt to divide by zero", loc); return b; }
    return lust_u128_divmod(a, b, 0);
})
lust_u128 lust_rem_u128(lust_u128 a, lust_u128 b, lust_loc loc) LUST_BODY({
    if (!b.lo && !b.hi) { lust_panic_cstr("attempt to calculate the remainder with a divisor of zero", loc); return b; }
    lust_u128 r;
    (void)lust_u128_divmod(a, b, &r);
    return r;
})

lust_u128 lust_i128_mag(lust_i128 a) LUST_BODY({
    lust_u128 u = lust_u128_from_i128(a);
    if ((int64_t)a.hi < 0) {
        lust_u128 z = {0, 0};
        return lust_u128_sub(z, u);
    }
    return u;
})

lust_i128 lust_add_i128(lust_i128 a, lust_i128 b, lust_loc loc) LUST_BODY({
    lust_i128 r = lust_i128_add(a, b);
    if (((a.hi ^ r.hi) & (b.hi ^ r.hi)) >> 63) LUST_OVF("add");
    return r;
})
lust_i128 lust_sub_i128(lust_i128 a, lust_i128 b, lust_loc loc) LUST_BODY({
    lust_i128 r = lust_i128_sub(a, b);
    if (((a.hi ^ b.hi) & (a.hi ^ r.hi)) >> 63) LUST_OVF("subtract");
    return r;
})
lust_i128 lust_neg_i128(lust_i128 a, lust_loc loc) LUST_BODY({
    if (a.lo == 0 && a.hi == 0x8000000000000000ull) LUST_OVF("negate");
    lust_i128 z = {0, 0};
    return lust_i128_sub(z, a);
})
lust_i128 lust_mul_i128(lust_i128 a, lust_i128 b, lust_loc loc) LUST_BODY({
    if ((!a.lo && !a.hi) || (!b.lo && !b.hi)) { lust_i128 z = {0, 0}; return z; }
    if (a.lo == 0 && a.hi == 0x8000000000000000ull && b.lo == 0xFFFFFFFFFFFFFFFFull && b.hi == 0xFFFFFFFFFFFFFFFFull) LUST_OVF("multiply");
    if (b.lo == 0 && b.hi == 0x8000000000000000ull && a.lo == 0xFFFFFFFFFFFFFFFFull && a.hi == 0xFFFFFFFFFFFFFFFFull) LUST_OVF("multiply");
    lust_i128 r = lust_i128_mul(a, b);
    /* Divide back, as the i64 helper does; the -1 edges are handled above. */
    lust_u128 q = lust_u128_divmod(lust_i128_mag(r), lust_i128_mag(b), 0);
    if (lust_u128_cmp(q, lust_i128_mag(a)) != 0) LUST_OVF("multiply");
    /* |a*b| <= 2^127 now; +2^127 wraps to i128::MIN, so the sign tells. */
    if (((a.hi ^ b.hi ^ r.hi) >> 63) & 1) LUST_OVF("multiply");
    return r;
})
lust_i128 lust_div_i128(lust_i128 a, lust_i128 b, lust_loc loc) LUST_BODY({
    if (!b.lo && !b.hi) { lust_panic_cstr("attempt to divide by zero", loc); return b; }
    if (a.lo == 0 && a.hi == 0x8000000000000000ull && b.lo == 0xFFFFFFFFFFFFFFFFull && b.hi == 0xFFFFFFFFFFFFFFFFull) LUST_OVF("divide");
    lust_u128 q = lust_u128_divmod(lust_i128_mag(a), lust_i128_mag(b), 0);
    if (((a.hi ^ b.hi) >> 63) & 1) {
        lust_u128 z = {0, 0};
        q = lust_u128_sub(z, q);
    }
    return lust_i128_from_u128(q);
})
lust_i128 lust_rem_i128(lust_i128 a, lust_i128 b, lust_loc loc) LUST_BODY({
    if (!b.lo && !b.hi) { lust_panic_cstr("attempt to calculate the remainder with a divisor of zero", loc); return b; }
    if (a.lo == 0 && a.hi == 0x8000000000000000ull && b.lo == 0xFFFFFFFFFFFFFFFFull && b.hi == 0xFFFFFFFFFFFFFFFFull) LUST_OVF("calculate the remainder");
    lust_u128 r;
    (void)lust_u128_divmod(lust_i128_mag(a), lust_i128_mag(b), &r);
    if ((int64_t)a.hi < 0) {
        lust_u128 z = {0, 0};
        r = lust_u128_sub(z, r);
    }
    return lust_i128_from_u128(r);
})

lust_i128 lust_abs_i128(lust_i128 a, lust_loc loc) LUST_BODY({ return (int64_t)a.hi < 0 ? lust_neg_i128(a, loc) : a; })
lust_u128 lust_pow_u128(lust_u128 a, uint32_t e, lust_loc loc) LUST_BODY({
    lust_u128 r = {1, 0};
    while (e) { if (e & 1) r = lust_mul_u128(r, a, loc); e >>= 1; if (e) a = lust_mul_u128(a, a, loc); }
    return r;
})
lust_i128 lust_pow_i128(lust_i128 a, uint32_t e, lust_loc loc) LUST_BODY({
    lust_i128 r = {1, 0};
    while (e) { if (e & 1) r = lust_mul_i128(r, a, loc); e >>= 1; if (e) a = lust_mul_i128(a, a, loc); }
    return r;
})
/* `abs` and `pow` with overflow checks off (release builds): they wrap. */
lust_i128 lust_wrapping_abs_i128(lust_i128 a) LUST_BODY({ lust_i128 z = {0, 0}; return (int64_t)a.hi < 0 ? lust_i128_sub(z, a) : a; })
lust_u128 lust_wrapping_pow_u128(lust_u128 a, uint32_t e) LUST_BODY({
    lust_u128 r = {1, 0};
    while (e) { if (e & 1) r = lust_u128_mul(r, a); e >>= 1; if (e) a = lust_u128_mul(a, a); }
    return r;
})
lust_i128 lust_wrapping_pow_i128(lust_i128 a, uint32_t e) LUST_BODY({
    lust_i128 r = {1, 0};
    while (e) { if (e & 1) r = lust_i128_mul(r, a); e >>= 1; if (e) a = lust_i128_mul(a, a); }
    return r;
})

/* Decimal format: split by 10^19, the largest power of ten in a word. */
void lust_fmt_u128(lust_String *out, lust_u128 v) LUST_BODY({
    if (!v.hi) { lust_fmt_u64(out, v.lo); return; }
    uint64_t chunks[3];
    int n = 0;
    while (v.lo || v.hi) {
        uint64_t r;
        v = lust_u128_divmod64(v, 10000000000000000000ull, &r);
        chunks[n++] = r;
    }
    lust_fmt_u64(out, chunks[--n]);
    char b[24];
    while (n > 0) {
        snprintf(b, sizeof b, "%019llu", (unsigned long long)chunks[--n]);
        lust_string_push_cstr(out, b);
    }
})
void lust_fmt_i128(lust_String *out, lust_i128 v) LUST_BODY({
    if ((int64_t)v.hi < 0) {
        lust_string_push_bytes(out, "-", 1);
        lust_fmt_u128(out, lust_i128_mag(v));
    } else {
        lust_fmt_u128(out, lust_u128_from_i128(v));
    }
})

/* Integer formatting with a format spec, as Rust renders it. `lo` and
   `hi` are the magnitude (already negated by the caller for decimal,
   raw two's-complement bits truncated to the type width for the radix
   modes, with `negative` clear). Modes: 0 decimal, 1 lower hex,
   2 upper hex, 3 octal, 4 binary. `align` is '<', '>', or '^', and
   0 for the numeric default (right). Precision is a minimum digit
   count; zero padding fills after the sign and radix prefix and is
   ignored when a precision is given, as in Rust. */
void lust_fmt_int_spec(lust_String *out, uint64_t lo, uint64_t hi, int negative, int mode, int plus, int alt, int zero_pad, uint32_t width, uint32_t fill, int align, int has_prec, uint32_t prec) LUST_BODY({
    static const char lo_digits[] = "0123456789abcdef";
    static const char up_digits[] = "0123456789ABCDEF";
    const char *digs = mode == 2 ? up_digits : lo_digits;
    uint64_t base = mode == 1 || mode == 2 ? 16 : mode == 3 ? 8 : mode == 4 ? 2 : 10;
    char rev[130];
    int nd = 0;
    lust_u128 v;
    v.lo = lo;
    v.hi = hi;
    if (!v.lo && !v.hi) {
        rev[nd++] = '0';
    } else {
        while (v.lo || v.hi) {
            uint64_t r;
            v = lust_u128_divmod64(v, base, &r);
            rev[nd++] = digs[r];
        }
    }
    const char *prefix = "";
    if (alt) prefix = mode == 1 ? "0x" : mode == 2 ? "0X" : mode == 3 ? "0o" : mode == 4 ? "0b" : "";
    uint64_t prefix_len = 0;
    while (prefix[prefix_len]) prefix_len++;
    int sign = negative ? '-' : plus ? '+' : 0;
    /* Precision is ignored for integers in Rust (it neither pads
       digits nor disables the zero flag). */
    uint32_t lead = 0;
    (void)has_prec; (void)prec;
    uint32_t total = (sign ? 1 : 0) + (uint32_t)prefix_len + lead + (uint32_t)nd;
    uint32_t zeros = 0;
    uint32_t left = 0, right = 0;
    if (zero_pad && total < width) {
        zeros = width - total;
        total = width;
    } else if (total < width) {
        uint32_t pad = width - total;
        if (align == '<') right = pad;
        else if (align == '^') { left = pad / 2; right = pad - left; }
        else left = pad;
    }
    uint32_t fill_cp = fill ? fill : ' ';
    for (uint32_t k = 0; k < left; k++) lust_string_push_char(out, fill_cp);
    if (sign) { char sc = (char)sign; lust_string_push_bytes(out, &sc, 1); }
    if (prefix_len) lust_string_push_bytes(out, prefix, prefix_len);
    for (uint32_t k = 0; k < zeros + lead; k++) lust_string_push_bytes(out, "0", 1);
    for (int k = nd - 1; k >= 0; k--) lust_string_push_bytes(out, &rev[k], 1);
    for (uint32_t k = 0; k < right; k++) lust_string_push_char(out, fill_cp);
})

/* The char count of a UTF-8 string view (non-continuation bytes). */
uint64_t lust_str_char_count(lust_str s) LUST_BODY({
    uint64_t n = 0;
    for (uint64_t i = 0; i < s.len; i++) if ((s.ptr[i] & 0xC0) != 0x80) n++;
    return n;
})

/* Appends `body` padded with `fill` to `width` chars: align '<'
   pads right, '^' centers (the larger half goes right, as in
   Rust), and anything else pads left. */
void lust_fmt_pad(lust_String *out, lust_str body, uint32_t width, uint32_t fill, int align) LUST_BODY({
    uint64_t count = lust_str_char_count(body);
    if (count >= width) { lust_string_push_str(out, body); return; }
    uint32_t pad = width - (uint32_t)count;
    uint32_t left = 0, right = 0;
    if (align == '<') right = pad;
    else if (align == '^') { left = pad / 2; right = pad - left; }
    else left = pad;
    uint32_t fill_cp = fill ? fill : ' ';
    for (uint32_t k = 0; k < left; k++) lust_string_push_char(out, fill_cp);
    lust_string_push_str(out, body);
    for (uint32_t k = 0; k < right; k++) lust_string_push_char(out, fill_cp);
})

/* Truncates a string to at most `chars` Unicode scalar values,
   cutting on a char boundary (a format precision for strings). */
void lust_str_trunc_chars(lust_String *s, uint32_t chars) LUST_BODY({
    uint32_t seen = 0;
    for (uint64_t i = 0; i < s->len; i++) {
        if ((s->ptr[i] & 0xC0) != 0x80) {
            if (seen == chars) { s->len = i; return; }
            seen++;
        }
    }
})

/* ---------- Vec insert/remove ---------- */

void lust_vec_insert_at(lust_Vec *v, uint64_t i, uint64_t elem, uint64_t align, lust_loc loc) LUST_BODY({
    if (i > v->len) {
        lust_String s = lust_string_new();
        lust_string_push_cstr(&s, "insertion index (is ");
        lust_fmt_u64(&s, i);
        lust_string_push_cstr(&s, ") should be <= len (is ");
        lust_fmt_u64(&s, v->len);
        lust_string_push_cstr(&s, ")");
        lust_panic_dyn(&s, loc);
        return;
    }
    lust_vec_reserve(v, 1, elem, align);
    lust_copy_small((char *)v->ptr + (i + 1) * elem, (char *)v->ptr + i * elem, (v->len - i) * elem);
    v->len++;
})

void lust_vec_check_remove(lust_Vec *v, uint64_t i, lust_loc loc) LUST_BODY({
    if (i >= v->len) {
        lust_String s = lust_string_new();
        lust_string_push_cstr(&s, "removal index (is ");
        lust_fmt_u64(&s, i);
        lust_string_push_cstr(&s, ") should be < len (is ");
        lust_fmt_u64(&s, v->len);
        lust_string_push_cstr(&s, ")");
        lust_panic_dyn(&s, loc);
    }
})

void lust_vec_remove_at(lust_Vec *v, uint64_t i, uint64_t elem) LUST_BODY({
    lust_copy_small((char *)v->ptr + i * elem, (char *)v->ptr + (i + 1) * elem, (v->len - i - 1) * elem);
    v->len--;
})

/* ---------- str ---------- */

uint8_t lust_str_starts_with(lust_str s, lust_str p) LUST_BODY({ return p.len <= s.len && (p.len == 0 || memcmp(s.ptr, p.ptr, p.len) == 0); })
uint8_t lust_str_ends_with(lust_str s, lust_str p) LUST_BODY({ return p.len <= s.len && (p.len == 0 || memcmp(s.ptr + s.len - p.len, p.ptr, p.len) == 0); })
/* str::contains and str::find with a &str pattern are lust_memmem (deps.c, declared here
   ahead of deps.h): its SSE2 path tries 16 starts at a time and gives the leftmost match, and
   0 for an empty pattern. */
uint64_t lust_memmem(const uint8_t *h, uint64_t hlen, const uint8_t *n, uint64_t nlen);
uint8_t lust_str_contains(lust_str s, lust_str p) LUST_BODY({ return lust_memmem(s.ptr, s.len, p.ptr, p.len) != UINT64_MAX; })

/* The byte index of the first (or last) match of `p` in `s`, or -1.
   An empty pattern matches at 0 for find and at s.len for rfind, as
   Rust's str::find and str::rfind do. A match of a UTF-8 pattern in
   a valid UTF-8 haystack always starts on a char boundary. */
int64_t lust_str_find(lust_str s, lust_str p) LUST_BODY({
    uint64_t i = lust_memmem(s.ptr, s.len, p.ptr, p.len);
    return i == UINT64_MAX ? -1 : (int64_t)i;
})
int64_t lust_str_rfind(lust_str s, lust_str p) LUST_BODY({
    if (p.len == 0) return (int64_t)s.len;
    if (p.len > s.len) return -1;
    for (uint64_t i = s.len - p.len;; i--) {
        if (s.ptr[i] == p.ptr[0] && memcmp(s.ptr + i, p.ptr, p.len) == 0) return (int64_t)i;
        if (i == 0) return -1;
    }
})

/* Unicode White_Space, as used by Rust's char::is_whitespace and the
   str trim methods. The table is generated (unicode_table.h). */
int lust_is_space(uint32_t c) LUST_BODY({ return LUST_UNI_IN(lust_uni_whitespace_ranges, c); })

/* Unicode char predicates over the generated range tables.
   is_alphanumeric is is_alphabetic || is_numeric: the generator
   asserts that identity for every scalar before it writes the table. */
int lust_char_is_alphabetic(uint32_t c) LUST_BODY({ return LUST_UNI_IN(lust_uni_alphabetic_ranges, c); })
int lust_char_is_numeric(uint32_t c) LUST_BODY({ return LUST_UNI_IN(lust_uni_numeric_ranges, c); })
int lust_char_is_alphanumeric(uint32_t c) LUST_BODY({
    return LUST_UNI_IN(lust_uni_alphabetic_ranges, c) || LUST_UNI_IN(lust_uni_numeric_ranges, c);
})
int lust_char_is_lowercase(uint32_t c) LUST_BODY({ return LUST_UNI_IN(lust_uni_lowercase_ranges, c); })
int lust_char_is_uppercase(uint32_t c) LUST_BODY({ return LUST_UNI_IN(lust_uni_uppercase_ranges, c); })
int lust_char_is_control(uint32_t c) LUST_BODY({ return LUST_UNI_IN(lust_uni_control_ranges, c); })

lust_str lust_str_trim_start(lust_str s) LUST_BODY({
    uint64_t a = 0;
    while (a < s.len) { uint64_t j = a; if (!lust_is_space(lust_utf8_next(s.ptr, &j))) break; a = j; }
    lust_str r; r.ptr = s.ptr + a; r.len = s.len - a;
    return r;
})

lust_str lust_str_trim_end(lust_str s) LUST_BODY({
    uint64_t b = s.len;
    while (b > 0) {
        uint64_t k = b - 1;
        while (k > 0 && (s.ptr[k] & 0xC0) == 0x80) k--;
        uint64_t j = k;
        if (!lust_is_space(lust_utf8_next(s.ptr, &j))) break;
        b = k;
    }
    lust_str r; r.ptr = s.ptr; r.len = b;
    return r;
})

/* Rust's `str::replace` for a `&str` pattern, capacities included:
   a one-byte pattern and one-byte `to` collect into exactly `s.len`;
   else the result starts at `s.len` when the pattern is no longer
   than `to` (0 otherwise) and grows by push_str of each piece
   (segment, `to`, ..., tail), with no exact or no-match fast path. */
/* `str::replacen(from, to, count)`: alloc's form, a String of capacity
   32 grown by `push_str`, the first `count` non-overlapping matches left
   to right replaced (an empty `from` matches at every char boundary,
   both ends included). */
lust_String lust_str_replacen(lust_str s, lust_str from, lust_str to, uint64_t count) LUST_BODY({
    lust_String r = lust_string_with_capacity(32);
    uint64_t last = 0, done = 0;
    if (from.len == 0) {
        uint64_t i = 0;
        while (done < count) {
            lust_string_push_bytes(&r, s.ptr + last, i - last);
            lust_string_push_str(&r, to);
            last = i;
            done++;
            if (i >= s.len) break;
            lust_utf8_next(s.ptr, &i);
        }
    } else {
        for (uint64_t i = 0; done < count && i + from.len <= s.len;) {
            if (s.ptr[i] == from.ptr[0] && memcmp(s.ptr + i, from.ptr, from.len) == 0) {
                lust_string_push_bytes(&r, s.ptr + last, i - last);
                lust_string_push_str(&r, to);
                i += from.len;
                last = i;
                done++;
            } else {
                i++;
            }
        }
    }
    lust_string_push_bytes(&r, s.ptr + last, s.len - last);
    return r;
})

lust_String lust_str_replace(lust_str s, lust_str from, lust_str to) LUST_BODY({
    if (from.len == 1 && to.len == 1) {
        lust_String r = lust_string_with_capacity(s.len);
        for (uint64_t i = 0; i < s.len; i++) r.ptr[i] = s.ptr[i] == from.ptr[0] ? to.ptr[0] : s.ptr[i];
        r.len = s.len;
        return r;
    }
    lust_String r = lust_string_with_capacity(from.len <= to.len ? s.len : 0);
    if (from.len == 0) {
        /* A match at every char boundary, both ends included: the
           pieces are `to`, then one char and `to` per char. */
        lust_string_push_str(&r, to);
        uint64_t i = 0;
        while (i < s.len) {
            uint64_t j = i;
            lust_utf8_next(s.ptr, &j);
            lust_string_push_bytes(&r, s.ptr + i, j - i);
            lust_string_push_str(&r, to);
            i = j;
        }
        return r;
    }
    uint64_t last = 0;
    for (uint64_t i = 0; i + from.len <= s.len;) {
        if (s.ptr[i] == from.ptr[0] && memcmp(s.ptr + i, from.ptr, from.len) == 0) {
            lust_string_push_bytes(&r, s.ptr + last, i - last);
            lust_string_push_str(&r, to);
            i += from.len;
            last = i;
        } else i++;
    }
    lust_string_push_bytes(&r, s.ptr + last, s.len - last);
    return r;
})

lust_String lust_str_repeat(lust_str s, uint64_t n, lust_loc loc) LUST_BODY({
    /* `checked_mul(n).expect(..)` in alloc's slice.rs, then RawVec's
       isize::MAX byte limit. */
    (void)loc;
    if (s.len && n > UINT64_MAX / s.len) { lust_panic_std("capacity overflow", "alloc/src/slice.rs:524:50"); return lust_string_new(); }
    uint64_t total = s.len * n;
    if (total > (uint64_t)9223372036854775807ull) { lust_vec_capacity_overflow(); return lust_string_new(); }
    lust_String r = lust_string_with_capacity(total);
    for (uint64_t i = 0; i < n; i++) { memcpy(r.ptr + r.len, s.ptr, s.len); r.len += s.len; }
    return r;
})

void lust_string_shrink_to(lust_String *s, uint64_t min_cap) LUST_BODY({
    uint64_t target = min_cap > s->len ? min_cap : s->len;
    if (s->cap <= target) return;
    if (!target) {
        free(s->ptr);
        s->ptr = (uint8_t *)(uintptr_t)1;
        s->cap = 0;
        return;
    }
    s->ptr = lust_realloc(s->ptr, s->cap, 1, target);
    s->cap = target;
})

/* The byte offset where the char at byte `end` starts searching
   backward; `end` is one past that char and must be > 0. */
static uint64_t lust_str_prev_start(const uint8_t *p, uint64_t end) {
    uint64_t k = end - 1;
    while (k > 0 && (p[k] & 0xC0) == 0x80) k--;
    return k;
}

uint32_t lust_string_pop(lust_String *s) LUST_BODY({
    uint64_t k = lust_str_prev_start(s->ptr, s->len);
    uint64_t j = k;
    uint32_t c = lust_utf8_next(s->ptr, &j);
    s->len = k;
    return c;
})

/* Rust's `assert!(self.is_char_boundary(<what>))` in String methods. */
static void lust_string_check_boundary(lust_String *s, uint64_t idx, const char *what, lust_loc loc) {
    if (idx > s->len || (idx < s->len && (s->ptr[idx] & 0xC0) == 0x80)) {
        lust_String m = lust_string_new();
        lust_string_push_cstr(&m, "assertion failed: self.is_char_boundary(");
        lust_string_push_cstr(&m, what);
        lust_string_push_cstr(&m, ")");
        lust_panic(&m, loc);
    }
}

/* String::remove slices `self[idx..]` first, so it panics as that slice does. */
uint32_t lust_string_remove(lust_String *s, uint64_t idx, lust_loc loc) LUST_BODY({
    (void)lust_str_range(s->ptr, idx, s->len, 0, s->len, loc);
    if (lust_unwind_mode && lust_unw_mine()) return 0;
    if (idx == s->len) { lust_panic_cstr("cannot remove a char from the end of a string", loc); return 0; }
    uint64_t j = idx;
    uint32_t c = lust_utf8_next(s->ptr, &j);
    memmove(s->ptr + idx, s->ptr + j, s->len - j);
    s->len -= j - idx;
    return c;
})

void lust_string_insert_bytes(lust_String *s, uint64_t idx, const uint8_t *p, uint64_t n, lust_loc loc) LUST_BODY({
    lust_string_check_boundary(s, idx, "idx", loc);
    if (lust_unwind_mode && lust_unw_mine()) return;
    /* Copy the inserted bytes first: they may view this String. */
    uint8_t small[4];
    uint8_t *tmp = small;
    if (n > sizeof small) { tmp = lust_alloc(n, 1); }
    memcpy(tmp, p, n);
    lust_string_reserve(s, n);
    memmove(s->ptr + idx + n, s->ptr + idx, s->len - idx);
    memcpy(s->ptr + idx, tmp, n);
    if (tmp != small) free(tmp);
    s->len += n;
})

void lust_string_insert_char(lust_String *s, uint64_t idx, uint32_t c, lust_loc loc) LUST_BODY({
    uint8_t b[4];
    int n;
    if (c < 0x80) { b[0] = c; n = 1; }
    else if (c < 0x800) { b[0] = 0xC0 | (c >> 6); b[1] = 0x80 | (c & 0x3F); n = 2; }
    else if (c < 0x10000) { b[0] = 0xE0 | (c >> 12); b[1] = 0x80 | ((c >> 6) & 0x3F); b[2] = 0x80 | (c & 0x3F); n = 3; }
    else { b[0] = 0xF0 | (c >> 18); b[1] = 0x80 | ((c >> 12) & 0x3F); b[2] = 0x80 | ((c >> 6) & 0x3F); b[3] = 0x80 | (c & 0x3F); n = 4; }
    lust_string_insert_bytes(s, idx, b, (uint64_t)n, loc);
})

void lust_string_truncate(lust_String *s, uint64_t n, lust_loc loc) LUST_BODY({
    if (n < s->len) {
        lust_string_check_boundary(s, n, "new_len", loc);
        if (lust_unwind_mode && lust_unw_mine()) return;
        s->len = n;
    }
})

lust_String lust_string_split_off(lust_String *s, uint64_t at, lust_loc loc) LUST_BODY({
    lust_string_check_boundary(s, at, "at", loc);
    if (lust_unwind_mode && lust_unw_mine()) return lust_string_new();
    lust_String r = lust_string_with_capacity(s->len - at);
    memcpy(r.ptr, s->ptr + at, s->len - at);
    r.len = s->len - at;
    s->len = at;
    return r;
})

lust_str lust_str_trim(lust_str s) LUST_BODY({
    uint64_t a = 0, b = s.len;
    while (a < b) { uint64_t j = a; if (!lust_is_space(lust_utf8_next(s.ptr, &j))) break; a = j; }
    while (b > a) {
        uint64_t k = b - 1;
        while (k > a && (s.ptr[k] & 0xC0) == 0x80) k--;
        uint64_t j = k;
        if (!lust_is_space(lust_utf8_next(s.ptr, &j))) break;
        b = k;
    }
    lust_str r; r.ptr = s.ptr + a; r.len = b - a;
    return r;
})

/* ASCII case mapping. Non-ASCII characters are copied unchanged (Rust maps them too). */
lust_String lust_str_ascii_case(lust_str s, int upper) LUST_BODY({
    lust_String r = lust_string_from(s);
    for (uint64_t i = 0; i < r.len; i++) {
        uint8_t c = r.ptr[i];
        if (upper && c >= 'a' && c <= 'z') r.ptr[i] = c - 32;
        if (!upper && c >= 'A' && c <= 'Z') r.ptr[i] = c + 32;
    }
    return r;
})

typedef struct { lust_str s; uint64_t pos; } lust_Chars;
lust_Chars lust_chars(lust_str s) LUST_BODY({ lust_Chars c; c.s = s; c.pos = 0; return c; })
uint64_t lust_chars_count(lust_Chars c) LUST_BODY({
    uint64_t n = 0;
    while (c.pos < c.s.len) { lust_utf8_next(c.s.ptr, &c.pos); n++; }
    return n;
})
/* The char that ends at `*end` (`Chars::next_back`): back over the
   continuation bytes, decode forward, and leave `*end` at its start. */
uint32_t lust_utf8_prev(const uint8_t *p, uint64_t *end) LUST_BODY({
    uint64_t i = *end - 1;
    while (i > 0 && (p[i] & 0xC0) == 0x80) i--;
    uint64_t j = i;
    uint32_t c = lust_utf8_next(p, &j);
    *end = i;
    return c;
})

/* The str split family (W-STD-B): std's SplitInternal and SplitNInternal
   over its searchers (CharSearcher, MultiCharEqSearcher for char sets and
   predicates, StrSearcher with its EmptyNeedle form). `lust_split` is the
   common start of the generated iterator struct (ty/iter.rs StrSplit):
   the haystack, the part not yet yielded (start..end), the searcher's
   front and back positions, flags, and a SplitN count. `lust_pat` names
   the pattern for one step. Modes follow ty/iter.rs SplitMode. */
typedef struct { lust_str hay; uint64_t start, end, fpos, bpos, flags, count; } lust_split;
typedef struct {
    uint8_t kind;
    uint32_t ch;
    lust_str needle;
    const uint32_t *set;
    uint64_t n;
    uint8_t (*pred)(void *, uint32_t);
    void *env;
} lust_pat;
enum { LUST_PAT_CHAR, LUST_PAT_STR, LUST_PAT_SET, LUST_PAT_PRED, LUST_PAT_SPACE, LUST_PAT_ASCII_SPACE };
enum { LUST_SPLIT_FINISHED = 1, LUST_SPLIT_TRAILING = 2, LUST_SPLIT_MATCH_FW = 4, LUST_SPLIT_MATCH_BW = 8, LUST_SPLIT_EMPTY_DONE = 16 };

/* One char against a char-at-a-time pattern (each predicate call once,
   in scan order, as MultiCharEqSearcher). */
int lust_pat_hit(const lust_pat *p, uint32_t c) LUST_BODY({
    switch (p->kind) {
    case LUST_PAT_CHAR: return c == p->ch;
    case LUST_PAT_SET:
        for (uint64_t i = 0; i < p->n; i++)
            if (p->set[i] == c) return 1;
        return 0;
    case LUST_PAT_PRED: return p->pred(p->env, c) != 0;
    case LUST_PAT_SPACE: return lust_is_space(c);
    default: return c == ' ' || c == '\t' || c == '\n' || c == 0x0C || c == '\r';
    }
})

/* next_match: the next match in fpos..bpos from the front (the empty
   needle walks from fpos to the haystack's end, as std). */
int lust_split_match_fw(lust_split *s, const lust_pat *p, uint64_t *a, uint64_t *b) LUST_BODY({
    const uint8_t *h = s->hay.ptr;
    if (p->kind == LUST_PAT_STR) {
        uint64_t m = p->needle.len;
        if (m == 0) {
            for (;;) {
                if (s->flags & LUST_SPLIT_EMPTY_DONE) return 0;
                int hit = (s->flags & LUST_SPLIT_MATCH_FW) != 0;
                s->flags ^= LUST_SPLIT_MATCH_FW;
                uint64_t pos = s->fpos;
                if (hit) { *a = pos; *b = pos; return 1; }
                if (pos >= s->hay.len) { s->flags |= LUST_SPLIT_EMPTY_DONE; return 0; }
                lust_utf8_next(h, &s->fpos);
            }
        }
        for (uint64_t i = s->fpos; i + m <= s->bpos; i++) {
            if (memcmp(h + i, p->needle.ptr, m) == 0) { *a = i; *b = i + m; s->fpos = i + m; return 1; }
        }
        s->fpos = s->bpos;
        return 0;
    }
    while (s->fpos < s->bpos) {
        uint64_t i = s->fpos;
        uint32_t c = lust_utf8_next(h, &s->fpos);
        if (lust_pat_hit(p, c)) { *a = i; *b = s->fpos; return 1; }
    }
    return 0;
})

/* next_match_back: the last match in fpos..bpos (the empty needle walks
   from bpos to the haystack's start, as std). */
int lust_split_match_bw(lust_split *s, const lust_pat *p, uint64_t *a, uint64_t *b) LUST_BODY({
    const uint8_t *h = s->hay.ptr;
    if (p->kind == LUST_PAT_STR) {
        uint64_t m = p->needle.len;
        if (m == 0) {
            for (;;) {
                if (s->flags & LUST_SPLIT_EMPTY_DONE) return 0;
                int hit = (s->flags & LUST_SPLIT_MATCH_BW) != 0;
                s->flags ^= LUST_SPLIT_MATCH_BW;
                uint64_t end = s->bpos;
                if (hit) { *a = end; *b = end; return 1; }
                if (end == 0) { s->flags |= LUST_SPLIT_EMPTY_DONE; return 0; }
                lust_utf8_prev(h, &s->bpos);
            }
        }
        for (uint64_t j = s->bpos; j >= s->fpos + m && j >= m; j--) {
            if (memcmp(h + j - m, p->needle.ptr, m) == 0) { *a = j - m; *b = j; s->bpos = j - m; return 1; }
            if (j == 0) break;
        }
        s->bpos = s->fpos;
        return 0;
    }
    while (s->bpos > s->fpos) {
        uint64_t j = s->bpos;
        uint32_t c = lust_utf8_prev(h, &s->bpos);
        if (lust_pat_hit(p, c)) { *a = s->bpos; *b = j; return 1; }
    }
    return 0;
})

lust_str lust_split_sub(lust_str h, uint64_t a, uint64_t b) LUST_BODY({ lust_str r; r.ptr = h.ptr + a; r.len = b - a; return r; })

/* SplitInternal::get_end. */
int lust_split_get_end(lust_split *s, lust_str *out) LUST_BODY({
    if (s->flags & LUST_SPLIT_FINISHED) return 0;
    s->flags |= LUST_SPLIT_FINISHED;
    if ((s->flags & LUST_SPLIT_TRAILING) || s->end > s->start) { *out = lust_split_sub(s->hay, s->start, s->end); return 1; }
    return 0;
})

/* SplitInternal::next, and next_inclusive when `incl`. */
int lust_split_fw(lust_split *s, const lust_pat *p, int incl, lust_str *out) LUST_BODY({
    if (s->flags & LUST_SPLIT_FINISHED) return 0;
    uint64_t a, b;
    if (lust_split_match_fw(s, p, &a, &b)) {
        *out = lust_split_sub(s->hay, s->start, incl ? b : a);
        s->start = b;
        return 1;
    }
    return lust_split_get_end(s, out);
})

/* SplitInternal::next_back, and next_back_inclusive when `incl`. */
int lust_split_bw(lust_split *s, const lust_pat *p, int incl, lust_str *out) LUST_BODY({
    if (s->flags & LUST_SPLIT_FINISHED) return 0;
    if (!(s->flags & LUST_SPLIT_TRAILING)) {
        s->flags |= LUST_SPLIT_TRAILING;
        lust_str e;
        if (lust_split_bw(s, p, incl, &e) && e.len > 0) { *out = e; return 1; }
        if (s->flags & LUST_SPLIT_FINISHED) return 0;
    }
    uint64_t a, b;
    if (lust_split_match_bw(s, p, &a, &b)) {
        *out = lust_split_sub(s->hay, b, s->end);
        s->end = incl ? b : a;
        return 1;
    }
    s->flags |= LUST_SPLIT_FINISHED;
    *out = lust_split_sub(s->hay, s->start, s->end);
    return 1;
})

/* One `next` (`next_back` when `back`) of a split iterator in `mode`. */
int lust_split_step(lust_split *s, const lust_pat *p, uint8_t mode, int back, lust_str *out) LUST_BODY({
    switch (mode) {
    case 0: case 2: return back ? lust_split_bw(s, p, 0, out) : lust_split_fw(s, p, 0, out);
    case 1: case 3: return back ? lust_split_fw(s, p, 0, out) : lust_split_bw(s, p, 0, out);
    case 4: case 5:
        if (s->count == 0) return 0;
        if (s->count == 1) { s->count = 0; return lust_split_get_end(s, out); }
        s->count--;
        return mode == 4 ? lust_split_fw(s, p, 0, out) : lust_split_bw(s, p, 0, out);
    case 6: return back ? lust_split_bw(s, p, 1, out) : lust_split_fw(s, p, 1, out);
    case 7: case 8:
        for (;;) {
            int got = back ? lust_split_bw(s, p, 0, out) : lust_split_fw(s, p, 0, out);
            if (!got) return 0;
            if (out->len > 0) return 1;
        }
    default: {
        int got = back ? lust_split_bw(s, p, 1, out) : lust_split_fw(s, p, 1, out);
        if (got && out->len > 0 && out->ptr[out->len - 1] == '\n') {
            out->len--;
            if (out->len > 0 && out->ptr[out->len - 1] == '\r') out->len--;
        }
        return got;
    }
    }
})

/* `split_ascii_whitespace`'s upper bound (slice::Split's, through the
   filter): 0 once finished, else the bytes left plus one. */
uint64_t lust_split_upper(const lust_split *s) LUST_BODY({ return (s->flags & LUST_SPLIT_FINISHED) ? 0 : s->end - s->start + 1; })

/* `split_once` (`rsplit_once` when `back`): the first (last) match. */
int lust_str_split_once(lust_str hay, const lust_pat *p, int back, lust_str *a, lust_str *b) LUST_BODY({
    lust_split s;
    s.hay = hay; s.start = 0; s.end = hay.len; s.fpos = 0; s.bpos = hay.len;
    s.flags = LUST_SPLIT_MATCH_FW | LUST_SPLIT_MATCH_BW; s.count = 0;
    uint64_t x, y;
    if (!(back ? lust_split_match_bw(&s, p, &x, &y) : lust_split_match_fw(&s, p, &x, &y))) return 0;
    *a = lust_split_sub(hay, 0, x);
    *b = lust_split_sub(hay, y, hay.len);
    return 1;
})

/* The str search and trim methods over a `lust_pat` (tf-str), on the
   split family's searchers so predicate calls run once per char in
   scan order, as std's do. A char-at-a-time pattern matches single
   chars; a string needle matches its bytes (only on char boundaries,
   as both texts are valid UTF-8). */

/* One match of `p` in `hay`, the first (or last, when `back`). */
int lust_pat_match(lust_str hay, const lust_pat *p, int back, uint64_t *a, uint64_t *b) LUST_BODY({
    lust_split s;
    s.hay = hay; s.start = 0; s.end = hay.len; s.fpos = 0; s.bpos = hay.len;
    s.flags = LUST_SPLIT_MATCH_FW | LUST_SPLIT_MATCH_BW; s.count = 0;
    return back ? lust_split_match_bw(&s, p, a, b) : lust_split_match_fw(&s, p, a, b);
})

/* A match at the start of `hay`, with its end: the needle as a
   prefix, or the first char against a char-at-a-time pattern. */
int lust_pat_prefix(lust_str hay, const lust_pat *p, uint64_t *end) LUST_BODY({
    if (p->kind == LUST_PAT_STR) {
        *end = p->needle.len;
        return p->needle.len <= hay.len && (p->needle.len == 0 || memcmp(hay.ptr, p->needle.ptr, p->needle.len) == 0);
    }
    if (hay.len == 0) return 0;
    uint64_t j = 0;
    uint32_t c = lust_utf8_next(hay.ptr, &j);
    if (!lust_pat_hit(p, c)) return 0;
    *end = j;
    return 1;
})

/* A match at the end of `hay`, with its start. */
int lust_pat_suffix(lust_str hay, const lust_pat *p, uint64_t *start) LUST_BODY({
    if (p->kind == LUST_PAT_STR) {
        if (p->needle.len > hay.len) return 0;
        *start = hay.len - p->needle.len;
        return p->needle.len == 0 || memcmp(hay.ptr + *start, p->needle.ptr, p->needle.len) == 0;
    }
    if (hay.len == 0) return 0;
    uint64_t e = hay.len;
    uint32_t c = lust_utf8_prev(hay.ptr, &e);
    if (!lust_pat_hit(p, c)) return 0;
    *start = e;
    return 1;
})

/* `trim_start_matches`: for a needle, strip it as a prefix while it
   is one (an empty needle changes nothing); else strip matching
   chars from the front. */
lust_str lust_pat_trim_start(lust_str hay, const lust_pat *p) LUST_BODY({
    uint64_t a = 0;
    if (p->kind == LUST_PAT_STR) {
        uint64_t m = p->needle.len;
        while (m > 0 && a + m <= hay.len && memcmp(hay.ptr + a, p->needle.ptr, m) == 0) a += m;
    } else {
        while (a < hay.len) {
            uint64_t j = a;
            if (!lust_pat_hit(p, lust_utf8_next(hay.ptr, &j))) break;
            a = j;
        }
    }
    return lust_split_sub(hay, a, hay.len);
})

/* `trim_end_matches`, from the back. */
lust_str lust_pat_trim_end(lust_str hay, const lust_pat *p) LUST_BODY({
    uint64_t b = hay.len;
    if (p->kind == LUST_PAT_STR) {
        uint64_t m = p->needle.len;
        while (m > 0 && b >= m && memcmp(hay.ptr + b - m, p->needle.ptr, m) == 0) b -= m;
    } else {
        while (b > 0) {
            uint64_t e = b;
            if (!lust_pat_hit(p, lust_utf8_prev(hay.ptr, &e))) break;
            b = e;
        }
    }
    return lust_split_sub(hay, 0, b);
})

/* One `next` (`next_back` when `back`) of a matches iterator: the
   match's start index and text. The state is a `lust_split` whose
   start and end stay 0 and hay.len. */
int lust_matches_step(lust_split *s, const lust_pat *p, int back, uint64_t *idx, lust_str *out) LUST_BODY({
    uint64_t a, b;
    if (!(back ? lust_split_match_bw(s, p, &a, &b) : lust_split_match_fw(s, p, &a, &b))) return 0;
    *idx = a;
    *out = lust_split_sub(s->hay, a, b);
    return 1;
})

/* `str::replace` / `replacen` over a char set or predicate pattern:
   alloc's loop over `match_indices(pat).take(count)` into a String of
   capacity `cap` (0 for `replace`, whose pattern has no UTF-8 form; 32
   for `replacen`). The searcher stops after `count` matches, so a
   predicate sees no char past the last replaced match. */
lust_String lust_pat_replacen(lust_str hay, const lust_pat *p, lust_str to, uint64_t count, uint64_t cap) LUST_BODY({
    lust_String r = lust_string_with_capacity(cap);
    lust_split s;
    s.hay = hay; s.start = 0; s.end = hay.len; s.fpos = 0; s.bpos = hay.len;
    s.flags = LUST_SPLIT_MATCH_FW | LUST_SPLIT_MATCH_BW; s.count = 0;
    uint64_t last = 0, done = 0, a, b;
    while (done < count && lust_split_match_fw(&s, p, &a, &b)) {
        lust_string_push_bytes(&r, hay.ptr + last, a - last);
        lust_string_push_str(&r, to);
        last = b;
        done++;
    }
    lust_string_push_bytes(&r, hay.ptr + last, hay.len - last);
    return r;
})

/* The primitive `FromStr` parsers (tf-str), core's semantics.
   Int kinds follow `IntErrorKind` (Empty 0, InvalidDigit 1,
   PosOverflow 2, NegOverflow 3): core's `from_str_radix` at radix
   10 checks each digit, then the checked multiply and add, in
   order, so an overflow ahead of a bad digit reports the overflow.
   The magnitude is accumulated in two words, so 128-bit targets
   take the same path. `from_str_radix` (R26) runs it at any radix in
   2..=36 (the caller checks the range); a letter digit is either case. */
int lust_parse_int_radix(lust_str s, uint32_t radix, int is_signed, int bits, uint64_t *lo, uint64_t *hi, int *kind) LUST_BODY({
    *lo = 0; *hi = 0;
    if (s.len == 0) { *kind = 0; return 0; }
    uint64_t i = 0;
    int neg = 0;
    if (s.ptr[0] == '+') {
        i = 1;
    } else if (s.ptr[0] == '-' && is_signed) {
        neg = 1;
        i = 1;
    }
    if (i >= s.len) { *kind = 1; return 0; }
    /* The magnitude limit: the type's max, or its min's magnitude. */
    uint64_t lim_lo, lim_hi;
    if (bits >= 128) {
        lim_hi = is_signed ? 0x7fffffffffffffffULL : 0xffffffffffffffffULL;
        lim_lo = 0xffffffffffffffffULL;
        if (is_signed && neg) { lim_hi = 0x8000000000000000ULL; lim_lo = 0; }
    } else if (bits == 64) {
        lim_hi = 0;
        lim_lo = is_signed ? (neg ? 0x8000000000000000ULL : 0x7fffffffffffffffULL) : 0xffffffffffffffffULL;
    } else {
        lim_hi = 0;
        uint64_t top = bits == 32 ? 0xffffffffULL : (bits == 16 ? 0xffffULL : 0xffULL);
        lim_lo = is_signed ? (neg ? (top / 2 + 1) : top / 2) : top;
    }
    uint64_t rlo = 0, rhi = 0;
    for (; i < s.len; i++) {
        uint8_t ch = s.ptr[i];
        uint64_t d = ch >= '0' && ch <= '9' ? (uint64_t)(ch - '0')
            : (ch | 32) >= 'a' && (ch | 32) <= 'z' ? (uint64_t)((ch | 32) - 'a' + 10) : 99;
        if (d >= radix) { *kind = 1; return 0; }
        /* r = r * radix + d, checked against the limit. A high word
           that would wrap past two words is past every limit. */
        uint64_t lo10 = (rlo & 0xffffffffULL) * radix;
        uint64_t hi10 = (rlo >> 32) * radix + (lo10 >> 32);
        if (rhi > (0xffffffffffffffffULL - (hi10 >> 32)) / radix) { *kind = neg ? 3 : 2; return 0; }
        uint64_t nlo = (lo10 & 0xffffffffULL) | ((hi10 & 0xffffffffULL) << 32);
        uint64_t nhi = (hi10 >> 32) + rhi * radix;
        nlo += d;
        if (nlo < d) {
            if (nhi == 0xffffffffffffffffULL) { *kind = neg ? 3 : 2; return 0; }
            nhi += 1;
        }
        if (nhi > lim_hi || (nhi == lim_hi && nlo > lim_lo)) { *kind = neg ? 3 : 2; return 0; }
        rlo = nlo; rhi = nhi;
    }
    if (neg) {
        /* Two's complement negation in the target width. */
        if (bits >= 128) {
            *lo = ~rlo + 1;
            *hi = ~rhi + (*lo == 0);
        } else if (bits == 64) {
            *lo = 0 - rlo; *hi = 0;
        } else {
            uint64_t mask = bits == 32 ? 0xffffffffULL : (bits == 16 ? 0xffffULL : 0xffULL);
            *lo = (0 - rlo) & mask; *hi = 0;
        }
    } else {
        *lo = rlo; *hi = rhi;
    }
    *kind = 0;
    return 1;
})

int lust_parse_int(lust_str s, int is_signed, int bits, uint64_t *lo, uint64_t *hi, int *kind) LUST_BODY({
    return lust_parse_int_radix(s, 10, is_signed, bits, lo, hi, kind);
})

/* core's `from_str_radix` radix check: a panic before any parsing. */
void lust_radix_check(uint32_t radix, lust_loc loc) LUST_BODY({
    if (radix >= 2 && radix <= 36) return;
    lust_String m = lust_string_new();
    lust_string_push_cstr(&m, "from_ascii_bytes_radix: radix must lie in the range `[2, 36]` - found ");
    lust_fmt_u64(&m, radix);
    lust_panic_dyn(&m, loc);
})

/* The float parsers of float.c (Rust's grammar, correctly
   rounded), declared in float.h below; 1 is empty, 2 is invalid. */
int lust_parse_f64(lust_str s, double *out);
int lust_parse_f32(lust_str s, float *out);

/* `f64::from_str` (tf-str): over the float core's parser, with
   core's error kinds (0 Empty, 1 Invalid). */
int lust_str_parse_f64(lust_str s, double *out, int *kind) LUST_BODY({
    int rc = lust_parse_f64(s, out);
    *kind = rc == 1 ? 0 : 1;
    return rc == 0;
})

int lust_str_parse_f32(lust_str s, float *out, int *kind) LUST_BODY({
    int rc = lust_parse_f32(s, out);
    *kind = rc == 1 ? 0 : 1;
    return rc == 0;
})

/* `bool::from_str`: exactly `true` or `false`. */
int lust_parse_bool(lust_str s, uint8_t *out) LUST_BODY({
    if (s.len == 4 && memcmp(s.ptr, "true", 4) == 0) { *out = 1; return 1; }
    if (s.len == 5 && memcmp(s.ptr, "false", 5) == 0) { *out = 0; return 1; }
    return 0;
})

/* `char::from_str`: exactly one char (kind: 0 EmptyString,
   1 TooManyChars). */
int lust_parse_char(lust_str s, uint32_t *out, int *kind) LUST_BODY({
    if (s.len == 0) { *kind = 0; return 0; }
    uint64_t j = 0;
    uint32_t c = lust_utf8_next(s.ptr, &j);
    if (j != s.len) { *kind = 1; return 0; }
    *out = c;
    *kind = 0;
    return 1;
})

/* `String::from_utf16_lossy` (tf-str): `char::decode_utf16` over
   the units collected into a String, as alloc runs it. The collect
   starts at the decoder's size-hint lower bound, `(units + 1) / 2`
   rounded as core counts it (an even count halves exactly), then
   pushes one char at a time, with U+FFFD for each unpaired
   surrogate, so capacities grow as std's do. */
lust_String lust_string_from_utf16_lossy(const uint16_t *v, uint64_t n) LUST_BODY({
    lust_String s = lust_string_new();
    lust_string_reserve(&s, (n + 1) / 2);
    uint64_t i = 0;
    while (i < n) {
        uint16_t u = v[i++];
        uint32_t c;
        if (u >= 0xD800 && u < 0xDC00) {
            if (i < n && v[i] >= 0xDC00 && v[i] < 0xE000) {
                c = 0x10000 + (((uint32_t)(u - 0xD800) << 10) | (uint32_t)(v[i] - 0xDC00));
                i++;
            } else {
                c = 0xFFFD;
            }
        } else if (u >= 0xDC00 && u < 0xE000) {
            c = 0xFFFD;
        } else {
            c = u;
        }
        lust_string_push_char(&s, c);
    }
    return s;
})

/* str::to_uppercase and str::to_lowercase as Rust 1.99 runs them
   (W-STD-B): the ASCII prefix byte by byte into a String with the str's
   length as capacity (`convert_while_ascii`), then each char through
   rustc-generated tables (one to three chars, pushed one by one), and in
   to_lowercase 'Σ' by the final-sigma rule. The tables are in the runtime
   unit only (`runtime_source`). */
// Generated by scripts/gen-case-tables.rs from char::to_uppercase,
// char::to_lowercase, and str::to_lowercase's final sigma (W-STD-B).
// Do not edit.
static const uint32_t lust_upper_map[][4] = {
  {0x61, 0x41, 0x0, 0x0},
  {0x62, 0x42, 0x0, 0x0},
  {0x63, 0x43, 0x0, 0x0},
  {0x64, 0x44, 0x0, 0x0},
  {0x65, 0x45, 0x0, 0x0},
  {0x66, 0x46, 0x0, 0x0},
  {0x67, 0x47, 0x0, 0x0},
  {0x68, 0x48, 0x0, 0x0},
  {0x69, 0x49, 0x0, 0x0},
  {0x6A, 0x4A, 0x0, 0x0},
  {0x6B, 0x4B, 0x0, 0x0},
  {0x6C, 0x4C, 0x0, 0x0},
  {0x6D, 0x4D, 0x0, 0x0},
  {0x6E, 0x4E, 0x0, 0x0},
  {0x6F, 0x4F, 0x0, 0x0},
  {0x70, 0x50, 0x0, 0x0},
  {0x71, 0x51, 0x0, 0x0},
  {0x72, 0x52, 0x0, 0x0},
  {0x73, 0x53, 0x0, 0x0},
  {0x74, 0x54, 0x0, 0x0},
  {0x75, 0x55, 0x0, 0x0},
  {0x76, 0x56, 0x0, 0x0},
  {0x77, 0x57, 0x0, 0x0},
  {0x78, 0x58, 0x0, 0x0},
  {0x79, 0x59, 0x0, 0x0},
  {0x7A, 0x5A, 0x0, 0x0},
  {0xB5, 0x39C, 0x0, 0x0},
  {0xDF, 0x53, 0x53, 0x0},
  {0xE0, 0xC0, 0x0, 0x0},
  {0xE1, 0xC1, 0x0, 0x0},
  {0xE2, 0xC2, 0x0, 0x0},
  {0xE3, 0xC3, 0x0, 0x0},
  {0xE4, 0xC4, 0x0, 0x0},
  {0xE5, 0xC5, 0x0, 0x0},
  {0xE6, 0xC6, 0x0, 0x0},
  {0xE7, 0xC7, 0x0, 0x0},
  {0xE8, 0xC8, 0x0, 0x0},
  {0xE9, 0xC9, 0x0, 0x0},
  {0xEA, 0xCA, 0x0, 0x0},
  {0xEB, 0xCB, 0x0, 0x0},
  {0xEC, 0xCC, 0x0, 0x0},
  {0xED, 0xCD, 0x0, 0x0},
  {0xEE, 0xCE, 0x0, 0x0},
  {0xEF, 0xCF, 0x0, 0x0},
  {0xF0, 0xD0, 0x0, 0x0},
  {0xF1, 0xD1, 0x0, 0x0},
  {0xF2, 0xD2, 0x0, 0x0},
  {0xF3, 0xD3, 0x0, 0x0},
  {0xF4, 0xD4, 0x0, 0x0},
  {0xF5, 0xD5, 0x0, 0x0},
  {0xF6, 0xD6, 0x0, 0x0},
  {0xF8, 0xD8, 0x0, 0x0},
  {0xF9, 0xD9, 0x0, 0x0},
  {0xFA, 0xDA, 0x0, 0x0},
  {0xFB, 0xDB, 0x0, 0x0},
  {0xFC, 0xDC, 0x0, 0x0},
  {0xFD, 0xDD, 0x0, 0x0},
  {0xFE, 0xDE, 0x0, 0x0},
  {0xFF, 0x178, 0x0, 0x0},
  {0x101, 0x100, 0x0, 0x0},
  {0x103, 0x102, 0x0, 0x0},
  {0x105, 0x104, 0x0, 0x0},
  {0x107, 0x106, 0x0, 0x0},
  {0x109, 0x108, 0x0, 0x0},
  {0x10B, 0x10A, 0x0, 0x0},
  {0x10D, 0x10C, 0x0, 0x0},
  {0x10F, 0x10E, 0x0, 0x0},
  {0x111, 0x110, 0x0, 0x0},
  {0x113, 0x112, 0x0, 0x0},
  {0x115, 0x114, 0x0, 0x0},
  {0x117, 0x116, 0x0, 0x0},
  {0x119, 0x118, 0x0, 0x0},
  {0x11B, 0x11A, 0x0, 0x0},
  {0x11D, 0x11C, 0x0, 0x0},
  {0x11F, 0x11E, 0x0, 0x0},
  {0x121, 0x120, 0x0, 0x0},
  {0x123, 0x122, 0x0, 0x0},
  {0x125, 0x124, 0x0, 0x0},
  {0x127, 0x126, 0x0, 0x0},
  {0x129, 0x128, 0x0, 0x0},
  {0x12B, 0x12A, 0x0, 0x0},
  {0x12D, 0x12C, 0x0, 0x0},
  {0x12F, 0x12E, 0x0, 0x0},
  {0x131, 0x49, 0x0, 0x0},
  {0x133, 0x132, 0x0, 0x0},
  {0x135, 0x134, 0x0, 0x0},
  {0x137, 0x136, 0x0, 0x0},
  {0x13A, 0x139, 0x0, 0x0},
  {0x13C, 0x13B, 0x0, 0x0},
  {0x13E, 0x13D, 0x0, 0x0},
  {0x140, 0x13F, 0x0, 0x0},
  {0x142, 0x141, 0x0, 0x0},
  {0x144, 0x143, 0x0, 0x0},
  {0x146, 0x145, 0x0, 0x0},
  {0x148, 0x147, 0x0, 0x0},
  {0x149, 0x2BC, 0x4E, 0x0},
  {0x14B, 0x14A, 0x0, 0x0},
  {0x14D, 0x14C, 0x0, 0x0},
  {0x14F, 0x14E, 0x0, 0x0},
  {0x151, 0x150, 0x0, 0x0},
  {0x153, 0x152, 0x0, 0x0},
  {0x155, 0x154, 0x0, 0x0},
  {0x157, 0x156, 0x0, 0x0},
  {0x159, 0x158, 0x0, 0x0},
  {0x15B, 0x15A, 0x0, 0x0},
  {0x15D, 0x15C, 0x0, 0x0},
  {0x15F, 0x15E, 0x0, 0x0},
  {0x161, 0x160, 0x0, 0x0},
  {0x163, 0x162, 0x0, 0x0},
  {0x165, 0x164, 0x0, 0x0},
  {0x167, 0x166, 0x0, 0x0},
  {0x169, 0x168, 0x0, 0x0},
  {0x16B, 0x16A, 0x0, 0x0},
  {0x16D, 0x16C, 0x0, 0x0},
  {0x16F, 0x16E, 0x0, 0x0},
  {0x171, 0x170, 0x0, 0x0},
  {0x173, 0x172, 0x0, 0x0},
  {0x175, 0x174, 0x0, 0x0},
  {0x177, 0x176, 0x0, 0x0},
  {0x17A, 0x179, 0x0, 0x0},
  {0x17C, 0x17B, 0x0, 0x0},
  {0x17E, 0x17D, 0x0, 0x0},
  {0x17F, 0x53, 0x0, 0x0},
  {0x180, 0x243, 0x0, 0x0},
  {0x183, 0x182, 0x0, 0x0},
  {0x185, 0x184, 0x0, 0x0},
  {0x188, 0x187, 0x0, 0x0},
  {0x18C, 0x18B, 0x0, 0x0},
  {0x192, 0x191, 0x0, 0x0},
  {0x195, 0x1F6, 0x0, 0x0},
  {0x199, 0x198, 0x0, 0x0},
  {0x19A, 0x23D, 0x0, 0x0},
  {0x19B, 0xA7DC, 0x0, 0x0},
  {0x19E, 0x220, 0x0, 0x0},
  {0x1A1, 0x1A0, 0x0, 0x0},
  {0x1A3, 0x1A2, 0x0, 0x0},
  {0x1A5, 0x1A4, 0x0, 0x0},
  {0x1A8, 0x1A7, 0x0, 0x0},
  {0x1AD, 0x1AC, 0x0, 0x0},
  {0x1B0, 0x1AF, 0x0, 0x0},
  {0x1B4, 0x1B3, 0x0, 0x0},
  {0x1B6, 0x1B5, 0x0, 0x0},
  {0x1B9, 0x1B8, 0x0, 0x0},
  {0x1BD, 0x1BC, 0x0, 0x0},
  {0x1BF, 0x1F7, 0x0, 0x0},
  {0x1C5, 0x1C4, 0x0, 0x0},
  {0x1C6, 0x1C4, 0x0, 0x0},
  {0x1C8, 0x1C7, 0x0, 0x0},
  {0x1C9, 0x1C7, 0x0, 0x0},
  {0x1CB, 0x1CA, 0x0, 0x0},
  {0x1CC, 0x1CA, 0x0, 0x0},
  {0x1CE, 0x1CD, 0x0, 0x0},
  {0x1D0, 0x1CF, 0x0, 0x0},
  {0x1D2, 0x1D1, 0x0, 0x0},
  {0x1D4, 0x1D3, 0x0, 0x0},
  {0x1D6, 0x1D5, 0x0, 0x0},
  {0x1D8, 0x1D7, 0x0, 0x0},
  {0x1DA, 0x1D9, 0x0, 0x0},
  {0x1DC, 0x1DB, 0x0, 0x0},
  {0x1DD, 0x18E, 0x0, 0x0},
  {0x1DF, 0x1DE, 0x0, 0x0},
  {0x1E1, 0x1E0, 0x0, 0x0},
  {0x1E3, 0x1E2, 0x0, 0x0},
  {0x1E5, 0x1E4, 0x0, 0x0},
  {0x1E7, 0x1E6, 0x0, 0x0},
  {0x1E9, 0x1E8, 0x0, 0x0},
  {0x1EB, 0x1EA, 0x0, 0x0},
  {0x1ED, 0x1EC, 0x0, 0x0},
  {0x1EF, 0x1EE, 0x0, 0x0},
  {0x1F0, 0x4A, 0x30C, 0x0},
  {0x1F2, 0x1F1, 0x0, 0x0},
  {0x1F3, 0x1F1, 0x0, 0x0},
  {0x1F5, 0x1F4, 0x0, 0x0},
  {0x1F9, 0x1F8, 0x0, 0x0},
  {0x1FB, 0x1FA, 0x0, 0x0},
  {0x1FD, 0x1FC, 0x0, 0x0},
  {0x1FF, 0x1FE, 0x0, 0x0},
  {0x201, 0x200, 0x0, 0x0},
  {0x203, 0x202, 0x0, 0x0},
  {0x205, 0x204, 0x0, 0x0},
  {0x207, 0x206, 0x0, 0x0},
  {0x209, 0x208, 0x0, 0x0},
  {0x20B, 0x20A, 0x0, 0x0},
  {0x20D, 0x20C, 0x0, 0x0},
  {0x20F, 0x20E, 0x0, 0x0},
  {0x211, 0x210, 0x0, 0x0},
  {0x213, 0x212, 0x0, 0x0},
  {0x215, 0x214, 0x0, 0x0},
  {0x217, 0x216, 0x0, 0x0},
  {0x219, 0x218, 0x0, 0x0},
  {0x21B, 0x21A, 0x0, 0x0},
  {0x21D, 0x21C, 0x0, 0x0},
  {0x21F, 0x21E, 0x0, 0x0},
  {0x223, 0x222, 0x0, 0x0},
  {0x225, 0x224, 0x0, 0x0},
  {0x227, 0x226, 0x0, 0x0},
  {0x229, 0x228, 0x0, 0x0},
  {0x22B, 0x22A, 0x0, 0x0},
  {0x22D, 0x22C, 0x0, 0x0},
  {0x22F, 0x22E, 0x0, 0x0},
  {0x231, 0x230, 0x0, 0x0},
  {0x233, 0x232, 0x0, 0x0},
  {0x23C, 0x23B, 0x0, 0x0},
  {0x23F, 0x2C7E, 0x0, 0x0},
  {0x240, 0x2C7F, 0x0, 0x0},
  {0x242, 0x241, 0x0, 0x0},
  {0x247, 0x246, 0x0, 0x0},
  {0x249, 0x248, 0x0, 0x0},
  {0x24B, 0x24A, 0x0, 0x0},
  {0x24D, 0x24C, 0x0, 0x0},
  {0x24F, 0x24E, 0x0, 0x0},
  {0x250, 0x2C6F, 0x0, 0x0},
  {0x251, 0x2C6D, 0x0, 0x0},
  {0x252, 0x2C70, 0x0, 0x0},
  {0x253, 0x181, 0x0, 0x0},
  {0x254, 0x186, 0x0, 0x0},
  {0x256, 0x189, 0x0, 0x0},
  {0x257, 0x18A, 0x0, 0x0},
  {0x259, 0x18F, 0x0, 0x0},
  {0x25B, 0x190, 0x0, 0x0},
  {0x25C, 0xA7AB, 0x0, 0x0},
  {0x260, 0x193, 0x0, 0x0},
  {0x261, 0xA7AC, 0x0, 0x0},
  {0x263, 0x194, 0x0, 0x0},
  {0x264, 0xA7CB, 0x0, 0x0},
  {0x265, 0xA78D, 0x0, 0x0},
  {0x266, 0xA7AA, 0x0, 0x0},
  {0x268, 0x197, 0x0, 0x0},
  {0x269, 0x196, 0x0, 0x0},
  {0x26A, 0xA7AE, 0x0, 0x0},
  {0x26B, 0x2C62, 0x0, 0x0},
  {0x26C, 0xA7AD, 0x0, 0x0},
  {0x26F, 0x19C, 0x0, 0x0},
  {0x271, 0x2C6E, 0x0, 0x0},
  {0x272, 0x19D, 0x0, 0x0},
  {0x275, 0x19F, 0x0, 0x0},
  {0x27D, 0x2C64, 0x0, 0x0},
  {0x280, 0x1A6, 0x0, 0x0},
  {0x282, 0xA7C5, 0x0, 0x0},
  {0x283, 0x1A9, 0x0, 0x0},
  {0x287, 0xA7B1, 0x0, 0x0},
  {0x288, 0x1AE, 0x0, 0x0},
  {0x289, 0x244, 0x0, 0x0},
  {0x28A, 0x1B1, 0x0, 0x0},
  {0x28B, 0x1B2, 0x0, 0x0},
  {0x28C, 0x245, 0x0, 0x0},
  {0x292, 0x1B7, 0x0, 0x0},
  {0x29D, 0xA7B2, 0x0, 0x0},
  {0x29E, 0xA7B0, 0x0, 0x0},
  {0x345, 0x399, 0x0, 0x0},
  {0x371, 0x370, 0x0, 0x0},
  {0x373, 0x372, 0x0, 0x0},
  {0x377, 0x376, 0x0, 0x0},
  {0x37B, 0x3FD, 0x0, 0x0},
  {0x37C, 0x3FE, 0x0, 0x0},
  {0x37D, 0x3FF, 0x0, 0x0},
  {0x390, 0x399, 0x308, 0x301},
  {0x3AC, 0x386, 0x0, 0x0},
  {0x3AD, 0x388, 0x0, 0x0},
  {0x3AE, 0x389, 0x0, 0x0},
  {0x3AF, 0x38A, 0x0, 0x0},
  {0x3B0, 0x3A5, 0x308, 0x301},
  {0x3B1, 0x391, 0x0, 0x0},
  {0x3B2, 0x392, 0x0, 0x0},
  {0x3B3, 0x393, 0x0, 0x0},
  {0x3B4, 0x394, 0x0, 0x0},
  {0x3B5, 0x395, 0x0, 0x0},
  {0x3B6, 0x396, 0x0, 0x0},
  {0x3B7, 0x397, 0x0, 0x0},
  {0x3B8, 0x398, 0x0, 0x0},
  {0x3B9, 0x399, 0x0, 0x0},
  {0x3BA, 0x39A, 0x0, 0x0},
  {0x3BB, 0x39B, 0x0, 0x0},
  {0x3BC, 0x39C, 0x0, 0x0},
  {0x3BD, 0x39D, 0x0, 0x0},
  {0x3BE, 0x39E, 0x0, 0x0},
  {0x3BF, 0x39F, 0x0, 0x0},
  {0x3C0, 0x3A0, 0x0, 0x0},
  {0x3C1, 0x3A1, 0x0, 0x0},
  {0x3C2, 0x3A3, 0x0, 0x0},
  {0x3C3, 0x3A3, 0x0, 0x0},
  {0x3C4, 0x3A4, 0x0, 0x0},
  {0x3C5, 0x3A5, 0x0, 0x0},
  {0x3C6, 0x3A6, 0x0, 0x0},
  {0x3C7, 0x3A7, 0x0, 0x0},
  {0x3C8, 0x3A8, 0x0, 0x0},
  {0x3C9, 0x3A9, 0x0, 0x0},
  {0x3CA, 0x3AA, 0x0, 0x0},
  {0x3CB, 0x3AB, 0x0, 0x0},
  {0x3CC, 0x38C, 0x0, 0x0},
  {0x3CD, 0x38E, 0x0, 0x0},
  {0x3CE, 0x38F, 0x0, 0x0},
  {0x3D0, 0x392, 0x0, 0x0},
  {0x3D1, 0x398, 0x0, 0x0},
  {0x3D5, 0x3A6, 0x0, 0x0},
  {0x3D6, 0x3A0, 0x0, 0x0},
  {0x3D7, 0x3CF, 0x0, 0x0},
  {0x3D9, 0x3D8, 0x0, 0x0},
  {0x3DB, 0x3DA, 0x0, 0x0},
  {0x3DD, 0x3DC, 0x0, 0x0},
  {0x3DF, 0x3DE, 0x0, 0x0},
  {0x3E1, 0x3E0, 0x0, 0x0},
  {0x3E3, 0x3E2, 0x0, 0x0},
  {0x3E5, 0x3E4, 0x0, 0x0},
  {0x3E7, 0x3E6, 0x0, 0x0},
  {0x3E9, 0x3E8, 0x0, 0x0},
  {0x3EB, 0x3EA, 0x0, 0x0},
  {0x3ED, 0x3EC, 0x0, 0x0},
  {0x3EF, 0x3EE, 0x0, 0x0},
  {0x3F0, 0x39A, 0x0, 0x0},
  {0x3F1, 0x3A1, 0x0, 0x0},
  {0x3F2, 0x3F9, 0x0, 0x0},
  {0x3F3, 0x37F, 0x0, 0x0},
  {0x3F5, 0x395, 0x0, 0x0},
  {0x3F8, 0x3F7, 0x0, 0x0},
  {0x3FB, 0x3FA, 0x0, 0x0},
  {0x430, 0x410, 0x0, 0x0},
  {0x431, 0x411, 0x0, 0x0},
  {0x432, 0x412, 0x0, 0x0},
  {0x433, 0x413, 0x0, 0x0},
  {0x434, 0x414, 0x0, 0x0},
  {0x435, 0x415, 0x0, 0x0},
  {0x436, 0x416, 0x0, 0x0},
  {0x437, 0x417, 0x0, 0x0},
  {0x438, 0x418, 0x0, 0x0},
  {0x439, 0x419, 0x0, 0x0},
  {0x43A, 0x41A, 0x0, 0x0},
  {0x43B, 0x41B, 0x0, 0x0},
  {0x43C, 0x41C, 0x0, 0x0},
  {0x43D, 0x41D, 0x0, 0x0},
  {0x43E, 0x41E, 0x0, 0x0},
  {0x43F, 0x41F, 0x0, 0x0},
  {0x440, 0x420, 0x0, 0x0},
  {0x441, 0x421, 0x0, 0x0},
  {0x442, 0x422, 0x0, 0x0},
  {0x443, 0x423, 0x0, 0x0},
  {0x444, 0x424, 0x0, 0x0},
  {0x445, 0x425, 0x0, 0x0},
  {0x446, 0x426, 0x0, 0x0},
  {0x447, 0x427, 0x0, 0x0},
  {0x448, 0x428, 0x0, 0x0},
  {0x449, 0x429, 0x0, 0x0},
  {0x44A, 0x42A, 0x0, 0x0},
  {0x44B, 0x42B, 0x0, 0x0},
  {0x44C, 0x42C, 0x0, 0x0},
  {0x44D, 0x42D, 0x0, 0x0},
  {0x44E, 0x42E, 0x0, 0x0},
  {0x44F, 0x42F, 0x0, 0x0},
  {0x450, 0x400, 0x0, 0x0},
  {0x451, 0x401, 0x0, 0x0},
  {0x452, 0x402, 0x0, 0x0},
  {0x453, 0x403, 0x0, 0x0},
  {0x454, 0x404, 0x0, 0x0},
  {0x455, 0x405, 0x0, 0x0},
  {0x456, 0x406, 0x0, 0x0},
  {0x457, 0x407, 0x0, 0x0},
  {0x458, 0x408, 0x0, 0x0},
  {0x459, 0x409, 0x0, 0x0},
  {0x45A, 0x40A, 0x0, 0x0},
  {0x45B, 0x40B, 0x0, 0x0},
  {0x45C, 0x40C, 0x0, 0x0},
  {0x45D, 0x40D, 0x0, 0x0},
  {0x45E, 0x40E, 0x0, 0x0},
  {0x45F, 0x40F, 0x0, 0x0},
  {0x461, 0x460, 0x0, 0x0},
  {0x463, 0x462, 0x0, 0x0},
  {0x465, 0x464, 0x0, 0x0},
  {0x467, 0x466, 0x0, 0x0},
  {0x469, 0x468, 0x0, 0x0},
  {0x46B, 0x46A, 0x0, 0x0},
  {0x46D, 0x46C, 0x0, 0x0},
  {0x46F, 0x46E, 0x0, 0x0},
  {0x471, 0x470, 0x0, 0x0},
  {0x473, 0x472, 0x0, 0x0},
  {0x475, 0x474, 0x0, 0x0},
  {0x477, 0x476, 0x0, 0x0},
  {0x479, 0x478, 0x0, 0x0},
  {0x47B, 0x47A, 0x0, 0x0},
  {0x47D, 0x47C, 0x0, 0x0},
  {0x47F, 0x47E, 0x0, 0x0},
  {0x481, 0x480, 0x0, 0x0},
  {0x48B, 0x48A, 0x0, 0x0},
  {0x48D, 0x48C, 0x0, 0x0},
  {0x48F, 0x48E, 0x0, 0x0},
  {0x491, 0x490, 0x0, 0x0},
  {0x493, 0x492, 0x0, 0x0},
  {0x495, 0x494, 0x0, 0x0},
  {0x497, 0x496, 0x0, 0x0},
  {0x499, 0x498, 0x0, 0x0},
  {0x49B, 0x49A, 0x0, 0x0},
  {0x49D, 0x49C, 0x0, 0x0},
  {0x49F, 0x49E, 0x0, 0x0},
  {0x4A1, 0x4A0, 0x0, 0x0},
  {0x4A3, 0x4A2, 0x0, 0x0},
  {0x4A5, 0x4A4, 0x0, 0x0},
  {0x4A7, 0x4A6, 0x0, 0x0},
  {0x4A9, 0x4A8, 0x0, 0x0},
  {0x4AB, 0x4AA, 0x0, 0x0},
  {0x4AD, 0x4AC, 0x0, 0x0},
  {0x4AF, 0x4AE, 0x0, 0x0},
  {0x4B1, 0x4B0, 0x0, 0x0},
  {0x4B3, 0x4B2, 0x0, 0x0},
  {0x4B5, 0x4B4, 0x0, 0x0},
  {0x4B7, 0x4B6, 0x0, 0x0},
  {0x4B9, 0x4B8, 0x0, 0x0},
  {0x4BB, 0x4BA, 0x0, 0x0},
  {0x4BD, 0x4BC, 0x0, 0x0},
  {0x4BF, 0x4BE, 0x0, 0x0},
  {0x4C2, 0x4C1, 0x0, 0x0},
  {0x4C4, 0x4C3, 0x0, 0x0},
  {0x4C6, 0x4C5, 0x0, 0x0},
  {0x4C8, 0x4C7, 0x0, 0x0},
  {0x4CA, 0x4C9, 0x0, 0x0},
  {0x4CC, 0x4CB, 0x0, 0x0},
  {0x4CE, 0x4CD, 0x0, 0x0},
  {0x4CF, 0x4C0, 0x0, 0x0},
  {0x4D1, 0x4D0, 0x0, 0x0},
  {0x4D3, 0x4D2, 0x0, 0x0},
  {0x4D5, 0x4D4, 0x0, 0x0},
  {0x4D7, 0x4D6, 0x0, 0x0},
  {0x4D9, 0x4D8, 0x0, 0x0},
  {0x4DB, 0x4DA, 0x0, 0x0},
  {0x4DD, 0x4DC, 0x0, 0x0},
  {0x4DF, 0x4DE, 0x0, 0x0},
  {0x4E1, 0x4E0, 0x0, 0x0},
  {0x4E3, 0x4E2, 0x0, 0x0},
  {0x4E5, 0x4E4, 0x0, 0x0},
  {0x4E7, 0x4E6, 0x0, 0x0},
  {0x4E9, 0x4E8, 0x0, 0x0},
  {0x4EB, 0x4EA, 0x0, 0x0},
  {0x4ED, 0x4EC, 0x0, 0x0},
  {0x4EF, 0x4EE, 0x0, 0x0},
  {0x4F1, 0x4F0, 0x0, 0x0},
  {0x4F3, 0x4F2, 0x0, 0x0},
  {0x4F5, 0x4F4, 0x0, 0x0},
  {0x4F7, 0x4F6, 0x0, 0x0},
  {0x4F9, 0x4F8, 0x0, 0x0},
  {0x4FB, 0x4FA, 0x0, 0x0},
  {0x4FD, 0x4FC, 0x0, 0x0},
  {0x4FF, 0x4FE, 0x0, 0x0},
  {0x501, 0x500, 0x0, 0x0},
  {0x503, 0x502, 0x0, 0x0},
  {0x505, 0x504, 0x0, 0x0},
  {0x507, 0x506, 0x0, 0x0},
  {0x509, 0x508, 0x0, 0x0},
  {0x50B, 0x50A, 0x0, 0x0},
  {0x50D, 0x50C, 0x0, 0x0},
  {0x50F, 0x50E, 0x0, 0x0},
  {0x511, 0x510, 0x0, 0x0},
  {0x513, 0x512, 0x0, 0x0},
  {0x515, 0x514, 0x0, 0x0},
  {0x517, 0x516, 0x0, 0x0},
  {0x519, 0x518, 0x0, 0x0},
  {0x51B, 0x51A, 0x0, 0x0},
  {0x51D, 0x51C, 0x0, 0x0},
  {0x51F, 0x51E, 0x0, 0x0},
  {0x521, 0x520, 0x0, 0x0},
  {0x523, 0x522, 0x0, 0x0},
  {0x525, 0x524, 0x0, 0x0},
  {0x527, 0x526, 0x0, 0x0},
  {0x529, 0x528, 0x0, 0x0},
  {0x52B, 0x52A, 0x0, 0x0},
  {0x52D, 0x52C, 0x0, 0x0},
  {0x52F, 0x52E, 0x0, 0x0},
  {0x561, 0x531, 0x0, 0x0},
  {0x562, 0x532, 0x0, 0x0},
  {0x563, 0x533, 0x0, 0x0},
  {0x564, 0x534, 0x0, 0x0},
  {0x565, 0x535, 0x0, 0x0},
  {0x566, 0x536, 0x0, 0x0},
  {0x567, 0x537, 0x0, 0x0},
  {0x568, 0x538, 0x0, 0x0},
  {0x569, 0x539, 0x0, 0x0},
  {0x56A, 0x53A, 0x0, 0x0},
  {0x56B, 0x53B, 0x0, 0x0},
  {0x56C, 0x53C, 0x0, 0x0},
  {0x56D, 0x53D, 0x0, 0x0},
  {0x56E, 0x53E, 0x0, 0x0},
  {0x56F, 0x53F, 0x0, 0x0},
  {0x570, 0x540, 0x0, 0x0},
  {0x571, 0x541, 0x0, 0x0},
  {0x572, 0x542, 0x0, 0x0},
  {0x573, 0x543, 0x0, 0x0},
  {0x574, 0x544, 0x0, 0x0},
  {0x575, 0x545, 0x0, 0x0},
  {0x576, 0x546, 0x0, 0x0},
  {0x577, 0x547, 0x0, 0x0},
  {0x578, 0x548, 0x0, 0x0},
  {0x579, 0x549, 0x0, 0x0},
  {0x57A, 0x54A, 0x0, 0x0},
  {0x57B, 0x54B, 0x0, 0x0},
  {0x57C, 0x54C, 0x0, 0x0},
  {0x57D, 0x54D, 0x0, 0x0},
  {0x57E, 0x54E, 0x0, 0x0},
  {0x57F, 0x54F, 0x0, 0x0},
  {0x580, 0x550, 0x0, 0x0},
  {0x581, 0x551, 0x0, 0x0},
  {0x582, 0x552, 0x0, 0x0},
  {0x583, 0x553, 0x0, 0x0},
  {0x584, 0x554, 0x0, 0x0},
  {0x585, 0x555, 0x0, 0x0},
  {0x586, 0x556, 0x0, 0x0},
  {0x587, 0x535, 0x552, 0x0},
  {0x10D0, 0x1C90, 0x0, 0x0},
  {0x10D1, 0x1C91, 0x0, 0x0},
  {0x10D2, 0x1C92, 0x0, 0x0},
  {0x10D3, 0x1C93, 0x0, 0x0},
  {0x10D4, 0x1C94, 0x0, 0x0},
  {0x10D5, 0x1C95, 0x0, 0x0},
  {0x10D6, 0x1C96, 0x0, 0x0},
  {0x10D7, 0x1C97, 0x0, 0x0},
  {0x10D8, 0x1C98, 0x0, 0x0},
  {0x10D9, 0x1C99, 0x0, 0x0},
  {0x10DA, 0x1C9A, 0x0, 0x0},
  {0x10DB, 0x1C9B, 0x0, 0x0},
  {0x10DC, 0x1C9C, 0x0, 0x0},
  {0x10DD, 0x1C9D, 0x0, 0x0},
  {0x10DE, 0x1C9E, 0x0, 0x0},
  {0x10DF, 0x1C9F, 0x0, 0x0},
  {0x10E0, 0x1CA0, 0x0, 0x0},
  {0x10E1, 0x1CA1, 0x0, 0x0},
  {0x10E2, 0x1CA2, 0x0, 0x0},
  {0x10E3, 0x1CA3, 0x0, 0x0},
  {0x10E4, 0x1CA4, 0x0, 0x0},
  {0x10E5, 0x1CA5, 0x0, 0x0},
  {0x10E6, 0x1CA6, 0x0, 0x0},
  {0x10E7, 0x1CA7, 0x0, 0x0},
  {0x10E8, 0x1CA8, 0x0, 0x0},
  {0x10E9, 0x1CA9, 0x0, 0x0},
  {0x10EA, 0x1CAA, 0x0, 0x0},
  {0x10EB, 0x1CAB, 0x0, 0x0},
  {0x10EC, 0x1CAC, 0x0, 0x0},
  {0x10ED, 0x1CAD, 0x0, 0x0},
  {0x10EE, 0x1CAE, 0x0, 0x0},
  {0x10EF, 0x1CAF, 0x0, 0x0},
  {0x10F0, 0x1CB0, 0x0, 0x0},
  {0x10F1, 0x1CB1, 0x0, 0x0},
  {0x10F2, 0x1CB2, 0x0, 0x0},
  {0x10F3, 0x1CB3, 0x0, 0x0},
  {0x10F4, 0x1CB4, 0x0, 0x0},
  {0x10F5, 0x1CB5, 0x0, 0x0},
  {0x10F6, 0x1CB6, 0x0, 0x0},
  {0x10F7, 0x1CB7, 0x0, 0x0},
  {0x10F8, 0x1CB8, 0x0, 0x0},
  {0x10F9, 0x1CB9, 0x0, 0x0},
  {0x10FA, 0x1CBA, 0x0, 0x0},
  {0x10FD, 0x1CBD, 0x0, 0x0},
  {0x10FE, 0x1CBE, 0x0, 0x0},
  {0x10FF, 0x1CBF, 0x0, 0x0},
  {0x13F8, 0x13F0, 0x0, 0x0},
  {0x13F9, 0x13F1, 0x0, 0x0},
  {0x13FA, 0x13F2, 0x0, 0x0},
  {0x13FB, 0x13F3, 0x0, 0x0},
  {0x13FC, 0x13F4, 0x0, 0x0},
  {0x13FD, 0x13F5, 0x0, 0x0},
  {0x1C80, 0x412, 0x0, 0x0},
  {0x1C81, 0x414, 0x0, 0x0},
  {0x1C82, 0x41E, 0x0, 0x0},
  {0x1C83, 0x421, 0x0, 0x0},
  {0x1C84, 0x422, 0x0, 0x0},
  {0x1C85, 0x422, 0x0, 0x0},
  {0x1C86, 0x42A, 0x0, 0x0},
  {0x1C87, 0x462, 0x0, 0x0},
  {0x1C88, 0xA64A, 0x0, 0x0},
  {0x1C8A, 0x1C89, 0x0, 0x0},
  {0x1D79, 0xA77D, 0x0, 0x0},
  {0x1D7D, 0x2C63, 0x0, 0x0},
  {0x1D8E, 0xA7C6, 0x0, 0x0},
  {0x1E01, 0x1E00, 0x0, 0x0},
  {0x1E03, 0x1E02, 0x0, 0x0},
  {0x1E05, 0x1E04, 0x0, 0x0},
  {0x1E07, 0x1E06, 0x0, 0x0},
  {0x1E09, 0x1E08, 0x0, 0x0},
  {0x1E0B, 0x1E0A, 0x0, 0x0},
  {0x1E0D, 0x1E0C, 0x0, 0x0},
  {0x1E0F, 0x1E0E, 0x0, 0x0},
  {0x1E11, 0x1E10, 0x0, 0x0},
  {0x1E13, 0x1E12, 0x0, 0x0},
  {0x1E15, 0x1E14, 0x0, 0x0},
  {0x1E17, 0x1E16, 0x0, 0x0},
  {0x1E19, 0x1E18, 0x0, 0x0},
  {0x1E1B, 0x1E1A, 0x0, 0x0},
  {0x1E1D, 0x1E1C, 0x0, 0x0},
  {0x1E1F, 0x1E1E, 0x0, 0x0},
  {0x1E21, 0x1E20, 0x0, 0x0},
  {0x1E23, 0x1E22, 0x0, 0x0},
  {0x1E25, 0x1E24, 0x0, 0x0},
  {0x1E27, 0x1E26, 0x0, 0x0},
  {0x1E29, 0x1E28, 0x0, 0x0},
  {0x1E2B, 0x1E2A, 0x0, 0x0},
  {0x1E2D, 0x1E2C, 0x0, 0x0},
  {0x1E2F, 0x1E2E, 0x0, 0x0},
  {0x1E31, 0x1E30, 0x0, 0x0},
  {0x1E33, 0x1E32, 0x0, 0x0},
  {0x1E35, 0x1E34, 0x0, 0x0},
  {0x1E37, 0x1E36, 0x0, 0x0},
  {0x1E39, 0x1E38, 0x0, 0x0},
  {0x1E3B, 0x1E3A, 0x0, 0x0},
  {0x1E3D, 0x1E3C, 0x0, 0x0},
  {0x1E3F, 0x1E3E, 0x0, 0x0},
  {0x1E41, 0x1E40, 0x0, 0x0},
  {0x1E43, 0x1E42, 0x0, 0x0},
  {0x1E45, 0x1E44, 0x0, 0x0},
  {0x1E47, 0x1E46, 0x0, 0x0},
  {0x1E49, 0x1E48, 0x0, 0x0},
  {0x1E4B, 0x1E4A, 0x0, 0x0},
  {0x1E4D, 0x1E4C, 0x0, 0x0},
  {0x1E4F, 0x1E4E, 0x0, 0x0},
  {0x1E51, 0x1E50, 0x0, 0x0},
  {0x1E53, 0x1E52, 0x0, 0x0},
  {0x1E55, 0x1E54, 0x0, 0x0},
  {0x1E57, 0x1E56, 0x0, 0x0},
  {0x1E59, 0x1E58, 0x0, 0x0},
  {0x1E5B, 0x1E5A, 0x0, 0x0},
  {0x1E5D, 0x1E5C, 0x0, 0x0},
  {0x1E5F, 0x1E5E, 0x0, 0x0},
  {0x1E61, 0x1E60, 0x0, 0x0},
  {0x1E63, 0x1E62, 0x0, 0x0},
  {0x1E65, 0x1E64, 0x0, 0x0},
  {0x1E67, 0x1E66, 0x0, 0x0},
  {0x1E69, 0x1E68, 0x0, 0x0},
  {0x1E6B, 0x1E6A, 0x0, 0x0},
  {0x1E6D, 0x1E6C, 0x0, 0x0},
  {0x1E6F, 0x1E6E, 0x0, 0x0},
  {0x1E71, 0x1E70, 0x0, 0x0},
  {0x1E73, 0x1E72, 0x0, 0x0},
  {0x1E75, 0x1E74, 0x0, 0x0},
  {0x1E77, 0x1E76, 0x0, 0x0},
  {0x1E79, 0x1E78, 0x0, 0x0},
  {0x1E7B, 0x1E7A, 0x0, 0x0},
  {0x1E7D, 0x1E7C, 0x0, 0x0},
  {0x1E7F, 0x1E7E, 0x0, 0x0},
  {0x1E81, 0x1E80, 0x0, 0x0},
  {0x1E83, 0x1E82, 0x0, 0x0},
  {0x1E85, 0x1E84, 0x0, 0x0},
  {0x1E87, 0x1E86, 0x0, 0x0},
  {0x1E89, 0x1E88, 0x0, 0x0},
  {0x1E8B, 0x1E8A, 0x0, 0x0},
  {0x1E8D, 0x1E8C, 0x0, 0x0},
  {0x1E8F, 0x1E8E, 0x0, 0x0},
  {0x1E91, 0x1E90, 0x0, 0x0},
  {0x1E93, 0x1E92, 0x0, 0x0},
  {0x1E95, 0x1E94, 0x0, 0x0},
  {0x1E96, 0x48, 0x331, 0x0},
  {0x1E97, 0x54, 0x308, 0x0},
  {0x1E98, 0x57, 0x30A, 0x0},
  {0x1E99, 0x59, 0x30A, 0x0},
  {0x1E9A, 0x41, 0x2BE, 0x0},
  {0x1E9B, 0x1E60, 0x0, 0x0},
  {0x1EA1, 0x1EA0, 0x0, 0x0},
  {0x1EA3, 0x1EA2, 0x0, 0x0},
  {0x1EA5, 0x1EA4, 0x0, 0x0},
  {0x1EA7, 0x1EA6, 0x0, 0x0},
  {0x1EA9, 0x1EA8, 0x0, 0x0},
  {0x1EAB, 0x1EAA, 0x0, 0x0},
  {0x1EAD, 0x1EAC, 0x0, 0x0},
  {0x1EAF, 0x1EAE, 0x0, 0x0},
  {0x1EB1, 0x1EB0, 0x0, 0x0},
  {0x1EB3, 0x1EB2, 0x0, 0x0},
  {0x1EB5, 0x1EB4, 0x0, 0x0},
  {0x1EB7, 0x1EB6, 0x0, 0x0},
  {0x1EB9, 0x1EB8, 0x0, 0x0},
  {0x1EBB, 0x1EBA, 0x0, 0x0},
  {0x1EBD, 0x1EBC, 0x0, 0x0},
  {0x1EBF, 0x1EBE, 0x0, 0x0},
  {0x1EC1, 0x1EC0, 0x0, 0x0},
  {0x1EC3, 0x1EC2, 0x0, 0x0},
  {0x1EC5, 0x1EC4, 0x0, 0x0},
  {0x1EC7, 0x1EC6, 0x0, 0x0},
  {0x1EC9, 0x1EC8, 0x0, 0x0},
  {0x1ECB, 0x1ECA, 0x0, 0x0},
  {0x1ECD, 0x1ECC, 0x0, 0x0},
  {0x1ECF, 0x1ECE, 0x0, 0x0},
  {0x1ED1, 0x1ED0, 0x0, 0x0},
  {0x1ED3, 0x1ED2, 0x0, 0x0},
  {0x1ED5, 0x1ED4, 0x0, 0x0},
  {0x1ED7, 0x1ED6, 0x0, 0x0},
  {0x1ED9, 0x1ED8, 0x0, 0x0},
  {0x1EDB, 0x1EDA, 0x0, 0x0},
  {0x1EDD, 0x1EDC, 0x0, 0x0},
  {0x1EDF, 0x1EDE, 0x0, 0x0},
  {0x1EE1, 0x1EE0, 0x0, 0x0},
  {0x1EE3, 0x1EE2, 0x0, 0x0},
  {0x1EE5, 0x1EE4, 0x0, 0x0},
  {0x1EE7, 0x1EE6, 0x0, 0x0},
  {0x1EE9, 0x1EE8, 0x0, 0x0},
  {0x1EEB, 0x1EEA, 0x0, 0x0},
  {0x1EED, 0x1EEC, 0x0, 0x0},
  {0x1EEF, 0x1EEE, 0x0, 0x0},
  {0x1EF1, 0x1EF0, 0x0, 0x0},
  {0x1EF3, 0x1EF2, 0x0, 0x0},
  {0x1EF5, 0x1EF4, 0x0, 0x0},
  {0x1EF7, 0x1EF6, 0x0, 0x0},
  {0x1EF9, 0x1EF8, 0x0, 0x0},
  {0x1EFB, 0x1EFA, 0x0, 0x0},
  {0x1EFD, 0x1EFC, 0x0, 0x0},
  {0x1EFF, 0x1EFE, 0x0, 0x0},
  {0x1F00, 0x1F08, 0x0, 0x0},
  {0x1F01, 0x1F09, 0x0, 0x0},
  {0x1F02, 0x1F0A, 0x0, 0x0},
  {0x1F03, 0x1F0B, 0x0, 0x0},
  {0x1F04, 0x1F0C, 0x0, 0x0},
  {0x1F05, 0x1F0D, 0x0, 0x0},
  {0x1F06, 0x1F0E, 0x0, 0x0},
  {0x1F07, 0x1F0F, 0x0, 0x0},
  {0x1F10, 0x1F18, 0x0, 0x0},
  {0x1F11, 0x1F19, 0x0, 0x0},
  {0x1F12, 0x1F1A, 0x0, 0x0},
  {0x1F13, 0x1F1B, 0x0, 0x0},
  {0x1F14, 0x1F1C, 0x0, 0x0},
  {0x1F15, 0x1F1D, 0x0, 0x0},
  {0x1F20, 0x1F28, 0x0, 0x0},
  {0x1F21, 0x1F29, 0x0, 0x0},
  {0x1F22, 0x1F2A, 0x0, 0x0},
  {0x1F23, 0x1F2B, 0x0, 0x0},
  {0x1F24, 0x1F2C, 0x0, 0x0},
  {0x1F25, 0x1F2D, 0x0, 0x0},
  {0x1F26, 0x1F2E, 0x0, 0x0},
  {0x1F27, 0x1F2F, 0x0, 0x0},
  {0x1F30, 0x1F38, 0x0, 0x0},
  {0x1F31, 0x1F39, 0x0, 0x0},
  {0x1F32, 0x1F3A, 0x0, 0x0},
  {0x1F33, 0x1F3B, 0x0, 0x0},
  {0x1F34, 0x1F3C, 0x0, 0x0},
  {0x1F35, 0x1F3D, 0x0, 0x0},
  {0x1F36, 0x1F3E, 0x0, 0x0},
  {0x1F37, 0x1F3F, 0x0, 0x0},
  {0x1F40, 0x1F48, 0x0, 0x0},
  {0x1F41, 0x1F49, 0x0, 0x0},
  {0x1F42, 0x1F4A, 0x0, 0x0},
  {0x1F43, 0x1F4B, 0x0, 0x0},
  {0x1F44, 0x1F4C, 0x0, 0x0},
  {0x1F45, 0x1F4D, 0x0, 0x0},
  {0x1F50, 0x3A5, 0x313, 0x0},
  {0x1F51, 0x1F59, 0x0, 0x0},
  {0x1F52, 0x3A5, 0x313, 0x300},
  {0x1F53, 0x1F5B, 0x0, 0x0},
  {0x1F54, 0x3A5, 0x313, 0x301},
  {0x1F55, 0x1F5D, 0x0, 0x0},
  {0x1F56, 0x3A5, 0x313, 0x342},
  {0x1F57, 0x1F5F, 0x0, 0x0},
  {0x1F60, 0x1F68, 0x0, 0x0},
  {0x1F61, 0x1F69, 0x0, 0x0},
  {0x1F62, 0x1F6A, 0x0, 0x0},
  {0x1F63, 0x1F6B, 0x0, 0x0},
  {0x1F64, 0x1F6C, 0x0, 0x0},
  {0x1F65, 0x1F6D, 0x0, 0x0},
  {0x1F66, 0x1F6E, 0x0, 0x0},
  {0x1F67, 0x1F6F, 0x0, 0x0},
  {0x1F70, 0x1FBA, 0x0, 0x0},
  {0x1F71, 0x1FBB, 0x0, 0x0},
  {0x1F72, 0x1FC8, 0x0, 0x0},
  {0x1F73, 0x1FC9, 0x0, 0x0},
  {0x1F74, 0x1FCA, 0x0, 0x0},
  {0x1F75, 0x1FCB, 0x0, 0x0},
  {0x1F76, 0x1FDA, 0x0, 0x0},
  {0x1F77, 0x1FDB, 0x0, 0x0},
  {0x1F78, 0x1FF8, 0x0, 0x0},
  {0x1F79, 0x1FF9, 0x0, 0x0},
  {0x1F7A, 0x1FEA, 0x0, 0x0},
  {0x1F7B, 0x1FEB, 0x0, 0x0},
  {0x1F7C, 0x1FFA, 0x0, 0x0},
  {0x1F7D, 0x1FFB, 0x0, 0x0},
  {0x1F80, 0x1F08, 0x399, 0x0},
  {0x1F81, 0x1F09, 0x399, 0x0},
  {0x1F82, 0x1F0A, 0x399, 0x0},
  {0x1F83, 0x1F0B, 0x399, 0x0},
  {0x1F84, 0x1F0C, 0x399, 0x0},
  {0x1F85, 0x1F0D, 0x399, 0x0},
  {0x1F86, 0x1F0E, 0x399, 0x0},
  {0x1F87, 0x1F0F, 0x399, 0x0},
  {0x1F88, 0x1F08, 0x399, 0x0},
  {0x1F89, 0x1F09, 0x399, 0x0},
  {0x1F8A, 0x1F0A, 0x399, 0x0},
  {0x1F8B, 0x1F0B, 0x399, 0x0},
  {0x1F8C, 0x1F0C, 0x399, 0x0},
  {0x1F8D, 0x1F0D, 0x399, 0x0},
  {0x1F8E, 0x1F0E, 0x399, 0x0},
  {0x1F8F, 0x1F0F, 0x399, 0x0},
  {0x1F90, 0x1F28, 0x399, 0x0},
  {0x1F91, 0x1F29, 0x399, 0x0},
  {0x1F92, 0x1F2A, 0x399, 0x0},
  {0x1F93, 0x1F2B, 0x399, 0x0},
  {0x1F94, 0x1F2C, 0x399, 0x0},
  {0x1F95, 0x1F2D, 0x399, 0x0},
  {0x1F96, 0x1F2E, 0x399, 0x0},
  {0x1F97, 0x1F2F, 0x399, 0x0},
  {0x1F98, 0x1F28, 0x399, 0x0},
  {0x1F99, 0x1F29, 0x399, 0x0},
  {0x1F9A, 0x1F2A, 0x399, 0x0},
  {0x1F9B, 0x1F2B, 0x399, 0x0},
  {0x1F9C, 0x1F2C, 0x399, 0x0},
  {0x1F9D, 0x1F2D, 0x399, 0x0},
  {0x1F9E, 0x1F2E, 0x399, 0x0},
  {0x1F9F, 0x1F2F, 0x399, 0x0},
  {0x1FA0, 0x1F68, 0x399, 0x0},
  {0x1FA1, 0x1F69, 0x399, 0x0},
  {0x1FA2, 0x1F6A, 0x399, 0x0},
  {0x1FA3, 0x1F6B, 0x399, 0x0},
  {0x1FA4, 0x1F6C, 0x399, 0x0},
  {0x1FA5, 0x1F6D, 0x399, 0x0},
  {0x1FA6, 0x1F6E, 0x399, 0x0},
  {0x1FA7, 0x1F6F, 0x399, 0x0},
  {0x1FA8, 0x1F68, 0x399, 0x0},
  {0x1FA9, 0x1F69, 0x399, 0x0},
  {0x1FAA, 0x1F6A, 0x399, 0x0},
  {0x1FAB, 0x1F6B, 0x399, 0x0},
  {0x1FAC, 0x1F6C, 0x399, 0x0},
  {0x1FAD, 0x1F6D, 0x399, 0x0},
  {0x1FAE, 0x1F6E, 0x399, 0x0},
  {0x1FAF, 0x1F6F, 0x399, 0x0},
  {0x1FB0, 0x1FB8, 0x0, 0x0},
  {0x1FB1, 0x1FB9, 0x0, 0x0},
  {0x1FB2, 0x1FBA, 0x399, 0x0},
  {0x1FB3, 0x391, 0x399, 0x0},
  {0x1FB4, 0x386, 0x399, 0x0},
  {0x1FB6, 0x391, 0x342, 0x0},
  {0x1FB7, 0x391, 0x342, 0x399},
  {0x1FBC, 0x391, 0x399, 0x0},
  {0x1FBE, 0x399, 0x0, 0x0},
  {0x1FC2, 0x1FCA, 0x399, 0x0},
  {0x1FC3, 0x397, 0x399, 0x0},
  {0x1FC4, 0x389, 0x399, 0x0},
  {0x1FC6, 0x397, 0x342, 0x0},
  {0x1FC7, 0x397, 0x342, 0x399},
  {0x1FCC, 0x397, 0x399, 0x0},
  {0x1FD0, 0x1FD8, 0x0, 0x0},
  {0x1FD1, 0x1FD9, 0x0, 0x0},
  {0x1FD2, 0x399, 0x308, 0x300},
  {0x1FD3, 0x399, 0x308, 0x301},
  {0x1FD6, 0x399, 0x342, 0x0},
  {0x1FD7, 0x399, 0x308, 0x342},
  {0x1FE0, 0x1FE8, 0x0, 0x0},
  {0x1FE1, 0x1FE9, 0x0, 0x0},
  {0x1FE2, 0x3A5, 0x308, 0x300},
  {0x1FE3, 0x3A5, 0x308, 0x301},
  {0x1FE4, 0x3A1, 0x313, 0x0},
  {0x1FE5, 0x1FEC, 0x0, 0x0},
  {0x1FE6, 0x3A5, 0x342, 0x0},
  {0x1FE7, 0x3A5, 0x308, 0x342},
  {0x1FF2, 0x1FFA, 0x399, 0x0},
  {0x1FF3, 0x3A9, 0x399, 0x0},
  {0x1FF4, 0x38F, 0x399, 0x0},
  {0x1FF6, 0x3A9, 0x342, 0x0},
  {0x1FF7, 0x3A9, 0x342, 0x399},
  {0x1FFC, 0x3A9, 0x399, 0x0},
  {0x214E, 0x2132, 0x0, 0x0},
  {0x2170, 0x2160, 0x0, 0x0},
  {0x2171, 0x2161, 0x0, 0x0},
  {0x2172, 0x2162, 0x0, 0x0},
  {0x2173, 0x2163, 0x0, 0x0},
  {0x2174, 0x2164, 0x0, 0x0},
  {0x2175, 0x2165, 0x0, 0x0},
  {0x2176, 0x2166, 0x0, 0x0},
  {0x2177, 0x2167, 0x0, 0x0},
  {0x2178, 0x2168, 0x0, 0x0},
  {0x2179, 0x2169, 0x0, 0x0},
  {0x217A, 0x216A, 0x0, 0x0},
  {0x217B, 0x216B, 0x0, 0x0},
  {0x217C, 0x216C, 0x0, 0x0},
  {0x217D, 0x216D, 0x0, 0x0},
  {0x217E, 0x216E, 0x0, 0x0},
  {0x217F, 0x216F, 0x0, 0x0},
  {0x2184, 0x2183, 0x0, 0x0},
  {0x24D0, 0x24B6, 0x0, 0x0},
  {0x24D1, 0x24B7, 0x0, 0x0},
  {0x24D2, 0x24B8, 0x0, 0x0},
  {0x24D3, 0x24B9, 0x0, 0x0},
  {0x24D4, 0x24BA, 0x0, 0x0},
  {0x24D5, 0x24BB, 0x0, 0x0},
  {0x24D6, 0x24BC, 0x0, 0x0},
  {0x24D7, 0x24BD, 0x0, 0x0},
  {0x24D8, 0x24BE, 0x0, 0x0},
  {0x24D9, 0x24BF, 0x0, 0x0},
  {0x24DA, 0x24C0, 0x0, 0x0},
  {0x24DB, 0x24C1, 0x0, 0x0},
  {0x24DC, 0x24C2, 0x0, 0x0},
  {0x24DD, 0x24C3, 0x0, 0x0},
  {0x24DE, 0x24C4, 0x0, 0x0},
  {0x24DF, 0x24C5, 0x0, 0x0},
  {0x24E0, 0x24C6, 0x0, 0x0},
  {0x24E1, 0x24C7, 0x0, 0x0},
  {0x24E2, 0x24C8, 0x0, 0x0},
  {0x24E3, 0x24C9, 0x0, 0x0},
  {0x24E4, 0x24CA, 0x0, 0x0},
  {0x24E5, 0x24CB, 0x0, 0x0},
  {0x24E6, 0x24CC, 0x0, 0x0},
  {0x24E7, 0x24CD, 0x0, 0x0},
  {0x24E8, 0x24CE, 0x0, 0x0},
  {0x24E9, 0x24CF, 0x0, 0x0},
  {0x2C30, 0x2C00, 0x0, 0x0},
  {0x2C31, 0x2C01, 0x0, 0x0},
  {0x2C32, 0x2C02, 0x0, 0x0},
  {0x2C33, 0x2C03, 0x0, 0x0},
  {0x2C34, 0x2C04, 0x0, 0x0},
  {0x2C35, 0x2C05, 0x0, 0x0},
  {0x2C36, 0x2C06, 0x0, 0x0},
  {0x2C37, 0x2C07, 0x0, 0x0},
  {0x2C38, 0x2C08, 0x0, 0x0},
  {0x2C39, 0x2C09, 0x0, 0x0},
  {0x2C3A, 0x2C0A, 0x0, 0x0},
  {0x2C3B, 0x2C0B, 0x0, 0x0},
  {0x2C3C, 0x2C0C, 0x0, 0x0},
  {0x2C3D, 0x2C0D, 0x0, 0x0},
  {0x2C3E, 0x2C0E, 0x0, 0x0},
  {0x2C3F, 0x2C0F, 0x0, 0x0},
  {0x2C40, 0x2C10, 0x0, 0x0},
  {0x2C41, 0x2C11, 0x0, 0x0},
  {0x2C42, 0x2C12, 0x0, 0x0},
  {0x2C43, 0x2C13, 0x0, 0x0},
  {0x2C44, 0x2C14, 0x0, 0x0},
  {0x2C45, 0x2C15, 0x0, 0x0},
  {0x2C46, 0x2C16, 0x0, 0x0},
  {0x2C47, 0x2C17, 0x0, 0x0},
  {0x2C48, 0x2C18, 0x0, 0x0},
  {0x2C49, 0x2C19, 0x0, 0x0},
  {0x2C4A, 0x2C1A, 0x0, 0x0},
  {0x2C4B, 0x2C1B, 0x0, 0x0},
  {0x2C4C, 0x2C1C, 0x0, 0x0},
  {0x2C4D, 0x2C1D, 0x0, 0x0},
  {0x2C4E, 0x2C1E, 0x0, 0x0},
  {0x2C4F, 0x2C1F, 0x0, 0x0},
  {0x2C50, 0x2C20, 0x0, 0x0},
  {0x2C51, 0x2C21, 0x0, 0x0},
  {0x2C52, 0x2C22, 0x0, 0x0},
  {0x2C53, 0x2C23, 0x0, 0x0},
  {0x2C54, 0x2C24, 0x0, 0x0},
  {0x2C55, 0x2C25, 0x0, 0x0},
  {0x2C56, 0x2C26, 0x0, 0x0},
  {0x2C57, 0x2C27, 0x0, 0x0},
  {0x2C58, 0x2C28, 0x0, 0x0},
  {0x2C59, 0x2C29, 0x0, 0x0},
  {0x2C5A, 0x2C2A, 0x0, 0x0},
  {0x2C5B, 0x2C2B, 0x0, 0x0},
  {0x2C5C, 0x2C2C, 0x0, 0x0},
  {0x2C5D, 0x2C2D, 0x0, 0x0},
  {0x2C5E, 0x2C2E, 0x0, 0x0},
  {0x2C5F, 0x2C2F, 0x0, 0x0},
  {0x2C61, 0x2C60, 0x0, 0x0},
  {0x2C65, 0x23A, 0x0, 0x0},
  {0x2C66, 0x23E, 0x0, 0x0},
  {0x2C68, 0x2C67, 0x0, 0x0},
  {0x2C6A, 0x2C69, 0x0, 0x0},
  {0x2C6C, 0x2C6B, 0x0, 0x0},
  {0x2C73, 0x2C72, 0x0, 0x0},
  {0x2C76, 0x2C75, 0x0, 0x0},
  {0x2C81, 0x2C80, 0x0, 0x0},
  {0x2C83, 0x2C82, 0x0, 0x0},
  {0x2C85, 0x2C84, 0x0, 0x0},
  {0x2C87, 0x2C86, 0x0, 0x0},
  {0x2C89, 0x2C88, 0x0, 0x0},
  {0x2C8B, 0x2C8A, 0x0, 0x0},
  {0x2C8D, 0x2C8C, 0x0, 0x0},
  {0x2C8F, 0x2C8E, 0x0, 0x0},
  {0x2C91, 0x2C90, 0x0, 0x0},
  {0x2C93, 0x2C92, 0x0, 0x0},
  {0x2C95, 0x2C94, 0x0, 0x0},
  {0x2C97, 0x2C96, 0x0, 0x0},
  {0x2C99, 0x2C98, 0x0, 0x0},
  {0x2C9B, 0x2C9A, 0x0, 0x0},
  {0x2C9D, 0x2C9C, 0x0, 0x0},
  {0x2C9F, 0x2C9E, 0x0, 0x0},
  {0x2CA1, 0x2CA0, 0x0, 0x0},
  {0x2CA3, 0x2CA2, 0x0, 0x0},
  {0x2CA5, 0x2CA4, 0x0, 0x0},
  {0x2CA7, 0x2CA6, 0x0, 0x0},
  {0x2CA9, 0x2CA8, 0x0, 0x0},
  {0x2CAB, 0x2CAA, 0x0, 0x0},
  {0x2CAD, 0x2CAC, 0x0, 0x0},
  {0x2CAF, 0x2CAE, 0x0, 0x0},
  {0x2CB1, 0x2CB0, 0x0, 0x0},
  {0x2CB3, 0x2CB2, 0x0, 0x0},
  {0x2CB5, 0x2CB4, 0x0, 0x0},
  {0x2CB7, 0x2CB6, 0x0, 0x0},
  {0x2CB9, 0x2CB8, 0x0, 0x0},
  {0x2CBB, 0x2CBA, 0x0, 0x0},
  {0x2CBD, 0x2CBC, 0x0, 0x0},
  {0x2CBF, 0x2CBE, 0x0, 0x0},
  {0x2CC1, 0x2CC0, 0x0, 0x0},
  {0x2CC3, 0x2CC2, 0x0, 0x0},
  {0x2CC5, 0x2CC4, 0x0, 0x0},
  {0x2CC7, 0x2CC6, 0x0, 0x0},
  {0x2CC9, 0x2CC8, 0x0, 0x0},
  {0x2CCB, 0x2CCA, 0x0, 0x0},
  {0x2CCD, 0x2CCC, 0x0, 0x0},
  {0x2CCF, 0x2CCE, 0x0, 0x0},
  {0x2CD1, 0x2CD0, 0x0, 0x0},
  {0x2CD3, 0x2CD2, 0x0, 0x0},
  {0x2CD5, 0x2CD4, 0x0, 0x0},
  {0x2CD7, 0x2CD6, 0x0, 0x0},
  {0x2CD9, 0x2CD8, 0x0, 0x0},
  {0x2CDB, 0x2CDA, 0x0, 0x0},
  {0x2CDD, 0x2CDC, 0x0, 0x0},
  {0x2CDF, 0x2CDE, 0x0, 0x0},
  {0x2CE1, 0x2CE0, 0x0, 0x0},
  {0x2CE3, 0x2CE2, 0x0, 0x0},
  {0x2CEC, 0x2CEB, 0x0, 0x0},
  {0x2CEE, 0x2CED, 0x0, 0x0},
  {0x2CF3, 0x2CF2, 0x0, 0x0},
  {0x2D00, 0x10A0, 0x0, 0x0},
  {0x2D01, 0x10A1, 0x0, 0x0},
  {0x2D02, 0x10A2, 0x0, 0x0},
  {0x2D03, 0x10A3, 0x0, 0x0},
  {0x2D04, 0x10A4, 0x0, 0x0},
  {0x2D05, 0x10A5, 0x0, 0x0},
  {0x2D06, 0x10A6, 0x0, 0x0},
  {0x2D07, 0x10A7, 0x0, 0x0},
  {0x2D08, 0x10A8, 0x0, 0x0},
  {0x2D09, 0x10A9, 0x0, 0x0},
  {0x2D0A, 0x10AA, 0x0, 0x0},
  {0x2D0B, 0x10AB, 0x0, 0x0},
  {0x2D0C, 0x10AC, 0x0, 0x0},
  {0x2D0D, 0x10AD, 0x0, 0x0},
  {0x2D0E, 0x10AE, 0x0, 0x0},
  {0x2D0F, 0x10AF, 0x0, 0x0},
  {0x2D10, 0x10B0, 0x0, 0x0},
  {0x2D11, 0x10B1, 0x0, 0x0},
  {0x2D12, 0x10B2, 0x0, 0x0},
  {0x2D13, 0x10B3, 0x0, 0x0},
  {0x2D14, 0x10B4, 0x0, 0x0},
  {0x2D15, 0x10B5, 0x0, 0x0},
  {0x2D16, 0x10B6, 0x0, 0x0},
  {0x2D17, 0x10B7, 0x0, 0x0},
  {0x2D18, 0x10B8, 0x0, 0x0},
  {0x2D19, 0x10B9, 0x0, 0x0},
  {0x2D1A, 0x10BA, 0x0, 0x0},
  {0x2D1B, 0x10BB, 0x0, 0x0},
  {0x2D1C, 0x10BC, 0x0, 0x0},
  {0x2D1D, 0x10BD, 0x0, 0x0},
  {0x2D1E, 0x10BE, 0x0, 0x0},
  {0x2D1F, 0x10BF, 0x0, 0x0},
  {0x2D20, 0x10C0, 0x0, 0x0},
  {0x2D21, 0x10C1, 0x0, 0x0},
  {0x2D22, 0x10C2, 0x0, 0x0},
  {0x2D23, 0x10C3, 0x0, 0x0},
  {0x2D24, 0x10C4, 0x0, 0x0},
  {0x2D25, 0x10C5, 0x0, 0x0},
  {0x2D27, 0x10C7, 0x0, 0x0},
  {0x2D2D, 0x10CD, 0x0, 0x0},
  {0xA641, 0xA640, 0x0, 0x0},
  {0xA643, 0xA642, 0x0, 0x0},
  {0xA645, 0xA644, 0x0, 0x0},
  {0xA647, 0xA646, 0x0, 0x0},
  {0xA649, 0xA648, 0x0, 0x0},
  {0xA64B, 0xA64A, 0x0, 0x0},
  {0xA64D, 0xA64C, 0x0, 0x0},
  {0xA64F, 0xA64E, 0x0, 0x0},
  {0xA651, 0xA650, 0x0, 0x0},
  {0xA653, 0xA652, 0x0, 0x0},
  {0xA655, 0xA654, 0x0, 0x0},
  {0xA657, 0xA656, 0x0, 0x0},
  {0xA659, 0xA658, 0x0, 0x0},
  {0xA65B, 0xA65A, 0x0, 0x0},
  {0xA65D, 0xA65C, 0x0, 0x0},
  {0xA65F, 0xA65E, 0x0, 0x0},
  {0xA661, 0xA660, 0x0, 0x0},
  {0xA663, 0xA662, 0x0, 0x0},
  {0xA665, 0xA664, 0x0, 0x0},
  {0xA667, 0xA666, 0x0, 0x0},
  {0xA669, 0xA668, 0x0, 0x0},
  {0xA66B, 0xA66A, 0x0, 0x0},
  {0xA66D, 0xA66C, 0x0, 0x0},
  {0xA681, 0xA680, 0x0, 0x0},
  {0xA683, 0xA682, 0x0, 0x0},
  {0xA685, 0xA684, 0x0, 0x0},
  {0xA687, 0xA686, 0x0, 0x0},
  {0xA689, 0xA688, 0x0, 0x0},
  {0xA68B, 0xA68A, 0x0, 0x0},
  {0xA68D, 0xA68C, 0x0, 0x0},
  {0xA68F, 0xA68E, 0x0, 0x0},
  {0xA691, 0xA690, 0x0, 0x0},
  {0xA693, 0xA692, 0x0, 0x0},
  {0xA695, 0xA694, 0x0, 0x0},
  {0xA697, 0xA696, 0x0, 0x0},
  {0xA699, 0xA698, 0x0, 0x0},
  {0xA69B, 0xA69A, 0x0, 0x0},
  {0xA723, 0xA722, 0x0, 0x0},
  {0xA725, 0xA724, 0x0, 0x0},
  {0xA727, 0xA726, 0x0, 0x0},
  {0xA729, 0xA728, 0x0, 0x0},
  {0xA72B, 0xA72A, 0x0, 0x0},
  {0xA72D, 0xA72C, 0x0, 0x0},
  {0xA72F, 0xA72E, 0x0, 0x0},
  {0xA733, 0xA732, 0x0, 0x0},
  {0xA735, 0xA734, 0x0, 0x0},
  {0xA737, 0xA736, 0x0, 0x0},
  {0xA739, 0xA738, 0x0, 0x0},
  {0xA73B, 0xA73A, 0x0, 0x0},
  {0xA73D, 0xA73C, 0x0, 0x0},
  {0xA73F, 0xA73E, 0x0, 0x0},
  {0xA741, 0xA740, 0x0, 0x0},
  {0xA743, 0xA742, 0x0, 0x0},
  {0xA745, 0xA744, 0x0, 0x0},
  {0xA747, 0xA746, 0x0, 0x0},
  {0xA749, 0xA748, 0x0, 0x0},
  {0xA74B, 0xA74A, 0x0, 0x0},
  {0xA74D, 0xA74C, 0x0, 0x0},
  {0xA74F, 0xA74E, 0x0, 0x0},
  {0xA751, 0xA750, 0x0, 0x0},
  {0xA753, 0xA752, 0x0, 0x0},
  {0xA755, 0xA754, 0x0, 0x0},
  {0xA757, 0xA756, 0x0, 0x0},
  {0xA759, 0xA758, 0x0, 0x0},
  {0xA75B, 0xA75A, 0x0, 0x0},
  {0xA75D, 0xA75C, 0x0, 0x0},
  {0xA75F, 0xA75E, 0x0, 0x0},
  {0xA761, 0xA760, 0x0, 0x0},
  {0xA763, 0xA762, 0x0, 0x0},
  {0xA765, 0xA764, 0x0, 0x0},
  {0xA767, 0xA766, 0x0, 0x0},
  {0xA769, 0xA768, 0x0, 0x0},
  {0xA76B, 0xA76A, 0x0, 0x0},
  {0xA76D, 0xA76C, 0x0, 0x0},
  {0xA76F, 0xA76E, 0x0, 0x0},
  {0xA77A, 0xA779, 0x0, 0x0},
  {0xA77C, 0xA77B, 0x0, 0x0},
  {0xA77F, 0xA77E, 0x0, 0x0},
  {0xA781, 0xA780, 0x0, 0x0},
  {0xA783, 0xA782, 0x0, 0x0},
  {0xA785, 0xA784, 0x0, 0x0},
  {0xA787, 0xA786, 0x0, 0x0},
  {0xA78C, 0xA78B, 0x0, 0x0},
  {0xA791, 0xA790, 0x0, 0x0},
  {0xA793, 0xA792, 0x0, 0x0},
  {0xA794, 0xA7C4, 0x0, 0x0},
  {0xA797, 0xA796, 0x0, 0x0},
  {0xA799, 0xA798, 0x0, 0x0},
  {0xA79B, 0xA79A, 0x0, 0x0},
  {0xA79D, 0xA79C, 0x0, 0x0},
  {0xA79F, 0xA79E, 0x0, 0x0},
  {0xA7A1, 0xA7A0, 0x0, 0x0},
  {0xA7A3, 0xA7A2, 0x0, 0x0},
  {0xA7A5, 0xA7A4, 0x0, 0x0},
  {0xA7A7, 0xA7A6, 0x0, 0x0},
  {0xA7A9, 0xA7A8, 0x0, 0x0},
  {0xA7B5, 0xA7B4, 0x0, 0x0},
  {0xA7B7, 0xA7B6, 0x0, 0x0},
  {0xA7B9, 0xA7B8, 0x0, 0x0},
  {0xA7BB, 0xA7BA, 0x0, 0x0},
  {0xA7BD, 0xA7BC, 0x0, 0x0},
  {0xA7BF, 0xA7BE, 0x0, 0x0},
  {0xA7C1, 0xA7C0, 0x0, 0x0},
  {0xA7C3, 0xA7C2, 0x0, 0x0},
  {0xA7C8, 0xA7C7, 0x0, 0x0},
  {0xA7CA, 0xA7C9, 0x0, 0x0},
  {0xA7CD, 0xA7CC, 0x0, 0x0},
  {0xA7CF, 0xA7CE, 0x0, 0x0},
  {0xA7D1, 0xA7D0, 0x0, 0x0},
  {0xA7D3, 0xA7D2, 0x0, 0x0},
  {0xA7D5, 0xA7D4, 0x0, 0x0},
  {0xA7D7, 0xA7D6, 0x0, 0x0},
  {0xA7D9, 0xA7D8, 0x0, 0x0},
  {0xA7DB, 0xA7DA, 0x0, 0x0},
  {0xA7F6, 0xA7F5, 0x0, 0x0},
  {0xAB53, 0xA7B3, 0x0, 0x0},
  {0xAB70, 0x13A0, 0x0, 0x0},
  {0xAB71, 0x13A1, 0x0, 0x0},
  {0xAB72, 0x13A2, 0x0, 0x0},
  {0xAB73, 0x13A3, 0x0, 0x0},
  {0xAB74, 0x13A4, 0x0, 0x0},
  {0xAB75, 0x13A5, 0x0, 0x0},
  {0xAB76, 0x13A6, 0x0, 0x0},
  {0xAB77, 0x13A7, 0x0, 0x0},
  {0xAB78, 0x13A8, 0x0, 0x0},
  {0xAB79, 0x13A9, 0x0, 0x0},
  {0xAB7A, 0x13AA, 0x0, 0x0},
  {0xAB7B, 0x13AB, 0x0, 0x0},
  {0xAB7C, 0x13AC, 0x0, 0x0},
  {0xAB7D, 0x13AD, 0x0, 0x0},
  {0xAB7E, 0x13AE, 0x0, 0x0},
  {0xAB7F, 0x13AF, 0x0, 0x0},
  {0xAB80, 0x13B0, 0x0, 0x0},
  {0xAB81, 0x13B1, 0x0, 0x0},
  {0xAB82, 0x13B2, 0x0, 0x0},
  {0xAB83, 0x13B3, 0x0, 0x0},
  {0xAB84, 0x13B4, 0x0, 0x0},
  {0xAB85, 0x13B5, 0x0, 0x0},
  {0xAB86, 0x13B6, 0x0, 0x0},
  {0xAB87, 0x13B7, 0x0, 0x0},
  {0xAB88, 0x13B8, 0x0, 0x0},
  {0xAB89, 0x13B9, 0x0, 0x0},
  {0xAB8A, 0x13BA, 0x0, 0x0},
  {0xAB8B, 0x13BB, 0x0, 0x0},
  {0xAB8C, 0x13BC, 0x0, 0x0},
  {0xAB8D, 0x13BD, 0x0, 0x0},
  {0xAB8E, 0x13BE, 0x0, 0x0},
  {0xAB8F, 0x13BF, 0x0, 0x0},
  {0xAB90, 0x13C0, 0x0, 0x0},
  {0xAB91, 0x13C1, 0x0, 0x0},
  {0xAB92, 0x13C2, 0x0, 0x0},
  {0xAB93, 0x13C3, 0x0, 0x0},
  {0xAB94, 0x13C4, 0x0, 0x0},
  {0xAB95, 0x13C5, 0x0, 0x0},
  {0xAB96, 0x13C6, 0x0, 0x0},
  {0xAB97, 0x13C7, 0x0, 0x0},
  {0xAB98, 0x13C8, 0x0, 0x0},
  {0xAB99, 0x13C9, 0x0, 0x0},
  {0xAB9A, 0x13CA, 0x0, 0x0},
  {0xAB9B, 0x13CB, 0x0, 0x0},
  {0xAB9C, 0x13CC, 0x0, 0x0},
  {0xAB9D, 0x13CD, 0x0, 0x0},
  {0xAB9E, 0x13CE, 0x0, 0x0},
  {0xAB9F, 0x13CF, 0x0, 0x0},
  {0xABA0, 0x13D0, 0x0, 0x0},
  {0xABA1, 0x13D1, 0x0, 0x0},
  {0xABA2, 0x13D2, 0x0, 0x0},
  {0xABA3, 0x13D3, 0x0, 0x0},
  {0xABA4, 0x13D4, 0x0, 0x0},
  {0xABA5, 0x13D5, 0x0, 0x0},
  {0xABA6, 0x13D6, 0x0, 0x0},
  {0xABA7, 0x13D7, 0x0, 0x0},
  {0xABA8, 0x13D8, 0x0, 0x0},
  {0xABA9, 0x13D9, 0x0, 0x0},
  {0xABAA, 0x13DA, 0x0, 0x0},
  {0xABAB, 0x13DB, 0x0, 0x0},
  {0xABAC, 0x13DC, 0x0, 0x0},
  {0xABAD, 0x13DD, 0x0, 0x0},
  {0xABAE, 0x13DE, 0x0, 0x0},
  {0xABAF, 0x13DF, 0x0, 0x0},
  {0xABB0, 0x13E0, 0x0, 0x0},
  {0xABB1, 0x13E1, 0x0, 0x0},
  {0xABB2, 0x13E2, 0x0, 0x0},
  {0xABB3, 0x13E3, 0x0, 0x0},
  {0xABB4, 0x13E4, 0x0, 0x0},
  {0xABB5, 0x13E5, 0x0, 0x0},
  {0xABB6, 0x13E6, 0x0, 0x0},
  {0xABB7, 0x13E7, 0x0, 0x0},
  {0xABB8, 0x13E8, 0x0, 0x0},
  {0xABB9, 0x13E9, 0x0, 0x0},
  {0xABBA, 0x13EA, 0x0, 0x0},
  {0xABBB, 0x13EB, 0x0, 0x0},
  {0xABBC, 0x13EC, 0x0, 0x0},
  {0xABBD, 0x13ED, 0x0, 0x0},
  {0xABBE, 0x13EE, 0x0, 0x0},
  {0xABBF, 0x13EF, 0x0, 0x0},
  {0xFB00, 0x46, 0x46, 0x0},
  {0xFB01, 0x46, 0x49, 0x0},
  {0xFB02, 0x46, 0x4C, 0x0},
  {0xFB03, 0x46, 0x46, 0x49},
  {0xFB04, 0x46, 0x46, 0x4C},
  {0xFB05, 0x53, 0x54, 0x0},
  {0xFB06, 0x53, 0x54, 0x0},
  {0xFB13, 0x544, 0x546, 0x0},
  {0xFB14, 0x544, 0x535, 0x0},
  {0xFB15, 0x544, 0x53B, 0x0},
  {0xFB16, 0x54E, 0x546, 0x0},
  {0xFB17, 0x544, 0x53D, 0x0},
  {0xFF41, 0xFF21, 0x0, 0x0},
  {0xFF42, 0xFF22, 0x0, 0x0},
  {0xFF43, 0xFF23, 0x0, 0x0},
  {0xFF44, 0xFF24, 0x0, 0x0},
  {0xFF45, 0xFF25, 0x0, 0x0},
  {0xFF46, 0xFF26, 0x0, 0x0},
  {0xFF47, 0xFF27, 0x0, 0x0},
  {0xFF48, 0xFF28, 0x0, 0x0},
  {0xFF49, 0xFF29, 0x0, 0x0},
  {0xFF4A, 0xFF2A, 0x0, 0x0},
  {0xFF4B, 0xFF2B, 0x0, 0x0},
  {0xFF4C, 0xFF2C, 0x0, 0x0},
  {0xFF4D, 0xFF2D, 0x0, 0x0},
  {0xFF4E, 0xFF2E, 0x0, 0x0},
  {0xFF4F, 0xFF2F, 0x0, 0x0},
  {0xFF50, 0xFF30, 0x0, 0x0},
  {0xFF51, 0xFF31, 0x0, 0x0},
  {0xFF52, 0xFF32, 0x0, 0x0},
  {0xFF53, 0xFF33, 0x0, 0x0},
  {0xFF54, 0xFF34, 0x0, 0x0},
  {0xFF55, 0xFF35, 0x0, 0x0},
  {0xFF56, 0xFF36, 0x0, 0x0},
  {0xFF57, 0xFF37, 0x0, 0x0},
  {0xFF58, 0xFF38, 0x0, 0x0},
  {0xFF59, 0xFF39, 0x0, 0x0},
  {0xFF5A, 0xFF3A, 0x0, 0x0},
  {0x10428, 0x10400, 0x0, 0x0},
  {0x10429, 0x10401, 0x0, 0x0},
  {0x1042A, 0x10402, 0x0, 0x0},
  {0x1042B, 0x10403, 0x0, 0x0},
  {0x1042C, 0x10404, 0x0, 0x0},
  {0x1042D, 0x10405, 0x0, 0x0},
  {0x1042E, 0x10406, 0x0, 0x0},
  {0x1042F, 0x10407, 0x0, 0x0},
  {0x10430, 0x10408, 0x0, 0x0},
  {0x10431, 0x10409, 0x0, 0x0},
  {0x10432, 0x1040A, 0x0, 0x0},
  {0x10433, 0x1040B, 0x0, 0x0},
  {0x10434, 0x1040C, 0x0, 0x0},
  {0x10435, 0x1040D, 0x0, 0x0},
  {0x10436, 0x1040E, 0x0, 0x0},
  {0x10437, 0x1040F, 0x0, 0x0},
  {0x10438, 0x10410, 0x0, 0x0},
  {0x10439, 0x10411, 0x0, 0x0},
  {0x1043A, 0x10412, 0x0, 0x0},
  {0x1043B, 0x10413, 0x0, 0x0},
  {0x1043C, 0x10414, 0x0, 0x0},
  {0x1043D, 0x10415, 0x0, 0x0},
  {0x1043E, 0x10416, 0x0, 0x0},
  {0x1043F, 0x10417, 0x0, 0x0},
  {0x10440, 0x10418, 0x0, 0x0},
  {0x10441, 0x10419, 0x0, 0x0},
  {0x10442, 0x1041A, 0x0, 0x0},
  {0x10443, 0x1041B, 0x0, 0x0},
  {0x10444, 0x1041C, 0x0, 0x0},
  {0x10445, 0x1041D, 0x0, 0x0},
  {0x10446, 0x1041E, 0x0, 0x0},
  {0x10447, 0x1041F, 0x0, 0x0},
  {0x10448, 0x10420, 0x0, 0x0},
  {0x10449, 0x10421, 0x0, 0x0},
  {0x1044A, 0x10422, 0x0, 0x0},
  {0x1044B, 0x10423, 0x0, 0x0},
  {0x1044C, 0x10424, 0x0, 0x0},
  {0x1044D, 0x10425, 0x0, 0x0},
  {0x1044E, 0x10426, 0x0, 0x0},
  {0x1044F, 0x10427, 0x0, 0x0},
  {0x104D8, 0x104B0, 0x0, 0x0},
  {0x104D9, 0x104B1, 0x0, 0x0},
  {0x104DA, 0x104B2, 0x0, 0x0},
  {0x104DB, 0x104B3, 0x0, 0x0},
  {0x104DC, 0x104B4, 0x0, 0x0},
  {0x104DD, 0x104B5, 0x0, 0x0},
  {0x104DE, 0x104B6, 0x0, 0x0},
  {0x104DF, 0x104B7, 0x0, 0x0},
  {0x104E0, 0x104B8, 0x0, 0x0},
  {0x104E1, 0x104B9, 0x0, 0x0},
  {0x104E2, 0x104BA, 0x0, 0x0},
  {0x104E3, 0x104BB, 0x0, 0x0},
  {0x104E4, 0x104BC, 0x0, 0x0},
  {0x104E5, 0x104BD, 0x0, 0x0},
  {0x104E6, 0x104BE, 0x0, 0x0},
  {0x104E7, 0x104BF, 0x0, 0x0},
  {0x104E8, 0x104C0, 0x0, 0x0},
  {0x104E9, 0x104C1, 0x0, 0x0},
  {0x104EA, 0x104C2, 0x0, 0x0},
  {0x104EB, 0x104C3, 0x0, 0x0},
  {0x104EC, 0x104C4, 0x0, 0x0},
  {0x104ED, 0x104C5, 0x0, 0x0},
  {0x104EE, 0x104C6, 0x0, 0x0},
  {0x104EF, 0x104C7, 0x0, 0x0},
  {0x104F0, 0x104C8, 0x0, 0x0},
  {0x104F1, 0x104C9, 0x0, 0x0},
  {0x104F2, 0x104CA, 0x0, 0x0},
  {0x104F3, 0x104CB, 0x0, 0x0},
  {0x104F4, 0x104CC, 0x0, 0x0},
  {0x104F5, 0x104CD, 0x0, 0x0},
  {0x104F6, 0x104CE, 0x0, 0x0},
  {0x104F7, 0x104CF, 0x0, 0x0},
  {0x104F8, 0x104D0, 0x0, 0x0},
  {0x104F9, 0x104D1, 0x0, 0x0},
  {0x104FA, 0x104D2, 0x0, 0x0},
  {0x104FB, 0x104D3, 0x0, 0x0},
  {0x10597, 0x10570, 0x0, 0x0},
  {0x10598, 0x10571, 0x0, 0x0},
  {0x10599, 0x10572, 0x0, 0x0},
  {0x1059A, 0x10573, 0x0, 0x0},
  {0x1059B, 0x10574, 0x0, 0x0},
  {0x1059C, 0x10575, 0x0, 0x0},
  {0x1059D, 0x10576, 0x0, 0x0},
  {0x1059E, 0x10577, 0x0, 0x0},
  {0x1059F, 0x10578, 0x0, 0x0},
  {0x105A0, 0x10579, 0x0, 0x0},
  {0x105A1, 0x1057A, 0x0, 0x0},
  {0x105A3, 0x1057C, 0x0, 0x0},
  {0x105A4, 0x1057D, 0x0, 0x0},
  {0x105A5, 0x1057E, 0x0, 0x0},
  {0x105A6, 0x1057F, 0x0, 0x0},
  {0x105A7, 0x10580, 0x0, 0x0},
  {0x105A8, 0x10581, 0x0, 0x0},
  {0x105A9, 0x10582, 0x0, 0x0},
  {0x105AA, 0x10583, 0x0, 0x0},
  {0x105AB, 0x10584, 0x0, 0x0},
  {0x105AC, 0x10585, 0x0, 0x0},
  {0x105AD, 0x10586, 0x0, 0x0},
  {0x105AE, 0x10587, 0x0, 0x0},
  {0x105AF, 0x10588, 0x0, 0x0},
  {0x105B0, 0x10589, 0x0, 0x0},
  {0x105B1, 0x1058A, 0x0, 0x0},
  {0x105B3, 0x1058C, 0x0, 0x0},
  {0x105B4, 0x1058D, 0x0, 0x0},
  {0x105B5, 0x1058E, 0x0, 0x0},
  {0x105B6, 0x1058F, 0x0, 0x0},
  {0x105B7, 0x10590, 0x0, 0x0},
  {0x105B8, 0x10591, 0x0, 0x0},
  {0x105B9, 0x10592, 0x0, 0x0},
  {0x105BB, 0x10594, 0x0, 0x0},
  {0x105BC, 0x10595, 0x0, 0x0},
  {0x10CC0, 0x10C80, 0x0, 0x0},
  {0x10CC1, 0x10C81, 0x0, 0x0},
  {0x10CC2, 0x10C82, 0x0, 0x0},
  {0x10CC3, 0x10C83, 0x0, 0x0},
  {0x10CC4, 0x10C84, 0x0, 0x0},
  {0x10CC5, 0x10C85, 0x0, 0x0},
  {0x10CC6, 0x10C86, 0x0, 0x0},
  {0x10CC7, 0x10C87, 0x0, 0x0},
  {0x10CC8, 0x10C88, 0x0, 0x0},
  {0x10CC9, 0x10C89, 0x0, 0x0},
  {0x10CCA, 0x10C8A, 0x0, 0x0},
  {0x10CCB, 0x10C8B, 0x0, 0x0},
  {0x10CCC, 0x10C8C, 0x0, 0x0},
  {0x10CCD, 0x10C8D, 0x0, 0x0},
  {0x10CCE, 0x10C8E, 0x0, 0x0},
  {0x10CCF, 0x10C8F, 0x0, 0x0},
  {0x10CD0, 0x10C90, 0x0, 0x0},
  {0x10CD1, 0x10C91, 0x0, 0x0},
  {0x10CD2, 0x10C92, 0x0, 0x0},
  {0x10CD3, 0x10C93, 0x0, 0x0},
  {0x10CD4, 0x10C94, 0x0, 0x0},
  {0x10CD5, 0x10C95, 0x0, 0x0},
  {0x10CD6, 0x10C96, 0x0, 0x0},
  {0x10CD7, 0x10C97, 0x0, 0x0},
  {0x10CD8, 0x10C98, 0x0, 0x0},
  {0x10CD9, 0x10C99, 0x0, 0x0},
  {0x10CDA, 0x10C9A, 0x0, 0x0},
  {0x10CDB, 0x10C9B, 0x0, 0x0},
  {0x10CDC, 0x10C9C, 0x0, 0x0},
  {0x10CDD, 0x10C9D, 0x0, 0x0},
  {0x10CDE, 0x10C9E, 0x0, 0x0},
  {0x10CDF, 0x10C9F, 0x0, 0x0},
  {0x10CE0, 0x10CA0, 0x0, 0x0},
  {0x10CE1, 0x10CA1, 0x0, 0x0},
  {0x10CE2, 0x10CA2, 0x0, 0x0},
  {0x10CE3, 0x10CA3, 0x0, 0x0},
  {0x10CE4, 0x10CA4, 0x0, 0x0},
  {0x10CE5, 0x10CA5, 0x0, 0x0},
  {0x10CE6, 0x10CA6, 0x0, 0x0},
  {0x10CE7, 0x10CA7, 0x0, 0x0},
  {0x10CE8, 0x10CA8, 0x0, 0x0},
  {0x10CE9, 0x10CA9, 0x0, 0x0},
  {0x10CEA, 0x10CAA, 0x0, 0x0},
  {0x10CEB, 0x10CAB, 0x0, 0x0},
  {0x10CEC, 0x10CAC, 0x0, 0x0},
  {0x10CED, 0x10CAD, 0x0, 0x0},
  {0x10CEE, 0x10CAE, 0x0, 0x0},
  {0x10CEF, 0x10CAF, 0x0, 0x0},
  {0x10CF0, 0x10CB0, 0x0, 0x0},
  {0x10CF1, 0x10CB1, 0x0, 0x0},
  {0x10CF2, 0x10CB2, 0x0, 0x0},
  {0x10D70, 0x10D50, 0x0, 0x0},
  {0x10D71, 0x10D51, 0x0, 0x0},
  {0x10D72, 0x10D52, 0x0, 0x0},
  {0x10D73, 0x10D53, 0x0, 0x0},
  {0x10D74, 0x10D54, 0x0, 0x0},
  {0x10D75, 0x10D55, 0x0, 0x0},
  {0x10D76, 0x10D56, 0x0, 0x0},
  {0x10D77, 0x10D57, 0x0, 0x0},
  {0x10D78, 0x10D58, 0x0, 0x0},
  {0x10D79, 0x10D59, 0x0, 0x0},
  {0x10D7A, 0x10D5A, 0x0, 0x0},
  {0x10D7B, 0x10D5B, 0x0, 0x0},
  {0x10D7C, 0x10D5C, 0x0, 0x0},
  {0x10D7D, 0x10D5D, 0x0, 0x0},
  {0x10D7E, 0x10D5E, 0x0, 0x0},
  {0x10D7F, 0x10D5F, 0x0, 0x0},
  {0x10D80, 0x10D60, 0x0, 0x0},
  {0x10D81, 0x10D61, 0x0, 0x0},
  {0x10D82, 0x10D62, 0x0, 0x0},
  {0x10D83, 0x10D63, 0x0, 0x0},
  {0x10D84, 0x10D64, 0x0, 0x0},
  {0x10D85, 0x10D65, 0x0, 0x0},
  {0x118C0, 0x118A0, 0x0, 0x0},
  {0x118C1, 0x118A1, 0x0, 0x0},
  {0x118C2, 0x118A2, 0x0, 0x0},
  {0x118C3, 0x118A3, 0x0, 0x0},
  {0x118C4, 0x118A4, 0x0, 0x0},
  {0x118C5, 0x118A5, 0x0, 0x0},
  {0x118C6, 0x118A6, 0x0, 0x0},
  {0x118C7, 0x118A7, 0x0, 0x0},
  {0x118C8, 0x118A8, 0x0, 0x0},
  {0x118C9, 0x118A9, 0x0, 0x0},
  {0x118CA, 0x118AA, 0x0, 0x0},
  {0x118CB, 0x118AB, 0x0, 0x0},
  {0x118CC, 0x118AC, 0x0, 0x0},
  {0x118CD, 0x118AD, 0x0, 0x0},
  {0x118CE, 0x118AE, 0x0, 0x0},
  {0x118CF, 0x118AF, 0x0, 0x0},
  {0x118D0, 0x118B0, 0x0, 0x0},
  {0x118D1, 0x118B1, 0x0, 0x0},
  {0x118D2, 0x118B2, 0x0, 0x0},
  {0x118D3, 0x118B3, 0x0, 0x0},
  {0x118D4, 0x118B4, 0x0, 0x0},
  {0x118D5, 0x118B5, 0x0, 0x0},
  {0x118D6, 0x118B6, 0x0, 0x0},
  {0x118D7, 0x118B7, 0x0, 0x0},
  {0x118D8, 0x118B8, 0x0, 0x0},
  {0x118D9, 0x118B9, 0x0, 0x0},
  {0x118DA, 0x118BA, 0x0, 0x0},
  {0x118DB, 0x118BB, 0x0, 0x0},
  {0x118DC, 0x118BC, 0x0, 0x0},
  {0x118DD, 0x118BD, 0x0, 0x0},
  {0x118DE, 0x118BE, 0x0, 0x0},
  {0x118DF, 0x118BF, 0x0, 0x0},
  {0x16E60, 0x16E40, 0x0, 0x0},
  {0x16E61, 0x16E41, 0x0, 0x0},
  {0x16E62, 0x16E42, 0x0, 0x0},
  {0x16E63, 0x16E43, 0x0, 0x0},
  {0x16E64, 0x16E44, 0x0, 0x0},
  {0x16E65, 0x16E45, 0x0, 0x0},
  {0x16E66, 0x16E46, 0x0, 0x0},
  {0x16E67, 0x16E47, 0x0, 0x0},
  {0x16E68, 0x16E48, 0x0, 0x0},
  {0x16E69, 0x16E49, 0x0, 0x0},
  {0x16E6A, 0x16E4A, 0x0, 0x0},
  {0x16E6B, 0x16E4B, 0x0, 0x0},
  {0x16E6C, 0x16E4C, 0x0, 0x0},
  {0x16E6D, 0x16E4D, 0x0, 0x0},
  {0x16E6E, 0x16E4E, 0x0, 0x0},
  {0x16E6F, 0x16E4F, 0x0, 0x0},
  {0x16E70, 0x16E50, 0x0, 0x0},
  {0x16E71, 0x16E51, 0x0, 0x0},
  {0x16E72, 0x16E52, 0x0, 0x0},
  {0x16E73, 0x16E53, 0x0, 0x0},
  {0x16E74, 0x16E54, 0x0, 0x0},
  {0x16E75, 0x16E55, 0x0, 0x0},
  {0x16E76, 0x16E56, 0x0, 0x0},
  {0x16E77, 0x16E57, 0x0, 0x0},
  {0x16E78, 0x16E58, 0x0, 0x0},
  {0x16E79, 0x16E59, 0x0, 0x0},
  {0x16E7A, 0x16E5A, 0x0, 0x0},
  {0x16E7B, 0x16E5B, 0x0, 0x0},
  {0x16E7C, 0x16E5C, 0x0, 0x0},
  {0x16E7D, 0x16E5D, 0x0, 0x0},
  {0x16E7E, 0x16E5E, 0x0, 0x0},
  {0x16E7F, 0x16E5F, 0x0, 0x0},
  {0x16EBB, 0x16EA0, 0x0, 0x0},
  {0x16EBC, 0x16EA1, 0x0, 0x0},
  {0x16EBD, 0x16EA2, 0x0, 0x0},
  {0x16EBE, 0x16EA3, 0x0, 0x0},
  {0x16EBF, 0x16EA4, 0x0, 0x0},
  {0x16EC0, 0x16EA5, 0x0, 0x0},
  {0x16EC1, 0x16EA6, 0x0, 0x0},
  {0x16EC2, 0x16EA7, 0x0, 0x0},
  {0x16EC3, 0x16EA8, 0x0, 0x0},
  {0x16EC4, 0x16EA9, 0x0, 0x0},
  {0x16EC5, 0x16EAA, 0x0, 0x0},
  {0x16EC6, 0x16EAB, 0x0, 0x0},
  {0x16EC7, 0x16EAC, 0x0, 0x0},
  {0x16EC8, 0x16EAD, 0x0, 0x0},
  {0x16EC9, 0x16EAE, 0x0, 0x0},
  {0x16ECA, 0x16EAF, 0x0, 0x0},
  {0x16ECB, 0x16EB0, 0x0, 0x0},
  {0x16ECC, 0x16EB1, 0x0, 0x0},
  {0x16ECD, 0x16EB2, 0x0, 0x0},
  {0x16ECE, 0x16EB3, 0x0, 0x0},
  {0x16ECF, 0x16EB4, 0x0, 0x0},
  {0x16ED0, 0x16EB5, 0x0, 0x0},
  {0x16ED1, 0x16EB6, 0x0, 0x0},
  {0x16ED2, 0x16EB7, 0x0, 0x0},
  {0x16ED3, 0x16EB8, 0x0, 0x0},
  {0x1E922, 0x1E900, 0x0, 0x0},
  {0x1E923, 0x1E901, 0x0, 0x0},
  {0x1E924, 0x1E902, 0x0, 0x0},
  {0x1E925, 0x1E903, 0x0, 0x0},
  {0x1E926, 0x1E904, 0x0, 0x0},
  {0x1E927, 0x1E905, 0x0, 0x0},
  {0x1E928, 0x1E906, 0x0, 0x0},
  {0x1E929, 0x1E907, 0x0, 0x0},
  {0x1E92A, 0x1E908, 0x0, 0x0},
  {0x1E92B, 0x1E909, 0x0, 0x0},
  {0x1E92C, 0x1E90A, 0x0, 0x0},
  {0x1E92D, 0x1E90B, 0x0, 0x0},
  {0x1E92E, 0x1E90C, 0x0, 0x0},
  {0x1E92F, 0x1E90D, 0x0, 0x0},
  {0x1E930, 0x1E90E, 0x0, 0x0},
  {0x1E931, 0x1E90F, 0x0, 0x0},
  {0x1E932, 0x1E910, 0x0, 0x0},
  {0x1E933, 0x1E911, 0x0, 0x0},
  {0x1E934, 0x1E912, 0x0, 0x0},
  {0x1E935, 0x1E913, 0x0, 0x0},
  {0x1E936, 0x1E914, 0x0, 0x0},
  {0x1E937, 0x1E915, 0x0, 0x0},
  {0x1E938, 0x1E916, 0x0, 0x0},
  {0x1E939, 0x1E917, 0x0, 0x0},
  {0x1E93A, 0x1E918, 0x0, 0x0},
  {0x1E93B, 0x1E919, 0x0, 0x0},
  {0x1E93C, 0x1E91A, 0x0, 0x0},
  {0x1E93D, 0x1E91B, 0x0, 0x0},
  {0x1E93E, 0x1E91C, 0x0, 0x0},
  {0x1E93F, 0x1E91D, 0x0, 0x0},
  {0x1E940, 0x1E91E, 0x0, 0x0},
  {0x1E941, 0x1E91F, 0x0, 0x0},
  {0x1E942, 0x1E920, 0x0, 0x0},
  {0x1E943, 0x1E921, 0x0, 0x0},
};
static const uint32_t lust_lower_map[][4] = {
  {0x41, 0x61, 0x0, 0x0},
  {0x42, 0x62, 0x0, 0x0},
  {0x43, 0x63, 0x0, 0x0},
  {0x44, 0x64, 0x0, 0x0},
  {0x45, 0x65, 0x0, 0x0},
  {0x46, 0x66, 0x0, 0x0},
  {0x47, 0x67, 0x0, 0x0},
  {0x48, 0x68, 0x0, 0x0},
  {0x49, 0x69, 0x0, 0x0},
  {0x4A, 0x6A, 0x0, 0x0},
  {0x4B, 0x6B, 0x0, 0x0},
  {0x4C, 0x6C, 0x0, 0x0},
  {0x4D, 0x6D, 0x0, 0x0},
  {0x4E, 0x6E, 0x0, 0x0},
  {0x4F, 0x6F, 0x0, 0x0},
  {0x50, 0x70, 0x0, 0x0},
  {0x51, 0x71, 0x0, 0x0},
  {0x52, 0x72, 0x0, 0x0},
  {0x53, 0x73, 0x0, 0x0},
  {0x54, 0x74, 0x0, 0x0},
  {0x55, 0x75, 0x0, 0x0},
  {0x56, 0x76, 0x0, 0x0},
  {0x57, 0x77, 0x0, 0x0},
  {0x58, 0x78, 0x0, 0x0},
  {0x59, 0x79, 0x0, 0x0},
  {0x5A, 0x7A, 0x0, 0x0},
  {0xC0, 0xE0, 0x0, 0x0},
  {0xC1, 0xE1, 0x0, 0x0},
  {0xC2, 0xE2, 0x0, 0x0},
  {0xC3, 0xE3, 0x0, 0x0},
  {0xC4, 0xE4, 0x0, 0x0},
  {0xC5, 0xE5, 0x0, 0x0},
  {0xC6, 0xE6, 0x0, 0x0},
  {0xC7, 0xE7, 0x0, 0x0},
  {0xC8, 0xE8, 0x0, 0x0},
  {0xC9, 0xE9, 0x0, 0x0},
  {0xCA, 0xEA, 0x0, 0x0},
  {0xCB, 0xEB, 0x0, 0x0},
  {0xCC, 0xEC, 0x0, 0x0},
  {0xCD, 0xED, 0x0, 0x0},
  {0xCE, 0xEE, 0x0, 0x0},
  {0xCF, 0xEF, 0x0, 0x0},
  {0xD0, 0xF0, 0x0, 0x0},
  {0xD1, 0xF1, 0x0, 0x0},
  {0xD2, 0xF2, 0x0, 0x0},
  {0xD3, 0xF3, 0x0, 0x0},
  {0xD4, 0xF4, 0x0, 0x0},
  {0xD5, 0xF5, 0x0, 0x0},
  {0xD6, 0xF6, 0x0, 0x0},
  {0xD8, 0xF8, 0x0, 0x0},
  {0xD9, 0xF9, 0x0, 0x0},
  {0xDA, 0xFA, 0x0, 0x0},
  {0xDB, 0xFB, 0x0, 0x0},
  {0xDC, 0xFC, 0x0, 0x0},
  {0xDD, 0xFD, 0x0, 0x0},
  {0xDE, 0xFE, 0x0, 0x0},
  {0x100, 0x101, 0x0, 0x0},
  {0x102, 0x103, 0x0, 0x0},
  {0x104, 0x105, 0x0, 0x0},
  {0x106, 0x107, 0x0, 0x0},
  {0x108, 0x109, 0x0, 0x0},
  {0x10A, 0x10B, 0x0, 0x0},
  {0x10C, 0x10D, 0x0, 0x0},
  {0x10E, 0x10F, 0x0, 0x0},
  {0x110, 0x111, 0x0, 0x0},
  {0x112, 0x113, 0x0, 0x0},
  {0x114, 0x115, 0x0, 0x0},
  {0x116, 0x117, 0x0, 0x0},
  {0x118, 0x119, 0x0, 0x0},
  {0x11A, 0x11B, 0x0, 0x0},
  {0x11C, 0x11D, 0x0, 0x0},
  {0x11E, 0x11F, 0x0, 0x0},
  {0x120, 0x121, 0x0, 0x0},
  {0x122, 0x123, 0x0, 0x0},
  {0x124, 0x125, 0x0, 0x0},
  {0x126, 0x127, 0x0, 0x0},
  {0x128, 0x129, 0x0, 0x0},
  {0x12A, 0x12B, 0x0, 0x0},
  {0x12C, 0x12D, 0x0, 0x0},
  {0x12E, 0x12F, 0x0, 0x0},
  {0x130, 0x69, 0x307, 0x0},
  {0x132, 0x133, 0x0, 0x0},
  {0x134, 0x135, 0x0, 0x0},
  {0x136, 0x137, 0x0, 0x0},
  {0x139, 0x13A, 0x0, 0x0},
  {0x13B, 0x13C, 0x0, 0x0},
  {0x13D, 0x13E, 0x0, 0x0},
  {0x13F, 0x140, 0x0, 0x0},
  {0x141, 0x142, 0x0, 0x0},
  {0x143, 0x144, 0x0, 0x0},
  {0x145, 0x146, 0x0, 0x0},
  {0x147, 0x148, 0x0, 0x0},
  {0x14A, 0x14B, 0x0, 0x0},
  {0x14C, 0x14D, 0x0, 0x0},
  {0x14E, 0x14F, 0x0, 0x0},
  {0x150, 0x151, 0x0, 0x0},
  {0x152, 0x153, 0x0, 0x0},
  {0x154, 0x155, 0x0, 0x0},
  {0x156, 0x157, 0x0, 0x0},
  {0x158, 0x159, 0x0, 0x0},
  {0x15A, 0x15B, 0x0, 0x0},
  {0x15C, 0x15D, 0x0, 0x0},
  {0x15E, 0x15F, 0x0, 0x0},
  {0x160, 0x161, 0x0, 0x0},
  {0x162, 0x163, 0x0, 0x0},
  {0x164, 0x165, 0x0, 0x0},
  {0x166, 0x167, 0x0, 0x0},
  {0x168, 0x169, 0x0, 0x0},
  {0x16A, 0x16B, 0x0, 0x0},
  {0x16C, 0x16D, 0x0, 0x0},
  {0x16E, 0x16F, 0x0, 0x0},
  {0x170, 0x171, 0x0, 0x0},
  {0x172, 0x173, 0x0, 0x0},
  {0x174, 0x175, 0x0, 0x0},
  {0x176, 0x177, 0x0, 0x0},
  {0x178, 0xFF, 0x0, 0x0},
  {0x179, 0x17A, 0x0, 0x0},
  {0x17B, 0x17C, 0x0, 0x0},
  {0x17D, 0x17E, 0x0, 0x0},
  {0x181, 0x253, 0x0, 0x0},
  {0x182, 0x183, 0x0, 0x0},
  {0x184, 0x185, 0x0, 0x0},
  {0x186, 0x254, 0x0, 0x0},
  {0x187, 0x188, 0x0, 0x0},
  {0x189, 0x256, 0x0, 0x0},
  {0x18A, 0x257, 0x0, 0x0},
  {0x18B, 0x18C, 0x0, 0x0},
  {0x18E, 0x1DD, 0x0, 0x0},
  {0x18F, 0x259, 0x0, 0x0},
  {0x190, 0x25B, 0x0, 0x0},
  {0x191, 0x192, 0x0, 0x0},
  {0x193, 0x260, 0x0, 0x0},
  {0x194, 0x263, 0x0, 0x0},
  {0x196, 0x269, 0x0, 0x0},
  {0x197, 0x268, 0x0, 0x0},
  {0x198, 0x199, 0x0, 0x0},
  {0x19C, 0x26F, 0x0, 0x0},
  {0x19D, 0x272, 0x0, 0x0},
  {0x19F, 0x275, 0x0, 0x0},
  {0x1A0, 0x1A1, 0x0, 0x0},
  {0x1A2, 0x1A3, 0x0, 0x0},
  {0x1A4, 0x1A5, 0x0, 0x0},
  {0x1A6, 0x280, 0x0, 0x0},
  {0x1A7, 0x1A8, 0x0, 0x0},
  {0x1A9, 0x283, 0x0, 0x0},
  {0x1AC, 0x1AD, 0x0, 0x0},
  {0x1AE, 0x288, 0x0, 0x0},
  {0x1AF, 0x1B0, 0x0, 0x0},
  {0x1B1, 0x28A, 0x0, 0x0},
  {0x1B2, 0x28B, 0x0, 0x0},
  {0x1B3, 0x1B4, 0x0, 0x0},
  {0x1B5, 0x1B6, 0x0, 0x0},
  {0x1B7, 0x292, 0x0, 0x0},
  {0x1B8, 0x1B9, 0x0, 0x0},
  {0x1BC, 0x1BD, 0x0, 0x0},
  {0x1C4, 0x1C6, 0x0, 0x0},
  {0x1C5, 0x1C6, 0x0, 0x0},
  {0x1C7, 0x1C9, 0x0, 0x0},
  {0x1C8, 0x1C9, 0x0, 0x0},
  {0x1CA, 0x1CC, 0x0, 0x0},
  {0x1CB, 0x1CC, 0x0, 0x0},
  {0x1CD, 0x1CE, 0x0, 0x0},
  {0x1CF, 0x1D0, 0x0, 0x0},
  {0x1D1, 0x1D2, 0x0, 0x0},
  {0x1D3, 0x1D4, 0x0, 0x0},
  {0x1D5, 0x1D6, 0x0, 0x0},
  {0x1D7, 0x1D8, 0x0, 0x0},
  {0x1D9, 0x1DA, 0x0, 0x0},
  {0x1DB, 0x1DC, 0x0, 0x0},
  {0x1DE, 0x1DF, 0x0, 0x0},
  {0x1E0, 0x1E1, 0x0, 0x0},
  {0x1E2, 0x1E3, 0x0, 0x0},
  {0x1E4, 0x1E5, 0x0, 0x0},
  {0x1E6, 0x1E7, 0x0, 0x0},
  {0x1E8, 0x1E9, 0x0, 0x0},
  {0x1EA, 0x1EB, 0x0, 0x0},
  {0x1EC, 0x1ED, 0x0, 0x0},
  {0x1EE, 0x1EF, 0x0, 0x0},
  {0x1F1, 0x1F3, 0x0, 0x0},
  {0x1F2, 0x1F3, 0x0, 0x0},
  {0x1F4, 0x1F5, 0x0, 0x0},
  {0x1F6, 0x195, 0x0, 0x0},
  {0x1F7, 0x1BF, 0x0, 0x0},
  {0x1F8, 0x1F9, 0x0, 0x0},
  {0x1FA, 0x1FB, 0x0, 0x0},
  {0x1FC, 0x1FD, 0x0, 0x0},
  {0x1FE, 0x1FF, 0x0, 0x0},
  {0x200, 0x201, 0x0, 0x0},
  {0x202, 0x203, 0x0, 0x0},
  {0x204, 0x205, 0x0, 0x0},
  {0x206, 0x207, 0x0, 0x0},
  {0x208, 0x209, 0x0, 0x0},
  {0x20A, 0x20B, 0x0, 0x0},
  {0x20C, 0x20D, 0x0, 0x0},
  {0x20E, 0x20F, 0x0, 0x0},
  {0x210, 0x211, 0x0, 0x0},
  {0x212, 0x213, 0x0, 0x0},
  {0x214, 0x215, 0x0, 0x0},
  {0x216, 0x217, 0x0, 0x0},
  {0x218, 0x219, 0x0, 0x0},
  {0x21A, 0x21B, 0x0, 0x0},
  {0x21C, 0x21D, 0x0, 0x0},
  {0x21E, 0x21F, 0x0, 0x0},
  {0x220, 0x19E, 0x0, 0x0},
  {0x222, 0x223, 0x0, 0x0},
  {0x224, 0x225, 0x0, 0x0},
  {0x226, 0x227, 0x0, 0x0},
  {0x228, 0x229, 0x0, 0x0},
  {0x22A, 0x22B, 0x0, 0x0},
  {0x22C, 0x22D, 0x0, 0x0},
  {0x22E, 0x22F, 0x0, 0x0},
  {0x230, 0x231, 0x0, 0x0},
  {0x232, 0x233, 0x0, 0x0},
  {0x23A, 0x2C65, 0x0, 0x0},
  {0x23B, 0x23C, 0x0, 0x0},
  {0x23D, 0x19A, 0x0, 0x0},
  {0x23E, 0x2C66, 0x0, 0x0},
  {0x241, 0x242, 0x0, 0x0},
  {0x243, 0x180, 0x0, 0x0},
  {0x244, 0x289, 0x0, 0x0},
  {0x245, 0x28C, 0x0, 0x0},
  {0x246, 0x247, 0x0, 0x0},
  {0x248, 0x249, 0x0, 0x0},
  {0x24A, 0x24B, 0x0, 0x0},
  {0x24C, 0x24D, 0x0, 0x0},
  {0x24E, 0x24F, 0x0, 0x0},
  {0x370, 0x371, 0x0, 0x0},
  {0x372, 0x373, 0x0, 0x0},
  {0x376, 0x377, 0x0, 0x0},
  {0x37F, 0x3F3, 0x0, 0x0},
  {0x386, 0x3AC, 0x0, 0x0},
  {0x388, 0x3AD, 0x0, 0x0},
  {0x389, 0x3AE, 0x0, 0x0},
  {0x38A, 0x3AF, 0x0, 0x0},
  {0x38C, 0x3CC, 0x0, 0x0},
  {0x38E, 0x3CD, 0x0, 0x0},
  {0x38F, 0x3CE, 0x0, 0x0},
  {0x391, 0x3B1, 0x0, 0x0},
  {0x392, 0x3B2, 0x0, 0x0},
  {0x393, 0x3B3, 0x0, 0x0},
  {0x394, 0x3B4, 0x0, 0x0},
  {0x395, 0x3B5, 0x0, 0x0},
  {0x396, 0x3B6, 0x0, 0x0},
  {0x397, 0x3B7, 0x0, 0x0},
  {0x398, 0x3B8, 0x0, 0x0},
  {0x399, 0x3B9, 0x0, 0x0},
  {0x39A, 0x3BA, 0x0, 0x0},
  {0x39B, 0x3BB, 0x0, 0x0},
  {0x39C, 0x3BC, 0x0, 0x0},
  {0x39D, 0x3BD, 0x0, 0x0},
  {0x39E, 0x3BE, 0x0, 0x0},
  {0x39F, 0x3BF, 0x0, 0x0},
  {0x3A0, 0x3C0, 0x0, 0x0},
  {0x3A1, 0x3C1, 0x0, 0x0},
  {0x3A3, 0x3C3, 0x0, 0x0},
  {0x3A4, 0x3C4, 0x0, 0x0},
  {0x3A5, 0x3C5, 0x0, 0x0},
  {0x3A6, 0x3C6, 0x0, 0x0},
  {0x3A7, 0x3C7, 0x0, 0x0},
  {0x3A8, 0x3C8, 0x0, 0x0},
  {0x3A9, 0x3C9, 0x0, 0x0},
  {0x3AA, 0x3CA, 0x0, 0x0},
  {0x3AB, 0x3CB, 0x0, 0x0},
  {0x3CF, 0x3D7, 0x0, 0x0},
  {0x3D8, 0x3D9, 0x0, 0x0},
  {0x3DA, 0x3DB, 0x0, 0x0},
  {0x3DC, 0x3DD, 0x0, 0x0},
  {0x3DE, 0x3DF, 0x0, 0x0},
  {0x3E0, 0x3E1, 0x0, 0x0},
  {0x3E2, 0x3E3, 0x0, 0x0},
  {0x3E4, 0x3E5, 0x0, 0x0},
  {0x3E6, 0x3E7, 0x0, 0x0},
  {0x3E8, 0x3E9, 0x0, 0x0},
  {0x3EA, 0x3EB, 0x0, 0x0},
  {0x3EC, 0x3ED, 0x0, 0x0},
  {0x3EE, 0x3EF, 0x0, 0x0},
  {0x3F4, 0x3B8, 0x0, 0x0},
  {0x3F7, 0x3F8, 0x0, 0x0},
  {0x3F9, 0x3F2, 0x0, 0x0},
  {0x3FA, 0x3FB, 0x0, 0x0},
  {0x3FD, 0x37B, 0x0, 0x0},
  {0x3FE, 0x37C, 0x0, 0x0},
  {0x3FF, 0x37D, 0x0, 0x0},
  {0x400, 0x450, 0x0, 0x0},
  {0x401, 0x451, 0x0, 0x0},
  {0x402, 0x452, 0x0, 0x0},
  {0x403, 0x453, 0x0, 0x0},
  {0x404, 0x454, 0x0, 0x0},
  {0x405, 0x455, 0x0, 0x0},
  {0x406, 0x456, 0x0, 0x0},
  {0x407, 0x457, 0x0, 0x0},
  {0x408, 0x458, 0x0, 0x0},
  {0x409, 0x459, 0x0, 0x0},
  {0x40A, 0x45A, 0x0, 0x0},
  {0x40B, 0x45B, 0x0, 0x0},
  {0x40C, 0x45C, 0x0, 0x0},
  {0x40D, 0x45D, 0x0, 0x0},
  {0x40E, 0x45E, 0x0, 0x0},
  {0x40F, 0x45F, 0x0, 0x0},
  {0x410, 0x430, 0x0, 0x0},
  {0x411, 0x431, 0x0, 0x0},
  {0x412, 0x432, 0x0, 0x0},
  {0x413, 0x433, 0x0, 0x0},
  {0x414, 0x434, 0x0, 0x0},
  {0x415, 0x435, 0x0, 0x0},
  {0x416, 0x436, 0x0, 0x0},
  {0x417, 0x437, 0x0, 0x0},
  {0x418, 0x438, 0x0, 0x0},
  {0x419, 0x439, 0x0, 0x0},
  {0x41A, 0x43A, 0x0, 0x0},
  {0x41B, 0x43B, 0x0, 0x0},
  {0x41C, 0x43C, 0x0, 0x0},
  {0x41D, 0x43D, 0x0, 0x0},
  {0x41E, 0x43E, 0x0, 0x0},
  {0x41F, 0x43F, 0x0, 0x0},
  {0x420, 0x440, 0x0, 0x0},
  {0x421, 0x441, 0x0, 0x0},
  {0x422, 0x442, 0x0, 0x0},
  {0x423, 0x443, 0x0, 0x0},
  {0x424, 0x444, 0x0, 0x0},
  {0x425, 0x445, 0x0, 0x0},
  {0x426, 0x446, 0x0, 0x0},
  {0x427, 0x447, 0x0, 0x0},
  {0x428, 0x448, 0x0, 0x0},
  {0x429, 0x449, 0x0, 0x0},
  {0x42A, 0x44A, 0x0, 0x0},
  {0x42B, 0x44B, 0x0, 0x0},
  {0x42C, 0x44C, 0x0, 0x0},
  {0x42D, 0x44D, 0x0, 0x0},
  {0x42E, 0x44E, 0x0, 0x0},
  {0x42F, 0x44F, 0x0, 0x0},
  {0x460, 0x461, 0x0, 0x0},
  {0x462, 0x463, 0x0, 0x0},
  {0x464, 0x465, 0x0, 0x0},
  {0x466, 0x467, 0x0, 0x0},
  {0x468, 0x469, 0x0, 0x0},
  {0x46A, 0x46B, 0x0, 0x0},
  {0x46C, 0x46D, 0x0, 0x0},
  {0x46E, 0x46F, 0x0, 0x0},
  {0x470, 0x471, 0x0, 0x0},
  {0x472, 0x473, 0x0, 0x0},
  {0x474, 0x475, 0x0, 0x0},
  {0x476, 0x477, 0x0, 0x0},
  {0x478, 0x479, 0x0, 0x0},
  {0x47A, 0x47B, 0x0, 0x0},
  {0x47C, 0x47D, 0x0, 0x0},
  {0x47E, 0x47F, 0x0, 0x0},
  {0x480, 0x481, 0x0, 0x0},
  {0x48A, 0x48B, 0x0, 0x0},
  {0x48C, 0x48D, 0x0, 0x0},
  {0x48E, 0x48F, 0x0, 0x0},
  {0x490, 0x491, 0x0, 0x0},
  {0x492, 0x493, 0x0, 0x0},
  {0x494, 0x495, 0x0, 0x0},
  {0x496, 0x497, 0x0, 0x0},
  {0x498, 0x499, 0x0, 0x0},
  {0x49A, 0x49B, 0x0, 0x0},
  {0x49C, 0x49D, 0x0, 0x0},
  {0x49E, 0x49F, 0x0, 0x0},
  {0x4A0, 0x4A1, 0x0, 0x0},
  {0x4A2, 0x4A3, 0x0, 0x0},
  {0x4A4, 0x4A5, 0x0, 0x0},
  {0x4A6, 0x4A7, 0x0, 0x0},
  {0x4A8, 0x4A9, 0x0, 0x0},
  {0x4AA, 0x4AB, 0x0, 0x0},
  {0x4AC, 0x4AD, 0x0, 0x0},
  {0x4AE, 0x4AF, 0x0, 0x0},
  {0x4B0, 0x4B1, 0x0, 0x0},
  {0x4B2, 0x4B3, 0x0, 0x0},
  {0x4B4, 0x4B5, 0x0, 0x0},
  {0x4B6, 0x4B7, 0x0, 0x0},
  {0x4B8, 0x4B9, 0x0, 0x0},
  {0x4BA, 0x4BB, 0x0, 0x0},
  {0x4BC, 0x4BD, 0x0, 0x0},
  {0x4BE, 0x4BF, 0x0, 0x0},
  {0x4C0, 0x4CF, 0x0, 0x0},
  {0x4C1, 0x4C2, 0x0, 0x0},
  {0x4C3, 0x4C4, 0x0, 0x0},
  {0x4C5, 0x4C6, 0x0, 0x0},
  {0x4C7, 0x4C8, 0x0, 0x0},
  {0x4C9, 0x4CA, 0x0, 0x0},
  {0x4CB, 0x4CC, 0x0, 0x0},
  {0x4CD, 0x4CE, 0x0, 0x0},
  {0x4D0, 0x4D1, 0x0, 0x0},
  {0x4D2, 0x4D3, 0x0, 0x0},
  {0x4D4, 0x4D5, 0x0, 0x0},
  {0x4D6, 0x4D7, 0x0, 0x0},
  {0x4D8, 0x4D9, 0x0, 0x0},
  {0x4DA, 0x4DB, 0x0, 0x0},
  {0x4DC, 0x4DD, 0x0, 0x0},
  {0x4DE, 0x4DF, 0x0, 0x0},
  {0x4E0, 0x4E1, 0x0, 0x0},
  {0x4E2, 0x4E3, 0x0, 0x0},
  {0x4E4, 0x4E5, 0x0, 0x0},
  {0x4E6, 0x4E7, 0x0, 0x0},
  {0x4E8, 0x4E9, 0x0, 0x0},
  {0x4EA, 0x4EB, 0x0, 0x0},
  {0x4EC, 0x4ED, 0x0, 0x0},
  {0x4EE, 0x4EF, 0x0, 0x0},
  {0x4F0, 0x4F1, 0x0, 0x0},
  {0x4F2, 0x4F3, 0x0, 0x0},
  {0x4F4, 0x4F5, 0x0, 0x0},
  {0x4F6, 0x4F7, 0x0, 0x0},
  {0x4F8, 0x4F9, 0x0, 0x0},
  {0x4FA, 0x4FB, 0x0, 0x0},
  {0x4FC, 0x4FD, 0x0, 0x0},
  {0x4FE, 0x4FF, 0x0, 0x0},
  {0x500, 0x501, 0x0, 0x0},
  {0x502, 0x503, 0x0, 0x0},
  {0x504, 0x505, 0x0, 0x0},
  {0x506, 0x507, 0x0, 0x0},
  {0x508, 0x509, 0x0, 0x0},
  {0x50A, 0x50B, 0x0, 0x0},
  {0x50C, 0x50D, 0x0, 0x0},
  {0x50E, 0x50F, 0x0, 0x0},
  {0x510, 0x511, 0x0, 0x0},
  {0x512, 0x513, 0x0, 0x0},
  {0x514, 0x515, 0x0, 0x0},
  {0x516, 0x517, 0x0, 0x0},
  {0x518, 0x519, 0x0, 0x0},
  {0x51A, 0x51B, 0x0, 0x0},
  {0x51C, 0x51D, 0x0, 0x0},
  {0x51E, 0x51F, 0x0, 0x0},
  {0x520, 0x521, 0x0, 0x0},
  {0x522, 0x523, 0x0, 0x0},
  {0x524, 0x525, 0x0, 0x0},
  {0x526, 0x527, 0x0, 0x0},
  {0x528, 0x529, 0x0, 0x0},
  {0x52A, 0x52B, 0x0, 0x0},
  {0x52C, 0x52D, 0x0, 0x0},
  {0x52E, 0x52F, 0x0, 0x0},
  {0x531, 0x561, 0x0, 0x0},
  {0x532, 0x562, 0x0, 0x0},
  {0x533, 0x563, 0x0, 0x0},
  {0x534, 0x564, 0x0, 0x0},
  {0x535, 0x565, 0x0, 0x0},
  {0x536, 0x566, 0x0, 0x0},
  {0x537, 0x567, 0x0, 0x0},
  {0x538, 0x568, 0x0, 0x0},
  {0x539, 0x569, 0x0, 0x0},
  {0x53A, 0x56A, 0x0, 0x0},
  {0x53B, 0x56B, 0x0, 0x0},
  {0x53C, 0x56C, 0x0, 0x0},
  {0x53D, 0x56D, 0x0, 0x0},
  {0x53E, 0x56E, 0x0, 0x0},
  {0x53F, 0x56F, 0x0, 0x0},
  {0x540, 0x570, 0x0, 0x0},
  {0x541, 0x571, 0x0, 0x0},
  {0x542, 0x572, 0x0, 0x0},
  {0x543, 0x573, 0x0, 0x0},
  {0x544, 0x574, 0x0, 0x0},
  {0x545, 0x575, 0x0, 0x0},
  {0x546, 0x576, 0x0, 0x0},
  {0x547, 0x577, 0x0, 0x0},
  {0x548, 0x578, 0x0, 0x0},
  {0x549, 0x579, 0x0, 0x0},
  {0x54A, 0x57A, 0x0, 0x0},
  {0x54B, 0x57B, 0x0, 0x0},
  {0x54C, 0x57C, 0x0, 0x0},
  {0x54D, 0x57D, 0x0, 0x0},
  {0x54E, 0x57E, 0x0, 0x0},
  {0x54F, 0x57F, 0x0, 0x0},
  {0x550, 0x580, 0x0, 0x0},
  {0x551, 0x581, 0x0, 0x0},
  {0x552, 0x582, 0x0, 0x0},
  {0x553, 0x583, 0x0, 0x0},
  {0x554, 0x584, 0x0, 0x0},
  {0x555, 0x585, 0x0, 0x0},
  {0x556, 0x586, 0x0, 0x0},
  {0x10A0, 0x2D00, 0x0, 0x0},
  {0x10A1, 0x2D01, 0x0, 0x0},
  {0x10A2, 0x2D02, 0x0, 0x0},
  {0x10A3, 0x2D03, 0x0, 0x0},
  {0x10A4, 0x2D04, 0x0, 0x0},
  {0x10A5, 0x2D05, 0x0, 0x0},
  {0x10A6, 0x2D06, 0x0, 0x0},
  {0x10A7, 0x2D07, 0x0, 0x0},
  {0x10A8, 0x2D08, 0x0, 0x0},
  {0x10A9, 0x2D09, 0x0, 0x0},
  {0x10AA, 0x2D0A, 0x0, 0x0},
  {0x10AB, 0x2D0B, 0x0, 0x0},
  {0x10AC, 0x2D0C, 0x0, 0x0},
  {0x10AD, 0x2D0D, 0x0, 0x0},
  {0x10AE, 0x2D0E, 0x0, 0x0},
  {0x10AF, 0x2D0F, 0x0, 0x0},
  {0x10B0, 0x2D10, 0x0, 0x0},
  {0x10B1, 0x2D11, 0x0, 0x0},
  {0x10B2, 0x2D12, 0x0, 0x0},
  {0x10B3, 0x2D13, 0x0, 0x0},
  {0x10B4, 0x2D14, 0x0, 0x0},
  {0x10B5, 0x2D15, 0x0, 0x0},
  {0x10B6, 0x2D16, 0x0, 0x0},
  {0x10B7, 0x2D17, 0x0, 0x0},
  {0x10B8, 0x2D18, 0x0, 0x0},
  {0x10B9, 0x2D19, 0x0, 0x0},
  {0x10BA, 0x2D1A, 0x0, 0x0},
  {0x10BB, 0x2D1B, 0x0, 0x0},
  {0x10BC, 0x2D1C, 0x0, 0x0},
  {0x10BD, 0x2D1D, 0x0, 0x0},
  {0x10BE, 0x2D1E, 0x0, 0x0},
  {0x10BF, 0x2D1F, 0x0, 0x0},
  {0x10C0, 0x2D20, 0x0, 0x0},
  {0x10C1, 0x2D21, 0x0, 0x0},
  {0x10C2, 0x2D22, 0x0, 0x0},
  {0x10C3, 0x2D23, 0x0, 0x0},
  {0x10C4, 0x2D24, 0x0, 0x0},
  {0x10C5, 0x2D25, 0x0, 0x0},
  {0x10C7, 0x2D27, 0x0, 0x0},
  {0x10CD, 0x2D2D, 0x0, 0x0},
  {0x13A0, 0xAB70, 0x0, 0x0},
  {0x13A1, 0xAB71, 0x0, 0x0},
  {0x13A2, 0xAB72, 0x0, 0x0},
  {0x13A3, 0xAB73, 0x0, 0x0},
  {0x13A4, 0xAB74, 0x0, 0x0},
  {0x13A5, 0xAB75, 0x0, 0x0},
  {0x13A6, 0xAB76, 0x0, 0x0},
  {0x13A7, 0xAB77, 0x0, 0x0},
  {0x13A8, 0xAB78, 0x0, 0x0},
  {0x13A9, 0xAB79, 0x0, 0x0},
  {0x13AA, 0xAB7A, 0x0, 0x0},
  {0x13AB, 0xAB7B, 0x0, 0x0},
  {0x13AC, 0xAB7C, 0x0, 0x0},
  {0x13AD, 0xAB7D, 0x0, 0x0},
  {0x13AE, 0xAB7E, 0x0, 0x0},
  {0x13AF, 0xAB7F, 0x0, 0x0},
  {0x13B0, 0xAB80, 0x0, 0x0},
  {0x13B1, 0xAB81, 0x0, 0x0},
  {0x13B2, 0xAB82, 0x0, 0x0},
  {0x13B3, 0xAB83, 0x0, 0x0},
  {0x13B4, 0xAB84, 0x0, 0x0},
  {0x13B5, 0xAB85, 0x0, 0x0},
  {0x13B6, 0xAB86, 0x0, 0x0},
  {0x13B7, 0xAB87, 0x0, 0x0},
  {0x13B8, 0xAB88, 0x0, 0x0},
  {0x13B9, 0xAB89, 0x0, 0x0},
  {0x13BA, 0xAB8A, 0x0, 0x0},
  {0x13BB, 0xAB8B, 0x0, 0x0},
  {0x13BC, 0xAB8C, 0x0, 0x0},
  {0x13BD, 0xAB8D, 0x0, 0x0},
  {0x13BE, 0xAB8E, 0x0, 0x0},
  {0x13BF, 0xAB8F, 0x0, 0x0},
  {0x13C0, 0xAB90, 0x0, 0x0},
  {0x13C1, 0xAB91, 0x0, 0x0},
  {0x13C2, 0xAB92, 0x0, 0x0},
  {0x13C3, 0xAB93, 0x0, 0x0},
  {0x13C4, 0xAB94, 0x0, 0x0},
  {0x13C5, 0xAB95, 0x0, 0x0},
  {0x13C6, 0xAB96, 0x0, 0x0},
  {0x13C7, 0xAB97, 0x0, 0x0},
  {0x13C8, 0xAB98, 0x0, 0x0},
  {0x13C9, 0xAB99, 0x0, 0x0},
  {0x13CA, 0xAB9A, 0x0, 0x0},
  {0x13CB, 0xAB9B, 0x0, 0x0},
  {0x13CC, 0xAB9C, 0x0, 0x0},
  {0x13CD, 0xAB9D, 0x0, 0x0},
  {0x13CE, 0xAB9E, 0x0, 0x0},
  {0x13CF, 0xAB9F, 0x0, 0x0},
  {0x13D0, 0xABA0, 0x0, 0x0},
  {0x13D1, 0xABA1, 0x0, 0x0},
  {0x13D2, 0xABA2, 0x0, 0x0},
  {0x13D3, 0xABA3, 0x0, 0x0},
  {0x13D4, 0xABA4, 0x0, 0x0},
  {0x13D5, 0xABA5, 0x0, 0x0},
  {0x13D6, 0xABA6, 0x0, 0x0},
  {0x13D7, 0xABA7, 0x0, 0x0},
  {0x13D8, 0xABA8, 0x0, 0x0},
  {0x13D9, 0xABA9, 0x0, 0x0},
  {0x13DA, 0xABAA, 0x0, 0x0},
  {0x13DB, 0xABAB, 0x0, 0x0},
  {0x13DC, 0xABAC, 0x0, 0x0},
  {0x13DD, 0xABAD, 0x0, 0x0},
  {0x13DE, 0xABAE, 0x0, 0x0},
  {0x13DF, 0xABAF, 0x0, 0x0},
  {0x13E0, 0xABB0, 0x0, 0x0},
  {0x13E1, 0xABB1, 0x0, 0x0},
  {0x13E2, 0xABB2, 0x0, 0x0},
  {0x13E3, 0xABB3, 0x0, 0x0},
  {0x13E4, 0xABB4, 0x0, 0x0},
  {0x13E5, 0xABB5, 0x0, 0x0},
  {0x13E6, 0xABB6, 0x0, 0x0},
  {0x13E7, 0xABB7, 0x0, 0x0},
  {0x13E8, 0xABB8, 0x0, 0x0},
  {0x13E9, 0xABB9, 0x0, 0x0},
  {0x13EA, 0xABBA, 0x0, 0x0},
  {0x13EB, 0xABBB, 0x0, 0x0},
  {0x13EC, 0xABBC, 0x0, 0x0},
  {0x13ED, 0xABBD, 0x0, 0x0},
  {0x13EE, 0xABBE, 0x0, 0x0},
  {0x13EF, 0xABBF, 0x0, 0x0},
  {0x13F0, 0x13F8, 0x0, 0x0},
  {0x13F1, 0x13F9, 0x0, 0x0},
  {0x13F2, 0x13FA, 0x0, 0x0},
  {0x13F3, 0x13FB, 0x0, 0x0},
  {0x13F4, 0x13FC, 0x0, 0x0},
  {0x13F5, 0x13FD, 0x0, 0x0},
  {0x1C89, 0x1C8A, 0x0, 0x0},
  {0x1C90, 0x10D0, 0x0, 0x0},
  {0x1C91, 0x10D1, 0x0, 0x0},
  {0x1C92, 0x10D2, 0x0, 0x0},
  {0x1C93, 0x10D3, 0x0, 0x0},
  {0x1C94, 0x10D4, 0x0, 0x0},
  {0x1C95, 0x10D5, 0x0, 0x0},
  {0x1C96, 0x10D6, 0x0, 0x0},
  {0x1C97, 0x10D7, 0x0, 0x0},
  {0x1C98, 0x10D8, 0x0, 0x0},
  {0x1C99, 0x10D9, 0x0, 0x0},
  {0x1C9A, 0x10DA, 0x0, 0x0},
  {0x1C9B, 0x10DB, 0x0, 0x0},
  {0x1C9C, 0x10DC, 0x0, 0x0},
  {0x1C9D, 0x10DD, 0x0, 0x0},
  {0x1C9E, 0x10DE, 0x0, 0x0},
  {0x1C9F, 0x10DF, 0x0, 0x0},
  {0x1CA0, 0x10E0, 0x0, 0x0},
  {0x1CA1, 0x10E1, 0x0, 0x0},
  {0x1CA2, 0x10E2, 0x0, 0x0},
  {0x1CA3, 0x10E3, 0x0, 0x0},
  {0x1CA4, 0x10E4, 0x0, 0x0},
  {0x1CA5, 0x10E5, 0x0, 0x0},
  {0x1CA6, 0x10E6, 0x0, 0x0},
  {0x1CA7, 0x10E7, 0x0, 0x0},
  {0x1CA8, 0x10E8, 0x0, 0x0},
  {0x1CA9, 0x10E9, 0x0, 0x0},
  {0x1CAA, 0x10EA, 0x0, 0x0},
  {0x1CAB, 0x10EB, 0x0, 0x0},
  {0x1CAC, 0x10EC, 0x0, 0x0},
  {0x1CAD, 0x10ED, 0x0, 0x0},
  {0x1CAE, 0x10EE, 0x0, 0x0},
  {0x1CAF, 0x10EF, 0x0, 0x0},
  {0x1CB0, 0x10F0, 0x0, 0x0},
  {0x1CB1, 0x10F1, 0x0, 0x0},
  {0x1CB2, 0x10F2, 0x0, 0x0},
  {0x1CB3, 0x10F3, 0x0, 0x0},
  {0x1CB4, 0x10F4, 0x0, 0x0},
  {0x1CB5, 0x10F5, 0x0, 0x0},
  {0x1CB6, 0x10F6, 0x0, 0x0},
  {0x1CB7, 0x10F7, 0x0, 0x0},
  {0x1CB8, 0x10F8, 0x0, 0x0},
  {0x1CB9, 0x10F9, 0x0, 0x0},
  {0x1CBA, 0x10FA, 0x0, 0x0},
  {0x1CBD, 0x10FD, 0x0, 0x0},
  {0x1CBE, 0x10FE, 0x0, 0x0},
  {0x1CBF, 0x10FF, 0x0, 0x0},
  {0x1E00, 0x1E01, 0x0, 0x0},
  {0x1E02, 0x1E03, 0x0, 0x0},
  {0x1E04, 0x1E05, 0x0, 0x0},
  {0x1E06, 0x1E07, 0x0, 0x0},
  {0x1E08, 0x1E09, 0x0, 0x0},
  {0x1E0A, 0x1E0B, 0x0, 0x0},
  {0x1E0C, 0x1E0D, 0x0, 0x0},
  {0x1E0E, 0x1E0F, 0x0, 0x0},
  {0x1E10, 0x1E11, 0x0, 0x0},
  {0x1E12, 0x1E13, 0x0, 0x0},
  {0x1E14, 0x1E15, 0x0, 0x0},
  {0x1E16, 0x1E17, 0x0, 0x0},
  {0x1E18, 0x1E19, 0x0, 0x0},
  {0x1E1A, 0x1E1B, 0x0, 0x0},
  {0x1E1C, 0x1E1D, 0x0, 0x0},
  {0x1E1E, 0x1E1F, 0x0, 0x0},
  {0x1E20, 0x1E21, 0x0, 0x0},
  {0x1E22, 0x1E23, 0x0, 0x0},
  {0x1E24, 0x1E25, 0x0, 0x0},
  {0x1E26, 0x1E27, 0x0, 0x0},
  {0x1E28, 0x1E29, 0x0, 0x0},
  {0x1E2A, 0x1E2B, 0x0, 0x0},
  {0x1E2C, 0x1E2D, 0x0, 0x0},
  {0x1E2E, 0x1E2F, 0x0, 0x0},
  {0x1E30, 0x1E31, 0x0, 0x0},
  {0x1E32, 0x1E33, 0x0, 0x0},
  {0x1E34, 0x1E35, 0x0, 0x0},
  {0x1E36, 0x1E37, 0x0, 0x0},
  {0x1E38, 0x1E39, 0x0, 0x0},
  {0x1E3A, 0x1E3B, 0x0, 0x0},
  {0x1E3C, 0x1E3D, 0x0, 0x0},
  {0x1E3E, 0x1E3F, 0x0, 0x0},
  {0x1E40, 0x1E41, 0x0, 0x0},
  {0x1E42, 0x1E43, 0x0, 0x0},
  {0x1E44, 0x1E45, 0x0, 0x0},
  {0x1E46, 0x1E47, 0x0, 0x0},
  {0x1E48, 0x1E49, 0x0, 0x0},
  {0x1E4A, 0x1E4B, 0x0, 0x0},
  {0x1E4C, 0x1E4D, 0x0, 0x0},
  {0x1E4E, 0x1E4F, 0x0, 0x0},
  {0x1E50, 0x1E51, 0x0, 0x0},
  {0x1E52, 0x1E53, 0x0, 0x0},
  {0x1E54, 0x1E55, 0x0, 0x0},
  {0x1E56, 0x1E57, 0x0, 0x0},
  {0x1E58, 0x1E59, 0x0, 0x0},
  {0x1E5A, 0x1E5B, 0x0, 0x0},
  {0x1E5C, 0x1E5D, 0x0, 0x0},
  {0x1E5E, 0x1E5F, 0x0, 0x0},
  {0x1E60, 0x1E61, 0x0, 0x0},
  {0x1E62, 0x1E63, 0x0, 0x0},
  {0x1E64, 0x1E65, 0x0, 0x0},
  {0x1E66, 0x1E67, 0x0, 0x0},
  {0x1E68, 0x1E69, 0x0, 0x0},
  {0x1E6A, 0x1E6B, 0x0, 0x0},
  {0x1E6C, 0x1E6D, 0x0, 0x0},
  {0x1E6E, 0x1E6F, 0x0, 0x0},
  {0x1E70, 0x1E71, 0x0, 0x0},
  {0x1E72, 0x1E73, 0x0, 0x0},
  {0x1E74, 0x1E75, 0x0, 0x0},
  {0x1E76, 0x1E77, 0x0, 0x0},
  {0x1E78, 0x1E79, 0x0, 0x0},
  {0x1E7A, 0x1E7B, 0x0, 0x0},
  {0x1E7C, 0x1E7D, 0x0, 0x0},
  {0x1E7E, 0x1E7F, 0x0, 0x0},
  {0x1E80, 0x1E81, 0x0, 0x0},
  {0x1E82, 0x1E83, 0x0, 0x0},
  {0x1E84, 0x1E85, 0x0, 0x0},
  {0x1E86, 0x1E87, 0x0, 0x0},
  {0x1E88, 0x1E89, 0x0, 0x0},
  {0x1E8A, 0x1E8B, 0x0, 0x0},
  {0x1E8C, 0x1E8D, 0x0, 0x0},
  {0x1E8E, 0x1E8F, 0x0, 0x0},
  {0x1E90, 0x1E91, 0x0, 0x0},
  {0x1E92, 0x1E93, 0x0, 0x0},
  {0x1E94, 0x1E95, 0x0, 0x0},
  {0x1E9E, 0xDF, 0x0, 0x0},
  {0x1EA0, 0x1EA1, 0x0, 0x0},
  {0x1EA2, 0x1EA3, 0x0, 0x0},
  {0x1EA4, 0x1EA5, 0x0, 0x0},
  {0x1EA6, 0x1EA7, 0x0, 0x0},
  {0x1EA8, 0x1EA9, 0x0, 0x0},
  {0x1EAA, 0x1EAB, 0x0, 0x0},
  {0x1EAC, 0x1EAD, 0x0, 0x0},
  {0x1EAE, 0x1EAF, 0x0, 0x0},
  {0x1EB0, 0x1EB1, 0x0, 0x0},
  {0x1EB2, 0x1EB3, 0x0, 0x0},
  {0x1EB4, 0x1EB5, 0x0, 0x0},
  {0x1EB6, 0x1EB7, 0x0, 0x0},
  {0x1EB8, 0x1EB9, 0x0, 0x0},
  {0x1EBA, 0x1EBB, 0x0, 0x0},
  {0x1EBC, 0x1EBD, 0x0, 0x0},
  {0x1EBE, 0x1EBF, 0x0, 0x0},
  {0x1EC0, 0x1EC1, 0x0, 0x0},
  {0x1EC2, 0x1EC3, 0x0, 0x0},
  {0x1EC4, 0x1EC5, 0x0, 0x0},
  {0x1EC6, 0x1EC7, 0x0, 0x0},
  {0x1EC8, 0x1EC9, 0x0, 0x0},
  {0x1ECA, 0x1ECB, 0x0, 0x0},
  {0x1ECC, 0x1ECD, 0x0, 0x0},
  {0x1ECE, 0x1ECF, 0x0, 0x0},
  {0x1ED0, 0x1ED1, 0x0, 0x0},
  {0x1ED2, 0x1ED3, 0x0, 0x0},
  {0x1ED4, 0x1ED5, 0x0, 0x0},
  {0x1ED6, 0x1ED7, 0x0, 0x0},
  {0x1ED8, 0x1ED9, 0x0, 0x0},
  {0x1EDA, 0x1EDB, 0x0, 0x0},
  {0x1EDC, 0x1EDD, 0x0, 0x0},
  {0x1EDE, 0x1EDF, 0x0, 0x0},
  {0x1EE0, 0x1EE1, 0x0, 0x0},
  {0x1EE2, 0x1EE3, 0x0, 0x0},
  {0x1EE4, 0x1EE5, 0x0, 0x0},
  {0x1EE6, 0x1EE7, 0x0, 0x0},
  {0x1EE8, 0x1EE9, 0x0, 0x0},
  {0x1EEA, 0x1EEB, 0x0, 0x0},
  {0x1EEC, 0x1EED, 0x0, 0x0},
  {0x1EEE, 0x1EEF, 0x0, 0x0},
  {0x1EF0, 0x1EF1, 0x0, 0x0},
  {0x1EF2, 0x1EF3, 0x0, 0x0},
  {0x1EF4, 0x1EF5, 0x0, 0x0},
  {0x1EF6, 0x1EF7, 0x0, 0x0},
  {0x1EF8, 0x1EF9, 0x0, 0x0},
  {0x1EFA, 0x1EFB, 0x0, 0x0},
  {0x1EFC, 0x1EFD, 0x0, 0x0},
  {0x1EFE, 0x1EFF, 0x0, 0x0},
  {0x1F08, 0x1F00, 0x0, 0x0},
  {0x1F09, 0x1F01, 0x0, 0x0},
  {0x1F0A, 0x1F02, 0x0, 0x0},
  {0x1F0B, 0x1F03, 0x0, 0x0},
  {0x1F0C, 0x1F04, 0x0, 0x0},
  {0x1F0D, 0x1F05, 0x0, 0x0},
  {0x1F0E, 0x1F06, 0x0, 0x0},
  {0x1F0F, 0x1F07, 0x0, 0x0},
  {0x1F18, 0x1F10, 0x0, 0x0},
  {0x1F19, 0x1F11, 0x0, 0x0},
  {0x1F1A, 0x1F12, 0x0, 0x0},
  {0x1F1B, 0x1F13, 0x0, 0x0},
  {0x1F1C, 0x1F14, 0x0, 0x0},
  {0x1F1D, 0x1F15, 0x0, 0x0},
  {0x1F28, 0x1F20, 0x0, 0x0},
  {0x1F29, 0x1F21, 0x0, 0x0},
  {0x1F2A, 0x1F22, 0x0, 0x0},
  {0x1F2B, 0x1F23, 0x0, 0x0},
  {0x1F2C, 0x1F24, 0x0, 0x0},
  {0x1F2D, 0x1F25, 0x0, 0x0},
  {0x1F2E, 0x1F26, 0x0, 0x0},
  {0x1F2F, 0x1F27, 0x0, 0x0},
  {0x1F38, 0x1F30, 0x0, 0x0},
  {0x1F39, 0x1F31, 0x0, 0x0},
  {0x1F3A, 0x1F32, 0x0, 0x0},
  {0x1F3B, 0x1F33, 0x0, 0x0},
  {0x1F3C, 0x1F34, 0x0, 0x0},
  {0x1F3D, 0x1F35, 0x0, 0x0},
  {0x1F3E, 0x1F36, 0x0, 0x0},
  {0x1F3F, 0x1F37, 0x0, 0x0},
  {0x1F48, 0x1F40, 0x0, 0x0},
  {0x1F49, 0x1F41, 0x0, 0x0},
  {0x1F4A, 0x1F42, 0x0, 0x0},
  {0x1F4B, 0x1F43, 0x0, 0x0},
  {0x1F4C, 0x1F44, 0x0, 0x0},
  {0x1F4D, 0x1F45, 0x0, 0x0},
  {0x1F59, 0x1F51, 0x0, 0x0},
  {0x1F5B, 0x1F53, 0x0, 0x0},
  {0x1F5D, 0x1F55, 0x0, 0x0},
  {0x1F5F, 0x1F57, 0x0, 0x0},
  {0x1F68, 0x1F60, 0x0, 0x0},
  {0x1F69, 0x1F61, 0x0, 0x0},
  {0x1F6A, 0x1F62, 0x0, 0x0},
  {0x1F6B, 0x1F63, 0x0, 0x0},
  {0x1F6C, 0x1F64, 0x0, 0x0},
  {0x1F6D, 0x1F65, 0x0, 0x0},
  {0x1F6E, 0x1F66, 0x0, 0x0},
  {0x1F6F, 0x1F67, 0x0, 0x0},
  {0x1F88, 0x1F80, 0x0, 0x0},
  {0x1F89, 0x1F81, 0x0, 0x0},
  {0x1F8A, 0x1F82, 0x0, 0x0},
  {0x1F8B, 0x1F83, 0x0, 0x0},
  {0x1F8C, 0x1F84, 0x0, 0x0},
  {0x1F8D, 0x1F85, 0x0, 0x0},
  {0x1F8E, 0x1F86, 0x0, 0x0},
  {0x1F8F, 0x1F87, 0x0, 0x0},
  {0x1F98, 0x1F90, 0x0, 0x0},
  {0x1F99, 0x1F91, 0x0, 0x0},
  {0x1F9A, 0x1F92, 0x0, 0x0},
  {0x1F9B, 0x1F93, 0x0, 0x0},
  {0x1F9C, 0x1F94, 0x0, 0x0},
  {0x1F9D, 0x1F95, 0x0, 0x0},
  {0x1F9E, 0x1F96, 0x0, 0x0},
  {0x1F9F, 0x1F97, 0x0, 0x0},
  {0x1FA8, 0x1FA0, 0x0, 0x0},
  {0x1FA9, 0x1FA1, 0x0, 0x0},
  {0x1FAA, 0x1FA2, 0x0, 0x0},
  {0x1FAB, 0x1FA3, 0x0, 0x0},
  {0x1FAC, 0x1FA4, 0x0, 0x0},
  {0x1FAD, 0x1FA5, 0x0, 0x0},
  {0x1FAE, 0x1FA6, 0x0, 0x0},
  {0x1FAF, 0x1FA7, 0x0, 0x0},
  {0x1FB8, 0x1FB0, 0x0, 0x0},
  {0x1FB9, 0x1FB1, 0x0, 0x0},
  {0x1FBA, 0x1F70, 0x0, 0x0},
  {0x1FBB, 0x1F71, 0x0, 0x0},
  {0x1FBC, 0x1FB3, 0x0, 0x0},
  {0x1FC8, 0x1F72, 0x0, 0x0},
  {0x1FC9, 0x1F73, 0x0, 0x0},
  {0x1FCA, 0x1F74, 0x0, 0x0},
  {0x1FCB, 0x1F75, 0x0, 0x0},
  {0x1FCC, 0x1FC3, 0x0, 0x0},
  {0x1FD8, 0x1FD0, 0x0, 0x0},
  {0x1FD9, 0x1FD1, 0x0, 0x0},
  {0x1FDA, 0x1F76, 0x0, 0x0},
  {0x1FDB, 0x1F77, 0x0, 0x0},
  {0x1FE8, 0x1FE0, 0x0, 0x0},
  {0x1FE9, 0x1FE1, 0x0, 0x0},
  {0x1FEA, 0x1F7A, 0x0, 0x0},
  {0x1FEB, 0x1F7B, 0x0, 0x0},
  {0x1FEC, 0x1FE5, 0x0, 0x0},
  {0x1FF8, 0x1F78, 0x0, 0x0},
  {0x1FF9, 0x1F79, 0x0, 0x0},
  {0x1FFA, 0x1F7C, 0x0, 0x0},
  {0x1FFB, 0x1F7D, 0x0, 0x0},
  {0x1FFC, 0x1FF3, 0x0, 0x0},
  {0x2126, 0x3C9, 0x0, 0x0},
  {0x212A, 0x6B, 0x0, 0x0},
  {0x212B, 0xE5, 0x0, 0x0},
  {0x2132, 0x214E, 0x0, 0x0},
  {0x2160, 0x2170, 0x0, 0x0},
  {0x2161, 0x2171, 0x0, 0x0},
  {0x2162, 0x2172, 0x0, 0x0},
  {0x2163, 0x2173, 0x0, 0x0},
  {0x2164, 0x2174, 0x0, 0x0},
  {0x2165, 0x2175, 0x0, 0x0},
  {0x2166, 0x2176, 0x0, 0x0},
  {0x2167, 0x2177, 0x0, 0x0},
  {0x2168, 0x2178, 0x0, 0x0},
  {0x2169, 0x2179, 0x0, 0x0},
  {0x216A, 0x217A, 0x0, 0x0},
  {0x216B, 0x217B, 0x0, 0x0},
  {0x216C, 0x217C, 0x0, 0x0},
  {0x216D, 0x217D, 0x0, 0x0},
  {0x216E, 0x217E, 0x0, 0x0},
  {0x216F, 0x217F, 0x0, 0x0},
  {0x2183, 0x2184, 0x0, 0x0},
  {0x24B6, 0x24D0, 0x0, 0x0},
  {0x24B7, 0x24D1, 0x0, 0x0},
  {0x24B8, 0x24D2, 0x0, 0x0},
  {0x24B9, 0x24D3, 0x0, 0x0},
  {0x24BA, 0x24D4, 0x0, 0x0},
  {0x24BB, 0x24D5, 0x0, 0x0},
  {0x24BC, 0x24D6, 0x0, 0x0},
  {0x24BD, 0x24D7, 0x0, 0x0},
  {0x24BE, 0x24D8, 0x0, 0x0},
  {0x24BF, 0x24D9, 0x0, 0x0},
  {0x24C0, 0x24DA, 0x0, 0x0},
  {0x24C1, 0x24DB, 0x0, 0x0},
  {0x24C2, 0x24DC, 0x0, 0x0},
  {0x24C3, 0x24DD, 0x0, 0x0},
  {0x24C4, 0x24DE, 0x0, 0x0},
  {0x24C5, 0x24DF, 0x0, 0x0},
  {0x24C6, 0x24E0, 0x0, 0x0},
  {0x24C7, 0x24E1, 0x0, 0x0},
  {0x24C8, 0x24E2, 0x0, 0x0},
  {0x24C9, 0x24E3, 0x0, 0x0},
  {0x24CA, 0x24E4, 0x0, 0x0},
  {0x24CB, 0x24E5, 0x0, 0x0},
  {0x24CC, 0x24E6, 0x0, 0x0},
  {0x24CD, 0x24E7, 0x0, 0x0},
  {0x24CE, 0x24E8, 0x0, 0x0},
  {0x24CF, 0x24E9, 0x0, 0x0},
  {0x2C00, 0x2C30, 0x0, 0x0},
  {0x2C01, 0x2C31, 0x0, 0x0},
  {0x2C02, 0x2C32, 0x0, 0x0},
  {0x2C03, 0x2C33, 0x0, 0x0},
  {0x2C04, 0x2C34, 0x0, 0x0},
  {0x2C05, 0x2C35, 0x0, 0x0},
  {0x2C06, 0x2C36, 0x0, 0x0},
  {0x2C07, 0x2C37, 0x0, 0x0},
  {0x2C08, 0x2C38, 0x0, 0x0},
  {0x2C09, 0x2C39, 0x0, 0x0},
  {0x2C0A, 0x2C3A, 0x0, 0x0},
  {0x2C0B, 0x2C3B, 0x0, 0x0},
  {0x2C0C, 0x2C3C, 0x0, 0x0},
  {0x2C0D, 0x2C3D, 0x0, 0x0},
  {0x2C0E, 0x2C3E, 0x0, 0x0},
  {0x2C0F, 0x2C3F, 0x0, 0x0},
  {0x2C10, 0x2C40, 0x0, 0x0},
  {0x2C11, 0x2C41, 0x0, 0x0},
  {0x2C12, 0x2C42, 0x0, 0x0},
  {0x2C13, 0x2C43, 0x0, 0x0},
  {0x2C14, 0x2C44, 0x0, 0x0},
  {0x2C15, 0x2C45, 0x0, 0x0},
  {0x2C16, 0x2C46, 0x0, 0x0},
  {0x2C17, 0x2C47, 0x0, 0x0},
  {0x2C18, 0x2C48, 0x0, 0x0},
  {0x2C19, 0x2C49, 0x0, 0x0},
  {0x2C1A, 0x2C4A, 0x0, 0x0},
  {0x2C1B, 0x2C4B, 0x0, 0x0},
  {0x2C1C, 0x2C4C, 0x0, 0x0},
  {0x2C1D, 0x2C4D, 0x0, 0x0},
  {0x2C1E, 0x2C4E, 0x0, 0x0},
  {0x2C1F, 0x2C4F, 0x0, 0x0},
  {0x2C20, 0x2C50, 0x0, 0x0},
  {0x2C21, 0x2C51, 0x0, 0x0},
  {0x2C22, 0x2C52, 0x0, 0x0},
  {0x2C23, 0x2C53, 0x0, 0x0},
  {0x2C24, 0x2C54, 0x0, 0x0},
  {0x2C25, 0x2C55, 0x0, 0x0},
  {0x2C26, 0x2C56, 0x0, 0x0},
  {0x2C27, 0x2C57, 0x0, 0x0},
  {0x2C28, 0x2C58, 0x0, 0x0},
  {0x2C29, 0x2C59, 0x0, 0x0},
  {0x2C2A, 0x2C5A, 0x0, 0x0},
  {0x2C2B, 0x2C5B, 0x0, 0x0},
  {0x2C2C, 0x2C5C, 0x0, 0x0},
  {0x2C2D, 0x2C5D, 0x0, 0x0},
  {0x2C2E, 0x2C5E, 0x0, 0x0},
  {0x2C2F, 0x2C5F, 0x0, 0x0},
  {0x2C60, 0x2C61, 0x0, 0x0},
  {0x2C62, 0x26B, 0x0, 0x0},
  {0x2C63, 0x1D7D, 0x0, 0x0},
  {0x2C64, 0x27D, 0x0, 0x0},
  {0x2C67, 0x2C68, 0x0, 0x0},
  {0x2C69, 0x2C6A, 0x0, 0x0},
  {0x2C6B, 0x2C6C, 0x0, 0x0},
  {0x2C6D, 0x251, 0x0, 0x0},
  {0x2C6E, 0x271, 0x0, 0x0},
  {0x2C6F, 0x250, 0x0, 0x0},
  {0x2C70, 0x252, 0x0, 0x0},
  {0x2C72, 0x2C73, 0x0, 0x0},
  {0x2C75, 0x2C76, 0x0, 0x0},
  {0x2C7E, 0x23F, 0x0, 0x0},
  {0x2C7F, 0x240, 0x0, 0x0},
  {0x2C80, 0x2C81, 0x0, 0x0},
  {0x2C82, 0x2C83, 0x0, 0x0},
  {0x2C84, 0x2C85, 0x0, 0x0},
  {0x2C86, 0x2C87, 0x0, 0x0},
  {0x2C88, 0x2C89, 0x0, 0x0},
  {0x2C8A, 0x2C8B, 0x0, 0x0},
  {0x2C8C, 0x2C8D, 0x0, 0x0},
  {0x2C8E, 0x2C8F, 0x0, 0x0},
  {0x2C90, 0x2C91, 0x0, 0x0},
  {0x2C92, 0x2C93, 0x0, 0x0},
  {0x2C94, 0x2C95, 0x0, 0x0},
  {0x2C96, 0x2C97, 0x0, 0x0},
  {0x2C98, 0x2C99, 0x0, 0x0},
  {0x2C9A, 0x2C9B, 0x0, 0x0},
  {0x2C9C, 0x2C9D, 0x0, 0x0},
  {0x2C9E, 0x2C9F, 0x0, 0x0},
  {0x2CA0, 0x2CA1, 0x0, 0x0},
  {0x2CA2, 0x2CA3, 0x0, 0x0},
  {0x2CA4, 0x2CA5, 0x0, 0x0},
  {0x2CA6, 0x2CA7, 0x0, 0x0},
  {0x2CA8, 0x2CA9, 0x0, 0x0},
  {0x2CAA, 0x2CAB, 0x0, 0x0},
  {0x2CAC, 0x2CAD, 0x0, 0x0},
  {0x2CAE, 0x2CAF, 0x0, 0x0},
  {0x2CB0, 0x2CB1, 0x0, 0x0},
  {0x2CB2, 0x2CB3, 0x0, 0x0},
  {0x2CB4, 0x2CB5, 0x0, 0x0},
  {0x2CB6, 0x2CB7, 0x0, 0x0},
  {0x2CB8, 0x2CB9, 0x0, 0x0},
  {0x2CBA, 0x2CBB, 0x0, 0x0},
  {0x2CBC, 0x2CBD, 0x0, 0x0},
  {0x2CBE, 0x2CBF, 0x0, 0x0},
  {0x2CC0, 0x2CC1, 0x0, 0x0},
  {0x2CC2, 0x2CC3, 0x0, 0x0},
  {0x2CC4, 0x2CC5, 0x0, 0x0},
  {0x2CC6, 0x2CC7, 0x0, 0x0},
  {0x2CC8, 0x2CC9, 0x0, 0x0},
  {0x2CCA, 0x2CCB, 0x0, 0x0},
  {0x2CCC, 0x2CCD, 0x0, 0x0},
  {0x2CCE, 0x2CCF, 0x0, 0x0},
  {0x2CD0, 0x2CD1, 0x0, 0x0},
  {0x2CD2, 0x2CD3, 0x0, 0x0},
  {0x2CD4, 0x2CD5, 0x0, 0x0},
  {0x2CD6, 0x2CD7, 0x0, 0x0},
  {0x2CD8, 0x2CD9, 0x0, 0x0},
  {0x2CDA, 0x2CDB, 0x0, 0x0},
  {0x2CDC, 0x2CDD, 0x0, 0x0},
  {0x2CDE, 0x2CDF, 0x0, 0x0},
  {0x2CE0, 0x2CE1, 0x0, 0x0},
  {0x2CE2, 0x2CE3, 0x0, 0x0},
  {0x2CEB, 0x2CEC, 0x0, 0x0},
  {0x2CED, 0x2CEE, 0x0, 0x0},
  {0x2CF2, 0x2CF3, 0x0, 0x0},
  {0xA640, 0xA641, 0x0, 0x0},
  {0xA642, 0xA643, 0x0, 0x0},
  {0xA644, 0xA645, 0x0, 0x0},
  {0xA646, 0xA647, 0x0, 0x0},
  {0xA648, 0xA649, 0x0, 0x0},
  {0xA64A, 0xA64B, 0x0, 0x0},
  {0xA64C, 0xA64D, 0x0, 0x0},
  {0xA64E, 0xA64F, 0x0, 0x0},
  {0xA650, 0xA651, 0x0, 0x0},
  {0xA652, 0xA653, 0x0, 0x0},
  {0xA654, 0xA655, 0x0, 0x0},
  {0xA656, 0xA657, 0x0, 0x0},
  {0xA658, 0xA659, 0x0, 0x0},
  {0xA65A, 0xA65B, 0x0, 0x0},
  {0xA65C, 0xA65D, 0x0, 0x0},
  {0xA65E, 0xA65F, 0x0, 0x0},
  {0xA660, 0xA661, 0x0, 0x0},
  {0xA662, 0xA663, 0x0, 0x0},
  {0xA664, 0xA665, 0x0, 0x0},
  {0xA666, 0xA667, 0x0, 0x0},
  {0xA668, 0xA669, 0x0, 0x0},
  {0xA66A, 0xA66B, 0x0, 0x0},
  {0xA66C, 0xA66D, 0x0, 0x0},
  {0xA680, 0xA681, 0x0, 0x0},
  {0xA682, 0xA683, 0x0, 0x0},
  {0xA684, 0xA685, 0x0, 0x0},
  {0xA686, 0xA687, 0x0, 0x0},
  {0xA688, 0xA689, 0x0, 0x0},
  {0xA68A, 0xA68B, 0x0, 0x0},
  {0xA68C, 0xA68D, 0x0, 0x0},
  {0xA68E, 0xA68F, 0x0, 0x0},
  {0xA690, 0xA691, 0x0, 0x0},
  {0xA692, 0xA693, 0x0, 0x0},
  {0xA694, 0xA695, 0x0, 0x0},
  {0xA696, 0xA697, 0x0, 0x0},
  {0xA698, 0xA699, 0x0, 0x0},
  {0xA69A, 0xA69B, 0x0, 0x0},
  {0xA722, 0xA723, 0x0, 0x0},
  {0xA724, 0xA725, 0x0, 0x0},
  {0xA726, 0xA727, 0x0, 0x0},
  {0xA728, 0xA729, 0x0, 0x0},
  {0xA72A, 0xA72B, 0x0, 0x0},
  {0xA72C, 0xA72D, 0x0, 0x0},
  {0xA72E, 0xA72F, 0x0, 0x0},
  {0xA732, 0xA733, 0x0, 0x0},
  {0xA734, 0xA735, 0x0, 0x0},
  {0xA736, 0xA737, 0x0, 0x0},
  {0xA738, 0xA739, 0x0, 0x0},
  {0xA73A, 0xA73B, 0x0, 0x0},
  {0xA73C, 0xA73D, 0x0, 0x0},
  {0xA73E, 0xA73F, 0x0, 0x0},
  {0xA740, 0xA741, 0x0, 0x0},
  {0xA742, 0xA743, 0x0, 0x0},
  {0xA744, 0xA745, 0x0, 0x0},
  {0xA746, 0xA747, 0x0, 0x0},
  {0xA748, 0xA749, 0x0, 0x0},
  {0xA74A, 0xA74B, 0x0, 0x0},
  {0xA74C, 0xA74D, 0x0, 0x0},
  {0xA74E, 0xA74F, 0x0, 0x0},
  {0xA750, 0xA751, 0x0, 0x0},
  {0xA752, 0xA753, 0x0, 0x0},
  {0xA754, 0xA755, 0x0, 0x0},
  {0xA756, 0xA757, 0x0, 0x0},
  {0xA758, 0xA759, 0x0, 0x0},
  {0xA75A, 0xA75B, 0x0, 0x0},
  {0xA75C, 0xA75D, 0x0, 0x0},
  {0xA75E, 0xA75F, 0x0, 0x0},
  {0xA760, 0xA761, 0x0, 0x0},
  {0xA762, 0xA763, 0x0, 0x0},
  {0xA764, 0xA765, 0x0, 0x0},
  {0xA766, 0xA767, 0x0, 0x0},
  {0xA768, 0xA769, 0x0, 0x0},
  {0xA76A, 0xA76B, 0x0, 0x0},
  {0xA76C, 0xA76D, 0x0, 0x0},
  {0xA76E, 0xA76F, 0x0, 0x0},
  {0xA779, 0xA77A, 0x0, 0x0},
  {0xA77B, 0xA77C, 0x0, 0x0},
  {0xA77D, 0x1D79, 0x0, 0x0},
  {0xA77E, 0xA77F, 0x0, 0x0},
  {0xA780, 0xA781, 0x0, 0x0},
  {0xA782, 0xA783, 0x0, 0x0},
  {0xA784, 0xA785, 0x0, 0x0},
  {0xA786, 0xA787, 0x0, 0x0},
  {0xA78B, 0xA78C, 0x0, 0x0},
  {0xA78D, 0x265, 0x0, 0x0},
  {0xA790, 0xA791, 0x0, 0x0},
  {0xA792, 0xA793, 0x0, 0x0},
  {0xA796, 0xA797, 0x0, 0x0},
  {0xA798, 0xA799, 0x0, 0x0},
  {0xA79A, 0xA79B, 0x0, 0x0},
  {0xA79C, 0xA79D, 0x0, 0x0},
  {0xA79E, 0xA79F, 0x0, 0x0},
  {0xA7A0, 0xA7A1, 0x0, 0x0},
  {0xA7A2, 0xA7A3, 0x0, 0x0},
  {0xA7A4, 0xA7A5, 0x0, 0x0},
  {0xA7A6, 0xA7A7, 0x0, 0x0},
  {0xA7A8, 0xA7A9, 0x0, 0x0},
  {0xA7AA, 0x266, 0x0, 0x0},
  {0xA7AB, 0x25C, 0x0, 0x0},
  {0xA7AC, 0x261, 0x0, 0x0},
  {0xA7AD, 0x26C, 0x0, 0x0},
  {0xA7AE, 0x26A, 0x0, 0x0},
  {0xA7B0, 0x29E, 0x0, 0x0},
  {0xA7B1, 0x287, 0x0, 0x0},
  {0xA7B2, 0x29D, 0x0, 0x0},
  {0xA7B3, 0xAB53, 0x0, 0x0},
  {0xA7B4, 0xA7B5, 0x0, 0x0},
  {0xA7B6, 0xA7B7, 0x0, 0x0},
  {0xA7B8, 0xA7B9, 0x0, 0x0},
  {0xA7BA, 0xA7BB, 0x0, 0x0},
  {0xA7BC, 0xA7BD, 0x0, 0x0},
  {0xA7BE, 0xA7BF, 0x0, 0x0},
  {0xA7C0, 0xA7C1, 0x0, 0x0},
  {0xA7C2, 0xA7C3, 0x0, 0x0},
  {0xA7C4, 0xA794, 0x0, 0x0},
  {0xA7C5, 0x282, 0x0, 0x0},
  {0xA7C6, 0x1D8E, 0x0, 0x0},
  {0xA7C7, 0xA7C8, 0x0, 0x0},
  {0xA7C9, 0xA7CA, 0x0, 0x0},
  {0xA7CB, 0x264, 0x0, 0x0},
  {0xA7CC, 0xA7CD, 0x0, 0x0},
  {0xA7CE, 0xA7CF, 0x0, 0x0},
  {0xA7D0, 0xA7D1, 0x0, 0x0},
  {0xA7D2, 0xA7D3, 0x0, 0x0},
  {0xA7D4, 0xA7D5, 0x0, 0x0},
  {0xA7D6, 0xA7D7, 0x0, 0x0},
  {0xA7D8, 0xA7D9, 0x0, 0x0},
  {0xA7DA, 0xA7DB, 0x0, 0x0},
  {0xA7DC, 0x19B, 0x0, 0x0},
  {0xA7F5, 0xA7F6, 0x0, 0x0},
  {0xFF21, 0xFF41, 0x0, 0x0},
  {0xFF22, 0xFF42, 0x0, 0x0},
  {0xFF23, 0xFF43, 0x0, 0x0},
  {0xFF24, 0xFF44, 0x0, 0x0},
  {0xFF25, 0xFF45, 0x0, 0x0},
  {0xFF26, 0xFF46, 0x0, 0x0},
  {0xFF27, 0xFF47, 0x0, 0x0},
  {0xFF28, 0xFF48, 0x0, 0x0},
  {0xFF29, 0xFF49, 0x0, 0x0},
  {0xFF2A, 0xFF4A, 0x0, 0x0},
  {0xFF2B, 0xFF4B, 0x0, 0x0},
  {0xFF2C, 0xFF4C, 0x0, 0x0},
  {0xFF2D, 0xFF4D, 0x0, 0x0},
  {0xFF2E, 0xFF4E, 0x0, 0x0},
  {0xFF2F, 0xFF4F, 0x0, 0x0},
  {0xFF30, 0xFF50, 0x0, 0x0},
  {0xFF31, 0xFF51, 0x0, 0x0},
  {0xFF32, 0xFF52, 0x0, 0x0},
  {0xFF33, 0xFF53, 0x0, 0x0},
  {0xFF34, 0xFF54, 0x0, 0x0},
  {0xFF35, 0xFF55, 0x0, 0x0},
  {0xFF36, 0xFF56, 0x0, 0x0},
  {0xFF37, 0xFF57, 0x0, 0x0},
  {0xFF38, 0xFF58, 0x0, 0x0},
  {0xFF39, 0xFF59, 0x0, 0x0},
  {0xFF3A, 0xFF5A, 0x0, 0x0},
  {0x10400, 0x10428, 0x0, 0x0},
  {0x10401, 0x10429, 0x0, 0x0},
  {0x10402, 0x1042A, 0x0, 0x0},
  {0x10403, 0x1042B, 0x0, 0x0},
  {0x10404, 0x1042C, 0x0, 0x0},
  {0x10405, 0x1042D, 0x0, 0x0},
  {0x10406, 0x1042E, 0x0, 0x0},
  {0x10407, 0x1042F, 0x0, 0x0},
  {0x10408, 0x10430, 0x0, 0x0},
  {0x10409, 0x10431, 0x0, 0x0},
  {0x1040A, 0x10432, 0x0, 0x0},
  {0x1040B, 0x10433, 0x0, 0x0},
  {0x1040C, 0x10434, 0x0, 0x0},
  {0x1040D, 0x10435, 0x0, 0x0},
  {0x1040E, 0x10436, 0x0, 0x0},
  {0x1040F, 0x10437, 0x0, 0x0},
  {0x10410, 0x10438, 0x0, 0x0},
  {0x10411, 0x10439, 0x0, 0x0},
  {0x10412, 0x1043A, 0x0, 0x0},
  {0x10413, 0x1043B, 0x0, 0x0},
  {0x10414, 0x1043C, 0x0, 0x0},
  {0x10415, 0x1043D, 0x0, 0x0},
  {0x10416, 0x1043E, 0x0, 0x0},
  {0x10417, 0x1043F, 0x0, 0x0},
  {0x10418, 0x10440, 0x0, 0x0},
  {0x10419, 0x10441, 0x0, 0x0},
  {0x1041A, 0x10442, 0x0, 0x0},
  {0x1041B, 0x10443, 0x0, 0x0},
  {0x1041C, 0x10444, 0x0, 0x0},
  {0x1041D, 0x10445, 0x0, 0x0},
  {0x1041E, 0x10446, 0x0, 0x0},
  {0x1041F, 0x10447, 0x0, 0x0},
  {0x10420, 0x10448, 0x0, 0x0},
  {0x10421, 0x10449, 0x0, 0x0},
  {0x10422, 0x1044A, 0x0, 0x0},
  {0x10423, 0x1044B, 0x0, 0x0},
  {0x10424, 0x1044C, 0x0, 0x0},
  {0x10425, 0x1044D, 0x0, 0x0},
  {0x10426, 0x1044E, 0x0, 0x0},
  {0x10427, 0x1044F, 0x0, 0x0},
  {0x104B0, 0x104D8, 0x0, 0x0},
  {0x104B1, 0x104D9, 0x0, 0x0},
  {0x104B2, 0x104DA, 0x0, 0x0},
  {0x104B3, 0x104DB, 0x0, 0x0},
  {0x104B4, 0x104DC, 0x0, 0x0},
  {0x104B5, 0x104DD, 0x0, 0x0},
  {0x104B6, 0x104DE, 0x0, 0x0},
  {0x104B7, 0x104DF, 0x0, 0x0},
  {0x104B8, 0x104E0, 0x0, 0x0},
  {0x104B9, 0x104E1, 0x0, 0x0},
  {0x104BA, 0x104E2, 0x0, 0x0},
  {0x104BB, 0x104E3, 0x0, 0x0},
  {0x104BC, 0x104E4, 0x0, 0x0},
  {0x104BD, 0x104E5, 0x0, 0x0},
  {0x104BE, 0x104E6, 0x0, 0x0},
  {0x104BF, 0x104E7, 0x0, 0x0},
  {0x104C0, 0x104E8, 0x0, 0x0},
  {0x104C1, 0x104E9, 0x0, 0x0},
  {0x104C2, 0x104EA, 0x0, 0x0},
  {0x104C3, 0x104EB, 0x0, 0x0},
  {0x104C4, 0x104EC, 0x0, 0x0},
  {0x104C5, 0x104ED, 0x0, 0x0},
  {0x104C6, 0x104EE, 0x0, 0x0},
  {0x104C7, 0x104EF, 0x0, 0x0},
  {0x104C8, 0x104F0, 0x0, 0x0},
  {0x104C9, 0x104F1, 0x0, 0x0},
  {0x104CA, 0x104F2, 0x0, 0x0},
  {0x104CB, 0x104F3, 0x0, 0x0},
  {0x104CC, 0x104F4, 0x0, 0x0},
  {0x104CD, 0x104F5, 0x0, 0x0},
  {0x104CE, 0x104F6, 0x0, 0x0},
  {0x104CF, 0x104F7, 0x0, 0x0},
  {0x104D0, 0x104F8, 0x0, 0x0},
  {0x104D1, 0x104F9, 0x0, 0x0},
  {0x104D2, 0x104FA, 0x0, 0x0},
  {0x104D3, 0x104FB, 0x0, 0x0},
  {0x10570, 0x10597, 0x0, 0x0},
  {0x10571, 0x10598, 0x0, 0x0},
  {0x10572, 0x10599, 0x0, 0x0},
  {0x10573, 0x1059A, 0x0, 0x0},
  {0x10574, 0x1059B, 0x0, 0x0},
  {0x10575, 0x1059C, 0x0, 0x0},
  {0x10576, 0x1059D, 0x0, 0x0},
  {0x10577, 0x1059E, 0x0, 0x0},
  {0x10578, 0x1059F, 0x0, 0x0},
  {0x10579, 0x105A0, 0x0, 0x0},
  {0x1057A, 0x105A1, 0x0, 0x0},
  {0x1057C, 0x105A3, 0x0, 0x0},
  {0x1057D, 0x105A4, 0x0, 0x0},
  {0x1057E, 0x105A5, 0x0, 0x0},
  {0x1057F, 0x105A6, 0x0, 0x0},
  {0x10580, 0x105A7, 0x0, 0x0},
  {0x10581, 0x105A8, 0x0, 0x0},
  {0x10582, 0x105A9, 0x0, 0x0},
  {0x10583, 0x105AA, 0x0, 0x0},
  {0x10584, 0x105AB, 0x0, 0x0},
  {0x10585, 0x105AC, 0x0, 0x0},
  {0x10586, 0x105AD, 0x0, 0x0},
  {0x10587, 0x105AE, 0x0, 0x0},
  {0x10588, 0x105AF, 0x0, 0x0},
  {0x10589, 0x105B0, 0x0, 0x0},
  {0x1058A, 0x105B1, 0x0, 0x0},
  {0x1058C, 0x105B3, 0x0, 0x0},
  {0x1058D, 0x105B4, 0x0, 0x0},
  {0x1058E, 0x105B5, 0x0, 0x0},
  {0x1058F, 0x105B6, 0x0, 0x0},
  {0x10590, 0x105B7, 0x0, 0x0},
  {0x10591, 0x105B8, 0x0, 0x0},
  {0x10592, 0x105B9, 0x0, 0x0},
  {0x10594, 0x105BB, 0x0, 0x0},
  {0x10595, 0x105BC, 0x0, 0x0},
  {0x10C80, 0x10CC0, 0x0, 0x0},
  {0x10C81, 0x10CC1, 0x0, 0x0},
  {0x10C82, 0x10CC2, 0x0, 0x0},
  {0x10C83, 0x10CC3, 0x0, 0x0},
  {0x10C84, 0x10CC4, 0x0, 0x0},
  {0x10C85, 0x10CC5, 0x0, 0x0},
  {0x10C86, 0x10CC6, 0x0, 0x0},
  {0x10C87, 0x10CC7, 0x0, 0x0},
  {0x10C88, 0x10CC8, 0x0, 0x0},
  {0x10C89, 0x10CC9, 0x0, 0x0},
  {0x10C8A, 0x10CCA, 0x0, 0x0},
  {0x10C8B, 0x10CCB, 0x0, 0x0},
  {0x10C8C, 0x10CCC, 0x0, 0x0},
  {0x10C8D, 0x10CCD, 0x0, 0x0},
  {0x10C8E, 0x10CCE, 0x0, 0x0},
  {0x10C8F, 0x10CCF, 0x0, 0x0},
  {0x10C90, 0x10CD0, 0x0, 0x0},
  {0x10C91, 0x10CD1, 0x0, 0x0},
  {0x10C92, 0x10CD2, 0x0, 0x0},
  {0x10C93, 0x10CD3, 0x0, 0x0},
  {0x10C94, 0x10CD4, 0x0, 0x0},
  {0x10C95, 0x10CD5, 0x0, 0x0},
  {0x10C96, 0x10CD6, 0x0, 0x0},
  {0x10C97, 0x10CD7, 0x0, 0x0},
  {0x10C98, 0x10CD8, 0x0, 0x0},
  {0x10C99, 0x10CD9, 0x0, 0x0},
  {0x10C9A, 0x10CDA, 0x0, 0x0},
  {0x10C9B, 0x10CDB, 0x0, 0x0},
  {0x10C9C, 0x10CDC, 0x0, 0x0},
  {0x10C9D, 0x10CDD, 0x0, 0x0},
  {0x10C9E, 0x10CDE, 0x0, 0x0},
  {0x10C9F, 0x10CDF, 0x0, 0x0},
  {0x10CA0, 0x10CE0, 0x0, 0x0},
  {0x10CA1, 0x10CE1, 0x0, 0x0},
  {0x10CA2, 0x10CE2, 0x0, 0x0},
  {0x10CA3, 0x10CE3, 0x0, 0x0},
  {0x10CA4, 0x10CE4, 0x0, 0x0},
  {0x10CA5, 0x10CE5, 0x0, 0x0},
  {0x10CA6, 0x10CE6, 0x0, 0x0},
  {0x10CA7, 0x10CE7, 0x0, 0x0},
  {0x10CA8, 0x10CE8, 0x0, 0x0},
  {0x10CA9, 0x10CE9, 0x0, 0x0},
  {0x10CAA, 0x10CEA, 0x0, 0x0},
  {0x10CAB, 0x10CEB, 0x0, 0x0},
  {0x10CAC, 0x10CEC, 0x0, 0x0},
  {0x10CAD, 0x10CED, 0x0, 0x0},
  {0x10CAE, 0x10CEE, 0x0, 0x0},
  {0x10CAF, 0x10CEF, 0x0, 0x0},
  {0x10CB0, 0x10CF0, 0x0, 0x0},
  {0x10CB1, 0x10CF1, 0x0, 0x0},
  {0x10CB2, 0x10CF2, 0x0, 0x0},
  {0x10D50, 0x10D70, 0x0, 0x0},
  {0x10D51, 0x10D71, 0x0, 0x0},
  {0x10D52, 0x10D72, 0x0, 0x0},
  {0x10D53, 0x10D73, 0x0, 0x0},
  {0x10D54, 0x10D74, 0x0, 0x0},
  {0x10D55, 0x10D75, 0x0, 0x0},
  {0x10D56, 0x10D76, 0x0, 0x0},
  {0x10D57, 0x10D77, 0x0, 0x0},
  {0x10D58, 0x10D78, 0x0, 0x0},
  {0x10D59, 0x10D79, 0x0, 0x0},
  {0x10D5A, 0x10D7A, 0x0, 0x0},
  {0x10D5B, 0x10D7B, 0x0, 0x0},
  {0x10D5C, 0x10D7C, 0x0, 0x0},
  {0x10D5D, 0x10D7D, 0x0, 0x0},
  {0x10D5E, 0x10D7E, 0x0, 0x0},
  {0x10D5F, 0x10D7F, 0x0, 0x0},
  {0x10D60, 0x10D80, 0x0, 0x0},
  {0x10D61, 0x10D81, 0x0, 0x0},
  {0x10D62, 0x10D82, 0x0, 0x0},
  {0x10D63, 0x10D83, 0x0, 0x0},
  {0x10D64, 0x10D84, 0x0, 0x0},
  {0x10D65, 0x10D85, 0x0, 0x0},
  {0x118A0, 0x118C0, 0x0, 0x0},
  {0x118A1, 0x118C1, 0x0, 0x0},
  {0x118A2, 0x118C2, 0x0, 0x0},
  {0x118A3, 0x118C3, 0x0, 0x0},
  {0x118A4, 0x118C4, 0x0, 0x0},
  {0x118A5, 0x118C5, 0x0, 0x0},
  {0x118A6, 0x118C6, 0x0, 0x0},
  {0x118A7, 0x118C7, 0x0, 0x0},
  {0x118A8, 0x118C8, 0x0, 0x0},
  {0x118A9, 0x118C9, 0x0, 0x0},
  {0x118AA, 0x118CA, 0x0, 0x0},
  {0x118AB, 0x118CB, 0x0, 0x0},
  {0x118AC, 0x118CC, 0x0, 0x0},
  {0x118AD, 0x118CD, 0x0, 0x0},
  {0x118AE, 0x118CE, 0x0, 0x0},
  {0x118AF, 0x118CF, 0x0, 0x0},
  {0x118B0, 0x118D0, 0x0, 0x0},
  {0x118B1, 0x118D1, 0x0, 0x0},
  {0x118B2, 0x118D2, 0x0, 0x0},
  {0x118B3, 0x118D3, 0x0, 0x0},
  {0x118B4, 0x118D4, 0x0, 0x0},
  {0x118B5, 0x118D5, 0x0, 0x0},
  {0x118B6, 0x118D6, 0x0, 0x0},
  {0x118B7, 0x118D7, 0x0, 0x0},
  {0x118B8, 0x118D8, 0x0, 0x0},
  {0x118B9, 0x118D9, 0x0, 0x0},
  {0x118BA, 0x118DA, 0x0, 0x0},
  {0x118BB, 0x118DB, 0x0, 0x0},
  {0x118BC, 0x118DC, 0x0, 0x0},
  {0x118BD, 0x118DD, 0x0, 0x0},
  {0x118BE, 0x118DE, 0x0, 0x0},
  {0x118BF, 0x118DF, 0x0, 0x0},
  {0x16E40, 0x16E60, 0x0, 0x0},
  {0x16E41, 0x16E61, 0x0, 0x0},
  {0x16E42, 0x16E62, 0x0, 0x0},
  {0x16E43, 0x16E63, 0x0, 0x0},
  {0x16E44, 0x16E64, 0x0, 0x0},
  {0x16E45, 0x16E65, 0x0, 0x0},
  {0x16E46, 0x16E66, 0x0, 0x0},
  {0x16E47, 0x16E67, 0x0, 0x0},
  {0x16E48, 0x16E68, 0x0, 0x0},
  {0x16E49, 0x16E69, 0x0, 0x0},
  {0x16E4A, 0x16E6A, 0x0, 0x0},
  {0x16E4B, 0x16E6B, 0x0, 0x0},
  {0x16E4C, 0x16E6C, 0x0, 0x0},
  {0x16E4D, 0x16E6D, 0x0, 0x0},
  {0x16E4E, 0x16E6E, 0x0, 0x0},
  {0x16E4F, 0x16E6F, 0x0, 0x0},
  {0x16E50, 0x16E70, 0x0, 0x0},
  {0x16E51, 0x16E71, 0x0, 0x0},
  {0x16E52, 0x16E72, 0x0, 0x0},
  {0x16E53, 0x16E73, 0x0, 0x0},
  {0x16E54, 0x16E74, 0x0, 0x0},
  {0x16E55, 0x16E75, 0x0, 0x0},
  {0x16E56, 0x16E76, 0x0, 0x0},
  {0x16E57, 0x16E77, 0x0, 0x0},
  {0x16E58, 0x16E78, 0x0, 0x0},
  {0x16E59, 0x16E79, 0x0, 0x0},
  {0x16E5A, 0x16E7A, 0x0, 0x0},
  {0x16E5B, 0x16E7B, 0x0, 0x0},
  {0x16E5C, 0x16E7C, 0x0, 0x0},
  {0x16E5D, 0x16E7D, 0x0, 0x0},
  {0x16E5E, 0x16E7E, 0x0, 0x0},
  {0x16E5F, 0x16E7F, 0x0, 0x0},
  {0x16EA0, 0x16EBB, 0x0, 0x0},
  {0x16EA1, 0x16EBC, 0x0, 0x0},
  {0x16EA2, 0x16EBD, 0x0, 0x0},
  {0x16EA3, 0x16EBE, 0x0, 0x0},
  {0x16EA4, 0x16EBF, 0x0, 0x0},
  {0x16EA5, 0x16EC0, 0x0, 0x0},
  {0x16EA6, 0x16EC1, 0x0, 0x0},
  {0x16EA7, 0x16EC2, 0x0, 0x0},
  {0x16EA8, 0x16EC3, 0x0, 0x0},
  {0x16EA9, 0x16EC4, 0x0, 0x0},
  {0x16EAA, 0x16EC5, 0x0, 0x0},
  {0x16EAB, 0x16EC6, 0x0, 0x0},
  {0x16EAC, 0x16EC7, 0x0, 0x0},
  {0x16EAD, 0x16EC8, 0x0, 0x0},
  {0x16EAE, 0x16EC9, 0x0, 0x0},
  {0x16EAF, 0x16ECA, 0x0, 0x0},
  {0x16EB0, 0x16ECB, 0x0, 0x0},
  {0x16EB1, 0x16ECC, 0x0, 0x0},
  {0x16EB2, 0x16ECD, 0x0, 0x0},
  {0x16EB3, 0x16ECE, 0x0, 0x0},
  {0x16EB4, 0x16ECF, 0x0, 0x0},
  {0x16EB5, 0x16ED0, 0x0, 0x0},
  {0x16EB6, 0x16ED1, 0x0, 0x0},
  {0x16EB7, 0x16ED2, 0x0, 0x0},
  {0x16EB8, 0x16ED3, 0x0, 0x0},
  {0x1E900, 0x1E922, 0x0, 0x0},
  {0x1E901, 0x1E923, 0x0, 0x0},
  {0x1E902, 0x1E924, 0x0, 0x0},
  {0x1E903, 0x1E925, 0x0, 0x0},
  {0x1E904, 0x1E926, 0x0, 0x0},
  {0x1E905, 0x1E927, 0x0, 0x0},
  {0x1E906, 0x1E928, 0x0, 0x0},
  {0x1E907, 0x1E929, 0x0, 0x0},
  {0x1E908, 0x1E92A, 0x0, 0x0},
  {0x1E909, 0x1E92B, 0x0, 0x0},
  {0x1E90A, 0x1E92C, 0x0, 0x0},
  {0x1E90B, 0x1E92D, 0x0, 0x0},
  {0x1E90C, 0x1E92E, 0x0, 0x0},
  {0x1E90D, 0x1E92F, 0x0, 0x0},
  {0x1E90E, 0x1E930, 0x0, 0x0},
  {0x1E90F, 0x1E931, 0x0, 0x0},
  {0x1E910, 0x1E932, 0x0, 0x0},
  {0x1E911, 0x1E933, 0x0, 0x0},
  {0x1E912, 0x1E934, 0x0, 0x0},
  {0x1E913, 0x1E935, 0x0, 0x0},
  {0x1E914, 0x1E936, 0x0, 0x0},
  {0x1E915, 0x1E937, 0x0, 0x0},
  {0x1E916, 0x1E938, 0x0, 0x0},
  {0x1E917, 0x1E939, 0x0, 0x0},
  {0x1E918, 0x1E93A, 0x0, 0x0},
  {0x1E919, 0x1E93B, 0x0, 0x0},
  {0x1E91A, 0x1E93C, 0x0, 0x0},
  {0x1E91B, 0x1E93D, 0x0, 0x0},
  {0x1E91C, 0x1E93E, 0x0, 0x0},
  {0x1E91D, 0x1E93F, 0x0, 0x0},
  {0x1E91E, 0x1E940, 0x0, 0x0},
  {0x1E91F, 0x1E941, 0x0, 0x0},
  {0x1E920, 0x1E942, 0x0, 0x0},
  {0x1E921, 0x1E943, 0x0, 0x0},
};
static const uint32_t lust_case_ignorable[][2] = {
  {0x27, 0x27},
  {0x2E, 0x2E},
  {0x3A, 0x3A},
  {0x5E, 0x5E},
  {0x60, 0x60},
  {0xA8, 0xA8},
  {0xAD, 0xAD},
  {0xAF, 0xAF},
  {0xB4, 0xB4},
  {0xB7, 0xB8},
  {0x2B0, 0x36F},
  {0x374, 0x375},
  {0x37A, 0x37A},
  {0x384, 0x385},
  {0x387, 0x387},
  {0x483, 0x489},
  {0x559, 0x559},
  {0x55F, 0x55F},
  {0x591, 0x5BD},
  {0x5BF, 0x5BF},
  {0x5C1, 0x5C2},
  {0x5C4, 0x5C5},
  {0x5C7, 0x5C7},
  {0x5F4, 0x5F4},
  {0x600, 0x605},
  {0x610, 0x61A},
  {0x61C, 0x61C},
  {0x640, 0x640},
  {0x64B, 0x65F},
  {0x670, 0x670},
  {0x6D6, 0x6DD},
  {0x6DF, 0x6E8},
  {0x6EA, 0x6ED},
  {0x70F, 0x70F},
  {0x711, 0x711},
  {0x730, 0x74A},
  {0x7A6, 0x7B0},
  {0x7EB, 0x7F5},
  {0x7FA, 0x7FA},
  {0x7FD, 0x7FD},
  {0x816, 0x82D},
  {0x859, 0x85B},
  {0x888, 0x888},
  {0x890, 0x891},
  {0x897, 0x89F},
  {0x8C9, 0x902},
  {0x93A, 0x93A},
  {0x93C, 0x93C},
  {0x941, 0x948},
  {0x94D, 0x94D},
  {0x951, 0x957},
  {0x962, 0x963},
  {0x971, 0x971},
  {0x981, 0x981},
  {0x9BC, 0x9BC},
  {0x9C1, 0x9C4},
  {0x9CD, 0x9CD},
  {0x9E2, 0x9E3},
  {0x9FE, 0x9FE},
  {0xA01, 0xA02},
  {0xA3C, 0xA3C},
  {0xA41, 0xA42},
  {0xA47, 0xA48},
  {0xA4B, 0xA4D},
  {0xA51, 0xA51},
  {0xA70, 0xA71},
  {0xA75, 0xA75},
  {0xA81, 0xA82},
  {0xABC, 0xABC},
  {0xAC1, 0xAC5},
  {0xAC7, 0xAC8},
  {0xACD, 0xACD},
  {0xAE2, 0xAE3},
  {0xAFA, 0xAFF},
  {0xB01, 0xB01},
  {0xB3C, 0xB3C},
  {0xB3F, 0xB3F},
  {0xB41, 0xB44},
  {0xB4D, 0xB4D},
  {0xB55, 0xB56},
  {0xB62, 0xB63},
  {0xB82, 0xB82},
  {0xBC0, 0xBC0},
  {0xBCD, 0xBCD},
  {0xC00, 0xC00},
  {0xC04, 0xC04},
  {0xC3C, 0xC3C},
  {0xC3E, 0xC40},
  {0xC46, 0xC48},
  {0xC4A, 0xC4D},
  {0xC55, 0xC56},
  {0xC62, 0xC63},
  {0xC81, 0xC81},
  {0xCBC, 0xCBC},
  {0xCBF, 0xCBF},
  {0xCC6, 0xCC6},
  {0xCCC, 0xCCD},
  {0xCE2, 0xCE3},
  {0xD00, 0xD01},
  {0xD3B, 0xD3C},
  {0xD41, 0xD44},
  {0xD4D, 0xD4D},
  {0xD62, 0xD63},
  {0xD81, 0xD81},
  {0xDCA, 0xDCA},
  {0xDD2, 0xDD4},
  {0xDD6, 0xDD6},
  {0xE31, 0xE31},
  {0xE34, 0xE3A},
  {0xE46, 0xE4E},
  {0xEB1, 0xEB1},
  {0xEB4, 0xEBC},
  {0xEC6, 0xEC6},
  {0xEC8, 0xECE},
  {0xF18, 0xF19},
  {0xF35, 0xF35},
  {0xF37, 0xF37},
  {0xF39, 0xF39},
  {0xF71, 0xF7E},
  {0xF80, 0xF84},
  {0xF86, 0xF87},
  {0xF8D, 0xF97},
  {0xF99, 0xFBC},
  {0xFC6, 0xFC6},
  {0x102D, 0x1030},
  {0x1032, 0x1037},
  {0x1039, 0x103A},
  {0x103D, 0x103E},
  {0x1058, 0x1059},
  {0x105E, 0x1060},
  {0x1071, 0x1074},
  {0x1082, 0x1082},
  {0x1085, 0x1086},
  {0x108D, 0x108D},
  {0x109D, 0x109D},
  {0x10FC, 0x10FC},
  {0x135D, 0x135F},
  {0x1712, 0x1714},
  {0x1732, 0x1733},
  {0x1752, 0x1753},
  {0x1772, 0x1773},
  {0x17B4, 0x17B5},
  {0x17B7, 0x17BD},
  {0x17C6, 0x17C6},
  {0x17C9, 0x17D3},
  {0x17D7, 0x17D7},
  {0x17DD, 0x17DD},
  {0x180B, 0x180F},
  {0x1843, 0x1843},
  {0x1885, 0x1886},
  {0x18A9, 0x18A9},
  {0x1920, 0x1922},
  {0x1927, 0x1928},
  {0x1932, 0x1932},
  {0x1939, 0x193B},
  {0x1A17, 0x1A18},
  {0x1A1B, 0x1A1B},
  {0x1A56, 0x1A56},
  {0x1A58, 0x1A5E},
  {0x1A60, 0x1A60},
  {0x1A62, 0x1A62},
  {0x1A65, 0x1A6C},
  {0x1A73, 0x1A7C},
  {0x1A7F, 0x1A7F},
  {0x1AA7, 0x1AA7},
  {0x1AB0, 0x1ADD},
  {0x1AE0, 0x1AEB},
  {0x1B00, 0x1B03},
  {0x1B34, 0x1B34},
  {0x1B36, 0x1B3A},
  {0x1B3C, 0x1B3C},
  {0x1B42, 0x1B42},
  {0x1B6B, 0x1B73},
  {0x1B80, 0x1B81},
  {0x1BA2, 0x1BA5},
  {0x1BA8, 0x1BA9},
  {0x1BAB, 0x1BAD},
  {0x1BE6, 0x1BE6},
  {0x1BE8, 0x1BE9},
  {0x1BED, 0x1BED},
  {0x1BEF, 0x1BF1},
  {0x1C2C, 0x1C33},
  {0x1C36, 0x1C37},
  {0x1C78, 0x1C7D},
  {0x1CD0, 0x1CD2},
  {0x1CD4, 0x1CE0},
  {0x1CE2, 0x1CE8},
  {0x1CED, 0x1CED},
  {0x1CF4, 0x1CF4},
  {0x1CF8, 0x1CF9},
  {0x1D2C, 0x1D6A},
  {0x1D78, 0x1D78},
  {0x1D9B, 0x1DFF},
  {0x1FBD, 0x1FBD},
  {0x1FBF, 0x1FC1},
  {0x1FCD, 0x1FCF},
  {0x1FDD, 0x1FDF},
  {0x1FED, 0x1FEF},
  {0x1FFD, 0x1FFE},
  {0x200B, 0x200F},
  {0x2018, 0x2019},
  {0x2024, 0x2024},
  {0x2027, 0x2027},
  {0x202A, 0x202E},
  {0x2060, 0x2064},
  {0x2066, 0x206F},
  {0x2071, 0x2071},
  {0x207F, 0x207F},
  {0x2090, 0x209C},
  {0x20D0, 0x20F0},
  {0x2C7C, 0x2C7D},
  {0x2CEF, 0x2CF1},
  {0x2D6F, 0x2D6F},
  {0x2D7F, 0x2D7F},
  {0x2DE0, 0x2DFF},
  {0x2E2F, 0x2E2F},
  {0x3005, 0x3005},
  {0x302A, 0x302D},
  {0x3031, 0x3035},
  {0x303B, 0x303B},
  {0x3099, 0x309E},
  {0x30FC, 0x30FE},
  {0xA015, 0xA015},
  {0xA4F8, 0xA4FD},
  {0xA60C, 0xA60C},
  {0xA66F, 0xA672},
  {0xA674, 0xA67D},
  {0xA67F, 0xA67F},
  {0xA69C, 0xA69F},
  {0xA6F0, 0xA6F1},
  {0xA700, 0xA721},
  {0xA770, 0xA770},
  {0xA788, 0xA78A},
  {0xA7F1, 0xA7F4},
  {0xA7F8, 0xA7F9},
  {0xA802, 0xA802},
  {0xA806, 0xA806},
  {0xA80B, 0xA80B},
  {0xA825, 0xA826},
  {0xA82C, 0xA82C},
  {0xA8C4, 0xA8C5},
  {0xA8E0, 0xA8F1},
  {0xA8FF, 0xA8FF},
  {0xA926, 0xA92D},
  {0xA947, 0xA951},
  {0xA980, 0xA982},
  {0xA9B3, 0xA9B3},
  {0xA9B6, 0xA9B9},
  {0xA9BC, 0xA9BD},
  {0xA9CF, 0xA9CF},
  {0xA9E5, 0xA9E6},
  {0xAA29, 0xAA2E},
  {0xAA31, 0xAA32},
  {0xAA35, 0xAA36},
  {0xAA43, 0xAA43},
  {0xAA4C, 0xAA4C},
  {0xAA70, 0xAA70},
  {0xAA7C, 0xAA7C},
  {0xAAB0, 0xAAB0},
  {0xAAB2, 0xAAB4},
  {0xAAB7, 0xAAB8},
  {0xAABE, 0xAABF},
  {0xAAC1, 0xAAC1},
  {0xAADD, 0xAADD},
  {0xAAEC, 0xAAED},
  {0xAAF3, 0xAAF4},
  {0xAAF6, 0xAAF6},
  {0xAB5B, 0xAB5F},
  {0xAB69, 0xAB6B},
  {0xABE5, 0xABE5},
  {0xABE8, 0xABE8},
  {0xABED, 0xABED},
  {0xFB1E, 0xFB1E},
  {0xFBB2, 0xFBC2},
  {0xFE00, 0xFE0F},
  {0xFE13, 0xFE13},
  {0xFE20, 0xFE2F},
  {0xFE52, 0xFE52},
  {0xFE55, 0xFE55},
  {0xFEFF, 0xFEFF},
  {0xFF07, 0xFF07},
  {0xFF0E, 0xFF0E},
  {0xFF1A, 0xFF1A},
  {0xFF3E, 0xFF3E},
  {0xFF40, 0xFF40},
  {0xFF70, 0xFF70},
  {0xFF9E, 0xFF9F},
  {0xFFE3, 0xFFE3},
  {0xFFF9, 0xFFFB},
  {0x101FD, 0x101FD},
  {0x102E0, 0x102E0},
  {0x10376, 0x1037A},
  {0x10780, 0x10785},
  {0x10787, 0x107B0},
  {0x107B2, 0x107BA},
  {0x10A01, 0x10A03},
  {0x10A05, 0x10A06},
  {0x10A0C, 0x10A0F},
  {0x10A38, 0x10A3A},
  {0x10A3F, 0x10A3F},
  {0x10AE5, 0x10AE6},
  {0x10D24, 0x10D27},
  {0x10D4E, 0x10D4E},
  {0x10D69, 0x10D6D},
  {0x10D6F, 0x10D6F},
  {0x10EAB, 0x10EAC},
  {0x10EC5, 0x10EC5},
  {0x10EFA, 0x10EFF},
  {0x10F46, 0x10F50},
  {0x10F82, 0x10F85},
  {0x11001, 0x11001},
  {0x11038, 0x11046},
  {0x11070, 0x11070},
  {0x11073, 0x11074},
  {0x1107F, 0x11081},
  {0x110B3, 0x110B6},
  {0x110B9, 0x110BA},
  {0x110BD, 0x110BD},
  {0x110C2, 0x110C2},
  {0x110CD, 0x110CD},
  {0x11100, 0x11102},
  {0x11127, 0x1112B},
  {0x1112D, 0x11134},
  {0x11173, 0x11173},
  {0x11180, 0x11181},
  {0x111B6, 0x111BE},
  {0x111C9, 0x111CC},
  {0x111CF, 0x111CF},
  {0x1122F, 0x11231},
  {0x11234, 0x11234},
  {0x11236, 0x11237},
  {0x1123E, 0x1123E},
  {0x11241, 0x11241},
  {0x112DF, 0x112DF},
  {0x112E3, 0x112EA},
  {0x11300, 0x11301},
  {0x1133B, 0x1133C},
  {0x11340, 0x11340},
  {0x11366, 0x1136C},
  {0x11370, 0x11374},
  {0x113BB, 0x113C0},
  {0x113CE, 0x113CE},
  {0x113D0, 0x113D0},
  {0x113D2, 0x113D2},
  {0x113E1, 0x113E2},
  {0x11438, 0x1143F},
  {0x11442, 0x11444},
  {0x11446, 0x11446},
  {0x1145E, 0x1145E},
  {0x114B3, 0x114B8},
  {0x114BA, 0x114BA},
  {0x114BF, 0x114C0},
  {0x114C2, 0x114C3},
  {0x115B2, 0x115B5},
  {0x115BC, 0x115BD},
  {0x115BF, 0x115C0},
  {0x115DC, 0x115DD},
  {0x11633, 0x1163A},
  {0x1163D, 0x1163D},
  {0x1163F, 0x11640},
  {0x116AB, 0x116AB},
  {0x116AD, 0x116AD},
  {0x116B0, 0x116B5},
  {0x116B7, 0x116B7},
  {0x1171D, 0x1171D},
  {0x1171F, 0x1171F},
  {0x11722, 0x11725},
  {0x11727, 0x1172B},
  {0x1182F, 0x11837},
  {0x11839, 0x1183A},
  {0x1193B, 0x1193C},
  {0x1193E, 0x1193E},
  {0x11943, 0x11943},
  {0x119D4, 0x119D7},
  {0x119DA, 0x119DB},
  {0x119E0, 0x119E0},
  {0x11A01, 0x11A0A},
  {0x11A33, 0x11A38},
  {0x11A3B, 0x11A3E},
  {0x11A47, 0x11A47},
  {0x11A51, 0x11A56},
  {0x11A59, 0x11A5B},
  {0x11A8A, 0x11A96},
  {0x11A98, 0x11A99},
  {0x11B60, 0x11B60},
  {0x11B62, 0x11B64},
  {0x11B66, 0x11B66},
  {0x11C30, 0x11C36},
  {0x11C38, 0x11C3D},
  {0x11C3F, 0x11C3F},
  {0x11C92, 0x11CA7},
  {0x11CAA, 0x11CB0},
  {0x11CB2, 0x11CB3},
  {0x11CB5, 0x11CB6},
  {0x11D31, 0x11D36},
  {0x11D3A, 0x11D3A},
  {0x11D3C, 0x11D3D},
  {0x11D3F, 0x11D45},
  {0x11D47, 0x11D47},
  {0x11D90, 0x11D91},
  {0x11D95, 0x11D95},
  {0x11D97, 0x11D97},
  {0x11DD9, 0x11DD9},
  {0x11EF3, 0x11EF4},
  {0x11F00, 0x11F01},
  {0x11F36, 0x11F3A},
  {0x11F40, 0x11F40},
  {0x11F42, 0x11F42},
  {0x11F5A, 0x11F5A},
  {0x13430, 0x13440},
  {0x13447, 0x13455},
  {0x1611E, 0x16129},
  {0x1612D, 0x1612F},
  {0x16AF0, 0x16AF4},
  {0x16B30, 0x16B36},
  {0x16B40, 0x16B43},
  {0x16D40, 0x16D42},
  {0x16D6B, 0x16D6C},
  {0x16F4F, 0x16F4F},
  {0x16F8F, 0x16F9F},
  {0x16FE0, 0x16FE1},
  {0x16FE3, 0x16FE4},
  {0x16FF2, 0x16FF3},
  {0x1AFF0, 0x1AFF3},
  {0x1AFF5, 0x1AFFB},
  {0x1AFFD, 0x1AFFE},
  {0x1BC9D, 0x1BC9E},
  {0x1BCA0, 0x1BCA3},
  {0x1CF00, 0x1CF2D},
  {0x1CF30, 0x1CF46},
  {0x1D167, 0x1D169},
  {0x1D173, 0x1D182},
  {0x1D185, 0x1D18B},
  {0x1D1AA, 0x1D1AD},
  {0x1D242, 0x1D244},
  {0x1DA00, 0x1DA36},
  {0x1DA3B, 0x1DA6C},
  {0x1DA75, 0x1DA75},
  {0x1DA84, 0x1DA84},
  {0x1DA9B, 0x1DA9F},
  {0x1DAA1, 0x1DAAF},
  {0x1E000, 0x1E006},
  {0x1E008, 0x1E018},
  {0x1E01B, 0x1E021},
  {0x1E023, 0x1E024},
  {0x1E026, 0x1E02A},
  {0x1E030, 0x1E06D},
  {0x1E08F, 0x1E08F},
  {0x1E130, 0x1E13D},
  {0x1E2AE, 0x1E2AE},
  {0x1E2EC, 0x1E2EF},
  {0x1E4EB, 0x1E4EF},
  {0x1E5EE, 0x1E5EF},
  {0x1E6E3, 0x1E6E3},
  {0x1E6E6, 0x1E6E6},
  {0x1E6EE, 0x1E6EF},
  {0x1E6F5, 0x1E6F5},
  {0x1E6FF, 0x1E6FF},
  {0x1E8D0, 0x1E8D6},
  {0x1E944, 0x1E94B},
  {0x1F3FB, 0x1F3FF},
  {0xE0001, 0xE0001},
  {0xE0020, 0xE007F},
  {0xE0100, 0xE01EF},
};
static const uint32_t lust_cased[][2] = {
  {0x41, 0x5A},
  {0x61, 0x7A},
  {0xAA, 0xAA},
  {0xB5, 0xB5},
  {0xBA, 0xBA},
  {0xC0, 0xD6},
  {0xD8, 0xF6},
  {0xF8, 0x1BA},
  {0x1BC, 0x1BF},
  {0x1C4, 0x293},
  {0x296, 0x2AF},
  {0x370, 0x373},
  {0x376, 0x377},
  {0x37B, 0x37D},
  {0x37F, 0x37F},
  {0x386, 0x386},
  {0x388, 0x38A},
  {0x38C, 0x38C},
  {0x38E, 0x3A1},
  {0x3A3, 0x3F5},
  {0x3F7, 0x481},
  {0x48A, 0x52F},
  {0x531, 0x556},
  {0x560, 0x588},
  {0x10A0, 0x10C5},
  {0x10C7, 0x10C7},
  {0x10CD, 0x10CD},
  {0x10D0, 0x10FA},
  {0x10FD, 0x10FF},
  {0x13A0, 0x13F5},
  {0x13F8, 0x13FD},
  {0x1C80, 0x1C8A},
  {0x1C90, 0x1CBA},
  {0x1CBD, 0x1CBF},
  {0x1D00, 0x1D2B},
  {0x1D6B, 0x1D77},
  {0x1D79, 0x1D9A},
  {0x1E00, 0x1F15},
  {0x1F18, 0x1F1D},
  {0x1F20, 0x1F45},
  {0x1F48, 0x1F4D},
  {0x1F50, 0x1F57},
  {0x1F59, 0x1F59},
  {0x1F5B, 0x1F5B},
  {0x1F5D, 0x1F5D},
  {0x1F5F, 0x1F7D},
  {0x1F80, 0x1FB4},
  {0x1FB6, 0x1FBC},
  {0x1FBE, 0x1FBE},
  {0x1FC2, 0x1FC4},
  {0x1FC6, 0x1FCC},
  {0x1FD0, 0x1FD3},
  {0x1FD6, 0x1FDB},
  {0x1FE0, 0x1FEC},
  {0x1FF2, 0x1FF4},
  {0x1FF6, 0x1FFC},
  {0x2102, 0x2102},
  {0x2107, 0x2107},
  {0x210A, 0x2113},
  {0x2115, 0x2115},
  {0x2119, 0x211D},
  {0x2124, 0x2124},
  {0x2126, 0x2126},
  {0x2128, 0x2128},
  {0x212A, 0x212D},
  {0x212F, 0x2134},
  {0x2139, 0x2139},
  {0x213C, 0x213F},
  {0x2145, 0x2149},
  {0x214E, 0x214E},
  {0x2160, 0x217F},
  {0x2183, 0x2184},
  {0x24B6, 0x24E9},
  {0x2C00, 0x2C7B},
  {0x2C7E, 0x2CE4},
  {0x2CEB, 0x2CEE},
  {0x2CF2, 0x2CF3},
  {0x2D00, 0x2D25},
  {0x2D27, 0x2D27},
  {0x2D2D, 0x2D2D},
  {0xA640, 0xA66D},
  {0xA680, 0xA69B},
  {0xA722, 0xA76F},
  {0xA771, 0xA787},
  {0xA78B, 0xA78E},
  {0xA790, 0xA7DC},
  {0xA7F5, 0xA7F6},
  {0xA7FA, 0xA7FA},
  {0xAB30, 0xAB5A},
  {0xAB60, 0xAB68},
  {0xAB70, 0xABBF},
  {0xFB00, 0xFB06},
  {0xFB13, 0xFB17},
  {0xFF21, 0xFF3A},
  {0xFF41, 0xFF5A},
  {0x10400, 0x1044F},
  {0x104B0, 0x104D3},
  {0x104D8, 0x104FB},
  {0x10570, 0x1057A},
  {0x1057C, 0x1058A},
  {0x1058C, 0x10592},
  {0x10594, 0x10595},
  {0x10597, 0x105A1},
  {0x105A3, 0x105B1},
  {0x105B3, 0x105B9},
  {0x105BB, 0x105BC},
  {0x10C80, 0x10CB2},
  {0x10CC0, 0x10CF2},
  {0x10D50, 0x10D65},
  {0x10D70, 0x10D85},
  {0x118A0, 0x118DF},
  {0x16E40, 0x16E7F},
  {0x16EA0, 0x16EB8},
  {0x16EBB, 0x16ED3},
  {0x1D400, 0x1D454},
  {0x1D456, 0x1D49C},
  {0x1D49E, 0x1D49F},
  {0x1D4A2, 0x1D4A2},
  {0x1D4A5, 0x1D4A6},
  {0x1D4A9, 0x1D4AC},
  {0x1D4AE, 0x1D4B9},
  {0x1D4BB, 0x1D4BB},
  {0x1D4BD, 0x1D4C3},
  {0x1D4C5, 0x1D505},
  {0x1D507, 0x1D50A},
  {0x1D50D, 0x1D514},
  {0x1D516, 0x1D51C},
  {0x1D51E, 0x1D539},
  {0x1D53B, 0x1D53E},
  {0x1D540, 0x1D544},
  {0x1D546, 0x1D546},
  {0x1D54A, 0x1D550},
  {0x1D552, 0x1D6A5},
  {0x1D6A8, 0x1D6C0},
  {0x1D6C2, 0x1D6DA},
  {0x1D6DC, 0x1D6FA},
  {0x1D6FC, 0x1D714},
  {0x1D716, 0x1D734},
  {0x1D736, 0x1D74E},
  {0x1D750, 0x1D76E},
  {0x1D770, 0x1D788},
  {0x1D78A, 0x1D7A8},
  {0x1D7AA, 0x1D7C2},
  {0x1D7C4, 0x1D7CB},
  {0x1DF00, 0x1DF09},
  {0x1DF0B, 0x1DF1E},
  {0x1DF25, 0x1DF2A},
  {0x1E900, 0x1E943},
  {0x1F130, 0x1F149},
  {0x1F150, 0x1F169},
  {0x1F170, 0x1F189},
};

static int lust_case_in(const uint32_t (*t)[2], uint64_t n, uint32_t c) LUST_BODY({
    uint64_t lo = 0, hi = n;
    while (lo < hi) {
        uint64_t m = lo + (hi - lo) / 2;
        if (c < t[m][0]) hi = m;
        else if (c > t[m][1]) lo = m + 1;
        else return 1;
    }
    return 0;
})
static const uint32_t *lust_case_map(const uint32_t (*t)[4], uint64_t n, uint32_t c) LUST_BODY({
    uint64_t lo = 0, hi = n;
    while (lo < hi) {
        uint64_t m = lo + (hi - lo) / 2;
        if (c < t[m][0]) hi = m;
        else if (c > t[m][0]) lo = m + 1;
        else return &t[m][1];
    }
    return 0;
})
/* `case_ignorable_then_cased` over the chars before byte `i` (backward)
   or from byte `i` on (forward). */
static int lust_ci_then_cased(lust_str s, uint64_t i, int back) LUST_BODY({
    for (;;) {
        uint32_t c;
        if (back) {
            if (i == 0) return 0;
            c = lust_utf8_prev(s.ptr, &i);
        } else {
            if (i >= s.len) return 0;
            c = lust_utf8_next(s.ptr, &i);
        }
        if (lust_case_in(lust_case_ignorable, sizeof lust_case_ignorable / sizeof lust_case_ignorable[0], c)) continue;
        return c == 0x3A3 || lust_case_in(lust_cased, sizeof lust_cased / sizeof lust_cased[0], c);
    }
})
lust_String lust_str_case(lust_str s, int upper) LUST_BODY({
    lust_String r = lust_string_with_capacity(s.len);
    uint64_t i = 0;
    while (i < s.len && s.ptr[i] < 0x80) {
        uint8_t c = s.ptr[i];
        if (upper && c >= 'a' && c <= 'z') c -= 32;
        if (!upper && c >= 'A' && c <= 'Z') c += 32;
        r.ptr[i] = c;
        i++;
    }
    r.len = i;
    while (i < s.len) {
        uint64_t at = i;
        uint32_t c = lust_utf8_next(s.ptr, &i);
        if (!upper && c == 0x3A3) {
            int fin = lust_ci_then_cased(s, at, 1) && !lust_ci_then_cased(s, at + 2, 0);
            lust_string_push_char(&r, fin ? 0x3C2 : 0x3C3);
            continue;
        }
        const uint32_t *m = upper ? lust_case_map(lust_upper_map, sizeof lust_upper_map / sizeof lust_upper_map[0], c)
                                  : lust_case_map(lust_lower_map, sizeof lust_lower_map / sizeof lust_lower_map[0], c);
        if (!m) { lust_string_push_char(&r, c); continue; }
        lust_string_push_char(&r, m[0]);
        if (m[1]) lust_string_push_char(&r, m[1]);
        if (m[2]) lust_string_push_char(&r, m[2]);
    }
    return r;
})

/* `char::to_lowercase` and `char::to_uppercase` for one char, as the
   `char_case` intrinsic returns it: the mapped code points (one to
   three, 21 bits each) in `lo`, their count in `hi`. No final-sigma
   rule: that is `str::to_lowercase` only. */
lust_u128 lust_char_case(uint32_t c, uint8_t upper) LUST_BODY({
    const uint32_t *m = upper ? lust_case_map(lust_upper_map, sizeof lust_upper_map / sizeof lust_upper_map[0], c)
                              : lust_case_map(lust_lower_map, sizeof lust_lower_map / sizeof lust_lower_map[0], c);
    uint32_t o0 = c, o1 = 0, o2 = 0;
    uint64_t n = 1;
    if (m) {
        o0 = m[0]; o1 = m[1]; o2 = m[2];
        n = o2 ? 3 : o1 ? 2 : 1;
    }
    lust_u128 r;
    r.lo = (uint64_t)o0 | ((uint64_t)o1 << 21) | ((uint64_t)o2 << 42);
    r.hi = n;
    return r;
})

/* The `encode_utf8: need ...` panic text of core (char/methods.rs),
   shared by the two encode helpers below. */
static void lust_encode_panic(const char *what, uint64_t need, uint32_t c, uint64_t have, lust_loc loc) LUST_BODY({
    char hex[16];
    int hn = 0;
    uint32_t v = c;
    if (v == 0) hex[hn++] = '0';
    char rev[16];
    int rn = 0;
    while (v) { rev[rn++] = "0123456789ABCDEF"[v & 15]; v >>= 4; }
    while (rn + hn < 4) hex[hn++] = '0';
    while (rn) hex[hn++] = rev[--rn];
    hex[hn] = 0;
    lust_String s = lust_string_new();
    lust_string_push_cstr(&s, what);
    lust_string_push_cstr(&s, ": need ");
    lust_fmt_u64(&s, need);
    lust_string_push_cstr(&s, " bytes to encode U+");
    lust_string_push_cstr(&s, hex);
    lust_string_push_cstr(&s, " but buffer has just ");
    lust_fmt_u64(&s, have);
    lust_panic_dyn(&s, loc);
})

/* `char::encode_utf8` into a caller buffer: the byte count written,
   or core's panic when the buffer is short. */
uint64_t lust_char_encode_utf8(uint32_t c, uint8_t *dst, uint64_t dst_len, lust_loc loc) LUST_BODY({
    uint64_t n = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
    if (dst_len < n) { lust_encode_panic("encode_utf8", n, c, dst_len, loc); return 0; }
    if (n == 1) {
        dst[0] = (uint8_t)c;
    } else if (n == 2) {
        dst[0] = (uint8_t)(0xC0 | (c >> 6));
        dst[1] = (uint8_t)(0x80 | (c & 0x3F));
    } else if (n == 3) {
        dst[0] = (uint8_t)(0xE0 | (c >> 12));
        dst[1] = (uint8_t)(0x80 | ((c >> 6) & 0x3F));
        dst[2] = (uint8_t)(0x80 | (c & 0x3F));
    } else {
        dst[0] = (uint8_t)(0xF0 | (c >> 18));
        dst[1] = (uint8_t)(0x80 | ((c >> 12) & 0x3F));
        dst[2] = (uint8_t)(0x80 | ((c >> 6) & 0x3F));
        dst[3] = (uint8_t)(0x80 | (c & 0x3F));
    }
    return n;
})

/* `char::encode_utf16` into a caller buffer: the unit count written,
   or core's panic (which says "bytes") when the buffer is short. */
uint64_t lust_char_encode_utf16(uint32_t c, uint16_t *dst, uint64_t dst_len, lust_loc loc) LUST_BODY({
    uint64_t n = c < 0x10000 ? 1 : 2;
    if (dst_len < n) { lust_encode_panic("encode_utf16", n, c, dst_len, loc); return 0; }
    if (n == 1) {
        dst[0] = (uint16_t)c;
    } else {
        uint32_t v = c - 0x10000;
        dst[0] = (uint16_t)(0xD800 + (v >> 10));
        dst[1] = (uint16_t)(0xDC00 + (v & 0x3FF));
    }
    return n;
})

/* UTF-8 validation with Rust's error report (core::str::validations::
   run_utf8_validation): 1 when `v` is valid; else 0 with the length of
   the valid prefix and the invalid sequence's length (1 to 3), or 0 when
   the input ends inside a sequence (Rust's `error_len() == None`). */
int lust_utf8_check(const uint8_t *v, uint64_t len, uint64_t *valid_up_to, uint8_t *error_len) LUST_BODY({
    uint64_t i = 0;
    while (i < len) {
        uint64_t start = i;
        uint8_t first = v[i];
        if (first < 0x80) {
            i++;
            /* An ASCII run: 16 bytes per step while none has its high bit, as core's
               validator skips ASCII by words (source text is mostly ASCII). */
            while (i + 16 <= len) {
                uint64_t a, b;
                memcpy(&a, v + i, 8);
                memcpy(&b, v + i + 8, 8);
                if ((a | b) & 0x8080808080808080ull) break;
                i += 16;
            }
            continue;
        }
        uint8_t el = 1;
        int w = (first >= 0xC2 && first <= 0xDF) ? 2 : (first >= 0xE0 && first <= 0xEF) ? 3 : (first >= 0xF0 && first <= 0xF4) ? 4 : 0;
        if (w == 0) goto bad;
        if (++i >= len) { el = 0; goto bad; }
        uint8_t b = v[i];
        if (w == 2) {
            if ((b & 0xC0) != 0x80) goto bad;
        } else {
            int ok = w == 3
                ? ((first == 0xE0 && b >= 0xA0 && b <= 0xBF) || (first >= 0xE1 && first <= 0xEC && b >= 0x80 && b <= 0xBF)
                   || (first == 0xED && b >= 0x80 && b <= 0x9F) || (first >= 0xEE && b >= 0x80 && b <= 0xBF))
                : ((first == 0xF0 && b >= 0x90 && b <= 0xBF) || (first >= 0xF1 && first <= 0xF3 && b >= 0x80 && b <= 0xBF)
                   || (first == 0xF4 && b >= 0x80 && b <= 0x8F));
            if (!ok) goto bad;
            el = 2;
            if (++i >= len) { el = 0; goto bad; }
            if ((v[i] & 0xC0) != 0x80) goto bad;
            if (w == 4) {
                el = 3;
                if (++i >= len) { el = 0; goto bad; }
                if ((v[i] & 0xC0) != 0x80) goto bad;
            }
        }
        i++;
        continue;
    bad:
        *valid_up_to = start;
        *error_len = el;
        return 0;
    }
    return 1;
})

/* `env::Args` (IterKind::Args): process argument `i` as a String. One
   that is not UTF-8 panics as std's `Args::next` (`back` 0) or
   `next_back` (`back` 1) does: `into_string().unwrap()` on an Err that
   prints the bytes with OsStr's Debug (valid runs as str Debug escapes
   them, each invalid byte as \xNN). */
lust_String lust_env_arg(uint64_t i, int back) LUST_BODY({
    lust_str a;
    a.ptr = (const uint8_t *)lust_argv[i];
    a.len = strlen(lust_argv[i]);
    uint64_t up;
    uint8_t el;
    if (lust_utf8_check(a.ptr, a.len, &up, &el)) return lust_string_from(a);
    lust_String s = lust_string_new();
    lust_string_push_cstr(&s, "called `Result::unwrap()` on an `Err` value: \"");
    uint64_t at = 0;
    while (at < a.len) {
        if (!lust_utf8_check(a.ptr + at, a.len - at, &up, &el)) {
            if (el == 0) el = (uint8_t)(a.len - at - up);
        } else {
            up = a.len - at;
            el = 0;
        }
        uint64_t j = at;
        while (j < at + up) lust_fmt_escape(&s, lust_utf8_next(a.ptr, &j), '"');
        for (uint64_t k = 0; k < el; k++) {
            char b[8];
            snprintf(b, sizeof b, "\\x%02X", a.ptr[at + up + k]);
            lust_string_push_cstr(&s, b);
        }
        at += up + el;
    }
    lust_string_push_cstr(&s, "\"");
    lust_panic(&s, back ? lust_std_loc(16, 914, 56) : lust_std_loc(16, 878, 51));
    return lust_string_new();
})

/* `Display` of `str::Utf8Error` (and `FromUtf8Error`, which shows its
   `Utf8Error`): Rust writes it with `write!`, so no padding applies. */
void lust_fmt_utf8_error(lust_String *out, uint64_t valid_up_to, uint32_t has_len, uint64_t len) LUST_BODY({
    if (has_len) {
        lust_string_push_cstr(out, "invalid utf-8 sequence of ");
        lust_fmt_u64(out, len);
        lust_string_push_cstr(out, " bytes from index ");
    } else {
        lust_string_push_cstr(out, "incomplete utf-8 byte sequence from index ");
    }
    lust_fmt_u64(out, valid_up_to);
})

/* char::to_digit. Returns 0xFFFFFFFF for "not a digit". */
uint32_t lust_digit(uint32_t c, uint32_t radix, lust_loc loc) LUST_BODY({
    if (radix < 2 || radix > 36) lust_panic_cstr("to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive", loc);
    uint32_t d = c >= '0' && c <= '9' ? c - '0' : (c | 32) >= 'a' && (c | 32) <= 'z' ? (c | 32) - 'a' + 10 : 0xFFFFFFFFu;
    return d < radix ? d : 0xFFFFFFFFu;
})

/* char::from_digit. Returns 0xFFFFFFFF for "not a digit in this radix".
   A radix under 2 is not a panic in Rust: every check is digit < radix. */
uint32_t lust_from_digit(uint32_t digit, uint32_t radix, lust_loc loc) LUST_BODY({
    if (radix > 36) lust_panic_cstr("from_digit: radix is too high (maximum 36)", loc);
    if (digit >= radix) return 0xFFFFFFFFu;
    return digit < 10 ? '0' + digit : 'a' + digit - 10;
})

/* Float formatting, parsing, and casts (src/runtime/float.h). */
/* Float text conversion for the lust runtime: byte-exact with Rust 1.99 std.
   Included at the end of runtime.c. The compiler inlines this header (and, for the
   runtime unit, float.c) into the generated C, because units are compiled from
   strings and cannot resolve file includes; see cgen::runtime_source.
   Correctness is gated by tests/float/fuzz.sh against rustc and ryu-js 1.0.2. */
#ifndef LUST_RT_FLOAT_H
#define LUST_RT_FLOAT_H

/* Modes for lust_float_spec.mode: Display, Debug, LowerExp, UpperExp. */
#define LUST_FLOAT_DISPLAY 0
#define LUST_FLOAT_DEBUG 1
#define LUST_FLOAT_LOWER_EXP 2
#define LUST_FLOAT_UPPER_EXP 3

/* Precision value that means "no precision was given". */
#define LUST_FLOAT_NO_PRECISION 0xFFFFFFFFu

/* One parsed format spec for a float, as Rust's format string grammar gives it.
   Zero every field for plain Display: mode 0, width 0, fill 0 (' '), align 0
   (right, like Rust numbers), precision LUST_FLOAT_NO_PRECISION.
   Notes from rustc 1.99 measurements, kept here so codegen can rely on them:
   - zero_pad (the '0' flag) beats fill and align, and pads after the sign.
     It applies to inf and NaN too ("00000inf", "00000NaN", "-0000inf").
   - alt ('#') has no effect on float output. It is accepted and ignored.
   - NaN never gets a sign, not even with plus or a negative NaN input. */
typedef struct {
    uint32_t precision;
    uint32_t width;
    uint32_t fill; /* Unicode scalar value; 0 means ' ' */
    uint8_t align; /* 0 = default, else '<', '>', or '^' */
    uint8_t plus;  /* '+' flag */
    uint8_t zero_pad;
    uint8_t alt;
    uint8_t mode;
} lust_float_spec;

/* Appends `v` formatted per `spec` (Rust Display, Debug, LowerExp, UpperExp). */
void lust_fmt_f64(lust_String *out, double v, lust_float_spec spec);
void lust_fmt_f32(lust_String *out, float v, lust_float_spec spec);

/* Plain Display ("{}") and Debug ("{:?}") with no other spec fields. */
void lust_fmt_f64_display(lust_String *out, double v);
void lust_fmt_f64_debug(lust_String *out, double v);
void lust_fmt_f32_display(lust_String *out, float v);
void lust_fmt_f32_debug(lust_String *out, float v);

/* ECMAScript Number::toString as ryu-js 1.0.2 Buffer::format does it:
   NaN, "Infinity", "-Infinity", and -0.0 prints as "0". */
void lust_fmt_js_f64(lust_String *out, double v);
void lust_fmt_js_f32(lust_String *out, float v);
/* Same text into a caller buffer of at least 32 bytes. No NUL is written.
   Returns the byte length. */
uint64_t lust_fmt_js_f64_buf(char *buf, double v);
uint64_t lust_fmt_js_f32_buf(char *buf, float v);

/* Rust str::parse::<f64> / ::<f32>. Returns 0 on success (*out is set),
   1 for an empty string, 2 for an invalid string. These are the two
   ParseFloatError kinds; overflow and underflow are success (inf or 0). */
int lust_parse_f64(lust_str s, double *out);
int lust_parse_f32(lust_str s, float *out);

/* Saturating float-to-int casts, Rust `as` semantics: NaN gives 0,
   values out of range clamp, fractions truncate toward zero. */
int8_t lust_f64_to_i8(double v);
int16_t lust_f64_to_i16(double v);
int32_t lust_f64_to_i32(double v);
int64_t lust_f64_to_i64(double v);
uint8_t lust_f64_to_u8(double v);
uint16_t lust_f64_to_u16(double v);
uint32_t lust_f64_to_u32(double v);
uint64_t lust_f64_to_u64(double v);
int8_t lust_f32_to_i8(float v);
int16_t lust_f32_to_i16(float v);
int32_t lust_f32_to_i32(float v);
int64_t lust_f32_to_i64(float v);
uint8_t lust_f32_to_u8(float v);
uint16_t lust_f32_to_u16(float v);
uint32_t lust_f32_to_u32(float v);
uint64_t lust_f32_to_u64(float v);
/* 128-bit results split into words: tcc has no __int128. *hi is the high
   64 bits (sign-extended pattern for the signed form). */
void lust_f64_to_i128(double v, uint64_t *lo, uint64_t *hi);
void lust_f64_to_u128(double v, uint64_t *lo, uint64_t *hi);
void lust_f32_to_i128(float v, uint64_t *lo, uint64_t *hi);
void lust_f32_to_u128(float v, uint64_t *lo, uint64_t *hi);

/* Int-to-float casts with a single round-to-nearest-even, done in integer
   arithmetic so no compiler can double-round them. */
double lust_i64_to_f64(int64_t v);
double lust_u64_to_f64(uint64_t v);
float lust_i64_to_f32(int64_t v);
float lust_u64_to_f32(uint64_t v);
double lust_i128_to_f64(uint64_t lo, uint64_t hi);
double lust_u128_to_f64(uint64_t lo, uint64_t hi);
float lust_i128_to_f32(uint64_t lo, uint64_t hi);
float lust_u128_to_f32(uint64_t lo, uint64_t hi);

/* Remainder (Rust `%` on floats, truncating division); defined in core.c
   next to the bounds helpers so no libm link is needed. */
double lust_fmod_f64(double, double);
float lust_fmod_f32(float, float);

/* Float-to-float casts (Rust `as`): f64 to f32 rounds to nearest even and
   overflows to inf; f32 to f64 is exact. Bit-level code, so the host
   compiler's float behavior cannot change the result. */
float lust_f64_to_f32(double v);
double lust_f32_to_f64(float v);


/* The libm entry points the float methods call: Rust lowers these
   methods to the same libm calls on this platform. The powi, min,
   max, and signum wrappers are lust's (Rust-specific semantics);
   they are defined in float.c. */
double sqrt(double);
float sqrtf(float);
double pow(double, double);
float powf(float, float);
double exp(double);
float expf(float);
double log(double);
float logf(float);
double log2(double);
float log2f(float);
double log10(double);
float log10f(float);
double floor(double);
float floorf(float);
double ceil(double);
float ceilf(float);
double round(double);
float roundf(float);
double trunc(double);
float truncf(float);
double fma(double, double, double);
float fmaf(float, float, float);
double fabs(double);
float fabsf(float);
double copysign(double, double);
float copysignf(float, float);

double lust_f64_powi(double a, int32_t e);
float lust_f32_powi(float a, int32_t e);
double lust_f64_min(double a, double b);
double lust_f64_max(double a, double b);
float lust_f32_min(float a, float b);
float lust_f32_max(float a, float b);
double lust_f64_signum(double a);
float lust_f32_signum(float a);
uint64_t lust_f64_to_bits(double v);
uint32_t lust_f32_to_bits(float v);
double lust_f64_from_bits_of(uint64_t b);
float lust_f32_from_bits_of(uint32_t b);

#ifdef LUST_IMPL
/* Implementation of the float text API declared in float.h. Included from
   float.h only in the runtime unit (LUST_IMPL), so this text never reaches
   the per-unit declarations.

   Method, in short. No conversion goes through host float arithmetic
   (one checked fast path in the parser is the only exception), so the
   output cannot depend on the C compiler:
   - Shortest printing is a Ryu port (see lust_ryu_d2d). Rust picks the
     closest candidate and rounds exact ties up; ECMAScript (ryu-js)
     rounds exact ties to an even last digit. Both facts were measured
     against rustc 1.99 and ryu-js 1.0.2 and are re-checked by
     tests/float/fuzz.sh on every run.
   - Fixed-precision output rounds the value's exact decimal digits,
     computed with a fixed-size bignum, ties to even, exactly like
     Rust's exact (Dragon) path.
   - Parsing scales the decimal input into an exact bignum ratio and
     rounds it once to the target type, ties to even. A fast path
     (Clinger) covers short inputs that one IEEE multiply or divide
     decides exactly. */

/* ---------- bit access ---------- */

static uint64_t lust_f64_bits(double v) {
    uint64_t b;
    memcpy(&b, &v, 8);
    return b;
}
static double lust_f64_from_bits(uint64_t b) {
    double v;
    memcpy(&v, &b, 8);
    return v;
}
static uint32_t lust_f32_bits(float v) {
    uint32_t b;
    memcpy(&b, &v, 4);
    return b;
}
static float lust_f32_from_bits(uint32_t b) {
    float v;
    memcpy(&v, &b, 4);
    return v;
}

/* Splits a finite float bit pattern into magnitude = m * 2^e with m > 0
   (or m == 0 for zero). `boundary` is set when the gap to the next float
   below is half the gap above (mantissa exactly a power of two, but not
   the smallest normal). */

typedef struct {
    int sign;
    int special; /* 0 finite, 1 inf, 2 NaN */
    uint64_t m;
    int e;
    int boundary;
    int mant_bits; /* 53 or 24 (counting the hidden bit) */
    uint64_t ieee_mant; /* raw fraction bits */
    uint32_t ieee_exp;  /* raw exponent field */
} lust_fparts;

static lust_fparts lust_f64_parts(double v) {
    lust_fparts p;
    uint64_t b = lust_f64_bits(v);
    int exp = (int)((b >> 52) & 0x7FF);
    uint64_t frac = b & (((uint64_t)1 << 52) - 1);
    p.sign = (int)(b >> 63);
    p.mant_bits = 53;
    p.ieee_mant = frac;
    p.ieee_exp = (uint32_t)exp;
    p.boundary = frac == 0 && exp > 1;
    if (exp == 0x7FF) {
        p.special = frac ? 2 : 1;
        p.m = 0;
        p.e = 0;
    } else if (exp == 0) {
        p.special = 0;
        p.m = frac;
        p.e = -1074;
    } else {
        p.special = 0;
        p.m = frac | ((uint64_t)1 << 52);
        p.e = exp - 1075;
    }
    return p;
}

static lust_fparts lust_f32_parts(float v) {
    lust_fparts p;
    uint32_t b = lust_f32_bits(v);
    int exp = (int)((b >> 23) & 0xFF);
    uint32_t frac = b & 0x7FFFFF;
    p.sign = (int)(b >> 31);
    p.mant_bits = 24;
    p.ieee_mant = frac;
    p.ieee_exp = (uint32_t)exp;
    p.boundary = frac == 0 && exp > 1;
    if (exp == 0xFF) {
        p.special = frac ? 2 : 1;
        p.m = 0;
        p.e = 0;
    } else if (exp == 0) {
        p.special = 0;
        p.m = frac;
        p.e = -149;
    } else {
        p.special = 0;
        p.m = frac | (1u << 23);
        p.e = exp - 150;
    }
    return p;
}

/* ---------- fixed-size bignum ----------
   Little-endian base-2^32 limbs. 256 limbs (8192 bits) hold every value the
   parser and printer build: the largest is a 1024-digit decimal (3402 bits)
   next to 5^1400 (3250 bits), plus small shifts. No allocation, no state. */

#define LUST_BIG_MAX 256

typedef struct {
    uint32_t w[LUST_BIG_MAX];
    int n; /* limbs in use; 0 means zero */
} lust_big;

static void lust_big_zero(lust_big *a) { a->n = 0; }

static void lust_big_set_u64(lust_big *a, uint64_t v) {
    a->w[0] = (uint32_t)v;
    a->w[1] = (uint32_t)(v >> 32);
    a->n = (v >> 32) ? 2 : (v ? 1 : 0);
}

static void lust_big_norm(lust_big *a) {
    while (a->n > 0 && a->w[a->n - 1] == 0) a->n--;
}

static void lust_big_mul_small(lust_big *a, uint32_t m) {
    uint64_t carry = 0;
    int i;
    if (a->n == 0 || m == 1) return;
    if (m == 0) {
        a->n = 0;
        return;
    }
    for (i = 0; i < a->n; i++) {
        uint64_t t = (uint64_t)a->w[i] * m + carry;
        a->w[i] = (uint32_t)t;
        carry = t >> 32;
    }
    while (carry && a->n < LUST_BIG_MAX) {
        a->w[a->n++] = (uint32_t)carry;
        carry >>= 32;
    }
}

static void lust_big_add_small(lust_big *a, uint32_t v) {
    uint64_t carry = v;
    int i = 0;
    while (carry) {
        uint64_t t;
        if (i >= a->n) a->w[a->n++] = 0;
        t = (uint64_t)a->w[i] + carry;
        a->w[i] = (uint32_t)t;
        carry = t >> 32;
        i++;
    }
}

/* Multiplies by 5^k for k >= 0, in 5^13 steps (largest power that keeps
   limb products inside uint64 with carry to spare). */
static void lust_big_mul_pow5(lust_big *a, int k) {
    static const uint32_t pow5[] = {1, 5, 25, 125, 625, 3125, 15625, 78125, 390625, 1953125, 9765625, 48828125, 244140625};
    while (k >= 13) {
        lust_big_mul_small(a, 1220703125u);
        k -= 13;
    }
    if (k) lust_big_mul_small(a, pow5[k]);
}

/* Multiplies by 10^k for k >= 0, in 10^9 steps. */
static void lust_big_mul_pow10(lust_big *a, int k) {
    static const uint32_t pow10[] = {1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000};
    while (k >= 9) {
        lust_big_mul_small(a, 1000000000u);
        k -= 9;
    }
    if (k) lust_big_mul_small(a, pow10[k]);
}

/* *dst = *src << bits. dst and src may be the same bignum. */
static void lust_big_shl_to(lust_big *dst, const lust_big *src, int bits) {
    lust_big tmp;
    int limbs = bits / 32, rem = bits % 32, i;
    if (src->n == 0) {
        dst->n = 0;
        return;
    }
    tmp = *src;
    for (i = 0; i < tmp.n + limbs + 1 && i < LUST_BIG_MAX; i++) dst->w[i] = 0;
    for (i = 0; i < tmp.n; i++) {
        uint32_t lo = rem ? (tmp.w[i] << rem) : tmp.w[i];
        uint32_t hi = rem ? (tmp.w[i] >> (32 - rem)) : 0;
        dst->w[i + limbs] |= lo;
        if (hi) dst->w[i + limbs + 1] |= hi;
    }
    dst->n = tmp.n + limbs + 1;
    if (dst->n > LUST_BIG_MAX) dst->n = LUST_BIG_MAX;
    lust_big_norm(dst);
}

static void lust_big_shl(lust_big *a, int bits) {
    if (bits) lust_big_shl_to(a, a, bits);
}

static int lust_big_bitlen(const lust_big *a) {
    uint32_t top;
    int bits = 0;
    if (a->n == 0) return 0;
    top = a->w[a->n - 1];
    while (top) {
        bits++;
        top >>= 1;
    }
    return (a->n - 1) * 32 + bits;
}

static int lust_big_cmp(const lust_big *a, const lust_big *b) {
    int i;
    if (a->n != b->n) return a->n < b->n ? -1 : 1;
    for (i = a->n - 1; i >= 0; i--)
        if (a->w[i] != b->w[i]) return a->w[i] < b->w[i] ? -1 : 1;
    return 0;
}

/* *a -= *b. The caller guarantees *a >= *b. */
static void lust_big_sub(lust_big *a, const lust_big *b) {
    uint64_t borrow = 0;
    int i;
    for (i = 0; i < a->n; i++) {
        uint64_t sub = (i < b->n ? b->w[i] : 0) + borrow;
        uint64_t cur = a->w[i];
        a->w[i] = (uint32_t)(cur - sub);
        borrow = cur < sub ? 1 : 0;
    }
    lust_big_norm(a);
}

/* Divides by a small value in place, returns the remainder. */
static uint32_t lust_big_divmod_small(lust_big *a, uint32_t d) {
    uint64_t rem = 0;
    int i;
    for (i = a->n - 1; i >= 0; i--) {
        uint64_t cur = (rem << 32) | a->w[i];
        a->w[i] = (uint32_t)(cur / d);
        rem = cur % d;
    }
    lust_big_norm(a);
    return (uint32_t)rem;
}

/* *a >>= 1, in place. */
static void lust_big_shr1(lust_big *a) {
    int i;
    for (i = 0; i < a->n; i++) {
        uint32_t carry = (i + 1 < a->n ? (a->w[i + 1] & 1) : 0) << 31;
        a->w[i] = (a->w[i] >> 1) | carry;
    }
    lust_big_norm(a);
}

/* floor(a / b) for quotients of at most 64 bits, with *rem = a - q*b.
   Binary long division: shift the divisor up once, then walk it down.
   The parser only divides down to 54-bit quotients. */
static uint64_t lust_big_div_q64(const lust_big *a, const lust_big *b, lust_big *rem) {
    lust_big r = *a, d;
    uint64_t q = 0;
    int shift = lust_big_bitlen(a) - lust_big_bitlen(b);
    int i;
    if (shift < 0) {
        *rem = r;
        return 0;
    }
    lust_big_shl_to(&d, b, shift);
    for (i = shift; i >= 0; i--) {
        if (lust_big_cmp(&d, &r) <= 0) {
            lust_big_sub(&r, &d);
            q |= (uint64_t)1 << i;
        }
        lust_big_shr1(&d);
    }
    *rem = r;
    return q;
}

/* ---------- exact decimal digits ----------
   A positive value as (digits, len, e10) meaning 0.digits * 10^e10, with
   no leading or trailing zeros in digits. Every finite float has a finite
   exact form here: at most 767 significant digits for f64. */

#define LUST_DIG_MAX 800

typedef struct {
    char d[LUST_DIG_MAX];
    int len;
    int e10;
} lust_dec;

/* Exact digits of mant * 2^e2 for mant > 0. */
static void lust_dec_exact(lust_dec *out, uint64_t mant, int e2) {
    lust_big n;
    char rev[LUST_DIG_MAX];
    int rn = 0, off = 0, i;
    lust_big_set_u64(&n, mant);
    if (e2 >= 0) {
        lust_big_shl(&n, e2);
    } else {
        lust_big_mul_pow5(&n, -e2);
        off = e2; /* value = n * 10^off */
    }
    while (n.n > 0) {
        uint32_t chunk = lust_big_divmod_small(&n, 1000000000u);
        int c;
        if (n.n == 0) {
            while (chunk) {
                rev[rn++] = (char)('0' + chunk % 10);
                chunk /= 10;
            }
        } else {
            for (c = 0; c < 9; c++) {
                rev[rn++] = (char)('0' + chunk % 10);
                chunk /= 10;
            }
        }
    }
    out->len = rn;
    out->e10 = rn + off;
    for (i = 0; i < rn; i++) out->d[i] = rev[rn - 1 - i];
    while (out->len > 1 && out->d[out->len - 1] == '0') out->len--;
}

/* Compares two positive normalized decimals: -1, 0, or 1. The (d, len, e10)
   form allows a shorter `len` view of a longer digit string; trailing
   zeros past len read as zeros. */
static int lust_dec_cmp(const char *d1, int l1, int e1, const char *d2, int l2, int e2) {
    int i, n;
    if (e1 != e2) return e1 < e2 ? -1 : 1;
    n = l1 > l2 ? l1 : l2;
    for (i = 0; i < n; i++) {
        char a = i < l1 ? d1[i] : '0';
        char b = i < l2 ? d2[i] : '0';
        if (a != b) return a < b ? -1 : 1;
    }
    return 0;
}

/* ---------- shortest digits: Ryu ----------
   Ported from ryu-js 1.0.2 (d2s.rs, f2s.rs, the intrinsics files, and
   common.rs), itself a port of Ulf Adams' Ryu C code (Apache-2.0 or
   Boost-1.0). Two changes from the original:
   - 128-bit products use 32-bit limbs, because tcc has no __int128.
   - When tie_up is set, an exact tie between the two shortest
     candidates rounds up (Rust's rule) instead of to even (the
     ECMAScript rule). The tie is decided in exactly one place in
     each core loop, marked below.
   tests/float/fuzz.sh checks both tie modes against rustc and
   against the ryu-js crate itself. */

/* Ryu pow5 split tables, generated by tests/float/gen_ryu_tables.py from
   ryu-js 1.0.2 (Ulf Adams' Ryu, Apache-2.0 or Boost-1.0). Do not edit.
   Each pair is (low, high) 64-bit halves of a 128-bit table entry. */
static const uint64_t lust_ryu_pow5_inv[342][2] = {
    {1ull, 2305843009213693952ull}, {11068046444225730970ull, 1844674407370955161ull},
    {5165088340638674453ull, 1475739525896764129ull}, {7821419487252849886ull, 1180591620717411303ull},
    {8824922364862649494ull, 1888946593147858085ull}, {7059937891890119595ull, 1511157274518286468ull},
    {13026647942995916322ull, 1208925819614629174ull}, {9774590264567735146ull, 1934281311383406679ull},
    {11509021026396098440ull, 1547425049106725343ull}, {16585914450600699399ull, 1237940039285380274ull},
    {15469416676735388068ull, 1980704062856608439ull}, {16064882156130220778ull, 1584563250285286751ull},
    {9162556910162266299ull, 1267650600228229401ull}, {7281393426775805432ull, 2028240960365167042ull},
    {16893161185646375315ull, 1622592768292133633ull}, {2446482504291369283ull, 1298074214633706907ull},
    {7603720821608101175ull, 2076918743413931051ull}, {2393627842544570617ull, 1661534994731144841ull},
    {16672297533003297786ull, 1329227995784915872ull}, {11918280793837635165ull, 2126764793255865396ull},
    {5845275820328197809ull, 1701411834604692317ull}, {15744267100488289217ull, 1361129467683753853ull},
    {3054734472329800808ull, 2177807148294006166ull}, {17201182836831481939ull, 1742245718635204932ull},
    {6382248639981364905ull, 1393796574908163946ull}, {2832900194486363201ull, 2230074519853062314ull},
    {5955668970331000884ull, 1784059615882449851ull}, {1075186361522890384ull, 1427247692705959881ull},
    {12788344622662355584ull, 2283596308329535809ull}, {13920024512871794791ull, 1826877046663628647ull},
    {3757321980813615186ull, 1461501637330902918ull}, {10384555214134712795ull, 1169201309864722334ull},
    {5547241898389809503ull, 1870722095783555735ull}, {4437793518711847602ull, 1496577676626844588ull},
    {10928932444453298728ull, 1197262141301475670ull}, {17486291911125277965ull, 1915619426082361072ull},
    {6610335899416401726ull, 1532495540865888858ull}, {12666966349016942027ull, 1225996432692711086ull},
    {12888448528943286597ull, 1961594292308337738ull}, {17689456452638449924ull, 1569275433846670190ull},
    {14151565162110759939ull, 1255420347077336152ull}, {7885109000409574610ull, 2008672555323737844ull},
    {9997436015069570011ull, 1606938044258990275ull}, {7997948812055656009ull, 1285550435407192220ull},
    {12796718099289049614ull, 2056880696651507552ull}, {2858676849947419045ull, 1645504557321206042ull},
    {13354987924183666206ull, 1316403645856964833ull}, {17678631863951955605ull, 2106245833371143733ull},
    {3074859046935833515ull, 1684996666696914987ull}, {13527933681774397782ull, 1347997333357531989ull},
    {10576647446613305481ull, 2156795733372051183ull}, {15840015586774465031ull, 1725436586697640946ull},
    {8982663654677661702ull, 1380349269358112757ull}, {18061610662226169046ull, 2208558830972980411ull},
    {10759939715039024913ull, 1766847064778384329ull}, {12297300586773130254ull, 1413477651822707463ull},
    {15986332124095098083ull, 2261564242916331941ull}, {9099716884534168143ull, 1809251394333065553ull},
    {14658471137111155161ull, 1447401115466452442ull}, {4348079280205103483ull, 1157920892373161954ull},
    {14335624477811986218ull, 1852673427797059126ull}, {7779150767507678651ull, 1482138742237647301ull},
    {2533971799264232598ull, 1185710993790117841ull}, {15122401323048503126ull, 1897137590064188545ull},
    {12097921058438802501ull, 1517710072051350836ull}, {5988988032009131678ull, 1214168057641080669ull},
    {16961078480698431330ull, 1942668892225729070ull}, {13568862784558745064ull, 1554135113780583256ull},
    {7165741412905085728ull, 1243308091024466605ull}, {11465186260648137165ull, 1989292945639146568ull},
    {16550846638002330379ull, 1591434356511317254ull}, {16930026125143774626ull, 1273147485209053803ull},
    {4951948911778577463ull, 2037035976334486086ull}, {272210314680951647ull, 1629628781067588869ull},
    {3907117066486671641ull, 1303703024854071095ull}, {6251387306378674625ull, 2085924839766513752ull},
    {16069156289328670670ull, 1668739871813211001ull}, {9165976216721026213ull, 1334991897450568801ull},
    {7286864317269821294ull, 2135987035920910082ull}, {16897537898041588005ull, 1708789628736728065ull},
    {13518030318433270404ull, 1367031702989382452ull}, {6871453250525591353ull, 2187250724783011924ull},
    {9186511415162383406ull, 1749800579826409539ull}, {11038557946871817048ull, 1399840463861127631ull},
    {10282995085511086630ull, 2239744742177804210ull}, {8226396068408869304ull, 1791795793742243368ull},
    {13959814484210916090ull, 1433436634993794694ull}, {11267656730511734774ull, 2293498615990071511ull},
    {5324776569667477496ull, 1834798892792057209ull}, {7949170070475892320ull, 1467839114233645767ull},
    {17427382500606444826ull, 1174271291386916613ull}, {5747719112518849781ull, 1878834066219066582ull},
    {15666221734240810795ull, 1503067252975253265ull}, {12532977387392648636ull, 1202453802380202612ull},
    {5295368560860596524ull, 1923926083808324180ull}, {4236294848688477220ull, 1539140867046659344ull},
    {7078384693692692099ull, 1231312693637327475ull}, {11325415509908307358ull, 1970100309819723960ull},
    {9060332407926645887ull, 1576080247855779168ull}, {14626963555825137356ull, 1260864198284623334ull},
    {12335095245094488799ull, 2017382717255397335ull}, {9868076196075591040ull, 1613906173804317868ull},
    {15273158586344293478ull, 1291124939043454294ull}, {13369007293925138595ull, 2065799902469526871ull},
    {7005857020398200553ull, 1652639921975621497ull}, {16672732060544291412ull, 1322111937580497197ull},
    {11918976037903224966ull, 2115379100128795516ull}, {5845832015580669650ull, 1692303280103036413ull},
    {12055363241948356366ull, 1353842624082429130ull}, {841837113407818570ull, 2166148198531886609ull},
    {4362818505468165179ull, 1732918558825509287ull}, {14558301248600263113ull, 1386334847060407429ull},
    {12225235553534690011ull, 2218135755296651887ull}, {2401490813343931363ull, 1774508604237321510ull},
    {1921192650675145090ull, 1419606883389857208ull}, {17831303500047873437ull, 2271371013423771532ull},
    {6886345170554478103ull, 1817096810739017226ull}, {1819727321701672159ull, 1453677448591213781ull},
    {16213177116328979020ull, 1162941958872971024ull}, {14873036941900635463ull, 1860707134196753639ull},
    {15587778368262418694ull, 1488565707357402911ull}, {8780873879868024632ull, 1190852565885922329ull},
    {2981351763563108441ull, 1905364105417475727ull}, {13453127855076217722ull, 1524291284333980581ull},
    {7073153469319063855ull, 1219433027467184465ull}, {11317045550910502167ull, 1951092843947495144ull},
    {12742985255470312057ull, 1560874275157996115ull}, {10194388204376249646ull, 1248699420126396892ull},
    {1553625868034358140ull, 1997919072202235028ull}, {8621598323911307159ull, 1598335257761788022ull},
    {17965325103354776697ull, 1278668206209430417ull}, {13987124906400001422ull, 2045869129935088668ull},
    {121653480894270168ull, 1636695303948070935ull}, {97322784715416134ull, 1309356243158456748ull},
    {14913111714512307107ull, 2094969989053530796ull}, {8241140556867935363ull, 1675975991242824637ull},
    {17660958889720079260ull, 1340780792994259709ull}, {17189487779326395846ull, 2145249268790815535ull},
    {13751590223461116677ull, 1716199415032652428ull}, {18379969808252713988ull, 1372959532026121942ull},
    {14650556434236701088ull, 2196735251241795108ull}, {652398703163629901ull, 1757388200993436087ull},
    {11589965406756634890ull, 1405910560794748869ull}, {7475898206584884855ull, 2249456897271598191ull},
    {2291369750525997561ull, 1799565517817278553ull}, {9211793429904618695ull, 1439652414253822842ull},
    {18428218302589300235ull, 2303443862806116547ull}, {7363877012587619542ull, 1842755090244893238ull},
    {13269799239553916280ull, 1474204072195914590ull}, {10615839391643133024ull, 1179363257756731672ull},
    {2227947767661371545ull, 1886981212410770676ull}, {16539753473096738529ull, 1509584969928616540ull},
    {13231802778477390823ull, 1207667975942893232ull}, {6413489186596184024ull, 1932268761508629172ull},
    {16198837793502678189ull, 1545815009206903337ull}, {5580372605318321905ull, 1236652007365522670ull},
    {8928596168509315048ull, 1978643211784836272ull}, {18210923379033183008ull, 1582914569427869017ull},
    {7190041073742725760ull, 1266331655542295214ull}, {436019273762630246ull, 2026130648867672343ull},
    {7727513048493924843ull, 1620904519094137874ull}, {9871359253537050198ull, 1296723615275310299ull},
    {4726128361433549347ull, 2074757784440496479ull}, {7470251503888749801ull, 1659806227552397183ull},
    {13354898832594820487ull, 1327844982041917746ull}, {13989140502667892133ull, 2124551971267068394ull},
    {14880661216876224029ull, 1699641577013654715ull}, {11904528973500979224ull, 1359713261610923772ull},
    {4289851098633925465ull, 2175541218577478036ull}, {18189276137874781665ull, 1740432974861982428ull},
    {3483374466074094362ull, 1392346379889585943ull}, {1884050330976640656ull, 2227754207823337509ull},
    {5196589079523222848ull, 1782203366258670007ull}, {15225317707844309248ull, 1425762693006936005ull},
    {5913764258841343181ull, 2281220308811097609ull}, {8420360221814984868ull, 1824976247048878087ull},
    {17804334621677718864ull, 1459980997639102469ull}, {17932816512084085415ull, 1167984798111281975ull},
    {10245762345624985047ull, 1868775676978051161ull}, {4507261061758077715ull, 1495020541582440929ull},
    {7295157664148372495ull, 1196016433265952743ull}, {7982903447895485668ull, 1913626293225524389ull},
    {10075671573058298858ull, 1530901034580419511ull}, {4371188443704728763ull, 1224720827664335609ull},
    {14372599139411386667ull, 1959553324262936974ull}, {15187428126271019657ull, 1567642659410349579ull},
    {15839291315758726049ull, 1254114127528279663ull}, {3206773216762499739ull, 2006582604045247462ull},
    {13633465017635730761ull, 1605266083236197969ull}, {14596120828850494932ull, 1284212866588958375ull},
    {4907049252451240275ull, 2054740586542333401ull}, {236290587219081897ull, 1643792469233866721ull},
    {14946427728742906810ull, 1315033975387093376ull}, {16535586736504830250ull, 2104054360619349402ull},
    {5849771759720043554ull, 1683243488495479522ull}, {15747863852001765813ull, 1346594790796383617ull},
    {10439186904235184007ull, 2154551665274213788ull}, {15730047152871967852ull, 1723641332219371030ull},
    {12584037722297574282ull, 1378913065775496824ull}, {9066413911450387881ull, 2206260905240794919ull},
    {10942479943902220628ull, 1765008724192635935ull}, {8753983955121776503ull, 1412006979354108748ull},
    {10317025513452932081ull, 2259211166966573997ull}, {874922781278525018ull, 1807368933573259198ull},
    {8078635854506640661ull, 1445895146858607358ull}, {13841606313089133175ull, 1156716117486885886ull},
    {14767872471458792434ull, 1850745787979017418ull}, {746251532941302978ull, 1480596630383213935ull},
    {597001226353042382ull, 1184477304306571148ull}, {15712597221132509104ull, 1895163686890513836ull},
    {8880728962164096960ull, 1516130949512411069ull}, {10793931984473187891ull, 1212904759609928855ull},
    {17270291175157100626ull, 1940647615375886168ull}, {2748186495899949531ull, 1552518092300708935ull},
    {2198549196719959625ull, 1242014473840567148ull}, {18275073973719576693ull, 1987223158144907436ull},
    {10930710364233751031ull, 1589778526515925949ull}, {12433917106128911148ull, 1271822821212740759ull},
    {8826220925580526867ull, 2034916513940385215ull}, {7060976740464421494ull, 1627933211152308172ull},
    {16716827836597268165ull, 1302346568921846537ull}, {11989529279587987770ull, 2083754510274954460ull},
    {9591623423670390216ull, 1667003608219963568ull}, {15051996368420132820ull, 1333602886575970854ull},
    {13015147745246481542ull, 2133764618521553367ull}, {3033420566713364587ull, 1707011694817242694ull},
    {6116085268112601993ull, 1365609355853794155ull}, {9785736428980163188ull, 2184974969366070648ull},
    {15207286772667951197ull, 1747979975492856518ull}, {1097782973908629988ull, 1398383980394285215ull},
    {1756452758253807981ull, 2237414368630856344ull}, {5094511021344956708ull, 1789931494904685075ull},
    {4075608817075965366ull, 1431945195923748060ull}, {6520974107321544586ull, 2291112313477996896ull},
    {1527430471115325346ull, 1832889850782397517ull}, {12289990821117991246ull, 1466311880625918013ull},
    {17210690286378213644ull, 1173049504500734410ull}, {9090360384495590213ull, 1876879207201175057ull},
    {18340334751822203140ull, 1501503365760940045ull}, {14672267801457762512ull, 1201202692608752036ull},
    {16096930852848599373ull, 1921924308174003258ull}, {1809498238053148529ull, 1537539446539202607ull},
    {12515645034668249793ull, 1230031557231362085ull}, {1578287981759648052ull, 1968050491570179337ull},
    {12330676829633449412ull, 1574440393256143469ull}, {13553890278448669853ull, 1259552314604914775ull},
    {3239480371808320148ull, 2015283703367863641ull}, {17348979556414297411ull, 1612226962694290912ull},
    {6500486015647617283ull, 1289781570155432730ull}, {10400777625036187652ull, 2063650512248692368ull},
    {15699319729512770768ull, 1650920409798953894ull}, {16248804598352126938ull, 1320736327839163115ull},
    {7551343283653851484ull, 2113178124542660985ull}, {6041074626923081187ull, 1690542499634128788ull},
    {12211557331022285596ull, 1352433999707303030ull}, {1091747655926105338ull, 2163894399531684849ull},
    {4562746939482794594ull, 1731115519625347879ull}, {7339546366328145998ull, 1384892415700278303ull},
    {8053925371383123274ull, 2215827865120445285ull}, {6443140297106498619ull, 1772662292096356228ull},
    {12533209867169019542ull, 1418129833677084982ull}, {5295740528502789974ull, 2269007733883335972ull},
    {15304638867027962949ull, 1815206187106668777ull}, {4865013464138549713ull, 1452164949685335022ull},
    {14960057215536570740ull, 1161731959748268017ull}, {9178696285890871890ull, 1858771135597228828ull},
    {14721654658196518159ull, 1487016908477783062ull}, {4398626097073393881ull, 1189613526782226450ull},
    {7037801755317430209ull, 1903381642851562320ull}, {5630241404253944167ull, 1522705314281249856ull},
    {814844308661245011ull, 1218164251424999885ull}, {1303750893857992017ull, 1949062802279999816ull},
    {15800395974054034906ull, 1559250241823999852ull}, {5261619149759407279ull, 1247400193459199882ull},
    {12107939454356961969ull, 1995840309534719811ull}, {5997002748743659252ull, 1596672247627775849ull},
    {8486951013736837725ull, 1277337798102220679ull}, {2511075177753209390ull, 2043740476963553087ull},
    {13076906586428298482ull, 1634992381570842469ull}, {14150874083884549109ull, 1307993905256673975ull},
    {4194654460505726958ull, 2092790248410678361ull}, {18113118827372222859ull, 1674232198728542688ull},
    {3422448617672047318ull, 1339385758982834151ull}, {16543964232501006678ull, 2143017214372534641ull},
    {9545822571258895019ull, 1714413771498027713ull}, {15015355686490936662ull, 1371531017198422170ull},
    {5577825024675947042ull, 2194449627517475473ull}, {11840957649224578280ull, 1755559702013980378ull},
    {16851463748863483271ull, 1404447761611184302ull}, {12204946739213931940ull, 2247116418577894884ull},
    {13453306206113055875ull, 1797693134862315907ull}, {3383947335406624054ull, 1438154507889852726ull},
    {16482362180876329456ull, 2301047212623764361ull}, {9496540929959153242ull, 1840837770099011489ull},
    {11286581558709232917ull, 1472670216079209191ull}, {5339916432225476010ull, 1178136172863367353ull},
    {4854517476818851293ull, 1885017876581387765ull}, {3883613981455081034ull, 1508014301265110212ull},
    {14174937629389795797ull, 1206411441012088169ull}, {11611853762797942306ull, 1930258305619341071ull},
    {5600134195496443521ull, 1544206644495472857ull}, {15548153800622885787ull, 1235365315596378285ull},
    {6430302007287065643ull, 1976584504954205257ull}, {16212288050055383484ull, 1581267603963364205ull},
    {12969830440044306787ull, 1265014083170691364ull}, {9683682259845159889ull, 2024022533073106183ull},
    {15125643437359948558ull, 1619218026458484946ull}, {8411165935146048523ull, 1295374421166787957ull},
    {17147214310975587960ull, 2072599073866860731ull}, {10028422634038560045ull, 1658079259093488585ull},
    {8022738107230848036ull, 1326463407274790868ull}, {9147032156827446534ull, 2122341451639665389ull},
    {11006974540203867551ull, 1697873161311732311ull}, {5116230817421183718ull, 1358298529049385849ull},
    {15564666937357714594ull, 2173277646479017358ull}, {1383687105660440706ull, 1738622117183213887ull},
    {12174996128754083534ull, 1390897693746571109ull}, {8411947361780802685ull, 2225436309994513775ull},
    {6729557889424642148ull, 1780349047995611020ull}, {5383646311539713719ull, 1424279238396488816ull},
    {1235136468979721303ull, 2278846781434382106ull}, {15745504434151418335ull, 1823077425147505684ull},
    {16285752362063044992ull, 1458461940118004547ull}, {5649904260166615347ull, 1166769552094403638ull},
    {5350498001524674232ull, 1866831283351045821ull}, {591049586477829062ull, 1493465026680836657ull},
    {11540886113407994219ull, 1194772021344669325ull}, {18673707743239135ull, 1911635234151470921ull},
    {14772334225162232601ull, 1529308187321176736ull}, {8128518565387875758ull, 1223446549856941389ull},
    {1937583260394870242ull, 1957514479771106223ull}, {8928764237799716840ull, 1566011583816884978ull},
    {14521709019723594119ull, 1252809267053507982ull}, {8477339172590109297ull, 2004494827285612772ull},
    {17849917782297818407ull, 1603595861828490217ull}, {6901236596354434079ull, 1282876689462792174ull},
    {18420676183650915173ull, 2052602703140467478ull}, {3668494502695001169ull, 1642082162512373983ull},
    {10313493231639821582ull, 1313665730009899186ull}, {9122891541139893884ull, 2101865168015838698ull},
    {14677010862395735754ull, 1681492134412670958ull}, {673562245690857633ull, 1345193707530136767ull},
};
static const uint64_t lust_ryu_pow5[326][2] = {
    {0ull, 1152921504606846976ull}, {0ull, 1441151880758558720ull},
    {0ull, 1801439850948198400ull}, {0ull, 2251799813685248000ull},
    {0ull, 1407374883553280000ull}, {0ull, 1759218604441600000ull},
    {0ull, 2199023255552000000ull}, {0ull, 1374389534720000000ull},
    {0ull, 1717986918400000000ull}, {0ull, 2147483648000000000ull},
    {0ull, 1342177280000000000ull}, {0ull, 1677721600000000000ull},
    {0ull, 2097152000000000000ull}, {0ull, 1310720000000000000ull},
    {0ull, 1638400000000000000ull}, {0ull, 2048000000000000000ull},
    {0ull, 1280000000000000000ull}, {0ull, 1600000000000000000ull},
    {0ull, 2000000000000000000ull}, {0ull, 1250000000000000000ull},
    {0ull, 1562500000000000000ull}, {0ull, 1953125000000000000ull},
    {0ull, 1220703125000000000ull}, {0ull, 1525878906250000000ull},
    {0ull, 1907348632812500000ull}, {0ull, 1192092895507812500ull},
    {0ull, 1490116119384765625ull}, {4611686018427387904ull, 1862645149230957031ull},
    {9799832789158199296ull, 1164153218269348144ull}, {12249790986447749120ull, 1455191522836685180ull},
    {15312238733059686400ull, 1818989403545856475ull}, {14528612397897220096ull, 2273736754432320594ull},
    {13692068767113150464ull, 1421085471520200371ull}, {12503399940464050176ull, 1776356839400250464ull},
    {15629249925580062720ull, 2220446049250313080ull}, {9768281203487539200ull, 1387778780781445675ull},
    {7598665485932036096ull, 1734723475976807094ull}, {274959820560269312ull, 2168404344971008868ull},
    {9395221924704944128ull, 1355252715606880542ull}, {2520655369026404352ull, 1694065894508600678ull},
    {12374191248137781248ull, 2117582368135750847ull}, {14651398557727195136ull, 1323488980084844279ull},
    {13702562178731606016ull, 1654361225106055349ull}, {3293144668132343808ull, 2067951531382569187ull},
    {18199116482078572544ull, 1292469707114105741ull}, {8913837547316051968ull, 1615587133892632177ull},
    {15753982952572452864ull, 2019483917365790221ull}, {12152082354571476992ull, 1262177448353618888ull},
    {15190102943214346240ull, 1577721810442023610ull}, {9764256642163156992ull, 1972152263052529513ull},
    {17631875447420442880ull, 1232595164407830945ull}, {8204786253993389888ull, 1540743955509788682ull},
    {1032610780636961552ull, 1925929944387235853ull}, {2951224747111794922ull, 1203706215242022408ull},
    {3689030933889743652ull, 1504632769052528010ull}, {13834660704216955373ull, 1880790961315660012ull},
    {17870034976990372916ull, 1175494350822287507ull}, {17725857702810578241ull, 1469367938527859384ull},
    {3710578054803671186ull, 1836709923159824231ull}, {26536550077201078ull, 2295887403949780289ull},
    {11545800389866720434ull, 1434929627468612680ull}, {14432250487333400542ull, 1793662034335765850ull},
    {8816941072311974870ull, 2242077542919707313ull}, {17039803216263454053ull, 1401298464324817070ull},
    {12076381983474541759ull, 1751623080406021338ull}, {5872105442488401391ull, 2189528850507526673ull},
    {15199280947623720629ull, 1368455531567204170ull}, {9775729147674874978ull, 1710569414459005213ull},
    {16831347453020981627ull, 2138211768073756516ull}, {1296220121283337709ull, 1336382355046097823ull},
    {15455333206886335848ull, 1670477943807622278ull}, {10095794471753144002ull, 2088097429759527848ull},
    {6309871544845715001ull, 1305060893599704905ull}, {12499025449484531656ull, 1631326116999631131ull},
    {11012095793428276666ull, 2039157646249538914ull}, {11494245889320060820ull, 1274473528905961821ull},
    {532749306367912313ull, 1593091911132452277ull}, {5277622651387278295ull, 1991364888915565346ull},
    {7910200175544436838ull, 1244603055572228341ull}, {14499436237857933952ull, 1555753819465285426ull},
    {8900923260467641632ull, 1944692274331606783ull}, {12480606065433357876ull, 1215432671457254239ull},
    {10989071563364309441ull, 1519290839321567799ull}, {9124653435777998898ull, 1899113549151959749ull},
    {8008751406574943263ull, 1186945968219974843ull}, {5399253239791291175ull, 1483682460274968554ull},
    {15972438586593889776ull, 1854603075343710692ull}, {759402079766405302ull, 1159126922089819183ull},
    {14784310654990170340ull, 1448908652612273978ull}, {9257016281882937117ull, 1811135815765342473ull},
    {16182956370781059300ull, 2263919769706678091ull}, {7808504722524468110ull, 1414949856066673807ull},
    {5148944884728197234ull, 1768687320083342259ull}, {1824495087482858639ull, 2210859150104177824ull},
    {1140309429676786649ull, 1381786968815111140ull}, {1425386787095983311ull, 1727233711018888925ull},
    {6393419502297367043ull, 2159042138773611156ull}, {13219259225790630210ull, 1349401336733506972ull},
    {16524074032238287762ull, 1686751670916883715ull}, {16043406521870471799ull, 2108439588646104644ull},
    {803757039314269066ull, 1317774742903815403ull}, {14839754354425000045ull, 1647218428629769253ull},
    {4714634887749086344ull, 2059023035787211567ull}, {9864175832484260821ull, 1286889397367007229ull},
    {16941905809032713930ull, 1608611746708759036ull}, {2730638187581340797ull, 2010764683385948796ull},
    {10930020904093113806ull, 1256727927116217997ull}, {18274212148543780162ull, 1570909908895272496ull},
    {4396021111970173586ull, 1963637386119090621ull}, {5053356204195052443ull, 1227273366324431638ull},
    {15540067292098591362ull, 1534091707905539547ull}, {14813398096695851299ull, 1917614634881924434ull},
    {13870059828862294966ull, 1198509146801202771ull}, {12725888767650480803ull, 1498136433501503464ull},
    {15907360959563101004ull, 1872670541876879330ull}, {14553786618154326031ull, 1170419088673049581ull},
    {4357175217410743827ull, 1463023860841311977ull}, {10058155040190817688ull, 1828779826051639971ull},
    {7961007781811134206ull, 2285974782564549964ull}, {14199001900486734687ull, 1428734239102843727ull},
    {13137066357181030455ull, 1785917798878554659ull}, {11809646928048900164ull, 2232397248598193324ull},
    {16604401366885338411ull, 1395248280373870827ull}, {16143815690179285109ull, 1744060350467338534ull},
    {10956397575869330579ull, 2180075438084173168ull}, {6847748484918331612ull, 1362547148802608230ull},
    {17783057643002690323ull, 1703183936003260287ull}, {17617136035325974999ull, 2128979920004075359ull},
    {17928239049719816230ull, 1330612450002547099ull}, {17798612793722382384ull, 1663265562503183874ull},
    {13024893955298202172ull, 2079081953128979843ull}, {5834715712847682405ull, 1299426220705612402ull},
    {16516766677914378815ull, 1624282775882015502ull}, {11422586310538197711ull, 2030353469852519378ull},
    {11750802462513761473ull, 1268970918657824611ull}, {10076817059714813937ull, 1586213648322280764ull},
    {12596021324643517422ull, 1982767060402850955ull}, {5566670318688504437ull, 1239229412751781847ull},
    {2346651879933242642ull, 1549036765939727309ull}, {7545000868343941206ull, 1936295957424659136ull},
    {4715625542714963254ull, 1210184973390411960ull}, {5894531928393704067ull, 1512731216738014950ull},
    {16591536947346905892ull, 1890914020922518687ull}, {17287239619732898039ull, 1181821263076574179ull},
    {16997363506238734644ull, 1477276578845717724ull}, {2799960309088866689ull, 1846595723557147156ull},
    {10973347230035317489ull, 1154122327223216972ull}, {13716684037544146861ull, 1442652909029021215ull},
    {12534169028502795672ull, 1803316136286276519ull}, {11056025267201106687ull, 2254145170357845649ull},
    {18439230838069161439ull, 1408840731473653530ull}, {13825666510731675991ull, 1761050914342066913ull},
    {3447025083132431277ull, 2201313642927583642ull}, {6766076695385157452ull, 1375821026829739776ull},
    {8457595869231446815ull, 1719776283537174720ull}, {10571994836539308519ull, 2149720354421468400ull},
    {6607496772837067824ull, 1343575221513417750ull}, {17482743002901110588ull, 1679469026891772187ull},
    {17241742735199000331ull, 2099336283614715234ull}, {15387775227926763111ull, 1312085177259197021ull},
    {5399660979626290177ull, 1640106471573996277ull}, {11361262242960250625ull, 2050133089467495346ull},
    {11712474920277544544ull, 1281333180917184591ull}, {10028907631919542777ull, 1601666476146480739ull},
    {7924448521472040567ull, 2002083095183100924ull}, {14176152362774801162ull, 1251301934489438077ull},
    {3885132398186337741ull, 1564127418111797597ull}, {9468101516160310080ull, 1955159272639746996ull},
    {15140935484454969608ull, 1221974545399841872ull}, {479425281859160394ull, 1527468181749802341ull},
    {5210967620751338397ull, 1909335227187252926ull}, {17091912818251750210ull, 1193334516992033078ull},
    {12141518985959911954ull, 1491668146240041348ull}, {15176898732449889943ull, 1864585182800051685ull},
    {11791404716994875166ull, 1165365739250032303ull}, {10127569877816206054ull, 1456707174062540379ull},
    {8047776328842869663ull, 1820883967578175474ull}, {836348374198811271ull, 2276104959472719343ull},
    {7440246761515338900ull, 1422565599670449589ull}, {13911994470321561530ull, 1778206999588061986ull},
    {8166621051047176104ull, 2222758749485077483ull}, {2798295147690791113ull, 1389224218428173427ull},
    {17332926989895652603ull, 1736530273035216783ull}, {17054472718942177850ull, 2170662841294020979ull},
    {8353202440125167204ull, 1356664275808763112ull}, {10441503050156459005ull, 1695830344760953890ull},
    {3828506775840797949ull, 2119787930951192363ull}, {86973725686804766ull, 1324867456844495227ull},
    {13943775212390669669ull, 1656084321055619033ull}, {3594660960206173375ull, 2070105401319523792ull},
    {2246663100128858359ull, 1293815875824702370ull}, {12031700912015848757ull, 1617269844780877962ull},
    {5816254103165035138ull, 2021587305976097453ull}, {5941001823691840913ull, 1263492066235060908ull},
    {7426252279614801142ull, 1579365082793826135ull}, {4671129331091113523ull, 1974206353492282669ull},
    {5225298841145639904ull, 1233878970932676668ull}, {6531623551432049880ull, 1542348713665845835ull},
    {3552843420862674446ull, 1927935892082307294ull}, {16055585193321335241ull, 1204959932551442058ull},
    {10846109454796893243ull, 1506199915689302573ull}, {18169322836923504458ull, 1882749894611628216ull},
    {11355826773077190286ull, 1176718684132267635ull}, {9583097447919099954ull, 1470898355165334544ull},
    {11978871809898874942ull, 1838622943956668180ull}, {14973589762373593678ull, 2298278679945835225ull},
    {2440964573842414192ull, 1436424174966147016ull}, {3051205717303017741ull, 1795530218707683770ull},
    {13037379183483547984ull, 2244412773384604712ull}, {8148361989677217490ull, 1402757983365377945ull},
    {14797138505523909766ull, 1753447479206722431ull}, {13884737113477499304ull, 2191809349008403039ull},
    {15595489723564518921ull, 1369880843130251899ull}, {14882676136028260747ull, 1712351053912814874ull},
    {9379973133180550126ull, 2140438817391018593ull}, {17391698254306313589ull, 1337774260869386620ull},
    {3292878744173340370ull, 1672217826086733276ull}, {4116098430216675462ull, 2090272282608416595ull},
    {266718509671728212ull, 1306420176630260372ull}, {333398137089660265ull, 1633025220787825465ull},
    {5028433689789463235ull, 2041281525984781831ull}, {10060300083759496378ull, 1275800953740488644ull},
    {12575375104699370472ull, 1594751192175610805ull}, {1884160825592049379ull, 1993438990219513507ull},
    {17318501580490888525ull, 1245899368887195941ull}, {7813068920331446945ull, 1557374211108994927ull},
    {5154650131986920777ull, 1946717763886243659ull}, {915813323278131534ull, 1216698602428902287ull},
    {14979824709379828129ull, 1520873253036127858ull}, {9501408849870009354ull, 1901091566295159823ull},
    {12855909558809837702ull, 1188182228934474889ull}, {2234828893230133415ull, 1485227786168093612ull},
    {2793536116537666769ull, 1856534732710117015ull}, {8663489100477123587ull, 1160334207943823134ull},
    {1605989338741628675ull, 1450417759929778918ull}, {11230858710281811652ull, 1813022199912223647ull},
    {9426887369424876662ull, 2266277749890279559ull}, {12809333633531629769ull, 1416423593681424724ull},
    {16011667041914537212ull, 1770529492101780905ull}, {6179525747111007803ull, 2213161865127226132ull},
    {13085575628799155685ull, 1383226165704516332ull}, {16356969535998944606ull, 1729032707130645415ull},
    {15834525901571292854ull, 2161290883913306769ull}, {2979049660840976177ull, 1350806802445816731ull},
    {17558870131333383934ull, 1688508503057270913ull}, {8113529608884566205ull, 2110635628821588642ull},
    {9682642023980241782ull, 1319147268013492901ull}, {16714988548402690132ull, 1648934085016866126ull},
    {11670363648648586857ull, 2061167606271082658ull}, {11905663298832754689ull, 1288229753919426661ull},
    {1047021068258779650ull, 1610287192399283327ull}, {15143834390605638274ull, 2012858990499104158ull},
    {4853210475701136017ull, 1258036869061940099ull}, {1454827076199032118ull, 1572546086327425124ull},
    {1818533845248790147ull, 1965682607909281405ull}, {3442426662494187794ull, 1228551629943300878ull},
    {13526405364972510550ull, 1535689537429126097ull}, {3072948650933474476ull, 1919611921786407622ull},
    {15755650962115585259ull, 1199757451116504763ull}, {15082877684217093670ull, 1499696813895630954ull},
    {9630225068416591280ull, 1874621017369538693ull}, {8324733676974063502ull, 1171638135855961683ull},
    {5794231077790191473ull, 1464547669819952104ull}, {7242788847237739342ull, 1830684587274940130ull},
    {18276858095901949986ull, 2288355734093675162ull}, {16034722328366106645ull, 1430222333808546976ull},
    {1596658836748081690ull, 1787777917260683721ull}, {6607509564362490017ull, 2234722396575854651ull},
    {1823850468512862308ull, 1396701497859909157ull}, {6891499104068465790ull, 1745876872324886446ull},
    {17837745916940358045ull, 2182346090406108057ull}, {4231062170446641922ull, 1363966306503817536ull},
    {5288827713058302403ull, 1704957883129771920ull}, {6611034641322878003ull, 2131197353912214900ull},
    {13355268687681574560ull, 1331998346195134312ull}, {16694085859601968200ull, 1664997932743917890ull},
    {11644235287647684442ull, 2081247415929897363ull}, {4971804045566108824ull, 1300779634956185852ull},
    {6214755056957636030ull, 1625974543695232315ull}, {3156757802769657134ull, 2032468179619040394ull},
    {6584659645158423613ull, 1270292612261900246ull}, {17454196593302805324ull, 1587865765327375307ull},
    {17206059723201118751ull, 1984832206659219134ull}, {6142101308573311315ull, 1240520129162011959ull},
    {3065940617289251240ull, 1550650161452514949ull}, {8444111790038951954ull, 1938312701815643686ull},
    {665883850346957067ull, 1211445438634777304ull}, {832354812933696334ull, 1514306798293471630ull},
    {10263815553021896226ull, 1892883497866839537ull}, {17944099766707154901ull, 1183052186166774710ull},
    {13206752671529167818ull, 1478815232708468388ull}, {16508440839411459773ull, 1848519040885585485ull},
    {12623618533845856310ull, 1155324400553490928ull}, {15779523167307320387ull, 1444155500691863660ull},
    {1277659885424598868ull, 1805194375864829576ull}, {1597074856780748586ull, 2256492969831036970ull},
    {5609857803915355770ull, 1410308106144398106ull}, {16235694291748970521ull, 1762885132680497632ull},
    {1847873790976661535ull, 2203606415850622041ull}, {12684136165428883219ull, 1377254009906638775ull},
    {11243484188358716120ull, 1721567512383298469ull}, {219297180166231438ull, 2151959390479123087ull},
    {7054589765244976505ull, 1344974619049451929ull}, {13429923224983608535ull, 1681218273811814911ull},
    {12175718012802122765ull, 2101522842264768639ull}, {14527352785642408584ull, 1313451776415480399ull},
    {13547504963625622826ull, 1641814720519350499ull}, {12322695186104640628ull, 2052268400649188124ull},
    {16925056528170176201ull, 1282667750405742577ull}, {7321262604930556539ull, 1603334688007178222ull},
    {18374950293017971482ull, 2004168360008972777ull}, {4566814905495150320ull, 1252605225005607986ull},
    {14931890668723713708ull, 1565756531257009982ull}, {9441491299049866327ull, 1957195664071262478ull},
    {1289246043478778550ull, 1223247290044539049ull}, {6223243572775861092ull, 1529059112555673811ull},
    {3167368447542438461ull, 1911323890694592264ull}, {1979605279714024038ull, 1194577431684120165ull},
    {7086192618069917952ull, 1493221789605150206ull}, {18081112809442173248ull, 1866527237006437757ull},
    {13606538515115052232ull, 1166579523129023598ull}, {7784801107039039482ull, 1458224403911279498ull},
    {507629346944023544ull, 1822780504889099373ull}, {5246222702107417334ull, 2278475631111374216ull},
    {3278889188817135834ull, 1424047269444608885ull}, {8710297504448807696ull, 1780059086805761106ull},
};


static int lust_ryu_pow5bits(int e) { return (int)(((uint32_t)e * 1217359u) >> 19) + 1; }
static uint32_t lust_ryu_log10_pow2(int e) { return ((uint32_t)e * 78913u) >> 18; }
static uint32_t lust_ryu_log10_pow5(int e) { return ((uint32_t)e * 732923u) >> 20; }

/* High 64 bits of a*b; *lo_out gets the low 64 bits. */
static uint64_t lust_mul64_hi(uint64_t a, uint64_t b, uint64_t *lo_out) {
    uint64_t a0 = a & 0xFFFFFFFFu, a1 = a >> 32, b0 = b & 0xFFFFFFFFu, b1 = b >> 32;
    uint64_t p0 = a0 * b0, p1 = a0 * b1, p2 = a1 * b0, p3 = a1 * b1;
    uint64_t t = (p0 >> 32) + (p1 & 0xFFFFFFFFu) + (p2 & 0xFFFFFFFFu);
    *lo_out = (t << 32) | (p0 & 0xFFFFFFFFu);
    return p3 + (p1 >> 32) + (p2 >> 32) + (t >> 32);
}

/* ((m * mul) >> j) with mul a 128-bit table entry, as in Ryu: only the
   top 64 bits of the 192-bit product pair are formed. */
static uint64_t lust_ryu_mul_shift_64(uint64_t m, const uint64_t mul[2], uint32_t j) {
    uint64_t b2lo;
    uint64_t b0hi = lust_mul64_hi(m, mul[0], &b2lo);
    uint64_t b2hi = lust_mul64_hi(m, mul[1], &b2lo);
    uint64_t lo = b2lo + b0hi;
    uint64_t hi = b2hi + (lo < b2lo ? 1 : 0);
    int s = (int)j - 64;
    if (s <= 0) return lo << (0 - s);
    if (s >= 64) return s >= 128 ? 0 : hi >> (s - 64);
    return (lo >> s) | (hi << (64 - s));
}

static uint64_t lust_ryu_mul_shift_all_64(uint64_t m, const uint64_t mul[2], uint32_t j, uint64_t *vp, uint64_t *vm, uint32_t mm_shift) {
    *vp = lust_ryu_mul_shift_64(4 * m + 2, mul, j);
    *vm = lust_ryu_mul_shift_64(4 * m - 1 - mm_shift, mul, j);
    return lust_ryu_mul_shift_64(4 * m, mul, j);
}

static uint32_t lust_ryu_pow5_factor(uint64_t value) {
    const uint64_t m_inv_5 = 14757395258967641293ull;
    const uint64_t n_div_5 = 3689348814741910323ull;
    uint32_t count = 0;
    for (;;) {
        value *= m_inv_5;
        if (value > n_div_5) break;
        count++;
    }
    return count;
}
static int lust_ryu_multiple_of_pow5(uint64_t v, uint32_t p) { return lust_ryu_pow5_factor(v) >= p; }
static int lust_ryu_multiple_of_pow2(uint64_t v, uint32_t p) { return (v & (((uint64_t)1 << p) - 1)) == 0; }

typedef struct {
    uint64_t mant;
    int exp; /* value = mant * 10^exp */
} lust_ryu64;

static lust_ryu64 lust_ryu_d2d(uint64_t ieee_mant, uint32_t ieee_exp, int tie_up) {
    int e2;
    uint64_t m2;
    if (ieee_exp == 0) {
        e2 = 1 - 1023 - 52 - 2;
        m2 = ieee_mant;
    } else {
        e2 = (int)ieee_exp - 1023 - 52 - 2;
        m2 = ((uint64_t)1 << 52) | ieee_mant;
    }
    {
        int accept_bounds = (m2 & 1) == 0;
        uint64_t mv = 4 * m2;
        uint32_t mm_shift = (ieee_mant != 0 || ieee_exp <= 1) ? 1 : 0;
        uint64_t vr, vp, vm;
        int e10, vm_tz = 0, vr_tz = 0;
        if (e2 >= 0) {
            uint32_t q = lust_ryu_log10_pow2(e2) - (e2 > 3 ? 1 : 0);
            int k = 125 + lust_ryu_pow5bits((int)q) - 1;
            int i = -e2 + (int)q + k;
            e10 = (int)q;
            vr = lust_ryu_mul_shift_all_64(m2, lust_ryu_pow5_inv[q], (uint32_t)i, &vp, &vm, mm_shift);
            if (q <= 21) {
                uint64_t mv_mod5 = mv - (mv / 5) * 5;
                if (mv_mod5 == 0) {
                    vr_tz = lust_ryu_multiple_of_pow5(mv, q);
                } else if (accept_bounds) {
                    vm_tz = lust_ryu_multiple_of_pow5(mv - 1 - mm_shift, q);
                } else {
                    vp -= lust_ryu_multiple_of_pow5(mv + 2, q) ? 1 : 0;
                }
            }
        } else {
            uint32_t q = lust_ryu_log10_pow5(-e2) - (-e2 > 1 ? 1 : 0);
            int i = -e2 - (int)q;
            int k = lust_ryu_pow5bits(i) - 125;
            int j = (int)q - k;
            e10 = (int)q + e2;
            vr = lust_ryu_mul_shift_all_64(m2, lust_ryu_pow5[i], (uint32_t)j, &vp, &vm, mm_shift);
            if (q <= 1) {
                vr_tz = 1;
                if (accept_bounds)
                    vm_tz = mm_shift == 1;
                else
                    vp -= 1;
            } else if (q < 63) {
                vr_tz = lust_ryu_multiple_of_pow2(mv, q);
            }
        }
        {
            int removed = 0;
            uint8_t last_digit = 0;
            uint64_t output;
            if (vm_tz || vr_tz) {
                for (;;) {
                    uint64_t vp_d = vp / 10, vm_d = vm / 10;
                    uint64_t vr_d, vr_m;
                    if (vp_d <= vm_d) break;
                    vm_tz &= (vm - vm_d * 10) == 0;
                    vr_d = vr / 10;
                    vr_m = vr - vr_d * 10;
                    vr_tz &= last_digit == 0;
                    last_digit = (uint8_t)vr_m;
                    vr = vr_d;
                    vp = vp_d;
                    vm = vm_d;
                    removed++;
                }
                if (vm_tz) {
                    for (;;) {
                        uint64_t vm_d = vm / 10, vr_d, vr_m;
                        if ((vm - vm_d * 10) != 0) break;
                        vr_d = vr / 10;
                        vr_m = vr - vr_d * 10;
                        vr_tz &= last_digit == 0;
                        last_digit = (uint8_t)vr_m;
                        vr = vr_d;
                        vp /= 10;
                        vm = vm_d;
                        removed++;
                    }
                }
                /* The one tie rule: the exact value ends .....50..0.
                   ECMAScript keeps the even candidate; Rust rounds up. */
                if (!tie_up && vr_tz && last_digit == 5 && (vr & 1) == 0) last_digit = 4;
                output = vr + (((vr == vm && (!accept_bounds || !vm_tz)) || last_digit >= 5) ? 1 : 0);
            } else {
                int round_up = 0;
                uint64_t vp_d = vp / 100, vm_d = vm / 100;
                if (vp_d > vm_d) {
                    uint64_t vr_d = vr / 100;
                    round_up = (vr - vr_d * 100) >= 50;
                    vr = vr_d;
                    vp = vp_d;
                    vm = vm_d;
                    removed += 2;
                }
                for (;;) {
                    uint64_t vp10 = vp / 10, vm10 = vm / 10, vr_d;
                    if (vp10 <= vm10) break;
                    vr_d = vr / 10;
                    round_up = (vr - vr_d * 10) >= 5;
                    vr = vr_d;
                    vp = vp10;
                    vm = vm10;
                    removed++;
                }
                output = vr + ((vr == vm || round_up) ? 1 : 0);
            }
            {
                lust_ryu64 r;
                r.mant = output;
                r.exp = e10 + removed;
                return r;
            }
        }
    }
}

static uint32_t lust_ryu_mul_shift_32(uint32_t m, uint64_t factor, int shift) {
    uint64_t bits0 = (uint64_t)m * (uint32_t)factor;
    uint64_t bits1 = (uint64_t)m * (uint32_t)(factor >> 32);
    uint64_t sum = (bits0 >> 32) + bits1;
    return (uint32_t)(sum >> (shift - 32));
}
static uint32_t lust_ryu_mul_pow5_inv(uint32_t m, uint32_t q, int j) { return lust_ryu_mul_shift_32(m, lust_ryu_pow5_inv[q][1] + 1, j); }
static uint32_t lust_ryu_mul_pow5(uint32_t m, uint32_t i, int j) { return lust_ryu_mul_shift_32(m, lust_ryu_pow5[i][1], j); }
static int lust_ryu_multiple_of_pow5_32(uint32_t v, uint32_t p) {
    uint32_t count = 0;
    for (;;) {
        uint32_t q = v / 5;
        if (v - q * 5 != 0) break;
        v = q;
        count++;
    }
    return count >= p;
}
static int lust_ryu_multiple_of_pow2_32(uint32_t v, uint32_t p) { return (v & (((uint32_t)1 << p) - 1)) == 0; }

static lust_ryu64 lust_ryu_f2d(uint32_t ieee_mant, uint32_t ieee_exp, int tie_up) {
    int e2;
    uint32_t m2;
    if (ieee_exp == 0) {
        e2 = 1 - 127 - 23 - 2;
        m2 = ieee_mant;
    } else {
        e2 = (int)ieee_exp - 127 - 23 - 2;
        m2 = (1u << 23) | ieee_mant;
    }
    {
        int accept_bounds = (m2 & 1) == 0;
        uint32_t mv = 4 * m2, mp = 4 * m2 + 2;
        uint32_t mm_shift = (ieee_mant != 0 || ieee_exp <= 1) ? 1 : 0;
        uint32_t mm = 4 * m2 - 1 - mm_shift;
        uint32_t vr, vp, vm;
        int e10, vm_tz = 0, vr_tz = 0;
        uint8_t last_digit = 0;
        if (e2 >= 0) {
            uint32_t q = lust_ryu_log10_pow2(e2);
            int k = (125 - 64) + lust_ryu_pow5bits((int)q) - 1;
            int i = -e2 + (int)q + k;
            e10 = (int)q;
            vr = lust_ryu_mul_pow5_inv(mv, q, i);
            vp = lust_ryu_mul_pow5_inv(mp, q, i);
            vm = lust_ryu_mul_pow5_inv(mm, q, i);
            if (q != 0 && (vp - 1) / 10 <= vm / 10) {
                int l = (125 - 64) + lust_ryu_pow5bits((int)q - 1) - 1;
                last_digit = (uint8_t)(lust_ryu_mul_pow5_inv(mv, q - 1, -e2 + (int)q - 1 + l) % 10);
            }
            if (q <= 9) {
                if (mv % 5 == 0)
                    vr_tz = lust_ryu_multiple_of_pow5_32(mv, q);
                else if (accept_bounds)
                    vm_tz = lust_ryu_multiple_of_pow5_32(mm, q);
                else
                    vp -= lust_ryu_multiple_of_pow5_32(mp, q) ? 1 : 0;
            }
        } else {
            uint32_t q = lust_ryu_log10_pow5(-e2);
            int i = -e2 - (int)q;
            int k = lust_ryu_pow5bits(i) - (125 - 64);
            int j = (int)q - k;
            e10 = (int)q + e2;
            vr = lust_ryu_mul_pow5(mv, (uint32_t)i, j);
            vp = lust_ryu_mul_pow5(mp, (uint32_t)i, j);
            vm = lust_ryu_mul_pow5(mm, (uint32_t)i, j);
            if (q != 0 && (vp - 1) / 10 <= vm / 10) {
                j = (int)q - 1 - (lust_ryu_pow5bits(i + 1) - (125 - 64));
                last_digit = (uint8_t)(lust_ryu_mul_pow5(mv, (uint32_t)(i + 1), j) % 10);
            }
            if (q <= 1) {
                vr_tz = 1;
                if (accept_bounds)
                    vm_tz = mm_shift == 1;
                else
                    vp -= 1;
            } else if (q < 31) {
                vr_tz = lust_ryu_multiple_of_pow2_32(mv, q - 1);
            }
        }
        {
            int removed = 0;
            uint32_t output;
            if (vm_tz || vr_tz) {
                while (vp / 10 > vm / 10) {
                    vm_tz &= (vm - (vm / 10) * 10) == 0;
                    vr_tz &= last_digit == 0;
                    last_digit = (uint8_t)(vr % 10);
                    vr /= 10;
                    vp /= 10;
                    vm /= 10;
                    removed++;
                }
                if (vm_tz) {
                    while (vm % 10 == 0) {
                        vr_tz &= last_digit == 0;
                        last_digit = (uint8_t)(vr % 10);
                        vr /= 10;
                        vp /= 10;
                        vm /= 10;
                        removed++;
                    }
                }
                if (!tie_up && vr_tz && last_digit == 5 && (vr & 1) == 0) last_digit = 4;
                output = vr + (((vr == vm && (!accept_bounds || !vm_tz)) || last_digit >= 5) ? 1 : 0);
            } else {
                while (vp / 10 > vm / 10) {
                    last_digit = (uint8_t)(vr % 10);
                    vr /= 10;
                    vp /= 10;
                    vm /= 10;
                    removed++;
                }
                output = vr + ((vr == vm || last_digit >= 5) ? 1 : 0);
            }
            {
                lust_ryu64 r;
                r.mant = output;
                r.exp = e10 + removed;
                return r;
            }
        }
    }
}

/* Shortest digits that parse back to the float the parts describe.
   tie_up != 0 for Rust's rule, 0 for ECMAScript. */
static void lust_dec_shortest(lust_dec *out, const lust_fparts *p, int tie_up) {
    lust_ryu64 r = p->mant_bits == 53 ? lust_ryu_d2d(p->ieee_mant, p->ieee_exp, tie_up)
                                      : lust_ryu_f2d((uint32_t)p->ieee_mant, p->ieee_exp, tie_up);
    char rev[20];
    int n = 0, i;
    uint64_t mant = r.mant;
    do {
        rev[n++] = (char)('0' + mant % 10);
        mant /= 10;
    } while (mant);
    out->len = n;
    out->e10 = n + r.exp;
    for (i = 0; i < n; i++) out->d[i] = rev[n - 1 - i];
    while (out->len > 1 && out->d[out->len - 1] == '0') out->len--;
}

/* Digit at significant position i (0-based); '0' outside the stored digits.
   The exact and shortest forms drop trailing zeros, so this is how fixed
   renders reach positions past the last stored digit. */
static char lust_dec_digit(const lust_dec *v, int i) { return (i >= 0 && i < v->len) ? v->d[i] : '0'; }

/* Rounds the exact digits to `keep` significant digits (keep >= 1),
   round-half-to-even, exactly like Rust's fixed-precision path. */
static void lust_dec_round(lust_dec *v, int keep) {
    int i, up;
    if (v->len <= keep) return;
    up = 0;
    if (v->d[keep] > '5') {
        up = 1;
    } else if (v->d[keep] == '5') {
        int rest = 0;
        for (i = keep + 1; i < v->len; i++)
            if (v->d[i] != '0') rest = 1;
        up = rest || ((v->d[keep - 1] - '0') & 1);
    }
    v->len = keep;
    if (!up) return;
    i = keep - 1;
    while (i >= 0 && v->d[i] == '9') v->d[i--] = '0';
    if (i < 0) {
        v->d[0] = '1';
        v->len = 1;
        v->e10++;
    } else {
        v->d[i]++;
    }
}

/* ---------- magnitude renders (no sign; core is a scratch String) ---------- */

static void lust_push_zeros(lust_String *out, uint64_t n) {
    static const char zeros[] = "00000000000000000000000000000000";
    while (n >= 32) {
        lust_string_push_bytes(out, zeros, 32);
        n -= 32;
    }
    if (n) lust_string_push_bytes(out, zeros, n);
}

static void lust_push_int(lust_String *out, int v) {
    char b[16];
    int i = 16;
    unsigned mag = v < 0 ? 0u - (unsigned)v : (unsigned)v;
    if (v < 0) lust_string_push_bytes(out, "-", 1);
    do {
        b[--i] = (char)('0' + mag % 10);
        mag /= 10;
    } while (mag);
    lust_string_push_bytes(out, b + i, 16 - i);
}

/* Fixed layout from significant digits, fraction zeros trimmed.
   `debug` adds ".0" when the value has no fraction part. */
static void lust_render_fixed_shortest(lust_String *core, const lust_dec *v, int debug) {
    if (v->e10 <= 0) {
        lust_string_push_bytes(core, "0.", 2);
        lust_push_zeros(core, (uint64_t)(-v->e10));
        lust_string_push_bytes(core, v->d, v->len);
    } else if (v->e10 >= v->len) {
        lust_string_push_bytes(core, v->d, v->len);
        lust_push_zeros(core, (uint64_t)(v->e10 - v->len));
        if (debug) lust_string_push_bytes(core, ".0", 2);
    } else {
        lust_string_push_bytes(core, v->d, v->e10);
        lust_string_push_bytes(core, ".", 1);
        lust_string_push_bytes(core, v->d + v->e10, v->len - v->e10);
    }
}

/* Fixed layout with exactly `prec` fraction digits. The digits in *v must
   already be rounded so nothing past the kept positions is nonzero. */
static void lust_render_fixed_prec(lust_String *core, const lust_dec *v, uint32_t prec) {
    int i;
    uint32_t j;
    if (v->e10 > 0) {
        for (i = 0; i < v->e10; i++) {
            char c = lust_dec_digit(v, i);
            lust_string_push_bytes(core, &c, 1);
        }
    } else {
        lust_string_push_bytes(core, "0", 1);
    }
    if (prec == 0) return;
    lust_string_push_bytes(core, ".", 1);
    for (j = 1; j <= prec; j++) {
        char c = lust_dec_digit(v, v->e10 - 1 + (int)j);
        lust_string_push_bytes(core, &c, 1);
    }
}

/* Scientific layout. With precision, count = fraction digits wanted and
   the digits are pre-rounded; without, all shortest digits print. */
static void lust_render_exp(lust_String *core, const lust_dec *v, int upper, int precision, uint32_t prec) {
    char c = lust_dec_digit(v, 0);
    int i;
    lust_string_push_bytes(core, &c, 1);
    if (precision) {
        if (prec > 0) {
            uint32_t j;
            lust_string_push_bytes(core, ".", 1);
            for (j = 1; j <= prec; j++) {
                c = lust_dec_digit(v, (int)j);
                lust_string_push_bytes(core, &c, 1);
            }
        }
    } else if (v->len > 1) {
        lust_string_push_bytes(core, ".", 1);
        for (i = 1; i < v->len; i++) lust_string_push_bytes(core, v->d + i, 1);
    }
    c = upper ? 'E' : 'e';
    lust_string_push_bytes(core, &c, 1);
    lust_push_int(core, v->e10 - 1);
}

/* Builds the magnitude text (no sign, no padding) into core. */
static void lust_float_core(lust_String *core, const lust_fparts *p, lust_float_spec spec) {
    lust_dec v;
    int precision = spec.precision != LUST_FLOAT_NO_PRECISION;
    if (p->special == 2) {
        lust_string_push_cstr(core, "NaN");
        return;
    }
    if (p->special == 1) {
        lust_string_push_cstr(core, "inf");
        return;
    }
    if (p->m == 0) {
        v.d[0] = '0';
        v.len = 1;
        v.e10 = 1;
        if (spec.mode == LUST_FLOAT_LOWER_EXP || spec.mode == LUST_FLOAT_UPPER_EXP)
            lust_render_exp(core, &v, spec.mode == LUST_FLOAT_UPPER_EXP, precision, spec.precision);
        else if (precision)
            lust_render_fixed_prec(core, &v, spec.precision);
        else
            lust_string_push_cstr(core, spec.mode == LUST_FLOAT_DEBUG ? "0.0" : "0");
        return;
    }
    if (!precision) {
        lust_dec_shortest(&v, p, 1);
        if (spec.mode == LUST_FLOAT_LOWER_EXP || spec.mode == LUST_FLOAT_UPPER_EXP) {
            lust_render_exp(core, &v, spec.mode == LUST_FLOAT_UPPER_EXP, 0, 0);
        } else if (spec.mode == LUST_FLOAT_DEBUG && (v.e10 <= -4 || v.e10 >= 17)) {
            lust_render_exp(core, &v, 0, 0, 0);
        } else {
            lust_render_fixed_shortest(core, &v, spec.mode == LUST_FLOAT_DEBUG);
        }
        return;
    }
    lust_dec_exact(&v, p->m, p->e);
    if (spec.mode == LUST_FLOAT_LOWER_EXP || spec.mode == LUST_FLOAT_UPPER_EXP) {
        lust_dec_round(&v, (int)spec.precision + 1);
        lust_render_exp(core, &v, spec.mode == LUST_FLOAT_UPPER_EXP, 1, spec.precision);
        return;
    }
    {
        int keep = v.e10 + (int)spec.precision;
        if (keep < 0) {
            v.d[0] = '0';
            v.len = 1;
            v.e10 = 1;
        } else if (keep == 0) {
            /* Rounding to a whole unit in the last fraction place:
               the value sits below, at, or above half that unit. */
            int cmp = lust_dec_cmp(v.d, v.len, v.e10, "5", 1, v.e10);
            if (cmp <= 0) {
                v.d[0] = '0';
                v.len = 1;
                v.e10 = 1;
            } else {
                v.d[0] = '1';
                v.len = 1;
                v.e10 = v.e10 + 1;
            }
        } else {
            lust_dec_round(&v, keep);
        }
        lust_render_fixed_prec(core, &v, spec.precision);
    }
}

/* One float rendering with sign and padding, per Rust's Formatter rules. */
static void lust_float_format(lust_String *out, const lust_fparts *p, lust_float_spec spec) {
    lust_String core = lust_string_new();
    const char *sign = "";
    uint64_t sign_len, total, padn, i;
    uint32_t fill = spec.fill ? spec.fill : ' ';
    lust_float_core(&core, p, spec);
    if (p->special != 2) sign = p->sign ? "-" : (spec.plus ? "+" : "");
    sign_len = sign[0] ? 1 : 0;
    total = sign_len + core.len;
    if (spec.width <= total) {
        if (sign_len) lust_string_push_bytes(out, sign, 1);
        lust_string_push_str(out, lust_string_as_str(&core));
        free(core.ptr);
        return;
    }
    padn = spec.width - total;
    if (spec.zero_pad) {
        if (sign_len) lust_string_push_bytes(out, sign, 1);
        lust_push_zeros(out, padn);
        lust_string_push_str(out, lust_string_as_str(&core));
    } else if (spec.align == '<') {
        if (sign_len) lust_string_push_bytes(out, sign, 1);
        lust_string_push_str(out, lust_string_as_str(&core));
        for (i = 0; i < padn; i++) lust_string_push_char(out, fill);
    } else if (spec.align == '^') {
        uint64_t left = padn / 2;
        for (i = 0; i < left; i++) lust_string_push_char(out, fill);
        if (sign_len) lust_string_push_bytes(out, sign, 1);
        lust_string_push_str(out, lust_string_as_str(&core));
        for (i = left; i < padn; i++) lust_string_push_char(out, fill);
    } else {
        for (i = 0; i < padn; i++) lust_string_push_char(out, fill);
        if (sign_len) lust_string_push_bytes(out, sign, 1);
        lust_string_push_str(out, lust_string_as_str(&core));
    }
    free(core.ptr);
}

void lust_fmt_f64(lust_String *out, double v, lust_float_spec spec) {
    lust_fparts p = lust_f64_parts(v);
    lust_float_format(out, &p, spec);
}
void lust_fmt_f32(lust_String *out, float v, lust_float_spec spec) {
    lust_fparts p = lust_f32_parts(v);
    lust_float_format(out, &p, spec);
}

static lust_float_spec lust_spec_plain(uint8_t mode) {
    lust_float_spec s;
    memset(&s, 0, sizeof s);
    s.precision = LUST_FLOAT_NO_PRECISION;
    s.mode = mode;
    return s;
}
void lust_fmt_f64_display(lust_String *out, double v) { lust_fmt_f64(out, v, lust_spec_plain(LUST_FLOAT_DISPLAY)); }
void lust_fmt_f64_debug(lust_String *out, double v) { lust_fmt_f64(out, v, lust_spec_plain(LUST_FLOAT_DEBUG)); }
void lust_fmt_f32_display(lust_String *out, float v) { lust_fmt_f32(out, v, lust_spec_plain(LUST_FLOAT_DISPLAY)); }
void lust_fmt_f32_debug(lust_String *out, float v) { lust_fmt_f32(out, v, lust_spec_plain(LUST_FLOAT_DEBUG)); }

/* ---------- ECMAScript Number::toString (ryu-js Buffer::format) ---------- */

/* Writes the JS form into buf (at least 32 bytes), returns its length.
   Branch structure follows ryu-js 1.0.2 pretty/mod.rs: kk is the decimal
   point position (digits * 10^(kk-len)), fixed forms up to 21 digits,
   small fixed forms down to 1e-6, scientific otherwise with a signed
   exponent. */
static uint64_t lust_js_render(char *buf, const lust_fparts *p) {
    lust_dec v;
    int n = 0, i, kk, k, len;
    if (p->special == 2) {
        memcpy(buf, "NaN", 3);
        return 3;
    }
    if (p->special == 1) {
        if (p->sign) buf[n++] = '-';
        memcpy(buf + n, "Infinity", 8);
        return n + 8;
    }
    if (p->m == 0) {
        buf[0] = '0';
        return 1;
    }
    if (p->sign) buf[n++] = '-';
    lust_dec_shortest(&v, p, 0);
    kk = v.e10;
    len = v.len;
    k = kk - len;
    if (k >= 0 && kk <= 21) {
        memcpy(buf + n, v.d, len);
        n += len;
        for (i = 0; i < k; i++) buf[n++] = '0';
    } else if (kk > 0 && kk <= 21) {
        memcpy(buf + n, v.d, kk);
        n += kk;
        buf[n++] = '.';
        memcpy(buf + n, v.d + kk, len - kk);
        n += len - kk;
    } else if (kk > -6 && kk <= 0) {
        buf[n++] = '0';
        buf[n++] = '.';
        for (i = 0; i < -kk; i++) buf[n++] = '0';
        memcpy(buf + n, v.d, len);
        n += len;
    } else {
        int exp = kk - 1;
        buf[n++] = v.d[0];
        if (len > 1) {
            buf[n++] = '.';
            memcpy(buf + n, v.d + 1, len - 1);
            n += len - 1;
        }
        buf[n++] = 'e';
        buf[n++] = exp < 0 ? '-' : '+';
        if (exp < 0) exp = -exp;
        if (exp >= 100) buf[n++] = (char)('0' + exp / 100);
        if (exp >= 10) buf[n++] = (char)('0' + (exp / 10) % 10);
        buf[n++] = (char)('0' + exp % 10);
    }
    return (uint64_t)n;
}

uint64_t lust_fmt_js_f64_buf(char *buf, double v) {
    lust_fparts p = lust_f64_parts(v);
    return lust_js_render(buf, &p);
}
uint64_t lust_fmt_js_f32_buf(char *buf, float v) {
    lust_fparts p = lust_f32_parts(v);
    return lust_js_render(buf, &p);
}
void lust_fmt_js_f64(lust_String *out, double v) {
    char buf[40];
    lust_string_push_bytes(out, buf, lust_fmt_js_f64_buf(buf, v));
}
void lust_fmt_js_f32(lust_String *out, float v) {
    char buf[40];
    lust_string_push_bytes(out, buf, lust_fmt_js_f32_buf(buf, v));
}

/* ---------- parsing ---------- */

static int lust_lower_eq(const uint8_t *s, uint64_t n, const char *word) {
    uint64_t i;
    for (i = 0; word[i]; i++) {
        uint8_t c;
        if (i >= n) return 0;
        c = s[i];
        if (c >= 'A' && c <= 'Z') c = (uint8_t)(c + 32);
        if (c != (uint8_t)word[i]) return 0;
    }
    return i == n;
}

/* Exact powers of ten for the parser fast path. 10^k is exactly
   representable in f64 for k <= 22 and in f32 for k <= 10. */
static const double lust_pow10_d[23] = {1e0,  1e1,  1e2,  1e3,  1e4,  1e5,  1e6,  1e7,  1e8,  1e9,  1e10, 1e11,
                                        1e12, 1e13, 1e14, 1e15, 1e16, 1e17, 1e18, 1e19, 1e20, 1e21, 1e22};
static const float lust_pow10_f[11] = {1e0f, 1e1f, 1e2f, 1e3f, 1e4f, 1e5f, 1e6f, 1e7f, 1e8f, 1e9f, 1e10f};

/* Rounds the exact ratio (num / den) * 2^binexp to a float with `p`
   mantissa bits (hidden bit counted), exponent range [emin, emax] for
   normals, ties to even. `sticky` marks dropped nonzero input digits:
   the true value is a hair above the ratio, which can only matter at
   an exact tie (1024 kept digits is far past the 768 a tie can span).
   Returns the magnitude bit pattern (sign bit clear); inf on overflow. */
static uint64_t lust_ratio_to_float(const lust_big *num, const lust_big *den, int binexp, int sticky, int p, int emin, int emax) {
    lust_big a, b, rem, probe;
    int s, be, scale, shift;
    uint64_t q, mant;
    int up;
    /* be = floor(log2(value)): the bit-length difference brackets it
       to two choices; one comparison decides. */
    s = lust_big_bitlen(num) - lust_big_bitlen(den);
    if (s >= 0)
        lust_big_shl_to(&probe, den, s);
    else
        lust_big_shl_to(&probe, num, -s);
    /* ratio >= 2^s  <=>  (s>=0 ? num >= den<<s : num<<-s >= den) */
    be = s + binexp;
    if (s >= 0 ? lust_big_cmp(num, &probe) < 0 : lust_big_cmp(&probe, den) < 0) be--;
    /* Divide once at p+1 bits of output, then round the last bit. Below
       the normal range the output scale is fixed at the subnormal step. */
    scale = (be >= emin ? be : emin) - p;
    shift = binexp - scale;
    if (shift >= 0) {
        lust_big_shl_to(&a, num, shift);
        b = *den;
    } else {
        a = *num;
        lust_big_shl_to(&b, den, -shift);
    }
    q = lust_big_div_q64(&a, &b, &rem);
    mant = q >> 1;
    up = (q & 1) && (rem.n > 0 || sticky || (mant & 1));
    mant += up ? 1 : 0;
    if (be < emin) {
        /* Subnormal or zero; mant == 2^(p-1) is the smallest normal. */
        if (mant >= (uint64_t)1 << (p - 1)) return (uint64_t)1 << (p - 1);
        return mant;
    }
    if (mant >= (uint64_t)1 << p) {
        mant >>= 1;
        be++;
    }
    if (be > emax) return ((uint64_t)((1 << (p == 53 ? 11 : 8)) - 1)) << (p - 1);
    return ((uint64_t)(be - emin + 1) << (p - 1)) | (mant & (((uint64_t)1 << (p - 1)) - 1));
}

/* The grammar is Rust's: an optional sign, then inf / infinity / NaN
   (any case) or a decimal number, and nothing else. No whitespace, no
   underscores, no hex. On success returns the full bit pattern. */
#define LUST_PARSE_KEEP 1024

static int lust_parse_bits(lust_str s, int p, uint64_t *bits_out) {
    const uint8_t *b = s.ptr;
    uint64_t n = s.len, i = 0;
    int neg = 0, emin = p == 53 ? -1022 : -126, emax = p == 53 ? 1023 : 127;
    uint64_t sign_bit = p == 53 ? (uint64_t)1 << 63 : (uint64_t)1 << 31;
    uint64_t inf_bits = p == 53 ? (uint64_t)0x7FF << 52 : (uint64_t)0xFF << 23;
    uint64_t nan_bits = p == 53 ? ((uint64_t)0x7FF << 52) | ((uint64_t)1 << 51) : ((uint64_t)0xFF << 23) | ((uint64_t)1 << 22);
    uint64_t int_lo, int_hi, frac_lo, frac_hi, total, first_sig, kept, dropped, pos;
    int64_t exp_in = 0, dec_exp, e10;
    int sticky = 0;
    if (n == 0) return 1;
    if (b[i] == '+' || b[i] == '-') {
        neg = b[i] == '-';
        i++;
        if (i == n) return 2;
    }
    if (lust_lower_eq(b + i, n - i, "inf") || lust_lower_eq(b + i, n - i, "infinity")) {
        *bits_out = inf_bits | (neg ? sign_bit : 0);
        return 0;
    }
    if (lust_lower_eq(b + i, n - i, "nan")) {
        *bits_out = nan_bits | (neg ? sign_bit : 0);
        return 0;
    }
    int_lo = i;
    while (i < n && b[i] >= '0' && b[i] <= '9') i++;
    int_hi = i;
    frac_lo = frac_hi = i;
    if (i < n && b[i] == '.') {
        i++;
        frac_lo = i;
        while (i < n && b[i] >= '0' && b[i] <= '9') i++;
        frac_hi = i;
    }
    if (int_hi - int_lo + (frac_hi - frac_lo) == 0) return 2;
    if (i < n && (b[i] == 'e' || b[i] == 'E')) {
        int eneg = 0, any = 0;
        i++;
        if (i < n && (b[i] == '+' || b[i] == '-')) {
            eneg = b[i] == '-';
            i++;
        }
        while (i < n && b[i] >= '0' && b[i] <= '9') {
            any = 1;
            if (exp_in < (int64_t)1 << 40) exp_in = exp_in * 10 + (b[i] - '0');
            i++;
        }
        if (!any) return 2;
        if (eneg) exp_in = -exp_in;
    }
    if (i != n) return 2;
    /* Digit at concatenated position: int part then frac part. */
    total = int_hi - int_lo + (frac_hi - frac_lo);
    first_sig = 0;
    while (first_sig < total) {
        uint64_t q = first_sig < int_hi - int_lo ? int_lo + first_sig : frac_lo + (first_sig - (int_hi - int_lo));
        if (b[q] != '0') break;
        first_sig++;
    }
    if (first_sig == total) {
        *bits_out = neg ? sign_bit : 0;
        return 0;
    }
    kept = total - first_sig;
    if (kept > LUST_PARSE_KEEP) {
        dropped = kept - LUST_PARSE_KEEP;
        kept = LUST_PARSE_KEEP;
    } else {
        dropped = 0;
    }
    for (pos = first_sig + kept; pos < total; pos++) {
        uint64_t q = pos < int_hi - int_lo ? int_lo + pos : frac_lo + (pos - (int_hi - int_lo));
        if (b[q] != '0') sticky = 1;
    }
    e10 = exp_in - (int64_t)(frac_hi - frac_lo) + (int64_t)dropped;
    dec_exp = e10 + (int64_t)kept;
    {
        int64_t dec_hi = p == 53 ? 310 : 40;  /* value >= 10^(dec_hi-1) overflows */
        int64_t dec_lo = p == 53 ? -324 : -46; /* value < 10^dec_lo rounds to zero */
        if (dec_exp >= dec_hi) {
            *bits_out = inf_bits | (neg ? sign_bit : 0);
            return 0;
        }
        if (dec_exp <= dec_lo) {
            *bits_out = neg ? sign_bit : 0;
            return 0;
        }
    }
    /* Fast path: one exact operation decides the result. The bignum path
       below gives the same answer; this only saves time. */
    if (!dropped && kept <= 19) {
        uint64_t m = 0;
        for (pos = first_sig; pos < first_sig + kept; pos++) {
            uint64_t q = pos < int_hi - int_lo ? int_lo + pos : frac_lo + (pos - (int_hi - int_lo));
            m = m * 10 + (uint64_t)(b[q] - '0');
        }
        if (p == 53 && m <= (uint64_t)1 << 53 && e10 >= -22 && e10 <= 22) {
            double r = e10 >= 0 ? (double)m * lust_pow10_d[e10] : (double)m / lust_pow10_d[-e10];
            if (neg) r = -r;
            *bits_out = lust_f64_bits(r);
            return 0;
        }
        if (p == 24 && m <= (uint64_t)1 << 24 && e10 >= -10 && e10 <= 10) {
            float r = e10 >= 0 ? (float)m * lust_pow10_f[e10] : (float)m / lust_pow10_f[-e10];
            if (neg) r = -r;
            *bits_out = lust_f32_bits(r);
            return 0;
        }
    }
    {
        lust_big num, den;
        uint64_t mag;
        int e = (int)e10;
        lust_big_zero(&num);
        for (pos = first_sig; pos < first_sig + kept;) {
            uint32_t chunk = 0;
            int cnt = 0;
            while (pos < first_sig + kept && cnt < 9) {
                uint64_t q = pos < int_hi - int_lo ? int_lo + pos : frac_lo + (pos - (int_hi - int_lo));
                chunk = chunk * 10 + (uint32_t)(b[q] - '0');
                pos++;
                cnt++;
            }
            lust_big_mul_pow10(&num, cnt);
            lust_big_add_small(&num, chunk);
        }
        lust_big_set_u64(&den, 1);
        if (e >= 0) {
            lust_big_mul_pow5(&num, e);
        } else {
            lust_big_mul_pow5(&den, -e);
        }
        mag = lust_ratio_to_float(&num, &den, e, sticky, p, emin, emax);
        *bits_out = mag | (neg ? sign_bit : 0);
        return 0;
    }
}

int lust_parse_f64(lust_str s, double *out) {
    uint64_t bits;
    int rc = lust_parse_bits(s, 53, &bits);
    if (rc == 0) *out = lust_f64_from_bits(bits);
    return rc;
}
int lust_parse_f32(lust_str s, float *out) {
    uint64_t bits;
    int rc = lust_parse_bits(s, 24, &bits);
    if (rc == 0) *out = lust_f32_from_bits((uint32_t)bits);
    return rc;
}

/* ---------- casts ----------
   All done on the (m, e) integer form, so no host floating cast (with
   its undefined out-of-range behavior) is involved anywhere. */

typedef struct {
    uint64_t lo, hi;
} lust_u128w;

/* Truncated magnitude of the value as a 128-bit integer.
   Sets *overflow when it does not fit. */
static void lust_mag128(const lust_fparts *p, lust_u128w *out, int *overflow) {
    uint64_t m = p->m;
    int bl = 0;
    uint64_t t = m;
    out->lo = 0;
    out->hi = 0;
    *overflow = 0;
    if (m == 0) return;
    while (t) {
        bl++;
        t >>= 1;
    }
    if (p->e >= 0) {
        if (bl + p->e > 128) {
            *overflow = 1;
            return;
        }
        if (p->e >= 64) {
            out->hi = m << (p->e - 64);
        } else {
            out->lo = m << p->e;
            out->hi = p->e ? m >> (64 - p->e) : 0;
        }
    } else {
        int s = -p->e;
        out->lo = s >= 64 ? 0 : m >> s;
    }
}

static int lust_u128_gt(lust_u128w a, lust_u128w b) { return a.hi != b.hi ? a.hi > b.hi : a.lo > b.lo; }

/* The Rust `as` result for an int target of `bits` bits, as a 128-bit
   two's complement pattern (sign-extended past `bits`). */
static lust_u128w lust_cast_to_int(const lust_fparts *p, int bits, int is_signed) {
    lust_u128w mag, limit, out;
    int ovf;
    out.lo = 0;
    out.hi = 0;
    if (p->special == 2) return out; /* NaN -> 0 */
    if (p->special == 1) {
        ovf = 1;
        mag.lo = 0;
        mag.hi = 0;
    } else {
        lust_mag128(p, &mag, &ovf);
    }
    if (!is_signed && p->sign) return out; /* negative -> 0 */
    if (bits == 128) {
        if (is_signed) {
            limit.lo = 0;
            limit.hi = (uint64_t)1 << 63;
            if (!p->sign) limit.lo = ~(uint64_t)0, limit.hi = ((uint64_t)1 << 63) - 1;
        } else {
            limit.lo = ~(uint64_t)0;
            limit.hi = ~(uint64_t)0;
        }
    } else if (is_signed) {
        limit.hi = 0;
        limit.lo = p->sign ? (uint64_t)1 << (bits - 1) : (((uint64_t)1 << (bits - 1)) - 1);
        if (bits == 64 && !p->sign) limit.lo = 0x7FFFFFFFFFFFFFFFull;
    } else {
        limit.hi = 0;
        limit.lo = bits == 64 ? ~(uint64_t)0 : (((uint64_t)1 << bits) - 1);
    }
    if (ovf || lust_u128_gt(mag, limit)) mag = limit;
    if (is_signed && p->sign) {
        out.lo = ~mag.lo + 1;
        out.hi = ~mag.hi + (mag.lo == 0 ? 1 : 0);
    } else {
        out = mag;
    }
    return out;
}

#define LUST_F2I(FN, CT, PARTS, VAL, BITS, SIGNED)                                \
    CT FN(VAL v) {                                                                \
        lust_fparts p = PARTS(v);                                                 \
        lust_u128w r = lust_cast_to_int(&p, BITS, SIGNED);                        \
        return (CT)r.lo;                                                          \
    }
LUST_F2I(lust_f64_to_i8, int8_t, lust_f64_parts, double, 8, 1)
LUST_F2I(lust_f64_to_i16, int16_t, lust_f64_parts, double, 16, 1)
LUST_F2I(lust_f64_to_i32, int32_t, lust_f64_parts, double, 32, 1)
LUST_F2I(lust_f64_to_i64, int64_t, lust_f64_parts, double, 64, 1)
LUST_F2I(lust_f64_to_u8, uint8_t, lust_f64_parts, double, 8, 0)
LUST_F2I(lust_f64_to_u16, uint16_t, lust_f64_parts, double, 16, 0)
LUST_F2I(lust_f64_to_u32, uint32_t, lust_f64_parts, double, 32, 0)
LUST_F2I(lust_f64_to_u64, uint64_t, lust_f64_parts, double, 64, 0)
LUST_F2I(lust_f32_to_i8, int8_t, lust_f32_parts, float, 8, 1)
LUST_F2I(lust_f32_to_i16, int16_t, lust_f32_parts, float, 16, 1)
LUST_F2I(lust_f32_to_i32, int32_t, lust_f32_parts, float, 32, 1)
LUST_F2I(lust_f32_to_i64, int64_t, lust_f32_parts, float, 64, 1)
LUST_F2I(lust_f32_to_u8, uint8_t, lust_f32_parts, float, 8, 0)
LUST_F2I(lust_f32_to_u16, uint16_t, lust_f32_parts, float, 16, 0)
LUST_F2I(lust_f32_to_u32, uint32_t, lust_f32_parts, float, 32, 0)
LUST_F2I(lust_f32_to_u64, uint64_t, lust_f32_parts, float, 64, 0)
#undef LUST_F2I

void lust_f64_to_i128(double v, uint64_t *lo, uint64_t *hi) {
    lust_fparts p = lust_f64_parts(v);
    lust_u128w r = lust_cast_to_int(&p, 128, 1);
    *lo = r.lo;
    *hi = r.hi;
}
void lust_f64_to_u128(double v, uint64_t *lo, uint64_t *hi) {
    lust_fparts p = lust_f64_parts(v);
    lust_u128w r = lust_cast_to_int(&p, 128, 0);
    *lo = r.lo;
    *hi = r.hi;
}
void lust_f32_to_i128(float v, uint64_t *lo, uint64_t *hi) {
    lust_fparts p = lust_f32_parts(v);
    lust_u128w r = lust_cast_to_int(&p, 128, 1);
    *lo = r.lo;
    *hi = r.hi;
}
void lust_f32_to_u128(float v, uint64_t *lo, uint64_t *hi) {
    lust_fparts p = lust_f32_parts(v);
    lust_u128w r = lust_cast_to_int(&p, 128, 0);
    *lo = r.lo;
    *hi = r.hi;
}

/* Magnitude bits of an unsigned 128-bit integer rounded once to a float
   with p mantissa bits and exponent bias `bias`, ties to even. */
static uint64_t lust_u128_to_mag(uint64_t lo, uint64_t hi, int p, int bias) {
    int bl = 0, be, shift, i;
    uint64_t mant;
    if (hi) {
        uint64_t t = hi;
        bl = 64;
        while (t) {
            bl++;
            t >>= 1;
        }
    } else {
        uint64_t t = lo;
        while (t) {
            bl++;
            t >>= 1;
        }
    }
    if (bl == 0) return 0;
    be = bl - 1;
    if (bl <= p) {
        mant = lo << (p - bl);
    } else {
        int round_bit, sticky = 0;
        shift = bl - p;
        if (shift >= 64)
            mant = hi >> (shift - 64);
        else
            mant = (lo >> shift) | (shift ? hi << (64 - shift) : 0);
        /* bit (shift-1) is the round bit; anything below is sticky. */
        if (shift - 1 >= 64)
            round_bit = (int)((hi >> (shift - 65)) & 1);
        else
            round_bit = (int)((lo >> (shift - 1)) & 1);
        for (i = 0; i < shift - 1 && i < 64; i++)
            if ((lo >> i) & 1) sticky = 1;
        if (shift - 1 > 64) {
            if (lo) sticky = 1;
            for (i = 0; i < shift - 65; i++)
                if ((hi >> i) & 1) sticky = 1;
        }
        if (round_bit && (sticky || (mant & 1))) mant++;
        if (mant >> p) {
            mant >>= 1;
            be++;
        }
    }
    return ((uint64_t)(be + bias) << (p - 1)) | (mant & (((uint64_t)1 << (p - 1)) - 1));
}

double lust_i64_to_f64(int64_t v) {
    int sign = v < 0;
    uint64_t m = sign ? (uint64_t)0 - (uint64_t)v : (uint64_t)v;
    uint64_t bits = lust_u128_to_mag(m, 0, 53, 1023);
    return lust_f64_from_bits(bits | (sign ? (uint64_t)1 << 63 : 0));
}
double lust_u64_to_f64(uint64_t v) { return lust_f64_from_bits(lust_u128_to_mag(v, 0, 53, 1023)); }
float lust_i64_to_f32(int64_t v) {
    int sign = v < 0;
    uint64_t m = sign ? (uint64_t)0 - (uint64_t)v : (uint64_t)v;
    uint64_t bits = lust_u128_to_mag(m, 0, 24, 127);
    return lust_f32_from_bits((uint32_t)bits | (sign ? 1u << 31 : 0));
}
float lust_u64_to_f32(uint64_t v) { return lust_f32_from_bits((uint32_t)lust_u128_to_mag(v, 0, 24, 127)); }
double lust_u128_to_f64(uint64_t lo, uint64_t hi) { return lust_f64_from_bits(lust_u128_to_mag(lo, hi, 53, 1023)); }
float lust_u128_to_f32(uint64_t lo, uint64_t hi) { return lust_f32_from_bits((uint32_t)lust_u128_to_mag(lo, hi, 24, 127)); }
double lust_i128_to_f64(uint64_t lo, uint64_t hi) {
    int sign = (int)(hi >> 63);
    uint64_t bits;
    if (sign) {
        uint64_t nlo = ~lo + 1;
        uint64_t nhi = ~hi + (lo == 0 ? 1 : 0);
        bits = lust_u128_to_mag(nlo, nhi, 53, 1023);
    } else {
        bits = lust_u128_to_mag(lo, hi, 53, 1023);
    }
    return lust_f64_from_bits(bits | (sign ? (uint64_t)1 << 63 : 0));
}
float lust_i128_to_f32(uint64_t lo, uint64_t hi) {
    int sign = (int)(hi >> 63);
    uint64_t bits;
    if (sign) {
        uint64_t nlo = ~lo + 1;
        uint64_t nhi = ~hi + (lo == 0 ? 1 : 0);
        bits = lust_u128_to_mag(nlo, nhi, 24, 127);
    } else {
        bits = lust_u128_to_mag(lo, hi, 24, 127);
    }
    return lust_f32_from_bits((uint32_t)bits | (sign ? 1u << 31 : 0));
}

float lust_f64_to_f32(double v) {
    lust_fparts p = lust_f64_parts(v);
    uint64_t bits;
    if (p.special == 2) {
        uint64_t b = lust_f64_bits(v);
        uint32_t frac = (uint32_t)((b & (((uint64_t)1 << 52) - 1)) >> 29);
        if (!((b >> 51) & 1)) frac |= 1u << 22; /* signaling -> quiet */
        if (frac == 0) frac = 1u << 22;
        return lust_f32_from_bits((p.sign ? 1u << 31 : 0) | (0xFFu << 23) | frac);
    }
    if (p.special == 1) return lust_f32_from_bits((p.sign ? 1u << 31 : 0) | (0xFFu << 23));
    if (p.m == 0) return lust_f32_from_bits(p.sign ? 1u << 31 : 0);
    {
        lust_big num, den;
        lust_big_set_u64(&num, p.m);
        lust_big_set_u64(&den, 1);
        bits = lust_ratio_to_float(&num, &den, p.e, 0, 24, -126, 127);
    }
    return lust_f32_from_bits((uint32_t)bits | (p.sign ? 1u << 31 : 0));
}

double lust_f32_to_f64(float v) {
    lust_fparts p = lust_f32_parts(v);
    if (p.special == 2) {
        uint32_t b = lust_f32_bits(v);
        uint64_t frac = (uint64_t)(b & 0x7FFFFF) << 29;
        if (!((b >> 22) & 1)) frac |= (uint64_t)1 << 51; /* signaling -> quiet */
        return lust_f64_from_bits((p.sign ? (uint64_t)1 << 63 : 0) | ((uint64_t)0x7FF << 52) | frac);
    }
    if (p.special == 1) return lust_f64_from_bits((p.sign ? (uint64_t)1 << 63 : 0) | ((uint64_t)0x7FF << 52));
    if (p.m == 0) return lust_f64_from_bits(p.sign ? (uint64_t)1 << 63 : 0);
    {
        int bl = 0;
        uint64_t t = p.m, mant;
        while (t) {
            bl++;
            t >>= 1;
        }
        mant = p.m << (53 - bl);
        return lust_f64_from_bits((p.sign ? (uint64_t)1 << 63 : 0) | ((uint64_t)(bl - 1 + p.e + 1023) << 52) |
                                   (mant & (((uint64_t)1 << 52) - 1)));
    }
}


/* ---------- Float methods ---------- */

/* The libm entry points the float methods call. Rust lowers these
   methods to the same libm calls on this platform, so the results
   match bit for bit. Declarations live in float.h for all units;
   only the powi, min, max, and signum wrappers below are ours: their
   semantics are Rust-specific (reciprocal order, NaN choice, signed
   zeros), so a plain libm call would not match. */

double lust_f64_powi(double a, int32_t e) {
    uint32_t n = e < 0 ? (uint32_t)(-(int64_t)e) : (uint32_t)e;
    double r = 1.0, x = a;
    while (n) {
        if (n & 1) r *= x;
        n >>= 1;
        if (!n) break;
        x *= x;
    }
    return e < 0 ? 1.0 / r : r;
}
float lust_f32_powi(float a, int32_t e) {
    uint32_t n = e < 0 ? (uint32_t)(-(int64_t)e) : (uint32_t)e;
    float r = 1.0f, x = a;
    while (n) {
        if (n & 1) r *= x;
        n >>= 1;
        if (!n) break;
        x *= x;
    }
    return e < 0 ? 1.0f / r : r;
}

/* f64::min and f64::max: a NaN operand yields the other operand,
   and equal operands yield the second one (so the zero sign of the
   second operand wins). */
double lust_f64_min(double a, double b) {
    if (a < b) return a;
    if (b < a) return b;
    if (a == b) return b;
    return a == a ? a : b;
}
double lust_f64_max(double a, double b) {
    if (a > b) return a;
    if (b > a) return b;
    if (a == b) return b;
    return a == a ? a : b;
}
float lust_f32_min(float a, float b) {
    if (a < b) return a;
    if (b < a) return b;
    if (a == b) return b;
    return a == a ? a : b;
}
float lust_f32_max(float a, float b) {
    if (a > b) return a;
    if (b > a) return b;
    if (a == b) return b;
    return a == a ? a : b;
}

double lust_f64_signum(double a) {
    if (a > 0) return 1.0;
    if (a < 0) return -1.0;
    if (a == 0) return lust_f64_bits(a) >> 63 ? -1.0 : 1.0;
    return a;
}
float lust_f32_signum(float a) {
    if (a > 0) return 1.0f;
    if (a < 0) return -1.0f;
    if (a == 0) return lust_f32_bits(a) >> 31 ? -1.0f : 1.0f;
    return a;
}

uint64_t lust_f64_to_bits(double v) { return lust_f64_bits(v); }
uint32_t lust_f32_to_bits(float v) { return lust_f32_bits(v); }
double lust_f64_from_bits_of(uint64_t b) { return lust_f64_from_bits(b); }
float lust_f32_from_bits_of(uint32_t b) { return lust_f32_from_bits(b); }

#endif

#endif


/* core::fmt: the Formatter, leaf impls, and Debug builders
   (src/runtime/fmt.h, W-STD-B). */
/* core::fmt for the lust runtime (W-STD-B): the Formatter, its sinks,
   pad and pad_integral, the leaf Display/Debug impls of the builtin
   types, and the Debug builders. A port of Rust 1.99
   core/src/fmt/{mod,builders,num}.rs, kept to the same write sequence
   where output can see it.

   Every fmt operation returns 0 for Ok(()) and 1 for Err(fmt::Error).
   Generated code calls these from format strings and from the Debug and
   Display glue (cgen::fmt), and user fmt impls reach them through
   `&mut Formatter` (a lust_Formatter pointer).

   Declarations here are in every unit; bodies (fmt.c) only in the
   runtime unit (LUST_IMPL), like float.h. */
#ifndef LUST_RT_FMT_H
#define LUST_RT_FMT_H

/* fmt::Alignment plus Rust's "unknown" (no alignment written). */
#define LUST_ALIGN_LEFT 0u
#define LUST_ALIGN_RIGHT 1u
#define LUST_ALIGN_CENTER 2u
#define LUST_ALIGN_UNKNOWN 3u

/* Formatter flags, one bit each: `+`, `-`, `#`, `0`, `x?`, `X?`, and
   whether a width or a precision was given. */
#define LUST_FLAG_PLUS 1u
#define LUST_FLAG_MINUS 2u
#define LUST_FLAG_ALT 4u
#define LUST_FLAG_ZERO 8u
#define LUST_FLAG_DEBUG_LOWER_HEX 16u
#define LUST_FLAG_DEBUG_UPPER_HEX 32u
#define LUST_FLAG_WIDTH 64u
#define LUST_FLAG_PREC 128u

/* One fmt::Write destination. `write` appends n bytes (valid UTF-8 in
   whole chars) and returns 0 or 1. `direct` is the String a plain
   String sink appends to, so leaf code may append there in one step;
   it is NULL for every other sink. */
typedef struct lust_sink lust_sink;
struct lust_sink {
    int (*write)(lust_sink *self, const uint8_t *p, uint64_t n);
    lust_String *direct;
};

/* builders::PadAdapter: indents each line written through it by four
   spaces. `on_newline` is the PadAdapterState it shares. */
typedef struct {
    lust_sink base;
    lust_sink *inner;
    uint8_t *on_newline;
} lust_pad_sink;

/* fmt::Formatter: the options of one placeholder and the sink. Width
   and precision are u16 in Rust 1.99; they are 0 when their flag is
   not set. */
typedef struct {
    lust_sink *buf;
    uint32_t fill;
    uint8_t align;
    uint8_t flags;
    uint16_t width;
    uint16_t prec;
} lust_Formatter;

/* Storage for one PadAdapter-wrapped Formatter (the `slot` and `state`
   of a builder call in pretty mode). */
typedef struct {
    lust_pad_sink pad;
    lust_Formatter f;
    uint8_t state;
} lust_fmt_slot;

/* The Debug builders (fmt::DebugStruct and kin). `err` is the stored
   fmt::Result. */
typedef struct {
    lust_Formatter *fmt;
    uint8_t err;
    uint8_t has_fields;
} lust_DebugStruct;
typedef struct {
    lust_Formatter *fmt;
    uint64_t fields;
    uint8_t err;
    uint8_t empty_name;
} lust_DebugTuple;
/* DebugList and DebugSet (builders::DebugInner); `set` picks the braces. */
typedef struct {
    lust_Formatter *fmt;
    uint8_t err;
    uint8_t has_fields;
    uint8_t set;
} lust_DebugList;
typedef struct {
    lust_Formatter *fmt;
    uint8_t err;
    uint8_t has_fields;
    uint8_t has_key;
    uint8_t state;
} lust_DebugMap;

/* fmt::Arguments (cgen format_args_value): `fmt` formats the parts of
   one format_args! site into a sink through a fresh Formatter, reading
   the argument references from `env`, and returns 0 (Ok) or 1 (Err).
   It is NULL for literal-only text (`text`, `len`). `cap` is the
   site's `estimated_capacity`, for `to_string`. */
typedef struct {
    int (*fmt)(const void *env, lust_sink *k);
    const void *env;
    const char *text;
    uint64_t len;
    uint64_t cap;
} lust_Arguments;

/* Sizes the compiler's layout tables assume (cgen fmt_size_align). */
_Static_assert(sizeof(lust_Formatter) == 24 && sizeof(lust_DebugTuple) == 24, "fmt layout");
_Static_assert(sizeof(lust_Arguments) == 40, "fmt layout");
_Static_assert(sizeof(lust_DebugStruct) == 16 && sizeof(lust_DebugList) == 16 && sizeof(lust_DebugMap) == 16, "fmt layout");

/* A sink over a String, and a Formatter with default options over a
   sink (Formatter::new: fill ' ', no alignment, no flags). */
void lust_sink_string(lust_sink *k, lust_String *s);
/* `print!` (to_stderr 0) and `eprint!` (1): locks the stream for the
   whole print, as std does (the lock is recursive, so a print inside a
   fmt impl goes on, and another thread's print waits), and makes `k` a
   sink that writes each piece to it. `lust_print_end` unlocks. */
void lust_print_begin(lust_sink *k, int to_stderr);
void lust_print_end(int to_stderr);
/* The sink of `io::Write::write_fmt` on a std stream: like the print
   sink, but a failed write records its errno in `err` and returns a
   fmt error instead of panicking, so the caller can build the
   `io::Error`. `lust_io_begin` locks the stream as `lust_print_begin`
   does; `lust_print_end` unlocks it. */
typedef struct {
    lust_sink base;
    int32_t err;
} lust_io_sink;
void lust_io_begin(lust_io_sink *k, int to_stderr);
void lust_f_init(lust_Formatter *f, lust_sink *buf);
/* fmt::Arguments: `fmt::write(k, a)`; Display and Debug of `a` into
   `f` (core writes to `f`'s sink and ignores `f`'s options); and
   `a.to_string()` (alloc's `fmt::format`). */
int lust_args_write(const lust_Arguments *a, lust_sink *k);
int lust_f_args(lust_Formatter *f, const lust_Arguments *a);
lust_String lust_args_to_string(const lust_Arguments *a);
/* Sets the options of one placeholder. `width` and `prec` count only
   when their flag bit is set. */
void lust_f_set(lust_Formatter *f, uint32_t fill, uint32_t align, uint32_t flags, uint32_t width, uint32_t prec);

int lust_f_write(lust_Formatter *f, const void *p, uint64_t n);
int lust_f_write_str(lust_Formatter *f, lust_str s);
int lust_f_write_char(lust_Formatter *f, uint32_t c);
/* Formatter::pad and Formatter::pad_integral. */
int lust_f_pad(lust_Formatter *f, lust_str s);
int lust_f_pad_integral(lust_Formatter *f, int nonneg, lust_str prefix, lust_str digits);

/* Integer Display (decimal), radix formats (mode 1 x, 2 X, 3 o, 4 b,
   over the value's bits at its type width), and Debug (Display unless
   the `x?` or `X?` flag asks for hex; `mask` cuts a signed value to its
   type width for that case). */
int lust_f_u64(lust_Formatter *f, uint64_t v);
int lust_f_i64(lust_Formatter *f, int64_t v);
int lust_f_u128(lust_Formatter *f, lust_u128 v);
int lust_f_i128(lust_Formatter *f, lust_i128 v);
int lust_f_radix(lust_Formatter *f, uint64_t lo, uint64_t hi, uint32_t mode);
int lust_f_dbg_u64(lust_Formatter *f, uint64_t v);
int lust_f_dbg_i64(lust_Formatter *f, int64_t v, uint64_t mask);
int lust_f_dbg_u128(lust_Formatter *f, lust_u128 v);
int lust_f_dbg_i128(lust_Formatter *f, lust_i128 v);
/* Floats in a LUST_FLOAT_* mode, with the Formatter's options. */
int lust_f_f64(lust_Formatter *f, double v, uint32_t mode);
int lust_f_f32(lust_Formatter *f, float v, uint32_t mode);
/* bool (Display and Debug), char Display, char and str Debug, `()`
   Debug, and fn pointer Debug (an address). */
int lust_f_bool(lust_Formatter *f, uint8_t v);
int lust_f_char(lust_Formatter *f, uint32_t c);
int lust_f_dbg_char(lust_Formatter *f, uint32_t c);
int lust_f_dbg_str(lust_Formatter *f, lust_str s);
int lust_f_unit(lust_Formatter *f);
int lust_f_fnptr(lust_Formatter *f, const void *p);
int lust_f_pointer(lust_Formatter *f, const void *p);
uint32_t lust_f_count(uint64_t n, lust_loc loc);

/* The builders. A `*_field`/`*_entry`/`*_key`/`*_value` call returns the
   Formatter the value writes to (the builder's own, or a PadAdapter in
   `slot` when the Formatter is alternate), or NULL when the stored
   result is already an error (then skip the value and the end call).
   The matching `*_end` call takes the value's result. */
void lust_dstruct_new(lust_DebugStruct *d, lust_Formatter *f, lust_str name);
lust_Formatter *lust_dstruct_field(lust_DebugStruct *d, lust_fmt_slot *s, lust_str name);
void lust_dstruct_field_end(lust_DebugStruct *d, lust_fmt_slot *s, int err);
int lust_dstruct_finish(lust_DebugStruct *d);
int lust_dstruct_finish_ne(lust_DebugStruct *d);
void lust_dtuple_new(lust_DebugTuple *d, lust_Formatter *f, lust_str name);
lust_Formatter *lust_dtuple_field(lust_DebugTuple *d, lust_fmt_slot *s);
void lust_dtuple_field_end(lust_DebugTuple *d, lust_fmt_slot *s, int err);
int lust_dtuple_finish(lust_DebugTuple *d);
int lust_dtuple_finish_ne(lust_DebugTuple *d);
void lust_dlist_new(lust_DebugList *d, lust_Formatter *f, int set);
lust_Formatter *lust_dlist_entry(lust_DebugList *d, lust_fmt_slot *s);
void lust_dlist_entry_end(lust_DebugList *d, lust_fmt_slot *s, int err);
int lust_dlist_finish(lust_DebugList *d);
int lust_dlist_finish_ne(lust_DebugList *d);
void lust_dmap_new(lust_DebugMap *d, lust_Formatter *f);
lust_Formatter *lust_dmap_key(lust_DebugMap *d, lust_fmt_slot *s, lust_loc loc);
void lust_dmap_key_end(lust_DebugMap *d, lust_fmt_slot *s, int err);
lust_Formatter *lust_dmap_value(lust_DebugMap *d, lust_fmt_slot *s, lust_loc loc);
void lust_dmap_value_end(lust_DebugMap *d, lust_fmt_slot *s, int err);
int lust_dmap_finish(lust_DebugMap *d, lust_loc loc);
int lust_dmap_finish_ne(lust_DebugMap *d, lust_loc loc);

/* The panic after a fmt impl returned Err into a sink that cannot fail:
   `what` 0 is format!, 1 is to_string, 2 is print! and eprint!
   (Rust's texts and std locations; a print has written the pieces
   before the failing one). */
void lust_fmt_failed(uint32_t what, lust_loc loc);

#ifdef LUST_IMPL
/* Implementation of the fmt API declared in fmt.h (W-STD-B). Included
   from fmt.h only in the runtime unit (LUST_IMPL). Each function names
   its Rust 1.99 counterpart; the write sequence follows Rust where a
   sink can see it (PadAdapter only sees newlines, so a run of text Rust
   writes in pieces may arrive here in one write). */

/* ---------- sinks ---------- */

static int lust_string_sink_write(lust_sink *k, const uint8_t *p, uint64_t n) {
    lust_string_push_bytes(k->direct, p, n);
    return 0;
}

void lust_sink_string(lust_sink *k, lust_String *s) {
    k->write = lust_string_sink_write;
    k->direct = s;
}

/* The sinks of `print!` and `eprint!`: std formats straight into its
   locked Stdout (a LineWriter, panic.c `lust_print_out`) or its
   unbuffered Stderr, so each piece is written as it is formatted. */
static int lust_stdout_sink_write(lust_sink *k, const uint8_t *p, uint64_t n) {
    (void)k;
    lust_print_out(p, n);
    return 0;
}

static int lust_stderr_sink_write(lust_sink *k, const uint8_t *p, uint64_t n) {
    (void)k;
    fwrite(p, 1, n, stderr);
    fflush(stderr);
    return 0;
}

void lust_print_begin(lust_sink *k, int to_stderr) {
    flockfile(to_stderr ? stderr : stdout);
    k->write = to_stderr ? lust_stderr_sink_write : lust_stdout_sink_write;
    k->direct = NULL;
}

void lust_print_end(int to_stderr) { funlockfile(to_stderr ? stderr : stdout); }

/* The `io::Write::write_fmt` sinks: stdout through the soft LineWriter
   (`lust_stdout_write_soft`, panic.c), stderr unbuffered with
   `write_all`'s retry on a short or interrupted write. The first
   failure's errno stays in `err`; later writes fail at once. */
static int lust_io_stdout_write(lust_sink *k, const uint8_t *p, uint64_t n) {
    lust_io_sink *io = (lust_io_sink *)k;
    if (io->err) return 1;
    io->err = lust_stdout_write_soft(p, n);
    return io->err != 0;
}

static int lust_io_stderr_write(lust_sink *k, const uint8_t *p, uint64_t n) {
    lust_io_sink *io = (lust_io_sink *)k;
    if (io->err) return 1;
    while (n) {
        size_t w = fwrite(p, 1, (size_t)n, stderr);
        if (!w) {
            int e = errno;
            clearerr(stderr);
            if (e == EINTR) continue;
            io->err = e ? e : EIO;
            return 1;
        }
        p += w;
        n -= w;
    }
    while (fflush(stderr) != 0) {
        int e = errno;
        clearerr(stderr);
        if (e == EINTR) continue;
        io->err = e ? e : EIO;
        return 1;
    }
    return 0;
}

void lust_io_begin(lust_io_sink *k, int to_stderr) {
    flockfile(to_stderr ? stderr : stdout);
    k->base.write = to_stderr ? lust_io_stderr_write : lust_io_stdout_write;
    k->base.direct = NULL;
    k->err = 0;
}

/* PadAdapter::write_str: indent at each line start, over
   `s.split_inclusive('\n')`. */
static int lust_pad_sink_write(lust_sink *k, const uint8_t *p, uint64_t n) {
    lust_pad_sink *s = (lust_pad_sink *)k;
    uint64_t i = 0;
    while (i < n) {
        uint64_t j = i;
        while (j < n && p[j] != '\n') j++;
        if (j < n) j++;
        if (*s->on_newline && s->inner->write(s->inner, (const uint8_t *)"    ", 4)) return 1;
        *s->on_newline = p[j - 1] == '\n';
        if (s->inner->write(s->inner, p + i, j - i)) return 1;
        i = j;
    }
    return 0;
}

int lust_args_write(const lust_Arguments *a, lust_sink *k) {
    if (a->fmt) return a->fmt(a->env, k);
    return a->len ? k->write(k, (const uint8_t *)a->text, a->len) : 0;
}

int lust_f_args(lust_Formatter *f, const lust_Arguments *a) {
    return lust_args_write(a, f->buf);
}

lust_String lust_args_to_string(const lust_Arguments *a) {
    lust_String s = lust_string_with_capacity(a->cap);
    lust_sink k;
    lust_sink_string(&k, &s);
    if (lust_args_write(a, &k)) lust_fmt_failed(0, 0);
    return s;
}

void lust_f_init(lust_Formatter *f, lust_sink *buf) {
    f->buf = buf;
    f->fill = ' ';
    f->align = LUST_ALIGN_UNKNOWN;
    f->flags = 0;
    f->width = 0;
    f->prec = 0;
}

void lust_f_set(lust_Formatter *f, uint32_t fill, uint32_t align, uint32_t flags, uint32_t width, uint32_t prec) {
    f->fill = fill;
    f->align = (uint8_t)align;
    f->flags = (uint8_t)flags;
    f->width = (flags & LUST_FLAG_WIDTH) ? (uint16_t)width : 0;
    f->prec = (flags & LUST_FLAG_PREC) ? (uint16_t)prec : 0;
}

/* Formatter::wrap_buf with a PadAdapter: the same options, writing
   through `s->pad` into `f`'s sink, sharing `state`. */
static lust_Formatter *lust_f_wrap_pad(lust_Formatter *f, lust_fmt_slot *s, uint8_t *state) {
    s->pad.base.write = lust_pad_sink_write;
    s->pad.base.direct = 0;
    s->pad.inner = f->buf;
    s->pad.on_newline = state;
    s->f = *f;
    s->f.buf = &s->pad.base;
    return &s->f;
}

int lust_f_write(lust_Formatter *f, const void *p, uint64_t n) {
    if (!n) return 0;
    return f->buf->write(f->buf, (const uint8_t *)p, n);
}

int lust_f_write_str(lust_Formatter *f, lust_str s) { return lust_f_write(f, s.ptr, s.len); }

static int lust_utf8_encode(uint32_t c, uint8_t *b) {
    if (c < 0x80) { b[0] = (uint8_t)c; return 1; }
    if (c < 0x800) { b[0] = 0xC0 | (c >> 6); b[1] = 0x80 | (c & 0x3F); return 2; }
    if (c < 0x10000) { b[0] = 0xE0 | (c >> 12); b[1] = 0x80 | ((c >> 6) & 0x3F); b[2] = 0x80 | (c & 0x3F); return 3; }
    b[0] = 0xF0 | (c >> 18); b[1] = 0x80 | ((c >> 12) & 0x3F); b[2] = 0x80 | ((c >> 6) & 0x3F); b[3] = 0x80 | (c & 0x3F);
    return 4;
}

int lust_f_write_char(lust_Formatter *f, uint32_t c) {
    uint8_t b[4];
    int n = lust_utf8_encode(c, b);
    return f->buf->write(f->buf, b, (uint64_t)n);
}

static lust_str lust_cstr(const char *c) {
    lust_str s;
    s.ptr = (uint8_t *)c;
    s.len = strlen(c);
    return s;
}

/* `n` fill chars, one write_char each (PostPadding::write). */
static int lust_f_fill_n(lust_Formatter *f, uint32_t fill, uint32_t n) {
    for (uint32_t i = 0; i < n; i++) {
        if (lust_f_write_char(f, fill)) return 1;
    }
    return 0;
}

/* Formatter::padding: writes the pre-padding; *post gets the count the
   caller writes after the content (with the fill captured here). */
static int lust_f_padding(lust_Formatter *f, uint32_t padding, uint32_t dflt, uint32_t *post) {
    uint32_t align = f->align == LUST_ALIGN_UNKNOWN ? dflt : f->align;
    uint32_t left = align == LUST_ALIGN_LEFT ? 0 : align == LUST_ALIGN_RIGHT ? padding : padding / 2;
    if (lust_f_fill_n(f, f->fill, left)) return 1;
    *post = padding - left;
    return 0;
}

/* Formatter::pad. */
int lust_f_pad(lust_Formatter *f, lust_str s) {
    if (!(f->flags & (LUST_FLAG_WIDTH | LUST_FLAG_PREC))) return lust_f_write_str(f, s);
    uint64_t chars = 0;
    if (f->flags & LUST_FLAG_PREC) {
        uint64_t i = 0;
        while (chars < f->prec && i < s.len) {
            lust_utf8_next(s.ptr, &i);
            chars++;
        }
        s.len = i;
    } else {
        chars = lust_str_char_count(s);
    }
    if (chars < f->width) {
        uint32_t fill = f->fill, post = 0;
        if (lust_f_padding(f, (uint32_t)(f->width - chars), LUST_ALIGN_LEFT, &post)) return 1;
        if (lust_f_write_str(f, s)) return 1;
        return lust_f_fill_n(f, fill, post);
    }
    return lust_f_write_str(f, s);
}

/* pad_integral's write_prefix: the sign, then the prefix if asked. */
static int lust_f_write_prefix(lust_Formatter *f, uint32_t sign, int use_prefix, lust_str prefix) {
    if (sign && lust_f_write_char(f, sign)) return 1;
    if (use_prefix) return lust_f_write_str(f, prefix);
    return 0;
}

/* Formatter::pad_integral. `digits.len` counts bytes, as in Rust. On an
   error inside the zero-pad branch the options stay changed, as Rust's
   early `?` leaves them. */
int lust_f_pad_integral(lust_Formatter *f, int nonneg, lust_str prefix, lust_str digits) {
    uint64_t width = digits.len;
    uint32_t sign = 0;
    if (!nonneg) {
        sign = '-';
        width++;
    } else if (f->flags & LUST_FLAG_PLUS) {
        sign = '+';
        width++;
    }
    int use_prefix = (f->flags & LUST_FLAG_ALT) != 0;
    if (use_prefix) width += lust_str_char_count(prefix);
    uint64_t min = f->width;
    if (width >= min) {
        if (lust_f_write_prefix(f, sign, use_prefix, prefix)) return 1;
        return lust_f_write_str(f, digits);
    }
    uint32_t post = 0;
    if (f->flags & LUST_FLAG_ZERO) {
        uint32_t old_fill = f->fill;
        uint8_t old_align = f->align;
        f->fill = '0';
        f->align = LUST_ALIGN_RIGHT;
        if (lust_f_write_prefix(f, sign, use_prefix, prefix)) return 1;
        if (lust_f_padding(f, (uint32_t)(min - width), LUST_ALIGN_RIGHT, &post)) return 1;
        if (lust_f_write_str(f, digits)) return 1;
        if (lust_f_fill_n(f, '0', post)) return 1;
        f->fill = old_fill;
        f->align = old_align;
        return 0;
    }
    uint32_t fill = f->fill;
    if (lust_f_padding(f, (uint32_t)(min - width), LUST_ALIGN_RIGHT, &post)) return 1;
    if (lust_f_write_prefix(f, sign, use_prefix, prefix)) return 1;
    if (lust_f_write_str(f, digits)) return 1;
    return lust_f_fill_n(f, fill, post);
}

/* ---------- integers ---------- */

/* Decimal digits of a u128 into the tail of buf[40]; returns the start. */
static int lust_f_dec128(lust_u128 v, char *buf) {
    int i = 40;
    if (!v.lo && !v.hi) buf[--i] = '0';
    while (v.lo || v.hi) {
        uint64_t r;
        v = lust_u128_divmod64(v, 10, &r);
        buf[--i] = (char)('0' + r);
    }
    return i;
}

static int lust_f_dec_out(lust_Formatter *f, int nonneg, uint64_t lo, uint64_t hi) {
    char buf[40];
    lust_u128 v;
    v.lo = lo;
    v.hi = hi;
    int i = lust_f_dec128(v, buf);
    lust_str d;
    d.ptr = (uint8_t *)buf + i;
    d.len = (uint64_t)(40 - i);
    return lust_f_pad_integral(f, nonneg, lust_cstr(""), d);
}

int lust_f_u64(lust_Formatter *f, uint64_t v) { return lust_f_dec_out(f, 1, v, 0); }

int lust_f_i64(lust_Formatter *f, int64_t v) {
    uint64_t mag = v < 0 ? (uint64_t)0 - (uint64_t)v : (uint64_t)v;
    return lust_f_dec_out(f, v >= 0, mag, 0);
}

int lust_f_u128(lust_Formatter *f, lust_u128 v) { return lust_f_dec_out(f, 1, v.lo, v.hi); }

int lust_f_i128(lust_Formatter *f, lust_i128 v) {
    int neg = (int64_t)v.hi < 0;
    lust_u128 m = neg ? lust_i128_mag(v) : lust_u128_from_i128(v);
    return lust_f_dec_out(f, !neg, m.lo, m.hi);
}

/* LowerHex, UpperHex, Octal, Binary (num.rs GenericRadix): the bits as
   unsigned, prefix 0x (also for X), 0o, 0b. */
int lust_f_radix(lust_Formatter *f, uint64_t lo, uint64_t hi, uint32_t mode) {
    static const char lower[] = "0123456789abcdef";
    static const char upper[] = "0123456789ABCDEF";
    const char *digs = mode == 2 ? upper : lower;
    uint64_t base = mode <= 2 ? 16 : mode == 3 ? 8 : 2;
    char buf[130];
    int i = 130;
    lust_u128 v;
    v.lo = lo;
    v.hi = hi;
    if (!v.lo && !v.hi) buf[--i] = '0';
    while (v.lo || v.hi) {
        uint64_t r;
        v = lust_u128_divmod64(v, base, &r);
        buf[--i] = digs[r];
    }
    lust_str d;
    d.ptr = (uint8_t *)buf + i;
    d.len = (uint64_t)(130 - i);
    return lust_f_pad_integral(f, 1, lust_cstr(mode <= 2 ? "0x" : mode == 3 ? "0o" : "0b"), d);
}

static int lust_f_debug_hex(const lust_Formatter *f) {
    return (f->flags & LUST_FLAG_DEBUG_LOWER_HEX) ? 1 : (f->flags & LUST_FLAG_DEBUG_UPPER_HEX) ? 2 : 0;
}

int lust_f_dbg_u64(lust_Formatter *f, uint64_t v) {
    int hex = lust_f_debug_hex(f);
    return hex ? lust_f_radix(f, v, 0, (uint32_t)hex) : lust_f_u64(f, v);
}

int lust_f_dbg_i64(lust_Formatter *f, int64_t v, uint64_t mask) {
    int hex = lust_f_debug_hex(f);
    return hex ? lust_f_radix(f, (uint64_t)v & mask, 0, (uint32_t)hex) : lust_f_i64(f, v);
}

int lust_f_dbg_u128(lust_Formatter *f, lust_u128 v) {
    int hex = lust_f_debug_hex(f);
    return hex ? lust_f_radix(f, v.lo, v.hi, (uint32_t)hex) : lust_f_u128(f, v);
}

int lust_f_dbg_i128(lust_Formatter *f, lust_i128 v) {
    int hex = lust_f_debug_hex(f);
    return hex ? lust_f_radix(f, v.lo, v.hi, (uint32_t)hex) : lust_f_i128(f, v);
}

/* ---------- floats, text leaves ---------- */

/* Runs `emit` style leaf output: append to the sink's String when it
   has one, else to a temporary that is then written in one piece. */
static lust_String *lust_f_out_begin(lust_Formatter *f, lust_String *tmp) {
    if (f->buf->direct) return f->buf->direct;
    *tmp = lust_string_new();
    return tmp;
}

static int lust_f_out_end(lust_Formatter *f, lust_String *out, lust_String *tmp) {
    if (out != tmp) return 0;
    int e = lust_f_write(f, tmp->ptr, tmp->len);
    lust_string_drop(tmp);
    return e;
}

static lust_float_spec lust_f_float_spec(const lust_Formatter *f, uint32_t mode) {
    lust_float_spec s;
    memset(&s, 0, sizeof s);
    s.precision = (f->flags & LUST_FLAG_PREC) ? f->prec : LUST_FLOAT_NO_PRECISION;
    s.mode = (uint8_t)mode;
    return s;
}

/* One numfmt::Part: `len` bytes copied from `p`, or `len` zeros when
   `p` is NULL (Part::Zero). Part::Num is a copy of its digits. */
typedef struct {
    const uint8_t *p;
    uint64_t len;
} lust_numpart;

/* Splits the magnitude text of float_core into the parts Rust's flt2dec
   builds for it (digits_to_dec_str and digits_to_exp_str), so each part
   is one write as in write_formatted_parts. `exact` is the fixed
   precision path, whose digit buffer keeps its trailing zeros. */
static int lust_float_split(const lust_String *core, int exact, lust_numpart *out) {
    const uint8_t *t = core->ptr;
    uint64_t n = core->len, i, e = n, dot = n;
    int k = 0;
    for (i = 0; i < n; i++) {
        if (t[i] == 'e' || t[i] == 'E') e = i;
        if (t[i] == '.' && dot == n) dot = i;
    }
    if (n >= 3 && (t[0] == 'N' || t[0] == 'i')) {
        out[k].p = t;
        out[k++].len = n;
        return k;
    }
    if (e < n) {
        /* Exponent form: [d][.][rest][e or e-][exp]; zero shortest is one
           copy ("0e0"), zero exact is [0.][zeros][e0]. */
        if (t[0] == '0' && (e == 1 || !exact)) {
            out[k].p = t;
            out[k++].len = n;
            return k;
        }
        if (t[0] == '0') {
            out[k].p = t;
            out[k++].len = 2;
            out[k].p = 0;
            out[k++].len = e - 2;
            out[k].p = t + e;
            out[k++].len = n - e;
            return k;
        }
        out[k].p = t;
        out[k++].len = 1;
        if (dot < e) {
            out[k].p = t + 1;
            out[k++].len = 1;
            out[k].p = t + 2;
            out[k++].len = e - 2;
        }
        uint64_t sign_len = (e + 1 < n && t[e + 1] == '-') ? 2 : 1;
        out[k].p = t + e;
        out[k++].len = sign_len;
        out[k].p = t + e + sign_len;
        out[k++].len = n - e - sign_len;
        return k;
    }
    if (n >= 2 && t[0] == '0' && t[1] == '.') {
        /* [0.][zeros][digits] */
        uint64_t z = 2;
        while (z < n && t[z] == '0') z++;
        out[k].p = t;
        out[k++].len = 2;
        out[k].p = 0;
        out[k++].len = z - 2;
        if (z < n) {
            out[k].p = t + z;
            out[k++].len = n - z;
        }
        return k;
    }
    int frac_zero = 1;
    for (i = dot + 1; i < n; i++)
        if (t[i] != '0') frac_zero = 0;
    if (exact || (dot < n && !frac_zero)) {
        /* [int][.][frac], or the whole digits when there is no point. */
        out[k].p = t;
        out[k++].len = dot;
        if (dot < n) {
            out[k].p = t + dot;
            out[k++].len = 1;
            out[k].p = t + dot + 1;
            out[k++].len = n - dot - 1;
        }
        return k;
    }
    /* Shortest digits ending before the point: [digits][zeros], then
       [.][zeros] for Debug's ".0". */
    uint64_t sig = dot;
    while (sig > 1 && t[sig - 1] == '0') sig--;
    out[k].p = t;
    out[k++].len = sig;
    out[k].p = 0;
    out[k++].len = dot - sig;
    if (dot < n) {
        out[k].p = t + dot;
        out[k++].len = 1;
        out[k].p = 0;
        out[k++].len = n - dot - 1;
    }
    return k;
}

/* Formatter::write_formatted_parts. */
static int lust_f_write_parts(lust_Formatter *f, const char *sign, const lust_numpart *parts, int k) {
    static const char zeros[] = "0000000000000000000000000000000000000000000000000000000000000000";
    if (sign[0] && lust_f_write(f, sign, 1)) return 1;
    for (int i = 0; i < k; i++) {
        if (parts[i].p) {
            if (lust_f_write(f, parts[i].p, parts[i].len)) return 1;
            continue;
        }
        uint64_t z = parts[i].len;
        while (z > 64) {
            if (lust_f_write(f, zeros, 64)) return 1;
            z -= 64;
        }
        if (z && lust_f_write(f, zeros, z)) return 1;
    }
    return 0;
}

/* float_to_*_common with Formatter::pad_formatted_parts. */
static int lust_f_float(lust_Formatter *f, const lust_fparts *p, uint32_t mode) {
    lust_float_spec spec = lust_f_float_spec(f, mode);
    lust_String core = lust_string_new();
    lust_numpart parts[8];
    lust_float_core(&core, p, spec);
    int k = lust_float_split(&core, spec.precision != LUST_FLOAT_NO_PRECISION, parts);
    const char *sign = p->special == 2 ? "" : p->sign ? "-" : (f->flags & LUST_FLAG_PLUS) ? "+" : "";
    int e;
    if (f->width == 0) {
        e = lust_f_write_parts(f, sign, parts, k);
    } else {
        uint32_t old_fill = f->fill;
        uint8_t old_align = f->align;
        uint64_t width = f->width;
        if (f->flags & LUST_FLAG_ZERO) {
            if (sign[0] && lust_f_write(f, sign, 1)) {
                lust_string_drop(&core);
                return 1;
            }
            width = width > (sign[0] ? 1u : 0u) ? width - (sign[0] ? 1u : 0u) : 0;
            sign = "";
            f->fill = '0';
            f->align = LUST_ALIGN_RIGHT;
        }
        uint64_t len = sign[0] ? 1 : 0;
        for (int i = 0; i < k; i++) len += parts[i].len;
        if (width <= len) {
            e = lust_f_write_parts(f, sign, parts, k);
        } else {
            uint32_t fill = f->fill, post = 0;
            e = lust_f_padding(f, (uint32_t)(width - len), LUST_ALIGN_RIGHT, &post) || lust_f_write_parts(f, sign, parts, k) ||
                lust_f_fill_n(f, fill, post);
        }
        f->fill = old_fill;
        f->align = old_align;
    }
    lust_string_drop(&core);
    return e;
}

int lust_f_f64(lust_Formatter *f, double v, uint32_t mode) {
    lust_fparts p = lust_f64_parts(v);
    return lust_f_float(f, &p, mode);
}

int lust_f_f32(lust_Formatter *f, float v, uint32_t mode) {
    lust_fparts p = lust_f32_parts(v);
    return lust_f_float(f, &p, mode);
}

/* bool Display (and Debug): str Display of "true" or "false". */
int lust_f_bool(lust_Formatter *f, uint8_t v) { return lust_f_pad(f, lust_cstr(v ? "true" : "false")); }

/* char Display: one write_char, or pad when a width or precision is set. */
int lust_f_char(lust_Formatter *f, uint32_t c) {
    if (!(f->flags & (LUST_FLAG_WIDTH | LUST_FLAG_PREC))) return lust_f_write_char(f, c);
    uint8_t b[4];
    lust_str s;
    s.ptr = b;
    s.len = (uint64_t)lust_utf8_encode(c, b);
    return lust_f_pad(f, s);
}

/* The escape text of one char for Debug (escape_debug_ext), in buf.
   Returns its byte length; `quote` is the quote char that escapes. */
static uint64_t lust_f_escape(uint32_t c, uint32_t quote, uint8_t *buf, uint64_t cap) {
    lust_String s = lust_string_new();
    lust_fmt_escape(&s, c, quote);
    uint64_t n = s.len < cap ? s.len : cap;
    memcpy(buf, s.ptr, n);
    lust_string_drop(&s);
    return n;
}

/* char Debug: quote, the escape (one write), quote. No padding. */
int lust_f_dbg_char(lust_Formatter *f, uint32_t c) {
    uint8_t buf[16];
    uint64_t n = lust_f_escape(c, '\'', buf, sizeof buf);
    return lust_f_write_char(f, '\'') || lust_f_write(f, buf, n) || lust_f_write_char(f, '\'');
}

/* str Debug: runs of chars that need no escape are written whole,
   between the escapes, as in Rust's printable_range loop. */
int lust_f_dbg_str(lust_Formatter *f, lust_str s) {
    if (lust_f_write_char(f, '"')) return 1;
    uint64_t start = 0, i = 0;
    while (i < s.len) {
        uint8_t b = s.ptr[i];
        if (!(b > 0x7E || b < 0x20 || b == '\\' || b == '"')) {
            i++;
            continue;
        }
        uint64_t j = i;
        uint32_t c = lust_utf8_next(s.ptr, &j);
        uint8_t buf[16];
        uint64_t n = lust_f_escape(c, '"', buf, sizeof buf);
        uint8_t one[4];
        int one_n = lust_utf8_encode(c, one);
        if (n != (uint64_t)one_n || memcmp(buf, one, n) != 0) {
            lust_str run;
            run.ptr = s.ptr + start;
            run.len = i - start;
            if (lust_f_write_str(f, run) || lust_f_write(f, buf, n)) return 1;
            start = j;
        }
        i = j;
    }
    lust_str rest;
    rest.ptr = s.ptr + start;
    rest.len = s.len - start;
    return lust_f_write_str(f, rest) || lust_f_write_char(f, '"');
}

int lust_f_unit(lust_Formatter *f) { return lust_f_pad(f, lust_cstr("()")); }

/* fmt::Pointer (pointer_fmt_inner): the address as `{:#x}`; with `#`
   it is zero-padded, to 18 places when no width is set. */
int lust_f_pointer(lust_Formatter *f, const void *p) {
    lust_Formatter g = *f;
    if (g.flags & LUST_FLAG_ALT) {
        g.flags |= LUST_FLAG_ZERO;
        if (!(g.flags & LUST_FLAG_WIDTH)) {
            g.flags |= LUST_FLAG_WIDTH;
            g.width = 18;
        }
    }
    g.flags |= LUST_FLAG_ALT;
    return lust_f_radix(&g, (uint64_t)(uintptr_t)p, 0, 1);
}

/* A width or precision taken from a `usize` argument: Rust 1.99 keeps
   them in u16 and panics past it. */
uint32_t lust_f_count(uint64_t n, lust_loc loc) {
    if (n > 0xffffu) lust_panic_cstr("Formatting argument out of range", loc);
    return (uint32_t)n;
}

int lust_f_fnptr(lust_Formatter *f, const void *p) {
    lust_String tmp;
    lust_String *out = lust_f_out_begin(f, &tmp);
    lust_fmt_fnptr_debug(out, p);
    return lust_f_out_end(f, out, &tmp);
}

/* ---------- builders (builders.rs) ---------- */

static int lust_f_alt(const lust_Formatter *f) { return (f->flags & LUST_FLAG_ALT) != 0; }

/* panic=unwind: a field or entry fmt impl that panicked returns with its
   panic pending. Rust's unwinding leaves the builder there, so the
   builder fails: it writes nothing more (no `, `, `]`, or `}`). */
static int lust_f_unwinding(void) { return lust_unw_pending && lust_unw_mine(); }

void lust_dstruct_new(lust_DebugStruct *d, lust_Formatter *f, lust_str name) {
    d->fmt = f;
    d->err = (uint8_t)lust_f_write_str(f, name);
    d->has_fields = 0;
}

/* DebugStruct::field_with, up to the value. */
lust_Formatter *lust_dstruct_field(lust_DebugStruct *d, lust_fmt_slot *s, lust_str name) {
    lust_Formatter *w = 0;
    if (!d->err) {
        if (lust_f_alt(d->fmt)) {
            if (!d->has_fields && lust_f_write_str(d->fmt, lust_cstr(" {\n"))) goto fail;
            s->state = 1;
            w = lust_f_wrap_pad(d->fmt, s, &s->state);
        } else {
            if (lust_f_write_str(d->fmt, lust_cstr(d->has_fields ? ", " : " { "))) goto fail;
            w = d->fmt;
        }
        if (lust_f_write_str(w, name) || lust_f_write_str(w, lust_cstr(": "))) goto fail;
    }
    if (!w) d->has_fields = 1;
    return w;
fail:
    d->err = 1;
    d->has_fields = 1;
    return 0;
}

void lust_dstruct_field_end(lust_DebugStruct *d, lust_fmt_slot *s, int err) {
    if (err || lust_f_unwinding() || (lust_f_alt(d->fmt) && lust_f_write_str(&s->f, lust_cstr(",\n")))) d->err = 1;
    d->has_fields = 1;
}

int lust_dstruct_finish(lust_DebugStruct *d) {
    if (d->has_fields && !d->err) d->err = (uint8_t)lust_f_write_str(d->fmt, lust_cstr(lust_f_alt(d->fmt) ? "}" : " }"));
    return d->err;
}

int lust_dstruct_finish_ne(lust_DebugStruct *d) {
    if (d->err) return 1;
    if (d->has_fields) {
        if (lust_f_alt(d->fmt)) {
            lust_fmt_slot s;
            s.state = 1;
            lust_Formatter *w = lust_f_wrap_pad(d->fmt, &s, &s.state);
            d->err = (uint8_t)(lust_f_write_str(w, lust_cstr("..\n")) || lust_f_write_str(d->fmt, lust_cstr("}")));
        } else {
            d->err = (uint8_t)lust_f_write_str(d->fmt, lust_cstr(", .. }"));
        }
    } else {
        d->err = (uint8_t)lust_f_write_str(d->fmt, lust_cstr(" { .. }"));
    }
    return d->err;
}

void lust_dtuple_new(lust_DebugTuple *d, lust_Formatter *f, lust_str name) {
    d->fmt = f;
    d->err = (uint8_t)lust_f_write_str(f, name);
    d->fields = 0;
    d->empty_name = name.len == 0;
}

lust_Formatter *lust_dtuple_field(lust_DebugTuple *d, lust_fmt_slot *s) {
    lust_Formatter *w = 0;
    if (!d->err) {
        if (lust_f_alt(d->fmt)) {
            if (d->fields == 0 && lust_f_write_str(d->fmt, lust_cstr("(\n"))) goto fail;
            s->state = 1;
            w = lust_f_wrap_pad(d->fmt, s, &s->state);
        } else {
            if (lust_f_write_str(d->fmt, lust_cstr(d->fields == 0 ? "(" : ", "))) goto fail;
            w = d->fmt;
        }
    }
    if (!w) d->fields++;
    return w;
fail:
    d->err = 1;
    d->fields++;
    return 0;
}

void lust_dtuple_field_end(lust_DebugTuple *d, lust_fmt_slot *s, int err) {
    if (err || lust_f_unwinding() || (lust_f_alt(d->fmt) && lust_f_write_str(&s->f, lust_cstr(",\n")))) d->err = 1;
    d->fields++;
}

int lust_dtuple_finish(lust_DebugTuple *d) {
    if (d->fields > 0 && !d->err) {
        if (d->fields == 1 && d->empty_name && !lust_f_alt(d->fmt) && lust_f_write_str(d->fmt, lust_cstr(","))) {
            d->err = 1;
            return 1;
        }
        d->err = (uint8_t)lust_f_write_str(d->fmt, lust_cstr(")"));
    }
    return d->err;
}

int lust_dtuple_finish_ne(lust_DebugTuple *d) {
    if (d->err) return 1;
    if (d->fields > 0) {
        if (lust_f_alt(d->fmt)) {
            lust_fmt_slot s;
            s.state = 1;
            lust_Formatter *w = lust_f_wrap_pad(d->fmt, &s, &s.state);
            d->err = (uint8_t)(lust_f_write_str(w, lust_cstr("..\n")) || lust_f_write_str(d->fmt, lust_cstr(")")));
        } else {
            d->err = (uint8_t)lust_f_write_str(d->fmt, lust_cstr(", ..)"));
        }
    } else {
        d->err = (uint8_t)lust_f_write_str(d->fmt, lust_cstr("(..)"));
    }
    return d->err;
}

void lust_dlist_new(lust_DebugList *d, lust_Formatter *f, int set) {
    d->fmt = f;
    d->set = (uint8_t)set;
    d->err = (uint8_t)lust_f_write_str(f, lust_cstr(set ? "{" : "["));
    d->has_fields = 0;
}

/* DebugInner::entry_with, up to the entry. */
lust_Formatter *lust_dlist_entry(lust_DebugList *d, lust_fmt_slot *s) {
    lust_Formatter *w = 0;
    if (!d->err) {
        if (lust_f_alt(d->fmt)) {
            if (!d->has_fields && lust_f_write_str(d->fmt, lust_cstr("\n"))) goto fail;
            s->state = 1;
            w = lust_f_wrap_pad(d->fmt, s, &s->state);
        } else {
            if (d->has_fields && lust_f_write_str(d->fmt, lust_cstr(", "))) goto fail;
            w = d->fmt;
        }
    }
    if (!w) d->has_fields = 1;
    return w;
fail:
    d->err = 1;
    d->has_fields = 1;
    return 0;
}

void lust_dlist_entry_end(lust_DebugList *d, lust_fmt_slot *s, int err) {
    if (err || lust_f_unwinding() || (lust_f_alt(d->fmt) && lust_f_write_str(&s->f, lust_cstr(",\n")))) d->err = 1;
    d->has_fields = 1;
}

int lust_dlist_finish(lust_DebugList *d) {
    if (!d->err) d->err = (uint8_t)lust_f_write_str(d->fmt, lust_cstr(d->set ? "}" : "]"));
    return d->err;
}

int lust_dlist_finish_ne(lust_DebugList *d) {
    if (d->err) return 1;
    const char *close = d->set ? "}" : "]";
    if (d->has_fields) {
        if (lust_f_alt(d->fmt)) {
            lust_fmt_slot s;
            s.state = 1;
            lust_Formatter *w = lust_f_wrap_pad(d->fmt, &s, &s.state);
            d->err = (uint8_t)(lust_f_write_str(w, lust_cstr("..\n")) || lust_f_write_str(d->fmt, lust_cstr(close)));
        } else {
            d->err = (uint8_t)lust_f_write_str(d->fmt, lust_cstr(d->set ? ", ..}" : ", ..]"));
        }
    } else {
        d->err = (uint8_t)lust_f_write_str(d->fmt, lust_cstr(d->set ? "..}" : "..]"));
    }
    return d->err;
}

void lust_dmap_new(lust_DebugMap *d, lust_Formatter *f) {
    d->fmt = f;
    d->err = (uint8_t)lust_f_write_str(f, lust_cstr("{"));
    d->has_fields = 0;
    d->has_key = 0;
    d->state = 1;
}

/* DebugMap's misuse panics come from core's builders.rs (no
   track_caller), as rustc 1.99 reports them; `loc` stays for the call
   shape. */
#define LUST_BUILDERS_RS "core/src/fmt/builders.rs:"

/* DebugMap::key_with, up to the key. */
lust_Formatter *lust_dmap_key(lust_DebugMap *d, lust_fmt_slot *s, lust_loc loc) {
    (void)loc;
    if (d->err) return 0;
    if (d->has_key) { lust_panic_std_lit("attempted to begin a new map entry without completing the previous one", LUST_BUILDERS_RS "1001:13"); return 0; }
    if (lust_f_alt(d->fmt)) {
        if (!d->has_fields && lust_f_write_str(d->fmt, lust_cstr("\n"))) goto fail;
        d->state = 1;
        return lust_f_wrap_pad(d->fmt, s, &d->state);
    }
    if (d->has_fields && lust_f_write_str(d->fmt, lust_cstr(", "))) goto fail;
    return d->fmt;
fail:
    d->err = 1;
    return 0;
}

void lust_dmap_key_end(lust_DebugMap *d, lust_fmt_slot *s, int err) {
    lust_Formatter *w = lust_f_alt(d->fmt) ? &s->f : d->fmt;
    if (err || lust_f_unwinding() || lust_f_write_str(w, lust_cstr(": "))) {
        d->err = 1;
        return;
    }
    d->has_key = 1;
}

/* DebugMap::value_with, up to the value. */
lust_Formatter *lust_dmap_value(lust_DebugMap *d, lust_fmt_slot *s, lust_loc loc) {
    (void)loc;
    if (d->err) {
        d->has_fields = 1;
        return 0;
    }
    if (!d->has_key) { lust_panic_std_lit("attempted to format a map value before its key", LUST_BUILDERS_RS "1077:13"); return 0; }
    if (lust_f_alt(d->fmt)) return lust_f_wrap_pad(d->fmt, s, &d->state);
    return d->fmt;
}

void lust_dmap_value_end(lust_DebugMap *d, lust_fmt_slot *s, int err) {
    if (err || lust_f_unwinding() || (lust_f_alt(d->fmt) && lust_f_write_str(&s->f, lust_cstr(",\n")))) {
        d->err = 1;
    } else {
        d->has_key = 0;
    }
    d->has_fields = 1;
}

int lust_dmap_finish(lust_DebugMap *d, lust_loc loc) {
    (void)loc;
    if (d->err) return 1;
    if (d->has_key) { lust_panic_std_lit("attempted to finish a map with a partial entry", LUST_BUILDERS_RS "1229:13"); return 0; }
    d->err = (uint8_t)lust_f_write_str(d->fmt, lust_cstr("}"));
    return d->err;
}

int lust_dmap_finish_ne(lust_DebugMap *d, lust_loc loc) {
    (void)loc;
    if (d->err) return 1;
    if (d->has_key) { lust_panic_std_lit("attempted to finish a map with a partial entry", LUST_BUILDERS_RS "1180:13"); return 0; }
    if (d->has_fields) {
        if (lust_f_alt(d->fmt)) {
            lust_fmt_slot s;
            s.state = 1;
            lust_Formatter *w = lust_f_wrap_pad(d->fmt, &s, &s.state);
            d->err = (uint8_t)(lust_f_write_str(w, lust_cstr("..\n")) || lust_f_write_str(d->fmt, lust_cstr("}")));
        } else {
            d->err = (uint8_t)lust_f_write_str(d->fmt, lust_cstr(", ..}"));
        }
    } else {
        d->err = (uint8_t)lust_f_write_str(d->fmt, lust_cstr("..}"));
    }
    return d->err;
}

void lust_fmt_failed(uint32_t what, lust_loc loc) {
    (void)loc;
    /* Rust raises these inside std, so they report std's location. */
    if (what == 1) lust_panic_std("a Display implementation returned an error unexpectedly: Error", "alloc/src/string.rs:2953:14");
    else if (what == 0) lust_panic_std("a formatting trait implementation returned an error when the underlying stream did not: Error", "alloc/src/fmt.rs:657:14");
    else lust_panic_std_lit("a formatting trait implementation returned an error when the underlying stream did not", "core/src/io/write.rs:411:17");
}

#endif

#endif


/* Slice sorting: Rust 1.99 driftsort and ipnsort (src/runtime/sort.h). */
/* Slice sorting for the lust runtime: a port of Rust 1.99's driftsort
   (`sort`, `sort_by`, `sort_by_key`) and ipnsort (`sort_unstable*`)
   from library/core/src/slice/sort, comparison for comparison
   (W-STD-A phase 3; ARCH 3.3 "Sorting").

   Exactness scope: the sequence of `is_less` calls, the resulting
   order (including equal elements under the unstable sort and
   inconsistent comparators), and the order-violation panic all match
   Rust for the same element size, Copy-ness, and freeze-ness (no
   Cell/RefCell inside). Those three properties choose the small-sort
   variant in Rust, so the caller passes them. Scratch length follows
   Rust (a 4096-byte stack buffer when it fits, else a heap buffer of
   the computed length). Every scratch buffer is aligned for the
   element (`align`), because the comparator sees pointers into it:
   an element aligned over 16 never uses a stack buffer, since tcc
   does not realign stack frames (fx-overalign).

   Elements are moved as bytes (`size` per element), as Rust's ptr
   copies are. `less(ctx, a, b)` is the comparator adapter codegen
   emits per call site (sort_by: `compare(a, b) == Less`; sort_by_key:
   `f(a).lt(&f(b))`; sort: `a.lt(b)`). */

typedef uint8_t (*lust_less_fn)(void *ctx, const void *a, const void *b);

typedef struct {
    uint64_t size, align;
    uint8_t freeze, copy;
    void *ctx;
    lust_less_fn less;
} lust_sort_cx;

#define LS_AT(p, i) ((uint8_t *)(p) + (uint64_t)(i) * s->size)
#define LS_LESS(a, b) (s->less(s->ctx, (a), (b)) != 0)

uint32_t lust_sort_ilog2(uint64_t n) LUST_BODY({ return 63 - (uint32_t)__builtin_clzll(n); })

void lust_sort_swap(lust_sort_cx *s, uint8_t *a, uint8_t *b) LUST_BODY({
    uint8_t tmp[64];
    uint64_t left = s->size;
    while (left) {
        uint64_t n = left < 64 ? left : 64;
        lust_copy_small(tmp, a, n);
        lust_copy_small(a, b, n);
        lust_copy_small(b, tmp, n);
        a += n;
        b += n;
        left -= n;
    }
})

void lust_sort_reverse(lust_sort_cx *s, uint8_t *v, uint64_t len) LUST_BODY({
    for (uint64_t i = 0; i < len / 2; i++) lust_sort_swap(s, LS_AT(v, i), LS_AT(v, len - 1 - i));
})

/* A temporary element buffer: on the stack for small elements. */
typedef struct { uint8_t *p; uint8_t local[64] __attribute__((aligned(16))); } lust_sort_tmp;
uint8_t *lust_sort_tmp_get(lust_sort_cx *s, lust_sort_tmp *t) LUST_BODY({
    t->p = s->size <= 64 && s->align <= 16 ? t->local : (uint8_t *)lust_alloc(s->size, s->align);
    return t->p;
})
void lust_sort_tmp_free(lust_sort_tmp *t) LUST_BODY({
    if (t->p != t->local) free(t->p);
})

/* shared/mod.rs find_existing_run */
uint64_t lust_sort_find_run(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *was_reversed) LUST_BODY({
    *was_reversed = 0;
    if (len < 2) return len;
    uint64_t run_len = 2;
    uint8_t desc = LS_LESS(LS_AT(v, 1), LS_AT(v, 0));
    if (desc) {
        while (run_len < len && LS_LESS(LS_AT(v, run_len), LS_AT(v, run_len - 1))) run_len++;
    } else {
        while (run_len < len && !LS_LESS(LS_AT(v, run_len), LS_AT(v, run_len - 1))) run_len++;
    }
    *was_reversed = desc;
    return run_len;
})

/* smallsort.rs insert_tail: `tail` sifts left until `begin`. */
void lust_sort_insert_tail(lust_sort_cx *s, uint8_t *begin, uint8_t *tail) LUST_BODY({
    uint8_t *sift = tail - s->size;
    if (!LS_LESS(tail, sift)) return;
    lust_sort_tmp t;
    uint8_t *tmp = lust_sort_tmp_get(s, &t);
    lust_copy_small(tmp, tail, s->size);
    uint8_t *gap = tail;
    for (;;) {
        lust_copy_small(gap, sift, s->size);
        gap = sift;
        if (sift == begin) break;
        sift -= s->size;
        if (!LS_LESS(tmp, sift)) break;
    }
    lust_copy_small(gap, tmp, s->size);
    lust_sort_tmp_free(&t);
})

void lust_sort_insertion_shift_left(lust_sort_cx *s, uint8_t *v, uint64_t len, uint64_t offset) LUST_BODY({
    if (offset == 0 || offset > len) abort();
    for (uint64_t i = offset; i < len; i++) lust_sort_insert_tail(s, v, LS_AT(v, i));
})

/* smallsort.rs sort4_stable: 4 elements of v into dst, stably. */
void lust_sort_sort4_stable(lust_sort_cx *s, uint8_t *v, uint8_t *dst) LUST_BODY({
    uint8_t c1 = LS_LESS(LS_AT(v, 1), LS_AT(v, 0));
    uint8_t c2 = LS_LESS(LS_AT(v, 3), LS_AT(v, 2));
    uint8_t *a = LS_AT(v, c1);
    uint8_t *b = LS_AT(v, !c1);
    uint8_t *c = LS_AT(v, 2 + c2);
    uint8_t *d = LS_AT(v, 2 + !c2);
    uint8_t c3 = LS_LESS(c, a);
    uint8_t c4 = LS_LESS(d, b);
    uint8_t *min = c3 ? c : a;
    uint8_t *max = c4 ? b : d;
    uint8_t *unknown_left = c3 ? a : (c4 ? c : b);
    uint8_t *unknown_right = c4 ? d : (c3 ? b : c);
    uint8_t c5 = LS_LESS(unknown_right, unknown_left);
    uint8_t *lo = c5 ? unknown_right : unknown_left;
    uint8_t *hi = c5 ? unknown_left : unknown_right;
    lust_copy_small(LS_AT(dst, 0), min, s->size);
    lust_copy_small(LS_AT(dst, 1), lo, s->size);
    lust_copy_small(LS_AT(dst, 2), hi, s->size);
    lust_copy_small(LS_AT(dst, 3), max, s->size);
})

void lust_sort_ord_violation(void) LUST_BODY({
    lust_panic_cstr("user-provided comparison function does not correctly implement a total order", 0);
})

/* smallsort.rs bidirectional_merge: the two sorted halves of src
   (len / 2 and the rest) into dst, from both ends at once. */
void lust_sort_bidir_merge(lust_sort_cx *s, uint8_t *src, uint64_t len, uint8_t *dst) LUST_BODY({
    uint64_t half = len / 2;
    uint64_t sz = s->size;
    uint8_t *left = src, *right = LS_AT(src, half), *out = dst;
    uint8_t *left_rev = LS_AT(src, half - 1), *right_rev = LS_AT(src, len - 1), *out_rev = LS_AT(dst, len - 1);
    for (uint64_t i = 0; i < half; i++) {
        /* merge_up */
        uint8_t is_l = !LS_LESS(right, left);
        lust_copy_small(out, is_l ? left : right, sz);
        right += is_l ? 0 : sz;
        left += is_l ? sz : 0;
        out += sz;
        /* merge_down */
        is_l = !LS_LESS(right_rev, left_rev);
        lust_copy_small(out_rev, is_l ? right_rev : left_rev, sz);
        right_rev -= is_l ? sz : 0;
        left_rev -= is_l ? 0 : sz;
        out_rev -= sz;
    }
    uint8_t *left_end = left_rev + sz, *right_end = right_rev + sz;
    if (len % 2 != 0) {
        uint8_t left_nonempty = left < left_end;
        lust_copy_small(out, left_nonempty ? left : right, sz);
        left += left_nonempty ? sz : 0;
        right += left_nonempty ? 0 : sz;
    }
    if (left != left_end || right != right_end) lust_sort_ord_violation();
})

void lust_sort_sort8_stable(lust_sort_cx *s, uint8_t *v, uint8_t *dst, uint8_t *scratch) LUST_BODY({
    lust_sort_sort4_stable(s, v, scratch);
    lust_sort_sort4_stable(s, LS_AT(v, 4), LS_AT(scratch, 4));
    lust_sort_bidir_merge(s, scratch, 8, dst);
})

/* smallsort.rs small_sort_general_with_scratch (scratch >= len + 16). */
void lust_sort_small_general(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch) LUST_BODY({
    if (len < 2) return;
    uint64_t half = len / 2;
    uint64_t presorted;
    if (s->size <= 16 && len >= 16) {
        lust_sort_sort8_stable(s, v, scratch, LS_AT(scratch, len));
        lust_sort_sort8_stable(s, LS_AT(v, half), LS_AT(scratch, half), LS_AT(scratch, len + 8));
        presorted = 8;
    } else if (len >= 8) {
        lust_sort_sort4_stable(s, v, scratch);
        lust_sort_sort4_stable(s, LS_AT(v, half), LS_AT(scratch, half));
        presorted = 4;
    } else {
        lust_copy_small(scratch, v, s->size);
        lust_copy_small(LS_AT(scratch, half), LS_AT(v, half), s->size);
        presorted = 1;
    }
    for (int k = 0; k < 2; k++) {
        uint64_t offset = k == 0 ? 0 : half;
        uint8_t *src = LS_AT(v, offset), *dst = LS_AT(scratch, offset);
        uint64_t desired = k == 0 ? half : len - half;
        for (uint64_t i = presorted; i < desired; i++) {
            lust_copy_small(LS_AT(dst, i), LS_AT(src, i), s->size);
            lust_sort_insert_tail(s, dst, LS_AT(dst, i));
        }
    }
    lust_sort_bidir_merge(s, scratch, len, v);
})

/* smallsort.rs swap_if_less: a stable compare-exchange. */
void lust_sort_swap_if_less(lust_sort_cx *s, uint8_t *v, uint64_t a_pos, uint64_t b_pos) LUST_BODY({
    uint8_t *va = LS_AT(v, a_pos), *vb = LS_AT(v, b_pos);
    if (LS_LESS(vb, va)) lust_sort_swap(s, va, vb);
})

void lust_sort_net(lust_sort_cx *s, uint8_t *v, const uint8_t *pairs, int n) LUST_BODY({
    for (int i = 0; i < n; i++) lust_sort_swap_if_less(s, v, pairs[2 * i], pairs[2 * i + 1]);
})

/* smallsort.rs small_sort_network (len <= 32, Copy + Freeze, size <= 8). */
void lust_sort_small_network(lust_sort_cx *s, uint8_t *v, uint64_t len) LUST_BODY({
    if (len < 2) return;
    if (len > 32) abort();
    uint64_t half = len / 2;
    uint8_t no_merge = len < 18;
    uint8_t *region = v;
    uint64_t region_len = no_merge ? len : half;
    for (;;) {
        uint64_t presorted;
        static const uint8_t lust_sort_net9[] = {0, 3, 1, 7, 2, 5, 4, 8, 0, 7, 2, 4, 3, 8, 5, 6, 0, 2, 1, 3, 4, 5, 7, 8, 1, 4, 3, 6, 5, 7,
                                                 0, 1, 2, 4, 3, 5, 6, 8, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6};
        static const uint8_t lust_sort_net13[] = {0, 12, 1, 10, 2, 9, 3, 7, 5, 11, 6, 8, 1, 6, 2, 3, 4, 11, 7, 9, 8, 10, 0, 4, 1, 2, 3, 6,
                                                  7, 8, 9, 10, 11, 12, 4, 6, 5, 9, 8, 11, 10, 12, 0, 5, 3, 8, 4, 7, 6, 11, 9, 10, 0, 1, 2, 5,
                                                  6, 9, 7, 8, 10, 11, 1, 3, 2, 4, 5, 6, 9, 10, 1, 2, 3, 4, 5, 7, 6, 8, 2, 3, 4, 5, 6, 7, 8, 9,
                                                  3, 4, 5, 6};
        if (region_len >= 13) {
            lust_sort_net(s, region, lust_sort_net13, 45);
            presorted = 13;
        } else if (region_len >= 9) {
            lust_sort_net(s, region, lust_sort_net9, 25);
            presorted = 9;
        } else {
            presorted = 1;
        }
        lust_sort_insertion_shift_left(s, region, region_len, presorted);
        if (no_merge) return;
        if (region != v) break;
        region = LS_AT(v, half);
        region_len = len - half;
    }
    uint8_t stack_buf[32 * 8] __attribute__((aligned(16)));
    uint8_t *stack = s->align <= 16 ? stack_buf : (uint8_t *)lust_alloc(sizeof stack_buf, s->align);
    lust_sort_bidir_merge(s, v, len, stack);
    lust_copy_small(v, stack, len * s->size);
    if (stack != stack_buf) free(stack);
})

/* shared/pivot.rs */
uint8_t *lust_sort_median3(lust_sort_cx *s, uint8_t *a, uint8_t *b, uint8_t *c) LUST_BODY({
    uint8_t x = LS_LESS(a, b);
    uint8_t y = LS_LESS(a, c);
    if (x == y) {
        uint8_t z = LS_LESS(b, c);
        return (z ^ x) ? c : b;
    }
    return a;
})
uint8_t *lust_sort_median3_rec(lust_sort_cx *s, uint8_t *a, uint8_t *b, uint8_t *c, uint64_t n) LUST_BODY({
    if (n * 8 >= 64) {
        uint64_t n8 = n / 8;
        a = lust_sort_median3_rec(s, a, LS_AT(a, n8 * 4), LS_AT(a, n8 * 7), n8);
        b = lust_sort_median3_rec(s, b, LS_AT(b, n8 * 4), LS_AT(b, n8 * 7), n8);
        c = lust_sort_median3_rec(s, c, LS_AT(c, n8 * 4), LS_AT(c, n8 * 7), n8);
    }
    return lust_sort_median3(s, a, b, c);
})
uint64_t lust_sort_choose_pivot(lust_sort_cx *s, uint8_t *v, uint64_t len) LUST_BODY({
    if (len < 8) abort();
    uint64_t d8 = len / 8;
    uint8_t *a = v, *b = LS_AT(v, d8 * 4), *c = LS_AT(v, d8 * 7);
    uint8_t *m = len < 64 ? lust_sort_median3(s, a, b, c) : lust_sort_median3_rec(s, a, b, c, d8);
    return (uint64_t)(m - v) / s->size;
})

/* ---------- stable: driftsort ---------- */

uint64_t lust_sort_stable_threshold(lust_sort_cx *s) LUST_BODY({ return s->freeze ? 32 : 16; })

void lust_sort_stable_small(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch) LUST_BODY({
    if (s->freeze) {
        lust_sort_small_general(s, v, len, scratch);
    } else if (len >= 2) {
        lust_sort_insertion_shift_left(s, v, len, 1);
    }
})

/* stable/merge.rs merge: v[..mid] and v[mid..] are sorted. */
void lust_sort_merge(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len, uint64_t mid) LUST_BODY({
    uint64_t sz = s->size;
    if (mid == 0 || mid >= len || scratch_len < (mid < len - mid ? mid : len - mid)) return;
    uint8_t *buf = scratch, *v_mid = LS_AT(v, mid), *v_end = LS_AT(v, len);
    uint64_t left_len = mid, right_len = len - mid;
    uint8_t left_shorter = left_len <= right_len;
    uint8_t *save_base = left_shorter ? v : v_mid;
    uint64_t save_len = left_shorter ? left_len : right_len;
    lust_copy_small(buf, save_base, save_len * sz);
    uint8_t *start = buf, *end = buf + save_len * sz, *dst = save_base;
    if (left_shorter) {
        uint8_t *right = v_mid;
        while (start != end && right != v_end) {
            uint8_t consume_left = !LS_LESS(right, start);
            lust_copy_small(dst, consume_left ? start : right, sz);
            start += consume_left ? sz : 0;
            right += consume_left ? 0 : sz;
            dst += sz;
        }
    } else {
        uint8_t *out = v_end;
        for (;;) {
            uint8_t *left = dst - sz, *right = end - sz;
            out -= sz;
            uint8_t consume_left = LS_LESS(right, left);
            lust_copy_small(out, consume_left ? left : right, sz);
            dst = consume_left ? left : left + sz;
            end = consume_left ? right + sz : right;
            if (dst == v || end == buf) break;
        }
    }
    lust_copy_small(dst, start, (uint64_t)(end - start));
})

void lust_sort_drift(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len, uint8_t eager_sort);

/* stable/quicksort.rs stable_partition; `inv` sorts with
   `|a, b| !is_less(b, a)` (the equal-partition comparator). */
uint64_t lust_sort_stable_partition(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len,
                                           uint64_t pivot_pos, uint8_t pivot_goes_left, uint8_t inv) LUST_BODY({
    uint64_t sz = s->size;
    if (scratch_len < len || pivot_pos >= len) abort();
    uint8_t *pivot = LS_AT(v, pivot_pos);
    uint8_t *scan = v, *scratch_rev = LS_AT(scratch, len), *pivot_in_scratch = 0;
    uint64_t num_left = 0, loop_end_pos = pivot_pos;
    for (;;) {
        uint8_t *loop_end = LS_AT(v, loop_end_pos);
        while (scan < loop_end) {
            uint8_t towards_left = inv ? !LS_LESS(pivot, scan) : LS_LESS(scan, pivot);
            scratch_rev -= sz;
            uint8_t *dst = (towards_left ? scratch : scratch_rev) + num_left * sz;
            lust_copy_small(dst, scan, sz);
            num_left += towards_left;
            scan += sz;
        }
        if (loop_end_pos == len) break;
        scratch_rev -= sz;
        pivot_in_scratch = (pivot_goes_left ? scratch : scratch_rev) + num_left * sz;
        lust_copy_small(pivot_in_scratch, scan, sz);
        num_left += pivot_goes_left;
        scan += sz;
        loop_end_pos = len;
    }
    if (!s->freeze) lust_copy_small(pivot_in_scratch, pivot, sz);
    lust_copy_small(v, scratch, num_left * sz);
    for (uint64_t i = 0; i < len - num_left; i++) lust_copy_small(LS_AT(v, num_left + i), LS_AT(scratch, len - 1 - i), sz);
    return num_left;
})

/* stable/quicksort.rs quicksort */
void lust_sort_stable_quick(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len, uint32_t limit,
                                   uint8_t *left_ancestor_pivot) LUST_BODY({
    for (;;) {
        if (len <= lust_sort_stable_threshold(s)) {
            lust_sort_stable_small(s, v, len, scratch);
            return;
        }
        if (limit == 0) {
            lust_sort_drift(s, v, len, scratch, scratch_len, 1);
            return;
        }
        limit--;
        uint64_t pivot_pos = lust_sort_choose_pivot(s, v, len);
        lust_sort_tmp t;
        uint8_t *pivot_copy = lust_sort_tmp_get(s, &t);
        lust_copy_small(pivot_copy, LS_AT(v, pivot_pos), s->size);
        uint8_t *pivot_ref = s->freeze ? pivot_copy : 0;
        uint8_t perform_equal = 0;
        if (left_ancestor_pivot) perform_equal = !LS_LESS(left_ancestor_pivot, LS_AT(v, pivot_pos));
        uint64_t left_len = 0;
        if (!perform_equal) {
            left_len = lust_sort_stable_partition(s, v, len, scratch, scratch_len, pivot_pos, 0, 0);
            perform_equal = left_len == 0;
        }
        if (perform_equal) {
            uint64_t mid_eq = lust_sort_stable_partition(s, v, len, scratch, scratch_len, pivot_pos, 1, 1);
            v = LS_AT(v, mid_eq);
            len -= mid_eq;
            left_ancestor_pivot = 0;
            lust_sort_tmp_free(&t);
            continue;
        }
        lust_sort_stable_quick(s, LS_AT(v, left_len), len - left_len, scratch, scratch_len, limit, pivot_ref);
        lust_sort_tmp_free(&t);
        len = left_len;
    }
})

void lust_sort_stable_quicksort(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len) LUST_BODY({
    uint32_t limit = 2 * lust_sort_ilog2(len | 1);
    lust_sort_stable_quick(s, v, len, scratch, scratch_len, limit, 0);
})

/* stable/drift.rs; a run is (len << 1) | sorted. */
void lust_sort_drift(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len, uint8_t eager_sort) LUST_BODY({
    if (len < 2) return;
    uint64_t scale = ((1ull << 62) + len - 1) / len;
    uint64_t min_good;
    if (len <= 64 * 64) {
        min_good = len - len / 2 < 64 ? len - len / 2 : 64;
    } else {
        uint32_t ilog = lust_sort_ilog2(len | 1);
        uint32_t shift = (ilog + 1) / 2;
        min_good = ((1ull << shift) + (len >> shift)) / 2;
    }
    uint64_t runs[66];
    uint8_t depths[66];
    uint64_t stack_len = 0, scan_idx = 0;
    uint64_t prev_run = 1; /* new_sorted(0) */
    for (;;) {
        uint64_t next_run;
        uint8_t desired;
        if (scan_idx < len) {
            /* create_run */
            uint8_t *rv = LS_AT(v, scan_idx);
            uint64_t rlen = len - scan_idx;
            next_run = 0;
            uint8_t made = 0;
            if (rlen >= min_good) {
                uint8_t rev;
                uint64_t run_len = lust_sort_find_run(s, rv, rlen, &rev);
                if (run_len >= min_good) {
                    if (rev) lust_sort_reverse(s, rv, run_len);
                    next_run = (run_len << 1) | 1;
                    made = 1;
                }
            }
            if (!made) {
                if (eager_sort) {
                    uint64_t thr = lust_sort_stable_threshold(s);
                    uint64_t eager_len = thr < rlen ? thr : rlen;
                    lust_sort_stable_quick(s, rv, eager_len, scratch, scratch_len, 0, 0);
                    next_run = (eager_len << 1) | 1;
                } else {
                    next_run = (min_good < rlen ? min_good : rlen) << 1;
                }
            }
            uint64_t left = scan_idx - (prev_run >> 1), mid = scan_idx, right = scan_idx + (next_run >> 1);
            uint64_t x = left + mid, y = mid + right;
            uint64_t z = (scale * x) ^ (scale * y);
            desired = z == 0 ? 64 : (uint8_t)__builtin_clzll(z);
        } else {
            next_run = 1;
            desired = 0;
        }
        while (stack_len > 1 && depths[stack_len - 1] >= desired) {
            uint64_t left = runs[stack_len - 1];
            uint64_t merged_len = (left >> 1) + (prev_run >> 1);
            uint8_t *mv = LS_AT(v, scan_idx - merged_len);
            /* logical_merge */
            if (merged_len > scratch_len || (left & 1) || (prev_run & 1)) {
                if (!(left & 1)) lust_sort_stable_quicksort(s, mv, left >> 1, scratch, scratch_len);
                if (!(prev_run & 1)) lust_sort_stable_quicksort(s, LS_AT(mv, left >> 1), prev_run >> 1, scratch, scratch_len);
                lust_sort_merge(s, mv, merged_len, scratch, scratch_len, left >> 1);
                prev_run = (merged_len << 1) | 1;
            } else {
                prev_run = merged_len << 1;
            }
            stack_len--;
        }
        runs[stack_len] = prev_run;
        depths[stack_len] = desired;
        stack_len++;
        if (scan_idx >= len) break;
        scan_idx += next_run >> 1;
        prev_run = next_run;
    }
    if (!(prev_run & 1)) lust_sort_stable_quicksort(s, v, len, scratch, scratch_len);
})

/* stable/mod.rs sort and driftsort_main */
void lust_sort_stable(void *v, uint64_t len, uint64_t size, uint64_t align, uint8_t freeze, void *ctx, lust_less_fn less) LUST_BODY({
    if (size == 0 || len < 2) return;
    lust_sort_cx cx = {size, align, freeze, 0, ctx, less};
    lust_sort_cx *s = &cx;
    if (len <= 20) {
        lust_sort_insertion_shift_left(s, (uint8_t *)v, len, 1);
        return;
    }
    uint64_t max_full = 8000000 / size;
    uint64_t a = len - len / 2, b = len < max_full ? len : max_full;
    uint64_t alloc_len = a > b ? a : b;
    if (alloc_len < 48) alloc_len = 48;
    uint64_t stack_len = 4096 / size;
    uint64_t scratch_len = stack_len >= alloc_len ? stack_len : alloc_len;
    uint8_t *scratch = align <= 16 ? (uint8_t *)malloc(scratch_len * size) : (uint8_t *)lust_alloc(scratch_len * size, align);
    if (!scratch) abort();
    uint8_t eager = len <= lust_sort_stable_threshold(s) * 2;
    lust_sort_drift(s, (uint8_t *)v, len, scratch, scratch_len, eager);
    free(scratch);
})

/* ---------- unstable: ipnsort ---------- */

uint8_t lust_sort_network_ok(lust_sort_cx *s) LUST_BODY({ return s->copy && s->size <= 8 && s->size * 32 <= 4096; })

uint64_t lust_sort_unstable_threshold(lust_sort_cx *s) LUST_BODY({
    if (!s->freeze) return 16;
    if (lust_sort_network_ok(s)) return 32;
    return s->size * 48 <= 4096 ? 32 : 16;
})

void lust_sort_unstable_small(lust_sort_cx *s, uint8_t *v, uint64_t len) LUST_BODY({
    if (s->freeze && lust_sort_network_ok(s)) {
        lust_sort_small_network(s, v, len);
    } else if (s->freeze && s->size * 48 <= 4096) {
        uint8_t scratch_buf[4096] __attribute__((aligned(16)));
        uint8_t *scratch = s->align <= 16 ? scratch_buf : (uint8_t *)lust_alloc(sizeof scratch_buf, s->align);
        lust_sort_small_general(s, v, len, scratch);
        if (scratch != scratch_buf) free(scratch);
    } else if (len >= 2) {
        lust_sort_insertion_shift_left(s, v, len, 1);
    }
})

/* unstable/heapsort.rs */
void lust_sort_sift_down(lust_sort_cx *s, uint8_t *v, uint64_t len, uint64_t node) LUST_BODY({
    for (;;) {
        uint64_t child = 2 * node + 1;
        if (child >= len) break;
        if (child + 1 < len) child += LS_LESS(LS_AT(v, child), LS_AT(v, child + 1));
        if (!LS_LESS(LS_AT(v, node), LS_AT(v, child))) break;
        lust_sort_swap(s, LS_AT(v, node), LS_AT(v, child));
        node = child;
    }
})
void lust_sort_heapsort(lust_sort_cx *s, uint8_t *v, uint64_t len) LUST_BODY({
    for (uint64_t i = len + len / 2; i-- > 0;) {
        uint64_t sift_idx;
        if (i >= len) {
            sift_idx = i - len;
        } else {
            lust_sort_swap(s, v, LS_AT(v, i));
            sift_idx = 0;
        }
        lust_sort_sift_down(s, v, i < len ? i : len, sift_idx);
    }
})

/* unstable/quicksort.rs partitions; `inv` is `|a, b| !is_less(b, a)`. */
uint8_t lust_sort_cmp(lust_sort_cx *s, uint8_t *a, uint8_t *b, uint8_t inv) LUST_BODY({ return inv ? !LS_LESS(b, a) : LS_LESS(a, b); })

uint64_t lust_sort_lomuto(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *pivot, uint8_t inv) LUST_BODY({
    uint64_t sz = s->size;
    if (len == 0) return 0;
    lust_sort_tmp t;
    uint8_t *gap_value = lust_sort_tmp_get(s, &t);
    lust_copy_small(gap_value, v, sz);
    uint64_t num_lt = 0;
    uint8_t *right = LS_AT(v, 1), *gap_pos = v, *end = LS_AT(v, len);
    for (;;) {
        uint8_t is_done = right == end;
        if (is_done) right = gap_value;
        uint8_t right_is_lt = lust_sort_cmp(s, right, pivot, inv);
        uint8_t *left = LS_AT(v, num_lt);
        lust_copy_small(gap_pos, left, sz);
        lust_copy_small(left, right, sz);
        gap_pos = right;
        num_lt += right_is_lt;
        right += sz;
        if (is_done) break;
    }
    lust_sort_tmp_free(&t);
    return num_lt;
})

uint64_t lust_sort_hoare(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *pivot, uint8_t inv) LUST_BODY({
    uint64_t sz = s->size;
    if (len == 0) return 0;
    lust_sort_tmp t;
    uint8_t *gap_value = lust_sort_tmp_get(s, &t);
    uint8_t *gap_pos = 0;
    uint8_t *left = v, *right = LS_AT(v, len);
    for (;;) {
        while (left < right && lust_sort_cmp(s, left, pivot, inv)) left += sz;
        for (;;) {
            right -= sz;
            if (left >= right || lust_sort_cmp(s, right, pivot, inv)) break;
        }
        if (left >= right) break;
        if (!gap_pos) {
            lust_copy_small(gap_value, left, sz);
        } else {
            lust_copy_small(gap_pos, left, sz);
        }
        gap_pos = right;
        lust_copy_small(left, right, sz);
        left += sz;
    }
    if (gap_pos) lust_copy_small(gap_pos, gap_value, sz);
    lust_sort_tmp_free(&t);
    return (uint64_t)(left - v) / sz;
})

uint64_t lust_sort_partition(lust_sort_cx *s, uint8_t *v, uint64_t len, uint64_t pivot, uint8_t inv) LUST_BODY({
    if (len == 0) return 0;
    if (pivot >= len) abort();
    lust_sort_swap(s, v, LS_AT(v, pivot));
    uint64_t num_lt = s->size <= 96 ? lust_sort_lomuto(s, LS_AT(v, 1), len - 1, v, inv) : lust_sort_hoare(s, LS_AT(v, 1), len - 1, v, inv);
    if (num_lt >= len) abort();
    lust_sort_swap(s, v, LS_AT(v, num_lt));
    return num_lt;
})

void lust_sort_unstable_quick(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *ancestor_pivot, uint32_t limit) LUST_BODY({
    for (;;) {
        if (len <= lust_sort_unstable_threshold(s)) {
            lust_sort_unstable_small(s, v, len);
            return;
        }
        if (limit == 0) {
            lust_sort_heapsort(s, v, len);
            return;
        }
        limit--;
        uint64_t pivot_pos = lust_sort_choose_pivot(s, v, len);
        if (ancestor_pivot && !LS_LESS(ancestor_pivot, LS_AT(v, pivot_pos))) {
            uint64_t num_lt = lust_sort_partition(s, v, len, pivot_pos, 1);
            v = LS_AT(v, num_lt + 1);
            len -= num_lt + 1;
            ancestor_pivot = 0;
            continue;
        }
        uint64_t num_lt = lust_sort_partition(s, v, len, pivot_pos, 0);
        lust_sort_unstable_quick(s, v, num_lt, ancestor_pivot, limit);
        ancestor_pivot = LS_AT(v, num_lt);
        v = LS_AT(v, num_lt + 1);
        len -= num_lt + 1;
    }
})

/* unstable/mod.rs sort and ipnsort */
void lust_sort_unstable(void *v, uint64_t len, uint64_t size, uint64_t align, uint8_t freeze, uint8_t copy, void *ctx, lust_less_fn less) LUST_BODY({
    if (size == 0 || len < 2) return;
    lust_sort_cx cx = {size, align, freeze, copy, ctx, less};
    lust_sort_cx *s = &cx;
    uint8_t *b = (uint8_t *)v;
    if (len <= 20) {
        lust_sort_insertion_shift_left(s, b, len, 1);
        return;
    }
    uint8_t rev;
    uint64_t run_len = lust_sort_find_run(s, b, len, &rev);
    if (run_len == len) {
        if (rev) lust_sort_reverse(s, b, len);
        return;
    }
    lust_sort_unstable_quick(s, b, len, 0, 2 * lust_sort_ilog2(len | 1));
})

#undef LS_AT
#undef LS_LESS

/* slice::binary_search_by (Rust 1.99's loop): the Ok index, or
   -(index + 1) for Err(index). `cmp(ctx, p)` answers `p.cmp(target)`
   as negative, zero, or positive (Less, Equal, Greater). */
typedef int32_t (*lust_cmp_fn)(void *ctx, const void *p);
int64_t lust_binary_search(void *v, uint64_t len, uint64_t size, void *ctx, lust_cmp_fn cmp) LUST_BODY({
    if (len == 0) return -1;
    uint64_t base = 0, n = len;
    while (n > 1) {
        uint64_t half = n / 2;
        uint64_t mid = base + half;
        int32_t c = cmp(ctx, (uint8_t *)v + mid * size);
        base = c > 0 ? base : mid;
        n -= half;
    }
    int32_t c = cmp(ctx, (uint8_t *)v + base * size);
    if (c == 0) return (int64_t)base;
    return -(int64_t)(base + (c < 0)) - 1;
})


/* Erased hash table core (src/runtime/hash.h): declarations in every
   unit, bodies only in the runtime unit (LUST_IMPL). */
/* Erased hash table core for the lust runtime: byte-exact with the
   hashbrown 0.17.1 table inside Rust 1.99 std (the table under std
   HashMap/HashSet, rustc-hash FxHashMap/FxHashSet, hashbrown HashTable,
   and the index table of indexmap 2.14.0, which pins hashbrown 0.17.1
   in ts-rust's Cargo.lock).

   Exactness scope: probe sequence, control bytes, growth, reserve,
   shrink, erase (tombstone vs empty), rehash in place, and iteration
   order all match hashbrown 0.17.1 for the same hash values, element
   size, and operation sequence. Iteration order is increasing bucket
   index. Capacity (items + growth_left) matches, so HashMap::capacity
   matches. Element memory layout inside the allocation does NOT match
   hashbrown (buckets are stored forward, not reversed); that layout is
   not observable through the std or indexmap APIs.

   Group width is part of the probe sequence (the probe stride grows by
   Group::WIDTH), so it is a compile-time target pin, not a free choice:
     LUST_HASH_GROUP_WIDTH 16  x86_64 with SSE2 (the default here)
     LUST_HASH_GROUP_WIDTH 8   aarch64 with NEON (uint8x8_t group) and
                               the generic 64-bit word group
   One binary matches one target. A width-16 table and a width-8 table
   give different iteration orders for the same inserts, exactly as
   hashbrown does across those targets. The group scan itself is SWAR
   over 8-byte chunks in this core; only the width (an observable) is
   pinned, not the instruction choice (not observable).

   The caller hashes. Every lookup or insert takes the full 64-bit hash
   of the probe key as a value. Operations that may rehash (reserve,
   shrink, insert fallbacks) also take a hash_of callback that returns
   the hash of a stored element, like hashbrown's `hasher` argument.
   Equality is a callback over a stored element with a caller context
   that holds the probe key. So FxHasher, SipHash, or any other BuildHasher
   works with no change here. FxHasher (rustc-hash 2.1.2) is provided
   below for convenience; a typed layer may also implement it in source.

   Rust operation -> this API (std HashMap layer):
     HashMap::new                 lust_hash_init (empty singleton)
     HashMap::with_capacity(n)    lust_hash_init_with_capacity
     map.get / get_mut / contains lust_hash_find
     map.insert                   lust_hash_find_or_insert, then replace
                                  the value in the slot, or
                                  lust_hash_insert_at + write the slot
     VacantEntry::insert          three flavors differ, keep them apart:
                                  std HashMap: entry() itself reserves 1
                                  when vacant (hashbrown rustc_entry),
                                  then lust_hash_insert_no_grow_slot;
                                  hashbrown crate HashMap: entry() only
                                  finds, insert re-probes through
                                  lust_hash_insert_unique_slot;
                                  hashbrown HashTable: entry reserves in
                                  the search, insert is lust_hash_insert_at
                                  at the found index (indexmap side table)
     map.remove / remove_entry    lust_hash_remove
     map.reserve(n)               lust_hash_reserve
     map.shrink_to_fit / shrink_to lust_hash_shrink_to (0 for to_fit)
     map.clear                    lust_hash_clear
     map.retain                   lust_hash_retain
     map.drain                    lust_hash_drain_* (yields in iteration
                                  order; finish drops the rest, then the
                                  table is empty with capacity kept)
     map.clone                    lust_hash_clone_into (same bucket count,
                                  same indices, elements cloned in order)
     iter / keys / values         lust_hash_iter_*
   HashSet uses the same core with element = the set element. std HashSet
   stores (T, ()) pairs in Rust, which has the same size and align as T
   when the unit adds no padding; the typed layer owns that choice. If it
   wants exact capacity for sets it must pass the pair size, because
   capacity_to_buckets depends on element size for tiny tables.

   Slot pointers are invalidated by any later mutating call on the same
   table, like Rust references into a map. Callbacks must not mutate the
   table. On allocation failure or capacity overflow the core prints the
   Rust message and aborts, like the rest of this runtime; there is no
   try_reserve error path yet (typed layer gap, see tests/hash/README).

   Wiring: core.c ends with `#include "hash.h"`, and
   cgen::runtime_source splices this header (and hash.c in the runtime
   unit) into the amalgamation the same way as float.h. Later std work
   calls it from source wrappers. Tests include this file directly.
   Correctness is gated by tests/hash/ against rustc 1.99 oracles. */
#ifndef LUST_RT_HASH_H
#define LUST_RT_HASH_H


#ifndef LUST_HASH_GROUP_WIDTH
#if defined(__x86_64__) || defined(__i386__)
#define LUST_HASH_GROUP_WIDTH 16
#else
#define LUST_HASH_GROUP_WIDTH 8
#endif
#endif

/* Control byte values, as in hashbrown's Tag. Full tags are 0..127. */
#define LUST_HASH_EMPTY 0xFFu
#define LUST_HASH_DELETED 0x80u

/* The full tag for a hash: its top 7 bits (64-bit hashes). */
static inline uint8_t lust_hash_tag(uint64_t hash) { return (uint8_t)((hash >> 57) & 0x7Fu); }

/* Hash of a stored element. `elem` points at the element bytes. */
typedef uint64_t (*lust_hash_of_fn)(void *ctx, const void *elem);
/* True when the stored element `elem` matches the probe key in `ctx`. */
typedef int (*lust_hash_eq_fn)(void *ctx, const void *elem);
/* Drops one stored element in place. May be NULL when elements are plain. */
typedef void (*lust_hash_drop_fn)(void *ctx, void *elem);
/* Retain predicate: true keeps the element. May mutate the element. */
typedef int (*lust_hash_keep_fn)(void *ctx, void *elem);
/* Clone `src` element into the uninitialized `dst` slot. */
typedef void (*lust_hash_clone_fn)(void *ctx, void *dst, const void *src);

/* One erased hash table. Zero the struct, then call an init function.
   `ctrl` holds buckets + GROUP_WIDTH control bytes (the tail mirrors the
   head, as in hashbrown). An unallocated table is the empty singleton:
   bucket_mask 0 with `ctrl` pointing at static empty tags. */
typedef struct {
    /* The four fields a lookup reads come first, in 32 bytes: a map inside a struct then
       touches one cache line for its header more often (hashbrown's header is 32 bytes). */
    uint8_t *ctrl;
    uint64_t bucket_mask;
    uint8_t *data;       /* bucket i at data + i * elem_size; NULL if singleton or ZST */
    uint64_t elem_size;
    uint64_t items;
    uint64_t growth_left;
    void *alloc_base;    /* raw malloc pointer, NULL if singleton */
    uint64_t elem_align;
} lust_hash_table;

/* The empty singleton's control bytes (Group::static_empty). A unit's header gets these
   declarations after inl.h, whose macros carry the names of the five functions that are in
   parentheses below: the parentheses keep those macros out of the declarations. */
extern const uint8_t lust_hash_static_empty[16];

/* Creates the empty table (no allocation), for elements of this size and
   align. Rust layout rules apply: size is a multiple of align, align is a
   power of two. Size 0 (ZST elements) is supported. */
void (lust_hash_init)(lust_hash_table *t, uint64_t elem_size, uint64_t elem_align);
/* Creates a table that holds `capacity` elements without growing.
   Capacity 0 gives the empty table. Bucket count follows hashbrown
   capacity_to_buckets, including its small-table minimums. */
void lust_hash_init_with_capacity(lust_hash_table *t, uint64_t elem_size, uint64_t elem_align, uint64_t capacity);
/* Frees the allocation. With a drop function, drops each element first in
   iteration order (Rust drop order for maps in practice: bucket order).
   Without one (drop == NULL), elements are not dropped. Either way the
   table becomes the empty singleton and may be reused. */
void (lust_hash_drop_table)(lust_hash_table *t, lust_hash_drop_fn drop, void *ctx);

uint64_t (lust_hash_len)(const lust_hash_table *t);
uint64_t (lust_hash_capacity)(const lust_hash_table *t); /* items + growth_left */
uint64_t lust_hash_buckets(const lust_hash_table *t);  /* 1 for the singleton */
int (lust_hash_is_empty)(const lust_hash_table *t);

/* The slot for bucket `index`, or NULL when it is not full. */
void *lust_hash_bucket(const lust_hash_table *t, uint64_t index);
/* The control byte for bucket `index` (tests and debug). */
uint8_t lust_hash_ctrl(const lust_hash_table *t, uint64_t index);

/* Finds the element with this hash that `eq` accepts. Returns its slot, or
   NULL. `out_index` (may be NULL) receives the bucket index on a hit. */
void *lust_hash_find(const lust_hash_table *t, uint64_t hash, lust_hash_eq_fn eq, void *eq_ctx, uint64_t *out_index);

/* HashMap::insert and entry search: reserves room for one more element
   first (exactly like hashbrown, even when the key turns out to exist),
   then searches. Returns 1 and the slot of the existing element, or 0 and
   in `out_index` the bucket index to insert at with lust_hash_insert_at. */
int lust_hash_find_or_insert(lust_hash_table *t, uint64_t hash, lust_hash_eq_fn eq, void *eq_ctx,
                             lust_hash_of_fn hash_of, void *hash_ctx, void **out_slot, uint64_t *out_index);
/* Records a new element at a bucket index from lust_hash_find_or_insert
   (or from a hashbrown HashTable vacant entry) and returns the slot to
   write the element bytes into. The slot is recorded before the write,
   as in hashbrown; write it before any other call on this table. */
void *lust_hash_insert_at(lust_hash_table *t, uint64_t hash, uint64_t index);
/* RawTable::insert for a key the caller knows is absent: probes for a
   free bucket, grows only if that bucket is EMPTY and no growth is left
   (a DELETED bucket is reused without growing), records the element,
   and returns the slot to write into. `out_index` may be NULL. */
void *lust_hash_insert_unique_slot(lust_hash_table *t, uint64_t hash, lust_hash_of_fn hash_of, void *hash_ctx,
                                   uint64_t *out_index);
/* RawTable::insert_no_grow for a key the caller knows is absent, after
   the caller reserved room (the std entry path: std entry() finds, then
   reserves 1 while still vacant, and only this insert runs after). The
   table must have a free bucket after that reserve. Returns the slot to
   write into. `out_index` may be NULL. */
void *lust_hash_insert_no_grow_slot(lust_hash_table *t, uint64_t hash, uint64_t *out_index);

/* Removes the matching element. Returns 1 on a hit; when `out_elem` is
   not NULL the element bytes are copied there first (ownership moves to
   the caller). The bucket becomes EMPTY or DELETED by hashbrown's erase
   rule (a full group of neighbours with no empty bucket in it). */
int lust_hash_remove(lust_hash_table *t, uint64_t hash, lust_hash_eq_fn eq, void *eq_ctx, void *out_elem);
/* Erases bucket `index`, which must be full. `out_elem` as above; pass
   NULL and drop the element yourself before or after as needed. */
void lust_hash_erase_at(lust_hash_table *t, uint64_t index, void *out_elem);
/* The bucket index of a full bucket's slot (an OccupiedEntry's). With a
   zero-sized element every slot has one address and the map holds at most
   one element: its bucket. */
uint64_t lust_hash_index_of(const lust_hash_table *t, const void *slot);

/* Ensures room for `additional` more elements. May rehash in place (same
   bucket count, tombstones cleared) when the new length fits in half the
   current capacity, else resizes, exactly as hashbrown reserve does. */
void lust_hash_reserve(lust_hash_table *t, uint64_t additional, lust_hash_of_fn hash_of, void *hash_ctx);
/* Shrinks toward `min_capacity` (0 is shrink_to_fit; the result still
   holds all elements). An emptied table is freed back to the singleton
   only when the clamped minimum is 0, as in hashbrown shrink_to. */
void lust_hash_shrink_to(lust_hash_table *t, uint64_t min_capacity, lust_hash_of_fn hash_of, void *hash_ctx);
/* Removes all elements (dropped in iteration order when drop != NULL).
   The allocation and capacity are kept. */
void lust_hash_clear(lust_hash_table *t, lust_hash_drop_fn drop, void *ctx);
/* Keeps the elements `keep` accepts, drops the rest, in iteration order.
   The predicate runs once per element in bucket order, as in Rust. */
void lust_hash_retain(lust_hash_table *t, lust_hash_keep_fn keep, void *keep_ctx, lust_hash_drop_fn drop,
                      void *drop_ctx);
/* Clones into `dst`, which must be an empty singleton for the same element
   layout (call lust_hash_init first). The clone gets the same bucket
   count and bucket indices; elements are cloned in iteration order. */
void lust_hash_clone_into(lust_hash_table *dst, const lust_hash_table *src, lust_hash_clone_fn clone_elem, void *ctx);

/* Iteration in bucket order. `left` counts down from len. Do not mutate
   the table while iterating, except through lust_hash_retain/drain. */
typedef struct {
    const lust_hash_table *t;
    uint64_t next_index;   /* next group base to load */
    uint64_t group_base;   /* base index of the loaded group */
    uint32_t group_bits;   /* full buckets left in the loaded group */
    uint64_t left;
} lust_hash_iter;
void lust_hash_iter_init(lust_hash_iter *it, const lust_hash_table *t);
/* Returns the next slot, or NULL at the end. `out_index` may be NULL. */
void *lust_hash_iter_next(lust_hash_iter *it, uint64_t *out_index);

/* Drain: yields slots in iteration order. The caller moves each element
   out of its slot before the next call. lust_hash_drain_finish drops the
   elements not yet yielded (when drop != NULL) and leaves the table
   empty with its capacity kept, matching a dropped Rust Drain. */
typedef struct {
    lust_hash_table *t;
    uint64_t next_index;
    uint64_t group_base;
    uint32_t group_bits;
    uint64_t left;
} lust_hash_drain;
void lust_hash_drain_init(lust_hash_drain *d, lust_hash_table *t);
void *lust_hash_drain_next(lust_hash_drain *d, uint64_t *out_index);
void lust_hash_drain_finish(lust_hash_drain *d, lust_hash_drop_fn drop, void *ctx);

/* ---------------- FxHasher (rustc-hash 2.1.2, 64-bit) ----------------
   State is one usize. Each write_* is the Hasher method of the same name
   as rustc-hash implements it on 64-bit targets (non-nightly build, the
   one ts-rust uses): write_u8/16/32/64/usize add once, write_u128 adds
   the low then the high 64 bits, write(bytes) goes through hash_bytes,
   and finish rotates left by 26. Signed and length/string helpers use
   the Rust core defaults: write_iN is write_uN of the same bits,
   write_length_prefix is write_usize, write_str is write(bytes) then
   write_u8(0xff). Hash byte streams above this layer (which write_*
   calls a type makes) belong to the typed layer and must match core:
   str writes the 0xff suffix, slices write a length prefix, a derived
   enum writes its discriminant as isize, and so on.
   On 32-bit targets rustc-hash differs (K, rotation 15, extra adds for
   u64/u128, the 32-bit multiply_mix); this core is 64-bit only, like
   both tier 1 targets. */
typedef struct {
    uint64_t hash;
} lust_fx_hasher;

lust_fx_hasher lust_fx_new(void);               /* seed 0 */
lust_fx_hasher lust_fx_with_seed(uint64_t seed);
void lust_fx_write(lust_fx_hasher *h, const void *bytes, uint64_t len);
void lust_fx_write_u8(lust_fx_hasher *h, uint8_t v);
void lust_fx_write_u16(lust_fx_hasher *h, uint16_t v);
void lust_fx_write_u32(lust_fx_hasher *h, uint32_t v);
void lust_fx_write_u64(lust_fx_hasher *h, uint64_t v);
void lust_fx_write_u128(lust_fx_hasher *h, uint64_t lo, uint64_t hi);
void lust_fx_write_usize(lust_fx_hasher *h, uint64_t v);
void lust_fx_write_i8(lust_fx_hasher *h, int8_t v);
void lust_fx_write_i16(lust_fx_hasher *h, int16_t v);
void lust_fx_write_i32(lust_fx_hasher *h, int32_t v);
void lust_fx_write_i64(lust_fx_hasher *h, int64_t v);
void lust_fx_write_i128(lust_fx_hasher *h, uint64_t lo, uint64_t hi);
void lust_fx_write_isize(lust_fx_hasher *h, int64_t v);
void lust_fx_write_length_prefix(lust_fx_hasher *h, uint64_t len);
void lust_fx_write_str(lust_fx_hasher *h, const void *bytes, uint64_t len);
uint64_t lust_fx_finish(const lust_fx_hasher *h);
/* The wyhash-inspired byte hash inside write(): exposed for tests and
   for callers that hash one byte string with no other writes (finish
   still applies: hash_one(bytes) is not lust_fx_hash_bytes alone). */
uint64_t lust_fx_hash_bytes(const void *bytes, uint64_t len);
/* One-shot helpers: a fresh hasher, one write, finish. These match
   FxBuildHasher::hash_one for the Rust types of the same name. */
uint64_t lust_fx_hash_u32(uint32_t v);
uint64_t lust_fx_hash_u64(uint64_t v);
uint64_t lust_fx_hash_usize(uint64_t v);
uint64_t lust_fx_hash_str(const void *bytes, uint64_t len);

/* ---------------- SipHash-1-3 (std DefaultHasher) ----------------
   core::hash::sip::Hasher<Sip13Rounds> as Rust 1.99 has it, behind
   std::hash::DefaultHasher: a byte-stream hash, so every write_* is a
   write of the value's little-endian bytes, and write_str adds 0xff.
   DefaultHasher::new() is keys (0, 0); RandomState draws keys (lust:
   a fixed start, k0 bumped per RandomState, as std bumps its per-thread
   keys; map order under RandomState is not an observable). The field
   order and size match Rust's (72 bytes). */
typedef struct {
    uint64_t k0;
    uint64_t k1;
    uint64_t length;
    uint64_t v0;
    uint64_t v2;
    uint64_t v1;
    uint64_t v3;
    uint64_t tail;
    uint64_t ntail;
} lust_sip13;
typedef struct {
    uint64_t k0;
    uint64_t k1;
} lust_random_state;

lust_sip13 lust_sip13_new_with_keys(uint64_t k0, uint64_t k1);
void lust_sip13_write(lust_sip13 *h, const void *bytes, uint64_t len);
uint64_t lust_sip13_finish(const lust_sip13 *h);
/* RandomState::new(): the next keys (std: per-thread, k0 + 1 each). */
lust_random_state lust_random_state_new(void);

/* ---------------- IndexMap core (indexmap 2.14.0) ----------------
   Entries are kept in insertion order in one erased Vec; a side
   lust_hash_table maps key hash to entry index (hashbrown HashTable of
   usize there, this core here), so the probing, growth, and tombstone
   behavior of the side table also matches. Each entry slot holds, in
   order: u64 hash, the key bytes, then the value bytes, each aligned as
   the caller says. The caller supplies sizes and aligns for key and
   value at init and hashes keys itself (IndexMap stores the u64 hash it
   computed from the map hasher; capacity decisions that depend on the
   entry struct size use the same total entry size here).

   Semantics matched: insertion order iteration, insert_full index,
   get by key and by index, swap_remove vs shift_remove (and the _index
   and pop forms), shift_insert at a position, reserve and reserve_exact
   (including indexmap's jump of the entries Vec capacity toward the
   side table capacity), shrink_to and shrink_to_fit, clear, retain
   (entries compacted in order, then the side table is cleared and
   rebuilt in entry order), reverse, swap_indices, move_index, truncate
   and range drain through the same erase_indices strategy choices, and
   capacity() = min(side table capacity, entries capacity).
   Sorting the entries is the typed layer's job (Rust std sort); after
   it reorders entry bytes with lust_index_entries_mut it must call
   lust_index_rebuild, like indexmap's with_entries.
   IndexSet is the same core with value size 0. */
typedef struct {
    lust_hash_table indices; /* element: uint64_t entry index */
    uint8_t *entries;        /* entries_cap * entry_size bytes */
    void *entries_alloc;     /* raw malloc pointer */
    uint64_t len;
    uint64_t entries_cap;
    uint64_t entry_size;     /* hash + key + value, padded to entry_align */
    uint64_t entry_align;
    uint64_t hash_offset;
    uint64_t key_offset;
    uint64_t key_size;
    uint64_t value_offset;
    uint64_t value_size;
} lust_index_table;

/* Drop one entry given its key and value slot pointers. */
typedef void (*lust_index_drop_fn)(void *ctx, void *key, void *value);
/* True when the stored key `key` matches the probe key in `ctx`. */
typedef int (*lust_index_eq_fn)(void *ctx, const void *key);
/* Retain predicate over one entry's key and value. True keeps it. */
typedef int (*lust_index_keep_fn)(void *ctx, void *key, void *value);

void lust_index_init(lust_index_table *t, uint64_t key_size, uint64_t key_align, uint64_t value_size,
                     uint64_t value_align);
void lust_index_init_with_capacity(lust_index_table *t, uint64_t key_size, uint64_t key_align, uint64_t value_size,
                                   uint64_t value_align, uint64_t capacity);
/* Drops all entries in order (when drop != NULL), frees both tables,
   and leaves an empty table with the same key/value layout. */
void lust_index_drop_table(lust_index_table *t, lust_index_drop_fn drop, void *ctx);

uint64_t lust_index_len(const lust_index_table *t);
uint64_t lust_index_capacity(const lust_index_table *t);
int lust_index_is_empty(const lust_index_table *t);

/* Key/value slots of the entry at position `index`, or NULL if out of
   range. Either out pointer may be NULL. Entry order is iteration order. */
int lust_index_get_index(const lust_index_table *t, uint64_t index, void **out_key, void **out_value);
/* Raw entry bytes for position `index` (hash word first). Use with
   lust_index_rebuild after an in-place reorder such as sort. */
void *lust_index_entry_mut(lust_index_table *t, uint64_t index);
uint64_t lust_index_entry_hash(const lust_index_table *t, uint64_t index);
/* The position of the matching key, or UINT64_MAX. */
uint64_t lust_index_get_index_of(const lust_index_table *t, uint64_t hash, lust_index_eq_fn eq, void *eq_ctx);
int lust_index_get(const lust_index_table *t, uint64_t hash, lust_index_eq_fn eq, void *eq_ctx, void **out_key,
                   void **out_value, uint64_t *out_index);

/* IndexMap::insert_full: if the key exists, returns its position, sets
   *out_replaced to 1, and gives the value slot in *out_value_slot (the
   caller swaps the new value in; the key is kept, as in Rust). Else
   appends a new entry and returns its position with *out_replaced 0 and
   the key/value slots to write into. The key bytes for the probe are
   read through `eq`; on insert the caller writes the real key bytes. */
uint64_t lust_index_insert_full(lust_index_table *t, uint64_t hash, lust_index_eq_fn eq, void *eq_ctx, int *out_replaced,
                                void **out_key_slot, void **out_value_slot);
/* Appends a key the caller knows is absent (entry API vacant paths,
   extend with unique keys). Returns the position; slots as above. */
uint64_t lust_index_insert_unique(lust_index_table *t, uint64_t hash, void **out_key_slot, void **out_value_slot);
/* VacantEntry::shift_insert: inserts a known-absent key at `index`
   (0..=len), shifting later entries one position up. */
void lust_index_shift_insert_unique(lust_index_table *t, uint64_t index, uint64_t hash, void **out_key_slot,
                                    void **out_value_slot);

/* Removals. The removed key and value bytes are copied to out_key /
   out_value when they are not NULL (ownership moves out). The by-key
   forms also report the position the entry had. */
int lust_index_swap_remove(lust_index_table *t, uint64_t hash, lust_index_eq_fn eq, void *eq_ctx, void *out_key,
                           void *out_value, uint64_t *out_index);
int lust_index_shift_remove(lust_index_table *t, uint64_t hash, lust_index_eq_fn eq, void *eq_ctx, void *out_key,
                            void *out_value, uint64_t *out_index);
int lust_index_swap_remove_index(lust_index_table *t, uint64_t index, void *out_key, void *out_value);
int lust_index_shift_remove_index(lust_index_table *t, uint64_t index, void *out_key, void *out_value);
int lust_index_pop(lust_index_table *t, void *out_key, void *out_value);

void lust_index_reserve(lust_index_table *t, uint64_t additional);
void lust_index_reserve_exact(lust_index_table *t, uint64_t additional);
void lust_index_shrink_to(lust_index_table *t, uint64_t min_capacity); /* 0 is shrink_to_fit */
void lust_index_clear(lust_index_table *t, lust_index_drop_fn drop, void *ctx);
void lust_index_truncate(lust_index_table *t, uint64_t len, lust_index_drop_fn drop, void *ctx);
/* Keeps accepted entries in order, drops the rest in order, then rebuilds
   the side table when anything was removed (indexmap retain_in_order).
   The predicate runs in entry order and may mutate key/value except it
   must not change any key's hash or equality, as in Rust. */
void lust_index_retain(lust_index_table *t, lust_index_keep_fn keep, void *keep_ctx, lust_index_drop_fn drop,
                       void *drop_ctx);
void lust_index_reverse(lust_index_table *t);
void lust_index_swap_indices(lust_index_table *t, uint64_t a, uint64_t b);
void lust_index_move_index(lust_index_table *t, uint64_t from, uint64_t to);
/* Removes the entry range [start, end), dropping those entries in order
   (when drop != NULL). Matches the erase_indices strategies of indexmap
   drain/truncate/splice for side table state; a lazy Rust Drain iterator
   that can be dropped midway belongs to the typed layer, which can
   drive the same end state from get_index + this call. */
void lust_index_drain_range(lust_index_table *t, uint64_t start, uint64_t end, lust_index_drop_fn drop, void *ctx);
/* Clears and rebuilds the side table from entry order and stored hashes.
   Required after the caller reorders or rewrites entry bytes. */
void lust_index_rebuild(lust_index_table *t);

#if !defined(__TINYC__) && !defined(LUST_IMPL) && !defined(LUST_NO_INL)
/* Units an optimizing C compiler builds (inl.h's rule: not tcc, the runtime unit or
   -DLUST_NO_INL) run a hash lookup's probe in the caller's unit, as hashbrown's
   monomorphized find runs in rustc's code: the key compare is the caller's eq glue, a known
   fn that clang calls directly or inlines. hash.c's order and results (lh_find_inner):
   h1 = hash & mask, a triangular stride of one group, matches in bit order, stop at a group
   with an EMPTY byte. The group test is hash.c's: one SSE2 load on x86_64 (vector builtins:
   units read no system header), its SWAR otherwise (a SWAR tag test may also flag the byte
   above a match, a candidate eq rejects). It returns the tag matches and sets the EMPTY and
   the EMPTY-or-DELETED masks (a caller that does not read a mask costs nothing for it). */
#if LUST_HASH_GROUP_WIDTH == 16 && defined(__SSE2__)
typedef char lust_hash_v16_ __attribute__((vector_size(16)));
static inline uint32_t lust_hash_group_(const uint8_t *ctrl, uint8_t tag, uint32_t *empty, uint32_t *eod) {
    lust_hash_v16_ g, zero = {0};
    __builtin_memcpy(&g, ctrl, 16);
    *empty = (uint32_t)__builtin_ia32_pmovmskb128((lust_hash_v16_)(g == zero + (char)LUST_HASH_EMPTY));
    *eod = (uint32_t)__builtin_ia32_pmovmskb128(g);
    return (uint32_t)__builtin_ia32_pmovmskb128((lust_hash_v16_)(g == zero + (char)tag));
}
#else
static inline uint32_t lust_hash_spread_bits_(uint64_t spread) {
    return (uint32_t)((((spread >> 7) & 0x0101010101010101ull) * 0x0102040810204080ull) >> 56);
}
static inline uint32_t lust_hash_bytes_(uint64_t w, uint8_t b) {
    uint64_t x = w ^ (b * 0x0101010101010101ull);
    return lust_hash_spread_bits_((x - 0x0101010101010101ull) & ~x & 0x8080808080808080ull);
}
static inline uint32_t lust_hash_group_(const uint8_t *ctrl, uint8_t tag, uint32_t *empty, uint32_t *eod) {
    uint32_t tb = 0, eb = 0, db = 0;
    for (uint32_t off = 0; off < LUST_HASH_GROUP_WIDTH; off += 8) {
        uint64_t w;
        __builtin_memcpy(&w, ctrl + off, 8);
        tb |= lust_hash_bytes_(w, tag) << off;
        eb |= lust_hash_bytes_(w, LUST_HASH_EMPTY) << off;
        db |= lust_hash_spread_bits_(w & 0x8080808080808080ull) << off;
    }
    *empty = eb;
    *eod = db;
    return tb;
}
#endif
static inline void *lust_hash_find_inl_(const lust_hash_table *t, uint64_t hash, lust_hash_eq_fn eq, void *ctx, uint64_t *out) {
    uint8_t tag = lust_hash_tag(hash);
    uint64_t mask = t->bucket_mask, pos = hash & mask, stride = 0;
    for (;;) {
        uint32_t empty, eod, m = lust_hash_group_(t->ctrl + pos, tag, &empty, &eod);
        while (m) {
            uint64_t index = (pos + (uint64_t)__builtin_ctz(m)) & mask;
            m &= m - 1;
            void *slot = (void *)(t->data + index * t->elem_size);
            if (eq(ctx, slot)) {
                if (out) *out = index;
                return slot;
            }
        }
        if (empty) return 0;
        stride += LUST_HASH_GROUP_WIDTH;
        pos = (pos + stride) & mask;
    }
}
/* The function reserves room for one first, which may move every element; with room that is
   a no-op, so the whole search runs here: lh_find_or_insert_inner's single pass, which notes
   the first EMPTY or DELETED bucket on its way and stops at a group with an EMPTY byte. A
   miss returns that insert index (fix_insert_index: in a table smaller than a group, a
   mirror byte can name a full bucket; then it is group 0's first EMPTY or DELETED). A full
   table calls the function (it grows first). */
static inline int lust_hash_find_or_insert_inl_(lust_hash_table *t, uint64_t hash, lust_hash_eq_fn eq, void *ctx,
                                                lust_hash_of_fn hash_of, void *hash_ctx, void **out_slot, uint64_t *out_index) {
    if (__builtin_expect(t->growth_left == 0, 0))
        return lust_hash_find_or_insert(t, hash, eq, ctx, hash_of, hash_ctx, out_slot, out_index);
    uint8_t tag = lust_hash_tag(hash);
    uint64_t mask = t->bucket_mask, pos = hash & mask, stride = 0, insert = 0;
    int have_insert = 0;
    for (;;) {
        uint32_t empty, eod, m = lust_hash_group_(t->ctrl + pos, tag, &empty, &eod);
        while (m) {
            uint64_t index = (pos + (uint64_t)__builtin_ctz(m)) & mask;
            m &= m - 1;
            void *slot = (void *)(t->data + index * t->elem_size);
            if (eq(ctx, slot)) {
                if (out_slot) *out_slot = slot;
                if (out_index) *out_index = index;
                return 1;
            }
        }
        if (!have_insert && eod) {
            insert = (pos + (uint64_t)__builtin_ctz(eod)) & mask;
            have_insert = 1;
        }
        if (have_insert && empty) {
            if (__builtin_expect((t->ctrl[insert] & 0x80u) == 0, 0)) {
                uint32_t e0, d0;
                (void)lust_hash_group_(t->ctrl, 0, &e0, &d0);
                insert = d0 ? (uint64_t)__builtin_ctz(d0) : 0;
            }
            if (out_index) *out_index = insert;
            return 0;
        }
        stride += LUST_HASH_GROUP_WIDTH;
        pos = (pos + stride) & mask;
    }
}
/* lust_hash_insert_at (RawTable::record_item_insert_at): the tag in the bucket's control
   byte and in its mirror, one more item, one less room when the byte was EMPTY. */
static inline void *lust_hash_insert_at_inl_(lust_hash_table *t, uint64_t hash, uint64_t index) {
    uint8_t tag = lust_hash_tag(hash);
    if (t->ctrl[index] == LUST_HASH_EMPTY) t->growth_left -= 1;
    t->ctrl[index] = tag;
    t->ctrl[((index - LUST_HASH_GROUP_WIDTH) & t->bucket_mask) + LUST_HASH_GROUP_WIDTH] = tag;
    t->items += 1;
    return (void *)(t->data + index * t->elem_size);
}
#define lust_hash_find(t, hash, eq, ctx, out) lust_hash_find_inl_((t), (hash), (eq), (ctx), (out))
#define lust_hash_find_or_insert(t, hash, eq, ctx, hash_of, hash_ctx, out_slot, out_index) \
    lust_hash_find_or_insert_inl_((t), (hash), (eq), (ctx), (hash_of), (hash_ctx), (out_slot), (out_index))
#define lust_hash_insert_at(t, hash, index) lust_hash_insert_at_inl_((t), (hash), (index))
#endif

#ifdef LUST_IMPL
/* Erased hash table core: see hash.h for the contract. This file is a
   scalar port of hashbrown 0.17.1 raw.rs (Rust 1.99 vendored std
   sources, library/vendor/hashbrown-0.17.1). Function and variable
   comments name the hashbrown counterpart where the match is not
   obvious. Internal helpers are static so this fragment can be
   amalgamated into the runtime unit without symbol clashes. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LH_WIDTH ((uint64_t)LUST_HASH_GROUP_WIDTH)

static void lust_hash_capacity_overflow(void) {
    static const char msg[] = "Hash table capacity overflow";
    lust_panic_at((const uint8_t *)msg, sizeof msg - 1, "/rust/deps/hashbrown-0.17.1/src/raw.rs", 36, 40);
}

/* Tag::is_full / special_is_empty for one control byte. */
static int lh_is_full(uint8_t c) { return (c & 0x80u) == 0; }

/* Group::static_empty for the empty singleton; 16 bytes cover both
   group widths this core supports. */
const uint8_t lust_hash_static_empty[16] = {
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
};

static uint64_t lh_align_up(uint64_t x, uint64_t a) { return (x + a - 1) & ~(a - 1); }

static uint64_t lh_ctrl_align(const lust_hash_table *t) {
    uint64_t a = t->elem_align < LH_WIDTH ? LH_WIDTH : t->elem_align;
    return a ? a : LH_WIDTH;
}

/* RawTableInner::bucket_ptr with forward storage. */
static void *lh_slot(const lust_hash_table *t, uint64_t index) {
    return (void *)(t->data + index * t->elem_size);
}

/* bucket_mask_to_capacity. */
static uint64_t lh_bucket_mask_to_capacity(uint64_t bucket_mask) {
    if (bucket_mask < 8) return bucket_mask;
    return ((bucket_mask + 1) / 8) * 7;
}

/* capacity_to_buckets. Returns 0 on overflow (None in Rust). */
static int lh_capacity_to_buckets(uint64_t cap, uint64_t elem_size, uint64_t *out) {
    if (cap < 15) {
        uint64_t min_cap;
        if (LH_WIDTH == 16 && elem_size <= 1) min_cap = 14;
        else if (LH_WIDTH == 16 && elem_size >= 2 && elem_size <= 3) min_cap = 7;
        else if (LH_WIDTH == 8 && elem_size <= 1) min_cap = 7;
        else min_cap = 3;
        if (cap < min_cap) cap = min_cap;
        *out = cap < 4 ? 4 : cap < 8 ? 8 : 16;
        return 1;
    }
    if (cap > UINT64_MAX / 8) return 0;
    uint64_t adjusted = cap * 8 / 7;
    uint64_t buckets = 1;
    while (buckets < adjusted) {
        if (buckets > (UINT64_MAX >> 1)) return 0;
        buckets <<= 1;
    }
    *out = buckets;
    return 1;
}

/* TableLayout::calculate_layout_for plus allocation. One malloc holds the
   buckets then the control bytes, aligned to ctrl_align. Control bytes
   are left uninitialized (RawTableInner::new_uninitialized); callers fill
   them. The oversized-allocation reuse in hashbrown cannot trigger with
   the Rust Global allocator, which returns exactly the layout size, so
   it is not reproduced. */
static int lh_alloc_buckets(lust_hash_table *t, uint64_t buckets) {
    uint64_t ctrl_align = lh_ctrl_align(t);
    /* A capacity overflow panics; under panic=unwind the panic returns
       here and the table stays as it was. */
    if (t->elem_size && buckets > UINT64_MAX / t->elem_size) return lust_hash_capacity_overflow(), 0;
    uint64_t data_bytes = t->elem_size * buckets;
    if (data_bytes > UINT64_MAX - (ctrl_align - 1)) return lust_hash_capacity_overflow(), 0;
    uint64_t ctrl_offset = lh_align_up(data_bytes, ctrl_align);
    if (ctrl_offset > UINT64_MAX - buckets - LH_WIDTH) return lust_hash_capacity_overflow(), 0;
    uint64_t total = ctrl_offset + buckets + LH_WIDTH;
    if (total > (uint64_t)INT64_MAX - (ctrl_align - 1)) return lust_hash_capacity_overflow(), 0;
    void *raw = malloc((size_t)(total + ctrl_align));
    if (!raw) lust_oom_size(total); /* hashbrown's table layout */
    uintptr_t base = lh_align_up((uint64_t)(uintptr_t)raw, ctrl_align);
    t->alloc_base = raw;
    t->data = (uint8_t *)base;
    t->ctrl = (uint8_t *)base + ctrl_offset;
    t->bucket_mask = buckets - 1;
    t->items = 0;
    t->growth_left = lh_bucket_mask_to_capacity(buckets - 1);
    return 1;
}

static void lh_free_table(lust_hash_table *t) {
    free(t->alloc_base);
    t->alloc_base = NULL;
    t->data = NULL;
    t->ctrl = (uint8_t *)lust_hash_static_empty;
    t->bucket_mask = 0;
    t->items = 0;
    t->growth_left = 0;
}

static int lh_is_singleton(const lust_hash_table *t) { return t->bucket_mask == 0; }
static uint64_t lh_num_buckets(const lust_hash_table *t) { return t->bucket_mask + 1; }

/* RawTableInner::with_capacity into an already-initialized layout. 0
   after a capacity overflow panic (panic=unwind), with `t` empty. */
static int lh_with_capacity(lust_hash_table *t, uint64_t capacity) {
    uint64_t buckets = 0;
    if (capacity && !lh_capacity_to_buckets(capacity, t->elem_size, &buckets)) lust_hash_capacity_overflow();
    if (capacity == 0 || !buckets || !lh_alloc_buckets(t, buckets)) {
        t->ctrl = (uint8_t *)lust_hash_static_empty;
        t->data = NULL;
        t->alloc_base = NULL;
        t->bucket_mask = 0;
        t->items = 0;
        t->growth_left = 0;
        return capacity == 0;
    }
    memset(t->ctrl, LUST_HASH_EMPTY, (size_t)(buckets + LH_WIDTH));
    return 1;
}

void lust_hash_init(lust_hash_table *t, uint64_t elem_size, uint64_t elem_align) {
    t->elem_size = elem_size;
    t->elem_align = elem_align ? elem_align : 1;
    t->ctrl = (uint8_t *)lust_hash_static_empty;
    t->data = NULL;
    t->alloc_base = NULL;
    t->bucket_mask = 0;
    t->items = 0;
    t->growth_left = 0;
}

void lust_hash_init_with_capacity(lust_hash_table *t, uint64_t elem_size, uint64_t elem_align, uint64_t capacity) {
    t->elem_size = elem_size;
    t->elem_align = elem_align ? elem_align : 1;
    lh_with_capacity(t, capacity);
}

uint64_t lust_hash_len(const lust_hash_table *t) { return t->items; }
uint64_t lust_hash_capacity(const lust_hash_table *t) { return t->items + t->growth_left; }
uint64_t lust_hash_buckets(const lust_hash_table *t) { return lh_num_buckets(t); }
int lust_hash_is_empty(const lust_hash_table *t) { return t->items == 0; }

void *lust_hash_bucket(const lust_hash_table *t, uint64_t index) {
    if (index >= lh_num_buckets(t) || !lh_is_full(t->ctrl[index])) return NULL;
    return lh_slot(t, index);
}
uint8_t lust_hash_ctrl(const lust_hash_table *t, uint64_t index) { return t->ctrl[index]; }

/* RawTableInner::set_ctrl: also writes the mirrored tail byte. */
static void lh_set_ctrl(lust_hash_table *t, uint64_t index, uint8_t ctrl) {
    uint64_t index2 = ((index - LH_WIDTH) & t->bucket_mask) + LH_WIDTH;
    t->ctrl[index] = ctrl;
    t->ctrl[index2] = ctrl;
}
static void lh_set_ctrl_hash(lust_hash_table *t, uint64_t index, uint64_t hash) {
    lh_set_ctrl(t, index, lust_hash_tag(hash));
}

/* A group load plus BitMask queries. Bit i is byte i. The scan is SWAR
   over 8-byte chunks (the generic hashbrown group does the same); only
   LH_WIDTH is observable, not this choice. Little-endian loads: both
   tier 1 targets are little-endian, and hashbrown's NEON group is
   little-endian only too. */
static uint64_t lh_load64(const uint8_t *p) {
    uint64_t w;
    memcpy(&w, p, 8);
    return w;
}
static uint32_t lh_spread_bits(uint64_t spread) {
    return (uint32_t)((((spread >> 7) & 0x0101010101010101ull) * 0x0102040810204080ull) >> 56);
}
static uint64_t lh_eq_spread(uint64_t w, uint8_t tag) {
    uint64_t x = w ^ (tag * 0x0101010101010101ull);
    return (x - 0x0101010101010101ull) & ~x & 0x8080808080808080ull;
}
#if defined(__SSE2__) && !defined(__TINYC__) && LUST_HASH_GROUP_WIDTH == 16
#include <emmintrin.h>
/* hashbrown's x86_64 group: one 16-byte load and byte compares. Its masks are
   exact, where the SWAR tag test below may also flag the byte above a match
   (a candidate that eq rejects): the same lookups, inserts and order. */
static uint32_t lh_movemask_eq(__m128i g, uint8_t b) {
    return (uint32_t)_mm_movemask_epi8(_mm_cmpeq_epi8(g, _mm_set1_epi8((char)b)));
}
/* mode: 0 match_tag, 1 match_empty, 2 match_empty_or_deleted, 3 match_full */
static uint32_t lh_group_bits(const lust_hash_table *t, uint64_t pos, int mode, uint8_t tag) {
    __m128i g = _mm_loadu_si128((const __m128i *)(t->ctrl + pos));
    if (mode == 0) return lh_movemask_eq(g, tag);
    if (mode == 1) return lh_movemask_eq(g, LUST_HASH_EMPTY);
    uint32_t hi = (uint32_t)_mm_movemask_epi8(g);
    return mode == 2 ? hi : hi ^ 0xFFFFu;
}
/* All three masks a probe needs, from one load. */
static void lh_group_masks(const lust_hash_table *t, uint64_t pos, uint8_t tag, uint32_t *tag_bits,
                           uint32_t *empty_bits, uint32_t *eod_bits) {
    __m128i g = _mm_loadu_si128((const __m128i *)(t->ctrl + pos));
    *tag_bits = lh_movemask_eq(g, tag);
    *empty_bits = lh_movemask_eq(g, LUST_HASH_EMPTY);
    *eod_bits = (uint32_t)_mm_movemask_epi8(g);
}
#else
/* mode: 0 match_tag, 1 match_empty, 2 match_empty_or_deleted, 3 match_full */
static uint32_t lh_group_bits(const lust_hash_table *t, uint64_t pos, int mode, uint8_t tag) {
    uint32_t bits = 0;
    for (uint64_t off = 0; off < LH_WIDTH; off += 8) {
        uint64_t w = lh_load64(t->ctrl + pos + off);
        uint64_t spread;
        if (mode == 0) spread = lh_eq_spread(w, tag);
        else if (mode == 1) spread = lh_eq_spread(w, LUST_HASH_EMPTY);
        else if (mode == 2) spread = w & 0x8080808080808080ull;
        else spread = ~w & 0x8080808080808080ull;
        bits |= lh_spread_bits(spread) << off;
    }
    return bits;
}
/* All three masks a probe needs, from one load per chunk. */
static void lh_group_masks(const lust_hash_table *t, uint64_t pos, uint8_t tag, uint32_t *tag_bits,
                           uint32_t *empty_bits, uint32_t *eod_bits) {
    uint32_t tb = 0, eb = 0, db = 0;
    for (uint64_t off = 0; off < LH_WIDTH; off += 8) {
        uint64_t w = lh_load64(t->ctrl + pos + off);
        tb |= lh_spread_bits(lh_eq_spread(w, tag)) << off;
        eb |= lh_spread_bits(lh_eq_spread(w, LUST_HASH_EMPTY)) << off;
        db |= lh_spread_bits(w & 0x8080808080808080ull) << off;
    }
    *tag_bits = tb;
    *empty_bits = eb;
    *eod_bits = db;
}
#endif
static int lh_lowest_bit(uint32_t bits, uint64_t *out) {
    if (!bits) return 0;
#ifndef __TINYC__
    *out = (uint64_t)__builtin_ctz(bits);
#else
    uint64_t i = 0;
    while (!(bits & 1u)) { bits >>= 1; i++; }
    *out = i;
#endif
    return 1;
}

/* ProbeSeq: triangular probe by groups. */
typedef struct {
    uint64_t pos;
    uint64_t stride;
} lh_probe;
static lh_probe lh_probe_seq(const lust_hash_table *t, uint64_t hash) {
    lh_probe p;
    p.pos = hash & t->bucket_mask; /* h1 */
    p.stride = 0;
    return p;
}
static void lh_probe_next(lh_probe *p, uint64_t bucket_mask) {
    p->stride += LH_WIDTH;
    p->pos = (p->pos + p->stride) & bucket_mask;
}

/* RawTableInner::fix_insert_index. */
static uint64_t lh_fix_insert_index(const lust_hash_table *t, uint64_t index) {
    if (lh_is_full(t->ctrl[index])) {
        uint64_t bit = 0;
        lh_lowest_bit(lh_group_bits(t, 0, 2, 0), &bit);
        index = bit;
    }
    return index;
}

/* RawTableInner::find_insert_index_in_group; -1 style via return 0. */
static int lh_find_insert_index_in_group(const lust_hash_table *t, uint32_t empty_or_deleted, const lh_probe *p,
                                         uint64_t *out) {
    uint64_t bit;
    if (!lh_lowest_bit(empty_or_deleted, &bit)) return 0;
    *out = (p->pos + bit) & t->bucket_mask;
    return 1;
}

/* RawTableInner::find_insert_index. */
static uint64_t lh_find_insert_index(const lust_hash_table *t, uint64_t hash) {
    lh_probe p = lh_probe_seq(t, hash);
    for (;;) {
        uint32_t eod = lh_group_bits(t, p.pos, 2, 0);
        uint64_t index;
        if (lh_find_insert_index_in_group(t, eod, &p, &index)) return lh_fix_insert_index(t, index);
        lh_probe_next(&p, t->bucket_mask);
    }
}

/* RawTableInner::find_inner with `eq` over elements. */
static int lh_find_inner(const lust_hash_table *t, uint64_t hash, lust_hash_eq_fn eq, void *eq_ctx, uint64_t *out) {
    uint8_t tag = lust_hash_tag(hash);
    lh_probe p = lh_probe_seq(t, hash);
    for (;;) {
        uint32_t m, empty_bits, eod_bits;
        lh_group_masks(t, p.pos, tag, &m, &empty_bits, &eod_bits);
        (void)eod_bits;
        while (m) {
            uint64_t bit;
            lh_lowest_bit(m, &bit);
            m &= m - 1;
            uint64_t index = (p.pos + bit) & t->bucket_mask;
            if (eq(eq_ctx, lh_slot(t, index))) {
                *out = index;
                return 1;
            }
        }
        if (empty_bits) return 0;
        lh_probe_next(&p, t->bucket_mask);
    }
}

/* RawTableInner::find_or_find_insert_index_inner.
   Returns 1 with a found index, or 0 with an insert index. */
static int lh_find_or_insert_inner(const lust_hash_table *t, uint64_t hash, lust_hash_eq_fn eq, void *eq_ctx,
                                   uint64_t *out) {
    int have_insert = 0;
    uint64_t insert_index = 0;
    uint8_t tag = lust_hash_tag(hash);
    lh_probe p = lh_probe_seq(t, hash);
    for (;;) {
        uint32_t m, empty_bits, eod_bits;
        lh_group_masks(t, p.pos, tag, &m, &empty_bits, &eod_bits);
        while (m) {
            uint64_t bit;
            lh_lowest_bit(m, &bit);
            m &= m - 1;
            uint64_t index = (p.pos + bit) & t->bucket_mask;
            if (eq(eq_ctx, lh_slot(t, index))) {
                *out = index;
                return 1;
            }
        }
        if (!have_insert) {
            have_insert = lh_find_insert_index_in_group(t, eod_bits, &p, &insert_index);
        }
        if (have_insert && empty_bits) {
            *out = lh_fix_insert_index(t, insert_index);
            return 0;
        }
        lh_probe_next(&p, t->bucket_mask);
    }
}

/* RawTableInner::prepare_insert_index: find, set the tag, report the old. */
static uint64_t lh_prepare_insert_index(lust_hash_table *t, uint64_t hash, uint8_t *out_old) {
    uint64_t index = lh_find_insert_index(t, hash);
    *out_old = t->ctrl[index];
    lh_set_ctrl_hash(t, index, hash);
    return index;
}

/* RawTableInner::erase (no element drop). The EMPTY vs DELETED choice:
   DELETED when the WIDTH buckets ending just after this one contain no
   EMPTY, measured as leading zeros of the group before plus trailing
   zeros of the group at this bucket in hashbrown's BitMask terms. */
static void lh_erase(lust_hash_table *t, uint64_t index) {
    uint64_t index_before = (index - LH_WIDTH) & t->bucket_mask;
    uint32_t eb = lh_group_bits(t, index_before, 1, 0);
    uint32_t ea = lh_group_bits(t, index, 1, 0);
    uint64_t leading = LH_WIDTH, trailing = LH_WIDTH;
    if (eb) {
        uint64_t hb = 0;
        for (uint64_t i = 0; i < LH_WIDTH; i++)
            if (eb & (1u << i)) hb = i;
        leading = LH_WIDTH - 1 - hb;
    }
    if (ea) lh_lowest_bit(ea, &trailing);
    uint8_t ctrl;
    if (leading + trailing >= LH_WIDTH) {
        ctrl = LUST_HASH_DELETED;
    } else {
        t->growth_left += 1;
        ctrl = LUST_HASH_EMPTY;
    }
    lh_set_ctrl(t, index, ctrl);
    t->items -= 1;
}

/* RawTableInner::clear_no_drop. */
static void lh_clear_no_drop(lust_hash_table *t) {
    if (!lh_is_singleton(t)) memset(t->ctrl, LUST_HASH_EMPTY, (size_t)(lh_num_buckets(t) + LH_WIDTH));
    t->items = 0;
    t->growth_left = lh_bucket_mask_to_capacity(t->bucket_mask);
}

/* Drops every element in bucket order, when drop != NULL. */
static void lh_drop_elements(lust_hash_table *t, lust_hash_drop_fn drop, void *ctx) {
    if (!drop || t->items == 0) return;
    uint64_t left = t->items;
    for (uint64_t i = 0; i < lh_num_buckets(t) && left; i++) {
        if (lh_is_full(t->ctrl[i])) {
            drop(ctx, lh_slot(t, i));
            left--;
        }
    }
}

/* RawTableInner::prepare_rehash_in_place: full -> DELETED, special ->
   EMPTY, in the first buckets bytes only, then fix the mirrored tail. */
static void lh_prepare_rehash_in_place(lust_hash_table *t) {
    uint64_t buckets = lh_num_buckets(t);
    for (uint64_t i = 0; i < buckets; i++)
        t->ctrl[i] = lh_is_full(t->ctrl[i]) ? LUST_HASH_DELETED : LUST_HASH_EMPTY;
    if (buckets < LH_WIDTH) memcpy(t->ctrl + LH_WIDTH, t->ctrl, (size_t)buckets);
    else memcpy(t->ctrl + buckets, t->ctrl, (size_t)LH_WIDTH);
}

/* RawTableInner::is_in_same_group. */
static int lh_is_in_same_group(const lust_hash_table *t, uint64_t i, uint64_t new_i, uint64_t hash) {
    uint64_t pos0 = hash & t->bucket_mask;
    uint64_t a = ((i - pos0) & t->bucket_mask) / LH_WIDTH;
    uint64_t b = ((new_i - pos0) & t->bucket_mask) / LH_WIDTH;
    return a == b;
}

/* RawTableInner::rehash_in_place. The scope guard for a panicking hasher
   has no C counterpart: hash_of must not fail. */
static void lh_rehash_in_place(lust_hash_table *t, lust_hash_of_fn hash_of, void *hash_ctx) {
    lh_prepare_rehash_in_place(t);
    uint64_t buckets = lh_num_buckets(t);
    for (uint64_t i = 0; i < buckets; i++) {
        if (t->ctrl[i] != LUST_HASH_DELETED) continue;
        for (;;) {
            uint64_t hash = hash_of(hash_ctx, lh_slot(t, i));
            uint64_t new_i = lh_find_insert_index(t, hash);
            if (lh_is_in_same_group(t, i, new_i, hash)) {
                lh_set_ctrl_hash(t, i, hash);
                break;
            }
            uint8_t prev = t->ctrl[new_i];
            lh_set_ctrl_hash(t, new_i, hash);
            if (prev == LUST_HASH_EMPTY) {
                lh_set_ctrl(t, i, LUST_HASH_EMPTY);
                lust_copy_small(lh_slot(t, new_i), lh_slot(t, i), t->elem_size);
                break;
            }
            /* prev is DELETED: swap the two elements and retry bucket i. */
            uint8_t *a = (uint8_t *)lh_slot(t, i);
            uint8_t *b = (uint8_t *)lh_slot(t, new_i);
            for (uint64_t k = 0; k < t->elem_size; k++) {
                uint8_t tmp = a[k];
                a[k] = b[k];
                b[k] = tmp;
            }
        }
    }
    t->growth_left = lh_bucket_mask_to_capacity(t->bucket_mask) - t->items;
}

/* RawTableInner::resize_inner: build a new table, move elements in old
   bucket order, swap, free the old allocation. */
static void lh_resize_inner(lust_hash_table *t, uint64_t capacity, lust_hash_of_fn hash_of, void *hash_ctx) {
    lust_hash_table nt;
    nt.elem_size = t->elem_size;
    nt.elem_align = t->elem_align;
    if (!lh_with_capacity(&nt, capacity)) return;
    if (t->items) {
        uint64_t left = t->items;
        for (uint64_t i = 0; i < lh_num_buckets(t) && left; i++) {
            if (!lh_is_full(t->ctrl[i])) continue;
            left--;
            uint64_t hash = hash_of(hash_ctx, lh_slot(t, i));
            uint8_t old;
            uint64_t ni = lh_prepare_insert_index(&nt, hash, &old);
            (void)old;
            lust_copy_small(lh_slot(&nt, ni), lh_slot(t, i), t->elem_size);
        }
    }
    nt.growth_left -= t->items;
    nt.items = t->items;
    lust_hash_table oldt = *t;
    *t = nt;
    free(oldt.alloc_base);
}

/* RawTableInner::reserve_rehash_inner. */
static void lh_reserve_rehash_inner(lust_hash_table *t, uint64_t additional, lust_hash_of_fn hash_of, void *hash_ctx) {
    if (additional > UINT64_MAX - t->items) {
        lust_hash_capacity_overflow();
        return;
    }
    uint64_t new_items = t->items + additional;
    uint64_t full_capacity = lh_bucket_mask_to_capacity(t->bucket_mask);
    if (new_items <= full_capacity / 2) {
        lh_rehash_in_place(t, hash_of, hash_ctx);
    } else {
        uint64_t cap = new_items > full_capacity + 1 ? new_items : full_capacity + 1;
        lh_resize_inner(t, cap, hash_of, hash_ctx);
    }
}

void lust_hash_reserve(lust_hash_table *t, uint64_t additional, lust_hash_of_fn hash_of, void *hash_ctx) {
    if (additional > t->growth_left) lh_reserve_rehash_inner(t, additional, hash_of, hash_ctx);
}

void lust_hash_shrink_to(lust_hash_table *t, uint64_t min_capacity, lust_hash_of_fn hash_of, void *hash_ctx) {
    uint64_t min_size = t->items > min_capacity ? t->items : min_capacity;
    if (min_size == 0) {
        uint64_t es = t->elem_size, ea = t->elem_align;
        lh_free_table(t);
        t->elem_size = es;
        t->elem_align = ea;
        return;
    }
    uint64_t min_buckets;
    if (!lh_capacity_to_buckets(min_size, t->elem_size, &min_buckets)) return;
    if (min_buckets < lh_num_buckets(t)) {
        if (t->items == 0) {
            lust_hash_table nt;
            nt.elem_size = t->elem_size;
            nt.elem_align = t->elem_align;
            lh_with_capacity(&nt, min_size);
            free(t->alloc_base);
            *t = nt;
        } else {
            lh_resize_inner(t, min_size, hash_of, hash_ctx);
        }
    }
}

void *lust_hash_find(const lust_hash_table *t, uint64_t hash, lust_hash_eq_fn eq, void *eq_ctx, uint64_t *out_index) {
    uint64_t index;
    if (!lh_find_inner(t, hash, eq, eq_ctx, &index)) return NULL;
    if (out_index) *out_index = index;
    return lh_slot(t, index);
}

/* RawTable::insert_at_index / record_item_insert_at. */
void *lust_hash_insert_at(lust_hash_table *t, uint64_t hash, uint64_t index) {
    uint8_t old = t->ctrl[index];
    if (old == LUST_HASH_EMPTY) t->growth_left -= 1;
    lh_set_ctrl(t, index, lust_hash_tag(hash));
    t->items += 1;
    return lh_slot(t, index);
}

int lust_hash_find_or_insert(lust_hash_table *t, uint64_t hash, lust_hash_eq_fn eq, void *eq_ctx,
                             lust_hash_of_fn hash_of, void *hash_ctx, void **out_slot, uint64_t *out_index) {
    lust_hash_reserve(t, 1, hash_of, hash_ctx);
    uint64_t index;
    if (lh_find_or_insert_inner(t, hash, eq, eq_ctx, &index)) {
        if (out_slot) *out_slot = lh_slot(t, index);
        if (out_index) *out_index = index;
        return 1;
    }
    if (out_index) *out_index = index;
    return 0;
}

void *lust_hash_insert_unique_slot(lust_hash_table *t, uint64_t hash, lust_hash_of_fn hash_of, void *hash_ctx,
                                   uint64_t *out_index) {
    uint64_t index = lh_find_insert_index(t, hash);
    uint8_t old = t->ctrl[index];
    if (t->growth_left == 0 && old == LUST_HASH_EMPTY) {
        lust_hash_reserve(t, 1, hash_of, hash_ctx);
        index = lh_find_insert_index(t, hash);
    }
    void *slot = lust_hash_insert_at(t, hash, index);
    if (out_index) *out_index = index;
    return slot;
}

void *lust_hash_insert_no_grow_slot(lust_hash_table *t, uint64_t hash, uint64_t *out_index) {
    uint8_t old;
    uint64_t index = lh_prepare_insert_index(t, hash, &old);
    if (old == LUST_HASH_EMPTY) t->growth_left -= 1;
    t->items += 1;
    if (out_index) *out_index = index;
    return lh_slot(t, index);
}

void lust_hash_erase_at(lust_hash_table *t, uint64_t index, void *out_elem) {
    if (out_elem && t->elem_size) lust_copy_small(out_elem, lh_slot(t, index), t->elem_size);
    lh_erase(t, index);
}

uint64_t lust_hash_index_of(const lust_hash_table *t, const void *slot) {
    if (t->elem_size) return (uint64_t)((const uint8_t *)slot - t->data) / t->elem_size;
    for (uint64_t i = 0; i < lh_num_buckets(t); i++)
        if (lh_is_full(t->ctrl[i])) return i;
    return 0;
}

int lust_hash_remove(lust_hash_table *t, uint64_t hash, lust_hash_eq_fn eq, void *eq_ctx, void *out_elem) {
    uint64_t index;
    if (!lh_find_inner(t, hash, eq, eq_ctx, &index)) return 0;
    lust_hash_erase_at(t, index, out_elem);
    return 1;
}

void lust_hash_clear(lust_hash_table *t, lust_hash_drop_fn drop, void *ctx) {
    if (t->items == 0) return; /* RawTable::clear keeps tombstones when empty. */
    lh_drop_elements(t, drop, ctx);
    lh_clear_no_drop(t);
}

void lust_hash_drop_table(lust_hash_table *t, lust_hash_drop_fn drop, void *ctx) {
    uint64_t es = t->elem_size, ea = t->elem_align;
    lh_drop_elements(t, drop, ctx);
    lh_free_table(t);
    t->elem_size = es;
    t->elem_align = ea;
}

void lust_hash_retain(lust_hash_table *t, lust_hash_keep_fn keep, void *keep_ctx, lust_hash_drop_fn drop, void *drop_ctx) {
    uint64_t left = t->items;
    for (uint64_t i = 0; i < lh_num_buckets(t) && left; i++) {
        if (!lh_is_full(t->ctrl[i])) continue;
        left--;
        void *slot = lh_slot(t, i);
        if (!keep(keep_ctx, slot)) {
            lh_erase(t, i);
            if (drop) drop(drop_ctx, slot);
        }
    }
}

void lust_hash_clone_into(lust_hash_table *dst, const lust_hash_table *src, lust_hash_clone_fn clone_elem, void *ctx) {
    if (lh_is_singleton(src)) return;
    uint64_t buckets = lh_num_buckets(src);
    lh_alloc_buckets(dst, buckets);
    memcpy(dst->ctrl, src->ctrl, (size_t)(buckets + LH_WIDTH));
    dst->items = src->items;
    dst->growth_left = src->growth_left;
    uint64_t left = src->items;
    for (uint64_t i = 0; i < buckets && left; i++) {
        if (!lh_is_full(src->ctrl[i])) continue;
        left--;
        if (clone_elem) clone_elem(ctx, lh_slot(dst, i), lh_slot(src, i));
        else memcpy(lh_slot(dst, i), lh_slot(src, i), (size_t)src->elem_size);
    }
}

void lust_hash_iter_init(lust_hash_iter *it, const lust_hash_table *t) {
    it->t = t;
    it->next_index = 0;
    it->group_base = 0;
    it->group_bits = 0;
    it->left = t->items;
}
/* Group-at-a-time scan like RawIterRange: aligned groups, bits low to
   high, bounded by the item count (so tail bytes of small tables and
   the singleton never produce phantom items). */
void *lust_hash_iter_next(lust_hash_iter *it, uint64_t *out_index) {
    if (!it->left) return NULL;
    while (!it->group_bits) {
        it->group_base = it->next_index;
        it->group_bits = lh_group_bits(it->t, it->group_base, 3, 0);
        it->next_index += LH_WIDTH;
    }
    uint64_t bit;
    lh_lowest_bit(it->group_bits, &bit);
    it->group_bits &= it->group_bits - 1;
    it->left--;
    uint64_t i = it->group_base + bit;
    if (out_index) *out_index = i;
    return lh_slot(it->t, i);
}

void lust_hash_drain_init(lust_hash_drain *d, lust_hash_table *t) {
    d->t = t;
    d->next_index = 0;
    d->group_base = 0;
    d->group_bits = 0;
    d->left = t->items;
}
void *lust_hash_drain_next(lust_hash_drain *d, uint64_t *out_index) {
    if (!d->left) return NULL;
    while (!d->group_bits) {
        d->group_base = d->next_index;
        d->group_bits = lh_group_bits(d->t, d->group_base, 3, 0);
        d->next_index += LH_WIDTH;
    }
    uint64_t bit;
    lh_lowest_bit(d->group_bits, &bit);
    d->group_bits &= d->group_bits - 1;
    d->left--;
    uint64_t i = d->group_base + bit;
    if (out_index) *out_index = i;
    return lh_slot(d->t, i);
}
void lust_hash_drain_finish(lust_hash_drain *d, lust_hash_drop_fn drop, void *ctx) {
    if (drop) {
        void *slot;
        while ((slot = lust_hash_drain_next(d, NULL)) != NULL) drop(ctx, slot);
    }
    lh_clear_no_drop(d->t);
    d->left = 0;
    d->group_bits = 0;
}

/* ---------------- FxHasher (rustc-hash 2.1.2, 64-bit) ---------------- */

#define LUST_FX_K 0xf1357aea2e62a9c5ull
#define LUST_FX_SEED1 0x243f6a8885a308d3ull
#define LUST_FX_SEED2 0x13198a2e03707344ull
#define LUST_FX_PREVENT_ZERO 0xa4093822299f31d0ull

/* ---------------- SipHash-1-3 (core::hash::sip) ---------------- */

static uint64_t lh_rotl(uint64_t x, int b) { return (x << b) | (x >> (64 - b)); }

/* sip.rs compress! */
static void lh_sip_round(lust_sip13 *s) {
    s->v0 += s->v1; s->v1 = lh_rotl(s->v1, 13); s->v1 ^= s->v0; s->v0 = lh_rotl(s->v0, 32);
    s->v2 += s->v3; s->v3 = lh_rotl(s->v3, 16); s->v3 ^= s->v2;
    s->v0 += s->v3; s->v3 = lh_rotl(s->v3, 21); s->v3 ^= s->v0;
    s->v2 += s->v1; s->v1 = lh_rotl(s->v1, 17); s->v1 ^= s->v2; s->v2 = lh_rotl(s->v2, 32);
}

/* u8to64_le: `len` (< 8) bytes at `p` as a little-endian word. */
static uint64_t lh_u8to64_le(const uint8_t *p, uint64_t len) {
    uint64_t out = 0;
    for (uint64_t i = 0; i < len; i++) out |= (uint64_t)p[i] << (8 * i);
    return out;
}

lust_sip13 lust_sip13_new_with_keys(uint64_t k0, uint64_t k1) {
    lust_sip13 h;
    h.k0 = k0;
    h.k1 = k1;
    h.length = 0;
    h.v0 = k0 ^ 0x736f6d6570736575ull;
    h.v1 = k1 ^ 0x646f72616e646f6dull;
    h.v2 = k0 ^ 0x6c7967656e657261ull;
    h.v3 = k1 ^ 0x7465646279746573ull;
    h.tail = 0;
    h.ntail = 0;
    return h;
}

/* sip.rs Hasher::write. */
void lust_sip13_write(lust_sip13 *h, const void *bytes, uint64_t length) {
    const uint8_t *msg = (const uint8_t *)bytes;
    h->length += length;
    uint64_t needed = 0;
    if (h->ntail != 0) {
        needed = 8 - h->ntail;
        h->tail |= lh_u8to64_le(msg, length < needed ? length : needed) << (8 * h->ntail);
        if (length < needed) {
            h->ntail += length;
            return;
        }
        h->v3 ^= h->tail;
        lh_sip_round(h);
        h->v0 ^= h->tail;
        h->ntail = 0;
    }
    uint64_t len = length - needed;
    uint64_t left = len & 7;
    uint64_t i = needed;
    while (i < len - left) {
        uint64_t mi = lh_u8to64_le(msg + i, 8);
        h->v3 ^= mi;
        lh_sip_round(h);
        h->v0 ^= mi;
        i += 8;
    }
    h->tail = lh_u8to64_le(msg + i, left);
    h->ntail = left;
}

/* sip.rs Hasher::finish: 1 compression round per block, 3 to finish. */
uint64_t lust_sip13_finish(const lust_sip13 *h) {
    lust_sip13 s = *h;
    uint64_t b = ((s.length & 0xff) << 56) | s.tail;
    s.v3 ^= b;
    lh_sip_round(&s);
    s.v0 ^= b;
    s.v2 ^= 0xff;
    lh_sip_round(&s);
    lh_sip_round(&s);
    lh_sip_round(&s);
    return s.v0 ^ s.v1 ^ s.v2 ^ s.v3;
}

lust_random_state lust_random_state_new(void) {
    static uint64_t k0 = 0x6c75737473697031ull;
    lust_random_state r;
    r.k0 = k0++;
    r.k1 = 0x6861736862726f77ull;
    return r;
}

lust_fx_hasher lust_fx_new(void) {
    lust_fx_hasher h;
    h.hash = 0;
    return h;
}
lust_fx_hasher lust_fx_with_seed(uint64_t seed) {
    lust_fx_hasher h;
    h.hash = seed;
    return h;
}
static void lust_fx_add(lust_fx_hasher *h, uint64_t i) { h->hash = (h->hash + i) * LUST_FX_K; }

/* multiply_mix: the full 64x64->128 product, low half XOR high half.
   Done with 32-bit parts so tcc (no __int128) gets the same bits. */
static uint64_t lust_fx_multiply_mix(uint64_t x, uint64_t y) {
    uint64_t lo = x * y;
    uint64_t xlo = x & 0xFFFFFFFFull, xhi = x >> 32;
    uint64_t ylo = y & 0xFFFFFFFFull, yhi = y >> 32;
    uint64_t ll = xlo * ylo, lh = xlo * yhi, hl = xhi * ylo, hh = xhi * yhi;
    uint64_t cross = (ll >> 32) + (lh & 0xFFFFFFFFull) + (hl & 0xFFFFFFFFull);
    uint64_t hi = hh + (lh >> 32) + (hl >> 32) + (cross >> 32);
    return lo ^ hi;
}

static uint64_t lust_fx_read_le64(const uint8_t *p) {
    uint64_t v = 0;
    for (int i = 7; i >= 0; i--) v = (v << 8) | p[i];
    return v;
}
static uint64_t lust_fx_read_le32(const uint8_t *p) {
    return (uint64_t)p[0] | ((uint64_t)p[1] << 8) | ((uint64_t)p[2] << 16) | ((uint64_t)p[3] << 24);
}

uint64_t lust_fx_hash_bytes(const void *bytes, uint64_t len) {
    const uint8_t *b = (const uint8_t *)bytes;
    uint64_t s0 = LUST_FX_SEED1, s1 = LUST_FX_SEED2;
    if (len <= 16) {
        if (len >= 8) {
            s0 ^= lust_fx_read_le64(b);
            s1 ^= lust_fx_read_le64(b + len - 8);
        } else if (len >= 4) {
            s0 ^= lust_fx_read_le32(b);
            s1 ^= lust_fx_read_le32(b + len - 4);
        } else if (len > 0) {
            s0 ^= b[0];
            s1 ^= ((uint64_t)b[len - 1] << 8) | b[len / 2];
        }
    } else {
        uint64_t bulk_len = len - 1;
        uint64_t i = 0;
        while (bulk_len - i >= 16) {
            uint64_t x = lust_fx_read_le64(b + i);
            uint64_t y = lust_fx_read_le64(b + i + 8);
            uint64_t t = lust_fx_multiply_mix(s0 ^ x, LUST_FX_PREVENT_ZERO ^ y);
            s0 = s1;
            s1 = t;
            i += 16;
        }
        s0 ^= lust_fx_read_le64(b + len - 16);
        s1 ^= lust_fx_read_le64(b + len - 8);
    }
    return lust_fx_multiply_mix(s0, s1) ^ len;
}

void lust_fx_write(lust_fx_hasher *h, const void *bytes, uint64_t len) {
    lust_fx_write_u64(h, lust_fx_hash_bytes(bytes, len));
}
void lust_fx_write_u8(lust_fx_hasher *h, uint8_t v) { lust_fx_add(h, v); }
void lust_fx_write_u16(lust_fx_hasher *h, uint16_t v) { lust_fx_add(h, v); }
void lust_fx_write_u32(lust_fx_hasher *h, uint32_t v) { lust_fx_add(h, v); }
void lust_fx_write_u64(lust_fx_hasher *h, uint64_t v) { lust_fx_add(h, v); }
void lust_fx_write_u128(lust_fx_hasher *h, uint64_t lo, uint64_t hi) {
    lust_fx_add(h, lo);
    lust_fx_add(h, hi);
}
void lust_fx_write_usize(lust_fx_hasher *h, uint64_t v) { lust_fx_add(h, v); }
void lust_fx_write_i8(lust_fx_hasher *h, int8_t v) { lust_fx_write_u8(h, (uint8_t)v); }
void lust_fx_write_i16(lust_fx_hasher *h, int16_t v) { lust_fx_write_u16(h, (uint16_t)v); }
void lust_fx_write_i32(lust_fx_hasher *h, int32_t v) { lust_fx_write_u32(h, (uint32_t)v); }
void lust_fx_write_i64(lust_fx_hasher *h, int64_t v) { lust_fx_write_u64(h, (uint64_t)v); }
void lust_fx_write_i128(lust_fx_hasher *h, uint64_t lo, uint64_t hi) { lust_fx_write_u128(h, lo, hi); }
void lust_fx_write_isize(lust_fx_hasher *h, int64_t v) { lust_fx_write_usize(h, (uint64_t)v); }
void lust_fx_write_length_prefix(lust_fx_hasher *h, uint64_t len) { lust_fx_write_usize(h, len); }
void lust_fx_write_str(lust_fx_hasher *h, const void *bytes, uint64_t len) {
    lust_fx_write(h, bytes, len);
    lust_fx_write_u8(h, 0xFF);
}
uint64_t lust_fx_finish(const lust_fx_hasher *h) { return (h->hash << 26) | (h->hash >> 38); }

uint64_t lust_fx_hash_u32(uint32_t v) {
    lust_fx_hasher h = lust_fx_new();
    lust_fx_write_u32(&h, v);
    return lust_fx_finish(&h);
}
uint64_t lust_fx_hash_u64(uint64_t v) {
    lust_fx_hasher h = lust_fx_new();
    lust_fx_write_u64(&h, v);
    return lust_fx_finish(&h);
}
uint64_t lust_fx_hash_usize(uint64_t v) {
    lust_fx_hasher h = lust_fx_new();
    lust_fx_write_usize(&h, v);
    return lust_fx_finish(&h);
}
uint64_t lust_fx_hash_str(const void *bytes, uint64_t len) {
    lust_fx_hasher h = lust_fx_new();
    lust_fx_write_str(&h, bytes, len);
    return lust_fx_finish(&h);
}

/* ---------------- IndexMap core (indexmap 2.14.0) ----------------
   A port of indexmap's inner::Core: a Vec of Bucket{hash, key, value}
   plus a hashbrown HashTable<usize> side index. Strategy choices that
   leave different side-table state (erase_indices, retain rebuild,
   entries capacity jumps) follow inner.rs; choices that only change how
   stored index values are found (increment/decrement_indices bulk vs
   per-entry updates) collapse to one scan here because the result is the
   same set of values in the same buckets. */

static void li_oob(void) {
    fputs("indexmap core: index out of bounds\n", stderr);
    abort();
}

/* Entry field offsets: fields ordered by alignment (largest first), in
   declaration order on ties, like the Rust layout of Bucket. Only the
   entry byte size can ever differ from a future lust layout engine;
   entry counts (what capacity() reports) do not depend on it. */
static void li_layout(lust_index_table *t, uint64_t ks, uint64_t ka, uint64_t vs, uint64_t va) {
    uint64_t sizes[3] = {8, ks, vs};
    uint64_t aligns[3] = {8, ka ? ka : 1, va ? va : 1};
    int order[3] = {0, 1, 2};
    for (int i = 0; i < 3; i++)
        for (int j = i + 1; j < 3; j++)
            if (aligns[order[j]] > aligns[order[i]]) {
                int tmp = order[i];
                order[i] = order[j];
                order[j] = tmp;
            }
    uint64_t offsets[3] = {0, 0, 0};
    uint64_t end = 0, max_align = 1;
    for (int i = 0; i < 3; i++) {
        int f = order[i];
        end = lh_align_up(end, aligns[f]);
        offsets[f] = end;
        end += sizes[f];
        if (aligns[f] > max_align) max_align = aligns[f];
    }
    t->hash_offset = offsets[0];
    t->key_offset = offsets[1];
    t->value_offset = offsets[2];
    t->key_size = ks;
    t->value_size = vs;
    t->entry_align = max_align;
    t->entry_size = lh_align_up(end, max_align);
}

static uint8_t *li_entry(const lust_index_table *t, uint64_t i) { return t->entries + i * t->entry_size; }
static void *li_key_ptr(const lust_index_table *t, uint64_t i) { return li_entry(t, i) + t->key_offset; }
static void *li_value_ptr(const lust_index_table *t, uint64_t i) { return li_entry(t, i) + t->value_offset; }
static uint64_t li_entry_hash_at(const lust_index_table *t, uint64_t i) {
    uint64_t h;
    memcpy(&h, li_entry(t, i) + t->hash_offset, 8);
    return h;
}
static void li_entry_set_hash(lust_index_table *t, uint64_t i, uint64_t h) {
    memcpy(li_entry(t, i) + t->hash_offset, &h, 8);
}
static uint64_t li_max_entries(const lust_index_table *t) { return (uint64_t)INT64_MAX / t->entry_size; }

/* The entries Vec, with Rust RawVec capacity rules for the paths
   indexmap uses: exact reserve, amortized reserve, exact shrink. */
static void li_entries_alloc(lust_index_table *t, uint64_t new_cap) {
    void *raw = NULL;
    uint8_t *base = NULL;
    if (new_cap) {
        if (new_cap > UINT64_MAX / t->entry_size) {
            lust_hash_capacity_overflow();
            return;
        }
        uint64_t bytes = new_cap * t->entry_size;
        raw = malloc((size_t)(bytes + t->entry_align));
        if (!raw) lust_oom_size(bytes); /* indexmap's entries Vec */
        base = (uint8_t *)lh_align_up((uint64_t)(uintptr_t)raw, t->entry_align);
        if (t->len) memcpy(base, t->entries, (size_t)(t->len * t->entry_size));
    }
    free(t->entries_alloc);
    t->entries_alloc = raw;
    t->entries = base;
    t->entries_cap = new_cap;
}
static int li_entries_try_reserve_exact(lust_index_table *t, uint64_t additional) {
    if (additional <= t->entries_cap - t->len) return 1;
    if (additional > UINT64_MAX - t->len) return 0;
    uint64_t needed = t->len + additional;
    if (needed > li_max_entries(t)) return 0;
    li_entries_alloc(t, needed);
    return 1;
}
static void li_entries_reserve_exact(lust_index_table *t, uint64_t additional) {
    if (!li_entries_try_reserve_exact(t, additional)) lust_hash_capacity_overflow();
}
static void li_entries_shrink_to(lust_index_table *t, uint64_t min_capacity) {
    if (t->entries_cap > min_capacity) {
        uint64_t target = t->len > min_capacity ? t->len : min_capacity;
        if (target < t->entries_cap) li_entries_alloc(t, target);
    }
}

/* Core::reserve_entries: jump the entries capacity to the side table
   capacity when that is more than asked for, else reserve exactly. */
static void li_reserve_entries(lust_index_table *t, uint64_t additional) {
    uint64_t icap = lust_hash_capacity(&t->indices);
    uint64_t try_cap = icap < li_max_entries(t) ? icap : li_max_entries(t);
    uint64_t try_add = try_cap - t->len;
    if (try_add > additional && li_entries_try_reserve_exact(t, try_add)) return;
    li_entries_reserve_exact(t, additional);
}

/* Side-table callbacks. The hash of a stored entry index sits in that
   entry. Modes cover the two rehash windows where stored indices and
   entry positions disagree:
   0: stored i -> entry i
   1: shift_insert: stored i -> entry (i < a ? i : i - 1)
   2: erase bulk rebuild: stored i (new position) -> entry (i < a ? i : i + b) */
typedef struct {
    lust_index_table *t;
    int mode;
    uint64_t a, b;
} li_hash_ctx;
static uint64_t li_hash_of(void *vctx, const void *elem) {
    li_hash_ctx *c = (li_hash_ctx *)vctx;
    uint64_t i;
    memcpy(&i, elem, 8);
    if (c->mode == 1) i = i < c->a ? i : i - 1;
    else if (c->mode == 2) i = i < c->a ? i : i + c->b;
    return li_entry_hash_at(c->t, i);
}
typedef struct {
    lust_index_table *t;
    lust_index_eq_fn eq;
    void *eq_ctx;
} li_eq_ctx;
static int li_eq_by_key(void *vctx, const void *elem) {
    li_eq_ctx *c = (li_eq_ctx *)vctx;
    uint64_t i;
    memcpy(&i, elem, 8);
    return c->eq(c->eq_ctx, li_key_ptr(c->t, i));
}
static int li_eq_by_index(void *vctx, const void *elem) {
    uint64_t want = *(uint64_t *)vctx;
    uint64_t i;
    memcpy(&i, elem, 8);
    return i == want;
}

/* inner::erase_index / update_index over the side table. */
static void li_erase_index(lust_index_table *t, uint64_t hash, uint64_t pos) {
    uint64_t bucket;
    if (lust_hash_find(&t->indices, hash, li_eq_by_index, &pos, &bucket)) lust_hash_erase_at(&t->indices, bucket, NULL);
}
static void li_update_index(lust_index_table *t, uint64_t hash, uint64_t old_pos, uint64_t new_pos) {
    void *slot = lust_hash_find(&t->indices, hash, li_eq_by_index, &old_pos, NULL);
    if (!slot) abort(); /* "index not found" in Rust */
    memcpy(slot, &new_pos, 8);
}

/* Mutates every stored index in [start, end) by delta (+1 or -1). */
static void li_shift_stored(lust_index_table *t, uint64_t start, uint64_t end, int delta) {
    lust_hash_iter it;
    lust_hash_iter_init(&it, &t->indices);
    void *slot;
    while ((slot = lust_hash_iter_next(&it, NULL)) != NULL) {
        uint64_t v;
        memcpy(&v, slot, 8);
        if (v >= start && v < end) {
            v = delta > 0 ? v + 1 : v - 1;
            memcpy(slot, &v, 8);
        }
    }
}

/* inner::insert_bulk_no_grow over one run of entries: inserts entry
   old positions [first_old, first_old+count) with their hashes, storing
   new positions first_new... in order. The caller guarantees room, so
   the hasher (mode-2 adjusted when rebuilding) is never rehashed with,
   exactly the unreachable hasher in indexmap. */
static void li_insert_bulk(lust_index_table *t, uint64_t first_old, uint64_t count, uint64_t first_new,
                           li_hash_ctx *hc) {
    for (uint64_t j = 0; j < count; j++) {
        uint64_t hash = li_entry_hash_at(t, first_old + j);
        void *slot = lust_hash_insert_unique_slot(&t->indices, hash, li_hash_of, hc, NULL);
        uint64_t v = first_new + j;
        memcpy(slot, &v, 8);
    }
}

void lust_index_rebuild(lust_index_table *t) {
    lust_hash_clear(&t->indices, NULL, NULL);
    li_hash_ctx hc = {t, 0, 0, 0};
    li_insert_bulk(t, 0, t->len, 0, &hc);
}

/* inner::Core::erase_indices: rewrites the side table for removing the
   entry range [start, end) before the entries themselves move. */
typedef struct {
    uint64_t start, end, offset;
} li_erase_retain_ctx;
static int li_erase_retain_keep(void *vctx, void *elem) {
    li_erase_retain_ctx *c = (li_erase_retain_ctx *)vctx;
    uint64_t v;
    memcpy(&v, elem, 8);
    if (v >= c->end) {
        v -= c->offset;
        memcpy(elem, &v, 8);
        return 1;
    }
    return v < c->start;
}
static void li_erase_indices(lust_index_table *t, uint64_t start, uint64_t end) {
    uint64_t erased = end - start;
    uint64_t shifted = t->len - end;
    uint64_t half = lust_hash_capacity(&t->indices) / 2;
    if (erased == 0) return;
    if (start + shifted < half && start < erased) {
        lust_hash_clear(&t->indices, NULL, NULL);
        li_hash_ctx hc = {t, 2, start, erased};
        li_insert_bulk(t, 0, start, 0, &hc);
        li_insert_bulk(t, end, shifted, start, &hc);
    } else if (erased + shifted < half) {
        for (uint64_t i = start; i < end; i++) li_erase_index(t, li_entry_hash_at(t, i), i);
        for (uint64_t j = 0; j < shifted; j++)
            li_update_index(t, li_entry_hash_at(t, end + j), end + j, start + j);
    } else {
        li_erase_retain_ctx c = {start, end, erased};
        lust_hash_retain(&t->indices, li_erase_retain_keep, &c, NULL, NULL);
    }
}

void lust_index_init(lust_index_table *t, uint64_t key_size, uint64_t key_align, uint64_t value_size,
                     uint64_t value_align) {
    li_layout(t, key_size, key_align, value_size, value_align);
    lust_hash_init(&t->indices, 8, 8);
    t->entries = NULL;
    t->entries_alloc = NULL;
    t->len = 0;
    t->entries_cap = 0;
}
void lust_index_init_with_capacity(lust_index_table *t, uint64_t key_size, uint64_t key_align, uint64_t value_size,
                                   uint64_t value_align, uint64_t capacity) {
    li_layout(t, key_size, key_align, value_size, value_align);
    lust_hash_init_with_capacity(&t->indices, 8, 8, capacity);
    t->entries = NULL;
    t->entries_alloc = NULL;
    t->len = 0;
    t->entries_cap = 0;
    if (capacity) li_entries_alloc(t, capacity);
}

static void li_drop_one(lust_index_table *t, uint64_t i, lust_index_drop_fn drop, void *ctx) {
    if (drop) drop(ctx, li_key_ptr(t, i), li_value_ptr(t, i));
}

void lust_index_drop_table(lust_index_table *t, lust_index_drop_fn drop, void *ctx) {
    for (uint64_t i = 0; i < t->len; i++) li_drop_one(t, i, drop, ctx);
    free(t->entries_alloc);
    t->entries_alloc = NULL;
    t->entries = NULL;
    t->len = 0;
    t->entries_cap = 0;
    lust_hash_drop_table(&t->indices, NULL, NULL);
}

uint64_t lust_index_len(const lust_index_table *t) { return t->len; }
uint64_t lust_index_capacity(const lust_index_table *t) {
    uint64_t ic = lust_hash_capacity(&t->indices);
    return ic < t->entries_cap ? ic : t->entries_cap;
}
int lust_index_is_empty(const lust_index_table *t) { return t->len == 0; }

int lust_index_get_index(const lust_index_table *t, uint64_t index, void **out_key, void **out_value) {
    if (index >= t->len) return 0;
    if (out_key) *out_key = li_key_ptr(t, index);
    if (out_value) *out_value = li_value_ptr(t, index);
    return 1;
}
void *lust_index_entry_mut(lust_index_table *t, uint64_t index) {
    if (index >= t->len) return NULL;
    return li_entry(t, index);
}
uint64_t lust_index_entry_hash(const lust_index_table *t, uint64_t index) { return li_entry_hash_at(t, index); }

uint64_t lust_index_get_index_of(const lust_index_table *t, uint64_t hash, lust_index_eq_fn eq, void *eq_ctx) {
    li_eq_ctx c = {(lust_index_table *)t, eq, eq_ctx};
    void *slot = lust_hash_find(&t->indices, hash, li_eq_by_key, &c, NULL);
    if (!slot) return UINT64_MAX;
    uint64_t v;
    memcpy(&v, slot, 8);
    return v;
}
int lust_index_get(const lust_index_table *t, uint64_t hash, lust_index_eq_fn eq, void *eq_ctx, void **out_key,
                   void **out_value, uint64_t *out_index) {
    uint64_t i = lust_index_get_index_of(t, hash, eq, eq_ctx);
    if (i == UINT64_MAX) return 0;
    if (out_key) *out_key = li_key_ptr(t, i);
    if (out_value) *out_value = li_value_ptr(t, i);
    if (out_index) *out_index = i;
    return 1;
}

/* Core::push_entry split in two: make room only when full, then claim
   the entry slot at the current len and set its hash word. */
static void li_push_entry_slot(lust_index_table *t, uint64_t hash, void **out_key, void **out_value) {
    if (t->len == t->entries_cap) li_reserve_entries(t, 1);
    uint64_t i = t->len++;
    li_entry_set_hash(t, i, hash);
    if (out_key) *out_key = li_key_ptr(t, i);
    if (out_value) *out_value = li_value_ptr(t, i);
}

uint64_t lust_index_insert_full(lust_index_table *t, uint64_t hash, lust_index_eq_fn eq, void *eq_ctx, int *out_replaced,
                                void **out_key_slot, void **out_value_slot) {
    li_eq_ctx ec = {t, eq, eq_ctx};
    li_hash_ctx hc = {t, 0, 0, 0};
    void *slot;
    uint64_t bidx;
    if (lust_hash_find_or_insert(&t->indices, hash, li_eq_by_key, &ec, li_hash_of, &hc, &slot, &bidx)) {
        uint64_t pos;
        memcpy(&pos, slot, 8);
        *out_replaced = 1;
        if (out_key_slot) *out_key_slot = li_key_ptr(t, pos);
        if (out_value_slot) *out_value_slot = li_value_ptr(t, pos);
        return pos;
    }
    *out_replaced = 0;
    uint64_t pos = t->len;
    void *islot = lust_hash_insert_at(&t->indices, hash, bidx);
    memcpy(islot, &pos, 8);
    li_push_entry_slot(t, hash, out_key_slot, out_value_slot);
    return pos;
}

uint64_t lust_index_insert_unique(lust_index_table *t, uint64_t hash, void **out_key_slot, void **out_value_slot) {
    uint64_t pos = lust_hash_len(&t->indices);
    li_hash_ctx hc = {t, 0, 0, 0};
    void *islot = lust_hash_insert_unique_slot(&t->indices, hash, li_hash_of, &hc, NULL);
    memcpy(islot, &pos, 8);
    li_push_entry_slot(t, hash, out_key_slot, out_value_slot);
    return pos;
}

void lust_index_shift_insert_unique(lust_index_table *t, uint64_t index, uint64_t hash, void **out_key_slot,
                                    void **out_value_slot) {
    uint64_t end = lust_hash_len(&t->indices);
    if (index > end) li_oob();
    li_shift_stored(t, index, end, +1);
    li_hash_ctx hc = {t, 1, index, 0};
    void *islot = lust_hash_insert_unique_slot(&t->indices, hash, li_hash_of, &hc, NULL);
    memcpy(islot, &index, 8);
    if (t->len == t->entries_cap) li_reserve_entries(t, 1);
    memmove(li_entry(t, index + 1), li_entry(t, index), (size_t)((t->len - index) * t->entry_size));
    t->len++;
    li_entry_set_hash(t, index, hash);
    if (out_key_slot) *out_key_slot = li_key_ptr(t, index);
    if (out_value_slot) *out_value_slot = li_value_ptr(t, index);
}

static void li_copy_out(lust_index_table *t, uint64_t i, void *out_key, void *out_value) {
    if (out_key && t->key_size) memcpy(out_key, li_key_ptr(t, i), (size_t)t->key_size);
    if (out_value && t->value_size) memcpy(out_value, li_value_ptr(t, i), (size_t)t->value_size);
}

static void li_swap_remove_finish(lust_index_table *t, uint64_t index, void *out_key, void *out_value) {
    li_copy_out(t, index, out_key, out_value);
    uint64_t last = t->len - 1;
    if (index != last) memcpy(li_entry(t, index), li_entry(t, last), (size_t)t->entry_size);
    t->len--;
    if (index < t->len) li_update_index(t, li_entry_hash_at(t, index), t->len, index);
}
static void li_shift_remove_finish(lust_index_table *t, uint64_t index, void *out_key, void *out_value) {
    li_shift_stored(t, index + 1, t->len, -1);
    li_copy_out(t, index, out_key, out_value);
    memmove(li_entry(t, index), li_entry(t, index + 1), (size_t)((t->len - index - 1) * t->entry_size));
    t->len--;
}

/* OccupiedEntry::remove on the side table by key; returns the position. */
static int li_remove_from_indices_by_key(lust_index_table *t, uint64_t hash, lust_index_eq_fn eq, void *eq_ctx,
                                         uint64_t *out_pos) {
    li_eq_ctx ec = {t, eq, eq_ctx};
    uint64_t bucket;
    void *slot = lust_hash_find(&t->indices, hash, li_eq_by_key, &ec, &bucket);
    if (!slot) return 0;
    memcpy(out_pos, slot, 8);
    lust_hash_erase_at(&t->indices, bucket, NULL);
    return 1;
}

int lust_index_swap_remove(lust_index_table *t, uint64_t hash, lust_index_eq_fn eq, void *eq_ctx, void *out_key,
                           void *out_value, uint64_t *out_index) {
    uint64_t pos;
    if (!li_remove_from_indices_by_key(t, hash, eq, eq_ctx, &pos)) return 0;
    li_swap_remove_finish(t, pos, out_key, out_value);
    if (out_index) *out_index = pos;
    return 1;
}
int lust_index_shift_remove(lust_index_table *t, uint64_t hash, lust_index_eq_fn eq, void *eq_ctx, void *out_key,
                            void *out_value, uint64_t *out_index) {
    uint64_t pos;
    if (!li_remove_from_indices_by_key(t, hash, eq, eq_ctx, &pos)) return 0;
    li_shift_remove_finish(t, pos, out_key, out_value);
    if (out_index) *out_index = pos;
    return 1;
}
int lust_index_swap_remove_index(lust_index_table *t, uint64_t index, void *out_key, void *out_value) {
    if (index >= t->len) return 0;
    li_erase_index(t, li_entry_hash_at(t, index), index);
    li_swap_remove_finish(t, index, out_key, out_value);
    return 1;
}
int lust_index_shift_remove_index(lust_index_table *t, uint64_t index, void *out_key, void *out_value) {
    if (index >= t->len) return 0;
    li_erase_index(t, li_entry_hash_at(t, index), index);
    li_shift_remove_finish(t, index, out_key, out_value);
    return 1;
}
int lust_index_pop(lust_index_table *t, void *out_key, void *out_value) {
    if (t->len == 0) return 0;
    uint64_t last = t->len - 1;
    uint64_t hash = li_entry_hash_at(t, last);
    li_copy_out(t, last, out_key, out_value);
    t->len--;
    li_erase_index(t, hash, t->len);
    return 1;
}

void lust_index_reserve(lust_index_table *t, uint64_t additional) {
    li_hash_ctx hc = {t, 0, 0, 0};
    lust_hash_reserve(&t->indices, additional, li_hash_of, &hc);
    if (additional > t->entries_cap - t->len) li_reserve_entries(t, additional);
}
void lust_index_reserve_exact(lust_index_table *t, uint64_t additional) {
    li_hash_ctx hc = {t, 0, 0, 0};
    lust_hash_reserve(&t->indices, additional, li_hash_of, &hc);
    li_entries_reserve_exact(t, additional);
}
void lust_index_shrink_to(lust_index_table *t, uint64_t min_capacity) {
    li_hash_ctx hc = {t, 0, 0, 0};
    lust_hash_shrink_to(&t->indices, min_capacity, li_hash_of, &hc);
    li_entries_shrink_to(t, min_capacity);
}
void lust_index_clear(lust_index_table *t, lust_index_drop_fn drop, void *ctx) {
    lust_hash_clear(&t->indices, NULL, NULL);
    for (uint64_t i = 0; i < t->len; i++) li_drop_one(t, i, drop, ctx);
    t->len = 0;
}
void lust_index_truncate(lust_index_table *t, uint64_t len, lust_index_drop_fn drop, void *ctx) {
    if (len >= t->len) return;
    li_erase_indices(t, len, t->len);
    for (uint64_t i = len; i < t->len; i++) li_drop_one(t, i, drop, ctx);
    t->len = len;
}
void lust_index_drain_range(lust_index_table *t, uint64_t start, uint64_t end, lust_index_drop_fn drop, void *ctx) {
    if (start > end || end > t->len) li_oob();
    li_erase_indices(t, start, end);
    for (uint64_t i = start; i < end; i++) li_drop_one(t, i, drop, ctx);
    memmove(li_entry(t, start), li_entry(t, end), (size_t)((t->len - end) * t->entry_size));
    t->len -= end - start;
}
void lust_index_retain(lust_index_table *t, lust_index_keep_fn keep, void *keep_ctx, lust_index_drop_fn drop,
                       void *drop_ctx) {
    uint64_t w = 0;
    for (uint64_t r = 0; r < t->len; r++) {
        if (keep(keep_ctx, li_key_ptr(t, r), li_value_ptr(t, r))) {
            if (w != r) memcpy(li_entry(t, w), li_entry(t, r), (size_t)t->entry_size);
            w++;
        } else {
            li_drop_one(t, r, drop, drop_ctx);
        }
    }
    int removed = w < t->len;
    t->len = w;
    if (removed && t->len < lust_hash_len(&t->indices)) lust_index_rebuild(t);
}
void lust_index_reverse(lust_index_table *t) {
    for (uint64_t i = 0; i < t->len / 2; i++) {
        uint8_t *a = li_entry(t, i);
        uint8_t *b = li_entry(t, t->len - 1 - i);
        for (uint64_t k = 0; k < t->entry_size; k++) {
            uint8_t tmp = a[k];
            a[k] = b[k];
            b[k] = tmp;
        }
    }
    lust_hash_iter it;
    lust_hash_iter_init(&it, &t->indices);
    void *slot;
    while ((slot = lust_hash_iter_next(&it, NULL)) != NULL) {
        uint64_t v;
        memcpy(&v, slot, 8);
        v = t->len - v - 1;
        memcpy(slot, &v, 8);
    }
}
void lust_index_swap_indices(lust_index_table *t, uint64_t a, uint64_t b) {
    if (a == b && a < t->len) return;
    if (a >= t->len || b >= t->len) li_oob();
    uint64_t ha = li_entry_hash_at(t, a), hb = li_entry_hash_at(t, b);
    li_update_index(t, ha, a, b);
    li_update_index(t, hb, b, a);
    uint8_t *ea = li_entry(t, a);
    uint8_t *eb = li_entry(t, b);
    for (uint64_t k = 0; k < t->entry_size; k++) {
        uint8_t tmp = ea[k];
        ea[k] = eb[k];
        eb[k] = tmp;
    }
}
void lust_index_move_index(lust_index_table *t, uint64_t from, uint64_t to) {
    if (from >= t->len || to >= t->len) li_oob();
    if (from == to) return;
    uint64_t hash = li_entry_hash_at(t, from);
    uint8_t *tmp = (uint8_t *)malloc((size_t)t->entry_size);
    if (!tmp) lust_oom();
    memcpy(tmp, li_entry(t, from), (size_t)t->entry_size);
    if (from < to) {
        li_shift_stored(t, from + 1, to + 1, -1);
        memmove(li_entry(t, from), li_entry(t, from + 1), (size_t)((to - from) * t->entry_size));
    } else {
        li_shift_stored(t, to, from, +1);
        memmove(li_entry(t, to + 1), li_entry(t, to), (size_t)((from - to) * t->entry_size));
    }
    memcpy(li_entry(t, to), tmp, (size_t)t->entry_size);
    free(tmp);
    li_update_index(t, hash, from, to);
}

#endif

#endif


/* Adapter crate cores, such as xxh3 (src/runtime/deps.h, W-DEPS). */
/* Adapter crate cores (docs/ARCH.md section 3.6, package W-DEPS): the C
   behind the adapter intrinsics of src/ty/lang.rs. Each one is exact
   with the upstream crate version its adapter pins. A `&[u8]` intrinsic
   argument (SigTy::Bytes) arrives here as a pointer and a length.

   Declarations here are in every unit; bodies (deps.c) only in the
   runtime unit (LUST_IMPL), like fmt.h. */
#ifndef LUST_RT_DEPS_H
#define LUST_RT_DEPS_H

/* memchr 2.8.2 adapter: the index of the first (memchr) or last
   (memrchr) byte equal to `needle`, or UINT64_MAX for none; memmem: the
   index of the first occurrence of the needle (0 for an empty needle),
   or UINT64_MAX. */
uint64_t lust_memchr(uint32_t needle, const uint8_t *p, uint64_t len);
uint64_t lust_memrchr(uint32_t needle, const uint8_t *p, uint64_t len);
uint64_t lust_memmem(const uint8_t *h, uint64_t hlen, const uint8_t *n, uint64_t nlen);
/* The first or last index of a byte equal to one of three needles, or UINT64_MAX. */
uint64_t lust_memchr3(uint32_t a, uint32_t b, uint32_t c, const uint8_t *p, uint64_t n);
uint64_t lust_memrchr3(uint32_t a, uint32_t b, uint32_t c, const uint8_t *p, uint64_t n);

/* XXH3 64-bit and 128-bit of `len` bytes, exact with xxhash-rust 0.8.15:
   xxh3_64 and xxh3_128 for seed 0, the _with_seed forms otherwise. */
uint64_t lust_xxh3_64(const uint8_t *p, uint64_t len, uint64_t seed);
lust_u128 lust_xxh3_128(const uint8_t *p, uint64_t len, uint64_t seed);

#ifdef LUST_IMPL
/* Bodies of the adapter crate cores declared in deps.h (W-DEPS). */
#include <string.h>

/* memchr through libc. A zero length never touches the pointer (an
   empty Rust slice may hold a dangling one). */
uint64_t lust_memchr(uint32_t needle, const uint8_t *p, uint64_t len) {
    const uint8_t *r = len ? (const uint8_t *)memchr(p, (int)(needle & 0xFFu), (size_t)len) : NULL;
    return r ? (uint64_t)(r - p) : UINT64_MAX;
}

/* memrchr is a GNU extension; a backward loop is portable. */
uint64_t lust_memrchr(uint32_t needle, const uint8_t *p, uint64_t len) {
    uint8_t b = (uint8_t)needle;
    while (len) {
        len--;
        if (p[len] == b) return len;
    }
    return UINT64_MAX;
}

#if !defined(__TINYC__) && defined(__x86_64__) && defined(__SSE2__)
/* Byte ranks for memmem's prefilter, 0 the rarest: the byte frequencies of TypeScript
   declarations (tsgo's bundled lib files) and Rust source, the text tsgo searches. */
static const uint8_t lust_mm_rank[256] = {
      0,   1,   2,   3,   4,   5,   6,   7,   8, 158, 245,   9,  10,  11,  12,  13,
     14,  15,  16,  17,  18,  19,  20,  21,  22,  23,  24,  25,  26,  27,  28,  29,
    255, 185, 208, 174, 161, 159, 204, 182, 232, 233, 226, 164, 230, 202, 234, 236,
    215, 197, 192, 183, 181, 176, 180, 172, 177, 173, 237, 225, 193, 219, 203, 175,
    163, 212, 187, 209, 206, 220, 198, 199, 179, 210, 171, 190, 201, 200, 217, 207,
    205, 162, 211, 223, 222, 184, 188, 189, 167, 165, 160, 195, 166, 194, 156, 242,
    216, 248, 228, 243, 244, 254, 240, 231, 235, 247, 186, 218, 246, 238, 251, 252,
    241, 178, 250, 249, 253, 239, 224, 221, 227, 229, 191, 214, 196, 213, 155,  30,
    168,  31, 157,  97, 112, 135, 153, 113, 144, 114,  32, 136, 146, 125,  33,  34,
    145,  35, 154, 138, 169,  98, 142, 134, 152, 115,  36,  37, 143, 116, 117, 139,
     38,  99,  39, 118,  40, 126, 147,  41, 100, 149,  42, 101, 127,  43,  44,  45,
    150, 120, 121, 102,  46,  47,  48,  49, 103, 104, 137, 128, 122, 129,  50, 130,
     51,  52, 141, 151, 148, 105,  53,  54,  55,  56,  57,  58, 131,  59,  60, 119,
     61,  62,  63,  64,  65,  66,  67,  68,  69,  70,  71,  72,  73,  74,  75,  76,
     77, 132, 170, 106, 107, 133, 108, 123, 109, 110,  78,  79,  80, 111,  81, 124,
    140,  82,  83,  84,  85,  86,  87,  88,  89,  90,  91,  92,  93,  94,  95,  96,
};
typedef char lust_mm_v16 __attribute__((vector_size(16)));
typedef char lust_mm_v16u __attribute__((vector_size(16), aligned(1)));
/* lust_memmem's block: starts i..i+15, the pair bytes compared at their offsets, then the
   needle at each start where both match (in order); the first match or UINT64_MAX. A
   2-byte needle's pair is the whole needle: a pair match is a match. */
static inline uint64_t lust_mm_block(const uint8_t *h, uint64_t i, uint64_t i1, uint64_t i2, lust_mm_v16 b1,
                                     lust_mm_v16 b2, const uint8_t *n, uint64_t nlen) {
    lust_mm_v16 e1 = *(const lust_mm_v16u *)(const void *)(h + i + i1) == b1;
    lust_mm_v16 e2 = *(const lust_mm_v16u *)(const void *)(h + i + i2) == b2;
    for (unsigned m = (unsigned)__builtin_ia32_pmovmskb128(e1 & e2); m; m &= m - 1) {
        uint64_t j = i + (uint64_t)__builtin_ctz(m);
        if (nlen == 2 || memcmp(h + j, n, (size_t)nlen) == 0) return j;
    }
    return UINT64_MAX;
}
#endif

/* memmem is a GNU extension too. The first match is the answer: candidates are tried in
   order. A clang or gcc build for x86_64 prefilters 16 candidate starts at a time on two
   bytes of the needle (the memchr crate's packed-pair idea: for a needle longer than 2,
   the bytes with the lowest `lust_mm_rank`, at their offsets), so the compare runs only
   where both match; the last block ends at the last start (it can overlap the block
   before: a start tried twice fails twice). It never reads past the haystack. Other builds
   take libc memchr for the first byte and memcmp to confirm. */
uint64_t lust_memmem(const uint8_t *h, uint64_t hlen, const uint8_t *n, uint64_t nlen) {
    if (nlen == 0) return 0;
    if (nlen > hlen) return UINT64_MAX;
    uint64_t last = hlen - nlen, i = 0;
#if !defined(__TINYC__) && defined(__x86_64__) && defined(__SSE2__)
    if (nlen >= 2 && last >= 16) {
        /* i1: the rarest byte; i2: the rarest other byte value (any other offset when
           the needle repeats one byte). */
        uint64_t i1 = 0, i2 = 1;
        if (nlen > 2) {
            for (uint64_t k = 1; k < nlen; k++)
                if (lust_mm_rank[n[k]] < lust_mm_rank[n[i1]]) i1 = k;
            i2 = i1 == 0 ? 1 : 0;
            int other = 0;
            for (uint64_t k = 0; k < nlen; k++)
                if (n[k] != n[i1] && (!other || lust_mm_rank[n[k]] < lust_mm_rank[n[i2]])) i2 = k, other = 1;
        }
        lust_mm_v16 b1 = (lust_mm_v16){0} + (char)n[i1], b2 = (lust_mm_v16){0} + (char)n[i2];
        /* Blocks at i < end, then the last one at end. The loads end at
           h + end + 15 + max(i1, i2) <= h + last + nlen - 1 = h + hlen - 1. */
        uint64_t end = last - 15, r;
        for (; i < end; i += 16)
            if ((r = lust_mm_block(h, i, i1, i2, b1, b2, n, nlen)) != UINT64_MAX) return r;
        return lust_mm_block(h, end, i1, i2, b1, b2, n, nlen);
    }
#endif
    while (i <= last) {
        const uint8_t *f = (const uint8_t *)memchr(h + i, n[0], (size_t)(last - i + 1));
        if (!f) return UINT64_MAX;
        i = (uint64_t)(f - h);
        if (memcmp(h + i, n, (size_t)nlen) == 0) return i;
        i++;
    }
    return UINT64_MAX;
}

/* The first (memchr3) or last (memrchr3) index of a byte equal to one of three needles,
   or UINT64_MAX: the memchr port's 2- and 3-needle searches and their iterators. A clang
   or gcc build for x86_64 tests 16 bytes a step (three compares, one mask), and the bytes
   left are one more block that ends at the slice's end (memrchr3: starts at its start),
   which may test bytes again: they hold no match, so the answer is the same. Other builds
   loop over the bytes. It never reads outside the n bytes. */
uint64_t lust_memchr3(uint32_t a, uint32_t b, uint32_t c, const uint8_t *p, uint64_t n) {
    uint64_t i = 0;
#if !defined(__TINYC__) && defined(__x86_64__) && defined(__SSE2__)
    if (n >= 16) {
        lust_mm_v16 va = (lust_mm_v16){0} + (char)a, vb = (lust_mm_v16){0} + (char)b, vc = (lust_mm_v16){0} + (char)c;
        for (; i + 16 <= n; i += 16) {
            lust_mm_v16 x = *(const lust_mm_v16u *)(const void *)(p + i);
            unsigned m = (unsigned)__builtin_ia32_pmovmskb128((x == va) | (x == vb) | (x == vc));
            if (m) return i + (uint64_t)__builtin_ctz(m);
        }
        if (i == n) return UINT64_MAX;
        lust_mm_v16 x = *(const lust_mm_v16u *)(const void *)(p + n - 16);
        unsigned m = (unsigned)__builtin_ia32_pmovmskb128((x == va) | (x == vb) | (x == vc));
        return m ? n - 16 + (uint64_t)__builtin_ctz(m) : UINT64_MAX;
    }
#endif
    for (; i < n; i++)
        if (p[i] == (uint8_t)a || p[i] == (uint8_t)b || p[i] == (uint8_t)c) return i;
    return UINT64_MAX;
}

uint64_t lust_memrchr3(uint32_t a, uint32_t b, uint32_t c, const uint8_t *p, uint64_t n) {
#if !defined(__TINYC__) && defined(__x86_64__) && defined(__SSE2__)
    if (n >= 16) {
        lust_mm_v16 va = (lust_mm_v16){0} + (char)a, vb = (lust_mm_v16){0} + (char)b, vc = (lust_mm_v16){0} + (char)c;
        uint64_t e = n;
        for (; e >= 16; e -= 16) {
            lust_mm_v16 x = *(const lust_mm_v16u *)(const void *)(p + e - 16);
            unsigned m = (unsigned)__builtin_ia32_pmovmskb128((x == va) | (x == vb) | (x == vc));
            if (m) return e - 16 + (uint64_t)(31 - __builtin_clz(m));
        }
        if (e == 0) return UINT64_MAX;
        lust_mm_v16 x = *(const lust_mm_v16u *)(const void *)p;
        unsigned m = (unsigned)__builtin_ia32_pmovmskb128((x == va) | (x == vb) | (x == vc));
        return m ? (uint64_t)(31 - __builtin_clz(m)) : UINT64_MAX;
    }
#endif
    while (n) {
        n--;
        if (p[n] == (uint8_t)a || p[n] == (uint8_t)b || p[n] == (uint8_t)c) return n;
    }
    return UINT64_MAX;
}

/* XXH3 one-shot hashes for the xxhash-rust 0.8.15 adapter. A scalar
   port of xxhash-rust's src/xxh3.rs (the default secret, seeded and
   unseeded forms); its SIMD paths compute the same values. No
   __int128: tcc lacks it, so the 64x64->128 product is built from
   32-bit halves. Inputs are read as little-endian bytes, so the result
   does not depend on the host. Gate: scripts/test-adapters.sh
   xxhash-rust (the real crate is the oracle). */

#define XXH_P32_1 0x9E3779B1u
#define XXH_P32_2 0x85EBCA77u
#define XXH_P32_3 0xC2B2AE3Du
#define XXH_P64_1 0x9E3779B185EBCA87ull
#define XXH_P64_2 0xC2B2AE3D27D4EB4Full
#define XXH_P64_3 0x165667B19E3779F9ull
#define XXH_P64_4 0x85EBCA77C2B2AE63ull
#define XXH_P64_5 0x27D4EB2F165667C5ull
#define XXH_SECRET_SIZE 192
#define XXH_SECRET_SIZE_MIN 136
#define XXH_STRIPE_LEN 64
#define XXH_CONSUME_RATE 8
#define XXH_MERGEACCS_START 11
#define XXH_LASTACC_START 7

static const uint8_t xxh_default_secret[XXH_SECRET_SIZE] = {
    0xb8, 0xfe, 0x6c, 0x39, 0x23, 0xa4, 0x4b, 0xbe, 0x7c, 0x01, 0x81, 0x2c, 0xf7, 0x21, 0xad, 0x1c,
    0xde, 0xd4, 0x6d, 0xe9, 0x83, 0x90, 0x97, 0xdb, 0x72, 0x40, 0xa4, 0xa4, 0xb7, 0xb3, 0x67, 0x1f,
    0xcb, 0x79, 0xe6, 0x4e, 0xcc, 0xc0, 0xe5, 0x78, 0x82, 0x5a, 0xd0, 0x7d, 0xcc, 0xff, 0x72, 0x21,
    0xb8, 0x08, 0x46, 0x74, 0xf7, 0x43, 0x24, 0x8e, 0xe0, 0x35, 0x90, 0xe6, 0x81, 0x3a, 0x26, 0x4c,
    0x3c, 0x28, 0x52, 0xbb, 0x91, 0xc3, 0x00, 0xcb, 0x88, 0xd0, 0x65, 0x8b, 0x1b, 0x53, 0x2e, 0xa3,
    0x71, 0x64, 0x48, 0x97, 0xa2, 0x0d, 0xf9, 0x4e, 0x38, 0x19, 0xef, 0x46, 0xa9, 0xde, 0xac, 0xd8,
    0xa8, 0xfa, 0x76, 0x3f, 0xe3, 0x9c, 0x34, 0x3f, 0xf9, 0xdc, 0xbb, 0xc7, 0xc7, 0x0b, 0x4f, 0x1d,
    0x8a, 0x51, 0xe0, 0x4b, 0xcd, 0xb4, 0x59, 0x31, 0xc8, 0x9f, 0x7e, 0xc9, 0xd9, 0x78, 0x73, 0x64,
    0xea, 0xc5, 0xac, 0x83, 0x34, 0xd3, 0xeb, 0xc3, 0xc5, 0x81, 0xa0, 0xff, 0xfa, 0x13, 0x63, 0xeb,
    0x17, 0x0d, 0xdd, 0x51, 0xb7, 0xf0, 0xda, 0x49, 0xd3, 0x16, 0x55, 0x26, 0x29, 0xd4, 0x68, 0x9e,
    0x2b, 0x16, 0xbe, 0x58, 0x7d, 0x47, 0xa1, 0xfc, 0x8f, 0xf8, 0xb8, 0xd1, 0x7a, 0xd0, 0x31, 0xce,
    0x45, 0xcb, 0x3a, 0x8f, 0x95, 0x16, 0x04, 0x28, 0xaf, 0xd7, 0xfb, 0xca, 0xbb, 0x4b, 0x40, 0x7e,
};

static uint32_t xxh_r32(const uint8_t *p) {
    return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24;
}

static uint64_t xxh_r64(const uint8_t *p) {
    return (uint64_t)xxh_r32(p) | (uint64_t)xxh_r32(p + 4) << 32;
}

static uint32_t xxh_swap32(uint32_t x) {
    return (x >> 24) | ((x >> 8) & 0xff00u) | ((x << 8) & 0xff0000u) | (x << 24);
}

static uint64_t xxh_swap64(uint64_t x) {
    return (uint64_t)xxh_swap32((uint32_t)x) << 32 | xxh_swap32((uint32_t)(x >> 32));
}

static uint64_t xxh_rotl64(uint64_t x, int r) { return (x << r) | (x >> (64 - r)); }
static uint32_t xxh_rotl32(uint32_t x, int r) { return (x << r) | (x >> (32 - r)); }

/* The full 128-bit product of two u64 values. */
static void xxh_mul128(uint64_t a, uint64_t b, uint64_t *lo, uint64_t *hi) {
    uint64_t a_lo = (uint32_t)a, a_hi = a >> 32, b_lo = (uint32_t)b, b_hi = b >> 32;
    uint64_t lo_lo = a_lo * b_lo, hi_lo = a_hi * b_lo, lo_hi = a_lo * b_hi, hi_hi = a_hi * b_hi;
    uint64_t cross = (lo_lo >> 32) + (uint32_t)hi_lo + lo_hi;
    *hi = (hi_lo >> 32) + (cross >> 32) + hi_hi;
    *lo = (cross << 32) | (uint32_t)lo_lo;
}

static uint64_t xxh_fold64(uint64_t a, uint64_t b) {
    uint64_t lo, hi;
    xxh_mul128(a, b, &lo, &hi);
    return lo ^ hi;
}

static uint64_t xxh_xorshift(uint64_t v, int s) { return v ^ (v >> s); }

static uint64_t xxh3_avalanche(uint64_t v) {
    v = xxh_xorshift(v, 37) * 0x165667919E3779F9ull;
    return xxh_xorshift(v, 32);
}

static uint64_t xxh64_avalanche(uint64_t v) {
    v ^= v >> 33;
    v *= XXH_P64_2;
    v ^= v >> 29;
    v *= XXH_P64_3;
    return v ^ (v >> 32);
}

static uint64_t xxh_strong_avalanche(uint64_t v, uint64_t len) {
    v ^= xxh_rotl64(v, 49) ^ xxh_rotl64(v, 24);
    v *= 0x9FB21C651E98DF25ull;
    v ^= (v >> 35) + len;
    v *= 0x9FB21C651E98DF25ull;
    return xxh_xorshift(v, 28);
}

static uint64_t xxh_mix16(const uint8_t *in, const uint8_t *sec, uint64_t seed) {
    uint64_t lo = xxh_r64(in) ^ (xxh_r64(sec) + seed);
    uint64_t hi = xxh_r64(in + 8) ^ (xxh_r64(sec + 8) - seed);
    return xxh_fold64(lo, hi);
}

static void xxh_mix32(uint64_t *lo, uint64_t *hi, const uint8_t *in1, const uint8_t *in2, const uint8_t *sec, uint64_t seed) {
    *lo += xxh_mix16(in1, sec, seed);
    *lo ^= xxh_r64(in2) + xxh_r64(in2 + 8);
    *hi += xxh_mix16(in2, sec + 16, seed);
    *hi ^= xxh_r64(in1) + xxh_r64(in1 + 8);
}

/* The default secret with `seed` added to the low and subtracted from
   the high u64 of each 16-byte pair (custom_default_secret). */
static void xxh_seeded_secret(uint64_t seed, uint8_t *out) {
    for (int i = 0; i < XXH_SECRET_SIZE; i += 16) {
        uint64_t lo = xxh_r64(xxh_default_secret + i) + seed, hi = xxh_r64(xxh_default_secret + i + 8) - seed;
        for (int b = 0; b < 8; b++) {
            out[i + b] = (uint8_t)(lo >> (8 * b));
            out[i + 8 + b] = (uint8_t)(hi >> (8 * b));
        }
    }
}

static void xxh_accumulate512(uint64_t *acc, const uint8_t *in, const uint8_t *sec) {
    for (int i = 0; i < 8; i++) {
        uint64_t v = xxh_r64(in + 8 * i), k = v ^ xxh_r64(sec + 8 * i);
        acc[i ^ 1] += v;
        acc[i] += (uint64_t)(uint32_t)k * (k >> 32);
    }
}

static void xxh_scramble(uint64_t *acc, const uint8_t *sec) {
    for (int i = 0; i < 8; i++) {
        acc[i] = (xxh_xorshift(acc[i], 47) ^ xxh_r64(sec + 8 * i)) * XXH_P32_1;
    }
}

/* hash_long_internal_loop over a 192-byte secret. */
static void xxh_long_loop(uint64_t *acc, const uint8_t *in, uint64_t len, const uint8_t *sec) {
    uint64_t stripes = (XXH_SECRET_SIZE - XXH_STRIPE_LEN) / XXH_CONSUME_RATE;
    uint64_t block = XXH_STRIPE_LEN * stripes, blocks = (len - 1) / block;
    for (uint64_t b = 0; b < blocks; b++) {
        for (uint64_t s = 0; s < stripes; s++) xxh_accumulate512(acc, in + b * block + s * XXH_STRIPE_LEN, sec + s * XXH_CONSUME_RATE);
        xxh_scramble(acc, sec + XXH_SECRET_SIZE - XXH_STRIPE_LEN);
    }
    uint64_t last = ((len - 1) - block * blocks) / XXH_STRIPE_LEN;
    for (uint64_t s = 0; s < last; s++) xxh_accumulate512(acc, in + blocks * block + s * XXH_STRIPE_LEN, sec + s * XXH_CONSUME_RATE);
    xxh_accumulate512(acc, in + len - XXH_STRIPE_LEN, sec + XXH_SECRET_SIZE - XXH_STRIPE_LEN - XXH_LASTACC_START);
}

static uint64_t xxh_merge(const uint64_t *acc, const uint8_t *sec, uint64_t start) {
    uint64_t r = start;
    for (int i = 0; i < 4; i++) r += xxh_fold64(acc[2 * i] ^ xxh_r64(sec + 16 * i), acc[2 * i + 1] ^ xxh_r64(sec + 16 * i + 8));
    return xxh3_avalanche(r);
}

static void xxh_long_acc(uint64_t *acc, const uint8_t *in, uint64_t len, uint64_t seed, uint8_t *secret_buf, const uint8_t **sec) {
    static const uint64_t init[8] = {XXH_P32_3, XXH_P64_1, XXH_P64_2, XXH_P64_3, XXH_P64_4, XXH_P32_2, XXH_P64_5, XXH_P32_1};
    for (int i = 0; i < 8; i++) acc[i] = init[i];
    *sec = xxh_default_secret;
    if (seed != 0) {
        xxh_seeded_secret(seed, secret_buf);
        *sec = secret_buf;
    }
    xxh_long_loop(acc, in, len, *sec);
}

/* XXH3 64-bit of `len` bytes at `p` (seed 0 is xxh3_64). */
uint64_t lust_xxh3_64(const uint8_t *p, uint64_t len, uint64_t seed) {
    const uint8_t *s = xxh_default_secret;
    if (len == 0) return xxh64_avalanche(seed ^ (xxh_r64(s + 56) ^ xxh_r64(s + 64)));
    if (len <= 3) {
        uint32_t combo = (uint32_t)p[0] << 16 | (uint32_t)p[len >> 1] << 24 | (uint32_t)p[len - 1] | (uint32_t)len << 8;
        uint64_t flip = (uint64_t)(xxh_r32(s) ^ xxh_r32(s + 4)) + seed;
        return xxh64_avalanche((uint64_t)combo ^ flip);
    }
    if (len <= 8) {
        uint64_t sd = seed ^ (uint64_t)xxh_swap32((uint32_t)seed) << 32;
        uint64_t flip = (xxh_r64(s + 8) ^ xxh_r64(s + 16)) - sd;
        uint64_t in64 = (uint64_t)xxh_r32(p + len - 4) + ((uint64_t)xxh_r32(p) << 32);
        return xxh_strong_avalanche(in64 ^ flip, len);
    }
    if (len <= 16) {
        uint64_t flip1 = (xxh_r64(s + 24) ^ xxh_r64(s + 32)) + seed, flip2 = (xxh_r64(s + 40) ^ xxh_r64(s + 48)) - seed;
        uint64_t lo = xxh_r64(p) ^ flip1, hi = xxh_r64(p + len - 8) ^ flip2;
        return xxh3_avalanche(len + xxh_swap64(lo) + hi + xxh_fold64(lo, hi));
    }
    if (len <= 128) {
        uint64_t acc = len * XXH_P64_1;
        if (len > 32) {
            if (len > 64) {
                if (len > 96) {
                    acc += xxh_mix16(p + 48, s + 96, seed);
                    acc += xxh_mix16(p + len - 64, s + 112, seed);
                }
                acc += xxh_mix16(p + 32, s + 64, seed);
                acc += xxh_mix16(p + len - 48, s + 80, seed);
            }
            acc += xxh_mix16(p + 16, s + 32, seed);
            acc += xxh_mix16(p + len - 32, s + 48, seed);
        }
        acc += xxh_mix16(p, s, seed);
        acc += xxh_mix16(p + len - 16, s + 16, seed);
        return xxh3_avalanche(acc);
    }
    if (len <= 240) {
        uint64_t acc = len * XXH_P64_1, rounds = len / 16, i = 0;
        for (; i < 8; i++) acc += xxh_mix16(p + 16 * i, s + 16 * i, seed);
        acc = xxh3_avalanche(acc);
        for (; i < rounds; i++) acc += xxh_mix16(p + 16 * i, s + 16 * (i - 8) + 3, seed);
        acc += xxh_mix16(p + len - 16, s + XXH_SECRET_SIZE_MIN - 17, seed);
        return xxh3_avalanche(acc);
    }
    uint64_t acc[8];
    uint8_t buf[XXH_SECRET_SIZE];
    const uint8_t *sec;
    xxh_long_acc(acc, p, len, seed, buf, &sec);
    return xxh_merge(acc, sec + XXH_MERGEACCS_START, len * XXH_P64_1);
}

/* XXH3 128-bit of `len` bytes at `p` (seed 0 is xxh3_128). */
lust_u128 lust_xxh3_128(const uint8_t *p, uint64_t len, uint64_t seed) {
    const uint8_t *s = xxh_default_secret;
    lust_u128 r;
    if (len == 0) {
        r.lo = xxh64_avalanche(seed ^ (xxh_r64(s + 64) ^ xxh_r64(s + 72)));
        r.hi = xxh64_avalanche(seed ^ (xxh_r64(s + 80) ^ xxh_r64(s + 88)));
        return r;
    }
    if (len <= 3) {
        uint32_t lo32 = (uint32_t)p[0] << 16 | (uint32_t)p[len >> 1] << 24 | (uint32_t)p[len - 1] | (uint32_t)len << 8;
        uint32_t hi32 = xxh_rotl32(xxh_swap32(lo32), 13);
        uint64_t flip_lo = ((uint64_t)xxh_r32(s) ^ xxh_r32(s + 4)) + seed, flip_hi = ((uint64_t)xxh_r32(s + 8) ^ xxh_r32(s + 12)) - seed;
        r.lo = xxh64_avalanche((uint64_t)lo32 ^ flip_lo);
        r.hi = xxh64_avalanche((uint64_t)hi32 ^ flip_hi);
        return r;
    }
    if (len <= 8) {
        uint64_t sd = seed ^ (uint64_t)xxh_swap32((uint32_t)seed) << 32;
        uint64_t in64 = (uint64_t)xxh_r32(p) + ((uint64_t)xxh_r32(p + len - 4) << 32);
        uint64_t flip = (xxh_r64(s + 16) ^ xxh_r64(s + 24)) + sd, lo, hi;
        xxh_mul128(in64 ^ flip, XXH_P64_1 + (len << 2), &lo, &hi);
        hi += lo << 1;
        lo ^= hi >> 3;
        lo = xxh_xorshift(lo, 35) * 0x9FB21C651E98DF25ull;
        r.lo = xxh_xorshift(lo, 28);
        r.hi = xxh3_avalanche(hi);
        return r;
    }
    if (len <= 16) {
        uint64_t flip_lo = (xxh_r64(s + 32) ^ xxh_r64(s + 40)) - seed, flip_hi = (xxh_r64(s + 48) ^ xxh_r64(s + 56)) + seed;
        uint64_t in_lo = xxh_r64(p), in_hi = xxh_r64(p + len - 8), m_lo, m_hi, r_lo, r_hi;
        xxh_mul128(in_lo ^ in_hi ^ flip_lo, XXH_P64_1, &m_lo, &m_hi);
        m_lo += (len - 1) << 54;
        in_hi ^= flip_hi;
        m_hi += in_hi + (uint64_t)(uint32_t)in_hi * (XXH_P32_2 - 1);
        m_lo ^= xxh_swap64(m_hi);
        xxh_mul128(m_lo, XXH_P64_2, &r_lo, &r_hi);
        r_hi += m_hi * XXH_P64_2;
        r.lo = xxh3_avalanche(r_lo);
        r.hi = xxh3_avalanche(r_hi);
        return r;
    }
    if (len <= 240) {
        uint64_t lo = len * XXH_P64_1, hi = 0;
        if (len <= 128) {
            if (len > 32) {
                if (len > 64) {
                    if (len > 96) xxh_mix32(&lo, &hi, p + 48, p + len - 64, s + 96, seed);
                    xxh_mix32(&lo, &hi, p + 32, p + len - 48, s + 64, seed);
                }
                xxh_mix32(&lo, &hi, p + 16, p + len - 32, s + 32, seed);
            }
            xxh_mix32(&lo, &hi, p, p + len - 16, s, seed);
        } else {
            uint64_t rounds = len / 32, i = 0;
            for (; i < 4; i++) xxh_mix32(&lo, &hi, p + 32 * i, p + 32 * i + 16, s + 32 * i, seed);
            lo = xxh3_avalanche(lo);
            hi = xxh3_avalanche(hi);
            for (; i < rounds; i++) xxh_mix32(&lo, &hi, p + 32 * i, p + 32 * i + 16, s + 3 + 32 * (i - 4), seed);
            xxh_mix32(&lo, &hi, p + len - 16, p + len - 32, s + XXH_SECRET_SIZE_MIN - 17 - 16, 0 - seed);
        }
        r.lo = xxh3_avalanche(lo + hi);
        r.hi = 0 - xxh3_avalanche(lo * XXH_P64_1 + hi * XXH_P64_4 + (len - seed) * XXH_P64_2);
        return r;
    }
    uint64_t acc[8];
    uint8_t buf[XXH_SECRET_SIZE];
    const uint8_t *sec;
    xxh_long_acc(acc, p, len, seed, buf, &sec);
    r.lo = xxh_merge(acc, sec + XXH_MERGEACCS_START, len * XXH_P64_1);
    r.hi = xxh_merge(acc, sec + XXH_SECRET_SIZE - 64 - XXH_MERGEACCS_START, ~(len * XXH_P64_2));
    return r;
}

#endif

#endif


/* ---------- Atomics, threads, and sync (W-THREADS, ARCH 7.3) ----------

   Every atomic access in a lust program goes through these functions, so
   generated code holds no atomic syntax: tcc and gcc compile the same
   plain calls. The bodies use the __atomic builtins both compilers have
   (tcc lowers them to calls into libtcc1's lock-prefixed helpers).

   Orderings arrive as Rust's `atomic::Ordering` discriminant: 0 Relaxed,
   1 Release, 2 Acquire, 3 AcqRel, 4 SeqCst. The functions panic with
   core's messages for the orderings Rust's methods reject at run time
   (rustc rejects the same orderings at compile time when they are
   written as the variant itself; check/sync.rs gives L0542 there). */

/* Rust's Ordering to the C11 memory order. */
#define LUST_MO(o) ((o) == 0 ? 0 : (o) == 1 ? 3 : (o) == 2 ? 2 : (o) == 3 ? 4 : 5)
/* The order a compare-exchange uses on success: never weaker than its
   failure order (C11 asks for that; a stronger order is always correct). */
#define LUST_MO_CAS(s, f) (((f) == 4) ? 5 : ((f) == 2 && ((s) == 0 || (s) == 1)) ? ((s) == 0 ? 2 : 4) : LUST_MO(s))
/* The failure order of a compare-exchange loop that implements an RMW with
   order `o`: the load half of `o`. */
#define LUST_MO_LOADPART(o) ((o) == 4 ? 5 : ((o) == 2 || (o) == 3) ? 2 : 0)

#ifdef LUST_IMPL
#ifdef __TINYC__
/* tcc has no fence builtins: libtcc1 provides these two (stdatomic.h). */
extern void atomic_thread_fence(int);
extern void atomic_signal_fence(int);
#define LUST_THREAD_FENCE(o) atomic_thread_fence(o)
#define LUST_SIGNAL_FENCE(o) atomic_signal_fence(o)
#else
#define LUST_THREAD_FENCE(o) __atomic_thread_fence(o)
#define LUST_SIGNAL_FENCE(o) __atomic_signal_fence(o)
#endif
#endif

/* Ordering panics come from core's atomic.rs (no track_caller), as rustc
   1.99 reports them; `weak` picks compare_exchange_weak's lines. The
   load and store `loc` params stay for the call shape. */
#define LUST_ATOMIC_RS "core/src/sync/atomic.rs:"

#define LUST_ATOMIC_WIDTH(N, U, S)                                                                                     \
    U lust_at_load_##N(U *p, uint32_t o, lust_loc loc) LUST_BODY({                                                    \
        if (o == 1) lust_panic_std_lit("there is no such thing as a release load", LUST_ATOMIC_RS "3997:24");                                       \
        if (o == 3) lust_panic_std_lit("there is no such thing as an acquire-release load", LUST_ATOMIC_RS "3998:23");                        \
        U r;                                                                                                           \
        __atomic_load(p, &r, LUST_MO(o));                                                                              \
        return r;                                                                                                      \
    })                                                                                                                 \
    void lust_at_store_##N(U *p, U v, uint32_t o, lust_loc loc) LUST_BODY({                                           \
        if (o == 2) { lust_panic_std_lit("there is no such thing as an acquire store", LUST_ATOMIC_RS "3981:24"); return; }                       \
        if (o == 3) { lust_panic_std_lit("there is no such thing as an acquire-release store", LUST_ATOMIC_RS "3982:23"); return; }           \
        __atomic_store(p, &v, LUST_MO(o));                                                                             \
    })                                                                                                                 \
    U lust_at_swap_##N(U *p, U v, uint32_t o) LUST_BODY({                                                             \
        U r;                                                                                                           \
        __atomic_exchange(p, &v, &r, LUST_MO(o));                                                                      \
        return r;                                                                                                      \
    })                                                                                                                 \
    int lust_at_cas_##N(U *p, U cur, U nv, uint32_t s, uint32_t f, U *old, int weak) LUST_BODY({                      \
        if (f == 3 || f == 1) {                                                                                        \
            if (f == 3) lust_panic_std_lit("there is no such thing as an acquire-release failure ordering", weak ? LUST_ATOMIC_RS "4184:28" : LUST_ATOMIC_RS "4118:28"); \
            else lust_panic_std_lit("there is no such thing as a release failure ordering", weak ? LUST_ATOMIC_RS "4185:29" : LUST_ATOMIC_RS "4119:29"); \
            *old = cur;                                                                                                \
            return 0;                                                                                                  \
        }                                                                                                              \
        U e = cur;                                                                                                     \
        int ok = __atomic_compare_exchange(p, &e, &nv, 0, LUST_MO_CAS(s, f), LUST_MO(f));                              \
        *old = e;                                                                                                      \
        return ok;                                                                                                     \
    })                                                                                                                 \
    U lust_at_fetch_add_##N(U *p, U v, uint32_t o) LUST_BODY({ return __atomic_fetch_add(p, v, LUST_MO(o)); })        \
    U lust_at_fetch_sub_##N(U *p, U v, uint32_t o) LUST_BODY({ return __atomic_fetch_sub(p, v, LUST_MO(o)); })        \
    U lust_at_fetch_and_##N(U *p, U v, uint32_t o) LUST_BODY({ return __atomic_fetch_and(p, v, LUST_MO(o)); })        \
    U lust_at_fetch_or_##N(U *p, U v, uint32_t o) LUST_BODY({ return __atomic_fetch_or(p, v, LUST_MO(o)); })          \
    U lust_at_fetch_xor_##N(U *p, U v, uint32_t o) LUST_BODY({ return __atomic_fetch_xor(p, v, LUST_MO(o)); })        \
    U lust_at_fetch_nand_##N(U *p, U v, uint32_t o) LUST_BODY({                                                       \
        U cur;                                                                                                         \
        __atomic_load(p, &cur, 0);                                                                                     \
        for (;;) {                                                                                                     \
            U nv = (U) ~(cur & v);                                                                                     \
            if (__atomic_compare_exchange(p, &cur, &nv, 1, LUST_MO(o), LUST_MO_LOADPART(o))) return cur;               \
        }                                                                                                              \
    })                                                                                                                 \
    U lust_at_fetch_umax_##N(U *p, U v, uint32_t o) LUST_BODY({                                                       \
        U cur;                                                                                                         \
        __atomic_load(p, &cur, 0);                                                                                     \
        for (;;) {                                                                                                     \
            U nv = cur > v ? cur : v;                                                                                  \
            if (__atomic_compare_exchange(p, &cur, &nv, 1, LUST_MO(o), LUST_MO_LOADPART(o))) return cur;               \
        }                                                                                                              \
    })                                                                                                                 \
    U lust_at_fetch_umin_##N(U *p, U v, uint32_t o) LUST_BODY({                                                       \
        U cur;                                                                                                         \
        __atomic_load(p, &cur, 0);                                                                                     \
        for (;;) {                                                                                                     \
            U nv = cur < v ? cur : v;                                                                                  \
            if (__atomic_compare_exchange(p, &cur, &nv, 1, LUST_MO(o), LUST_MO_LOADPART(o))) return cur;               \
        }                                                                                                              \
    })                                                                                                                 \
    U lust_at_fetch_smax_##N(U *p, U v, uint32_t o) LUST_BODY({                                                       \
        U cur;                                                                                                         \
        __atomic_load(p, &cur, 0);                                                                                     \
        for (;;) {                                                                                                     \
            U nv = (S)cur > (S)v ? cur : v;                                                                            \
            if (__atomic_compare_exchange(p, &cur, &nv, 1, LUST_MO(o), LUST_MO_LOADPART(o))) return cur;               \
        }                                                                                                              \
    })                                                                                                                 \
    U lust_at_fetch_smin_##N(U *p, U v, uint32_t o) LUST_BODY({                                                       \
        U cur;                                                                                                         \
        __atomic_load(p, &cur, 0);                                                                                     \
        for (;;) {                                                                                                     \
            U nv = (S)cur < (S)v ? cur : v;                                                                            \
            if (__atomic_compare_exchange(p, &cur, &nv, 1, LUST_MO(o), LUST_MO_LOADPART(o))) return cur;               \
        }                                                                                                              \
    })

LUST_ATOMIC_WIDTH(1, uint8_t, int8_t)
LUST_ATOMIC_WIDTH(2, uint16_t, int16_t)
LUST_ATOMIC_WIDTH(4, uint32_t, int32_t)
LUST_ATOMIC_WIDTH(8, uint64_t, int64_t)

/* `AtomicBool::fetch_nand`, as core writes it: `fetch_xor(true)` when
   `v` is true (a nand with true is a not), else `swap(true)`. */
uint8_t lust_at_fetch_bnand_1(uint8_t *p, uint8_t v, uint32_t o) LUST_BODY({
    return v ? lust_at_fetch_xor_1(p, 1, o) : lust_at_swap_1(p, 1, o);
})

void lust_at_fence(uint32_t o, lust_loc loc) LUST_BODY({
    (void)loc;
    if (o == 0) lust_panic_std_lit("there is no such thing as a relaxed fence", LUST_ATOMIC_RS "4497:24");
    LUST_THREAD_FENCE(LUST_MO(o));
})

void lust_at_compiler_fence(uint32_t o, lust_loc loc) LUST_BODY({
    (void)loc;
    if (o == 0) lust_panic_std_lit("there is no such thing as a relaxed fence", LUST_ATOMIC_RS "4582:24");
    LUST_SIGNAL_FENCE(LUST_MO(o));
})

/* ---------- Arc and sync::Weak ----------

   An `Arc<T>` points at the same counted header as an `Rc<T>` (`RcI_T`:
   `strong`, `weak`, then the value), but every count changes atomically,
   as alloc::sync does. `weak` counts the Weaks plus one implicit weak
   held by all the strong refs together. `get_mut`'s uniqueness test
   locks the weak count (UINT64_MAX) for a moment; `downgrade` waits it
   out. These functions take the header as `uint64_t *h`: h[0] is
   `strong`, h[1] is `weak`. */

/* Adds one to a count. Rust aborts when a count passes isize::MAX. */
void lust_arc_inc(uint64_t *c) LUST_BODY({
    if (__atomic_fetch_add(c, 1, 0) > (uint64_t)INT64_MAX) abort();
})

/* Takes one from a count; 1 when that was the last (with the acquire
   fence Rust's drop takes before it frees). */
int lust_arc_dec(uint64_t *c) LUST_BODY({
    if (__atomic_fetch_sub(c, 1, 3) != 1) return 0;
    LUST_THREAD_FENCE(2);
    return 1;
})

/* The one shared allocation of every empty `Arc<str>` and `Arc<[T]>`
   that `Default` makes (std's static ArcInner, w-unsized): its strong
   count starts at 1, so it is never freed. Takes one more strong ref and
   returns the data pointer, right after the two counts. */
void *lust_arc_empty(void) LUST_BODY({
    static _Alignas(16) uint64_t h[2] = { 1, 1 };
    lust_arc_inc(&h[0]);
    return (void *)(h + 2);
})

/* An acquire load of a count. */
uint64_t lust_arc_load(uint64_t *c) LUST_BODY({
    uint64_t v;
    __atomic_load(c, &v, 2);
    return v;
})

/* `Arc::downgrade`: one more weak ref. */
void lust_arc_downgrade(uint64_t *h) LUST_BODY({
    uint64_t cur;
    __atomic_load(&h[1], &cur, 0);
    for (;;) {
        if (cur == UINT64_MAX) {
            __atomic_load(&h[1], &cur, 0);
            continue;
        }
        if (cur > (uint64_t)INT64_MAX) abort();
        uint64_t nv = cur + 1;
        if (__atomic_compare_exchange(&h[1], &cur, &nv, 1, 2, 0)) return;
    }
})

/* `Weak::upgrade` on a live pointer: 1 when a strong ref was taken
   (the strong count was not zero). */
int lust_arc_upgrade(uint64_t *h) LUST_BODY({
    uint64_t n;
    __atomic_load(&h[0], &n, 0);
    for (;;) {
        if (n == 0) return 0;
        if (n > (uint64_t)INT64_MAX) abort();
        uint64_t nv = n + 1;
        if (__atomic_compare_exchange(&h[0], &n, &nv, 1, 2, 0)) return 1;
    }
})

/* `Arc::weak_count`: the Weaks, without the implicit one. */
uint64_t lust_arc_weak_count(uint64_t *h) LUST_BODY({
    uint64_t w = lust_arc_load(&h[1]);
    return w == UINT64_MAX ? 0 : w - 1;
})

/* `Weak::weak_count` on a live pointer: 0 once the value is gone. */
uint64_t lust_arc_weak_weak_count(uint64_t *h) LUST_BODY({
    uint64_t w = lust_arc_load(&h[1]);
    uint64_t s = lust_arc_load(&h[0]);
    if (s == 0) return 0;
    return w == UINT64_MAX ? 0 : w - 1;
})

/* `Arc::get_mut`'s test: no other strong ref and no Weak. */
int lust_arc_is_unique(uint64_t *h) LUST_BODY({
    uint64_t one = 1, locked = UINT64_MAX;
    if (!__atomic_compare_exchange(&h[1], &one, &locked, 0, 2, 0)) return 0;
    int unique = lust_arc_load(&h[0]) == 1;
    uint64_t back = 1;
    __atomic_store(&h[1], &back, 3);
    return unique;
})

/* `Arc::make_mut`'s three cases: 0 another strong ref exists (clone the
   value), 1 this was the only strong ref but Weaks exist (strong is now
   0: move the value out), 2 unique (nothing to do). */
int lust_arc_make_mut_state(uint64_t *h) LUST_BODY({
    uint64_t one = 1, zero = 0;
    if (!__atomic_compare_exchange(&h[0], &one, &zero, 0, 2, 0)) return 0;
    uint64_t w;
    __atomic_load(&h[1], &w, 0);
    if (w != 1) return 1;
    __atomic_store(&h[0], &one, 3);
    return 2;
})

/* `Arc::try_unwrap`'s test: 1 when this was the only strong ref (strong
   is now 0 and the caller owns the value). */
int lust_arc_take_unique(uint64_t *h) LUST_BODY({
    uint64_t one = 1, zero = 0;
    if (!__atomic_compare_exchange(&h[0], &one, &zero, 0, 0, 0)) return 0;
    LUST_THREAD_FENCE(2);
    return 1;
})

/* ---------- Locks: Mutex and RwLock over a futex word ----------

   A `Mutex<T>` is { uint32_t st; uint8_t poison; T v; } and an `RwLock<T>`
   { uint32_t st; uint32_t wn; uint8_t poison; T v; } (cgen/sync.rs). All
   zero is unlocked, so `Mutex::new` in a static needs no constructor. The
   poison flag stays 0: a panic aborts the process. Locking a lock this
   thread already holds deadlocks, as std's futex locks do on Linux. */
#ifdef LUST_IMPL
#if defined(__linux__)
long syscall(long number, ...);
#if defined(__x86_64__)
#define LUST_SYS_FUTEX 202
#define LUST_SYS_SCHED_GETAFFINITY 204
#elif defined(__aarch64__)
#define LUST_SYS_FUTEX 98
#define LUST_SYS_SCHED_GETAFFINITY 123
#endif
#elif defined(__APPLE__)
/* Darwin's futex: the ulock calls in libSystem (no public header;
   UL_COMPARE_AND_WAIT sleeps while the u32 at the address equals the
   value, with a timeout in microseconds, 0 for no limit; wake takes
   ULF_WAKE_ALL to wake every waiter). */
int __ulock_wait(uint32_t op, void *addr, uint64_t value, uint32_t timeout_us);
int __ulock_wake(uint32_t op, void *addr, uint64_t wake_value);
#define LUST_ULOCK_COMPARE_AND_WAIT 1u
#define LUST_ULOCK_WAKE_ALL 0x100u
#endif
int sched_yield(void);
/* Sleep while *p == v (spurious wakeups are fine: callers loop). */
#ifdef _WIN32
/* WaitOnAddress and its wakes live behind an api-set with no zig
   import library: resolve them from kernel32 on first use. */
typedef int (*lust_woa_fn)(volatile void *, void *, size_t, uint32_t);
typedef void (*lust_wake_fn)(void *);
static lust_woa_fn lust_woa;
static lust_wake_fn lust_wake1, lust_wakeall;
static void lust_woa_init(void) {
    HMODULE k = GetModuleHandleW(L"kernel32.dll");
    lust_woa = (lust_woa_fn)GetProcAddress(k, "WaitOnAddress");
    lust_wake1 = (lust_wake_fn)GetProcAddress(k, "WakeByAddressSingle");
    lust_wakeall = (lust_wake_fn)GetProcAddress(k, "WakeByAddressAll");
}
static lust_pthread_once_t lust_woa_once = LUST_PTHREAD_ONCE_INIT;
#endif
static void lust_futex_wait(uint32_t *p, uint32_t v) {
#ifdef _WIN32
    pthread_once(&lust_woa_once, lust_woa_init);
    if (lust_woa) lust_woa(p, &v, sizeof v, 0xFFFFFFFFu);
    else SwitchToThread();
#elif defined(LUST_SYS_FUTEX)
    syscall(LUST_SYS_FUTEX, p, 128 /* FUTEX_WAIT_PRIVATE */, v, (void *)0, (void *)0, 0);
#elif defined(__APPLE__)
    __ulock_wait(LUST_ULOCK_COMPARE_AND_WAIT, p, v, 0);
#else
    (void)p; (void)v;
    sched_yield();
#endif
}
static void lust_futex_wake(uint32_t *p, int n) {
#ifdef _WIN32
    pthread_once(&lust_woa_once, lust_woa_init);
    if (n == 1) { if (lust_wake1) lust_wake1(p); } else if (lust_wakeall) lust_wakeall(p);
#elif defined(LUST_SYS_FUTEX)
    syscall(LUST_SYS_FUTEX, p, 129 /* FUTEX_WAKE_PRIVATE */, n, (void *)0, (void *)0, 0);
#elif defined(__APPLE__)
    __ulock_wake(LUST_ULOCK_COMPARE_AND_WAIT | (n == 1 ? 0 : LUST_ULOCK_WAKE_ALL), p, 0);
#else
    (void)p; (void)n;
#endif
}
/* The timed form of lust_futex_wait for the Condvar and channel
   timeouts below: sleep while *p == v, at most rs seconds and rn
   nanoseconds (callers recompute what is left and loop, so a capped
   or early return is fine). */
static void lust_futex_wait_for(uint32_t *p, uint32_t v, long rs, long rn) {
#ifdef LUST_SYS_FUTEX
    long rel[2];
    rel[0] = rs;
    rel[1] = rn;
    syscall(LUST_SYS_FUTEX, p, 128 /* FUTEX_WAIT_PRIVATE */, v, rel, (void *)0, 0);
#elif defined(__APPLE__)
    uint64_t us = (uint64_t)rs * 1000000u + (uint64_t)rn / 1000u;
    if (us == 0) us = 1;
    if (us > 0xffffffffu) us = 0xffffffffu;
    __ulock_wait(LUST_ULOCK_COMPARE_AND_WAIT, p, v, (uint32_t)us);
#else
    (void)p; (void)v; (void)rs; (void)rn;
    sched_yield();
#endif
}
#endif

/* Poisoning (panic=unwind): the `poison` byte of a Mutex or RwLock. Bit 0
   is std's poison flag; bit 1 says the write guard that holds the lock was
   taken while its thread was panicking. A write guard dropped while
   panicking poisons the lock only when it was not taken that way (std's
   poison::Guard). */
void lust_poison_enter(uint8_t *f) LUST_BODY({
    if (lust_unw_panicking()) *f |= 2;
    else *f &= (uint8_t)~2;
})
void lust_poison_leave(uint8_t *f) LUST_BODY({
    if (!(*f & 2) && lust_unw_panicking()) *f |= 1;
})

/* A spin-wait hint for the lock loops below (as kconst.c's). */
static void lust_lock_pause(void) {
#if !defined(__TINYC__) && (defined(__x86_64__) || defined(__i386__))
    __builtin_ia32_pause();
#elif !defined(__TINYC__) && defined(__aarch64__)
    __asm__ __volatile__("yield");
#endif
}

/* The lock word after up to 100 relaxed loads while it reads `busy` (std's
   futex locks `spin`): a lock held for a short time is then taken without
   a futex wait and wake, two syscalls and two context switches. */
static uint32_t lust_lock_spin(uint32_t *st, uint32_t busy) {
    uint32_t s;
    for (int i = 0; i < 100; i++) {
        __atomic_load(st, &s, 0);
        if (s != busy) return s;
        lust_lock_pause();
    }
    __atomic_load(st, &s, 0);
    return s;
}

/* Mutex states: 0 unlocked, 1 locked, 2 locked with waiters (Drepper's
   futex mutex, as std's: spin first, then mark waiters and sleep). */
void lust_mutex_lock(uint32_t *st) LUST_BODY({
    uint32_t zero = 0, one = 1, two = 2, old;
    if (__atomic_compare_exchange(st, &zero, &one, 0, 2, 0)) return;
    uint32_t s = lust_lock_spin(st, 1);
    if (s == 0) {
        if (__atomic_compare_exchange(st, &s, &one, 0, 2, 0)) return;
    }
    for (;;) {
        if (s != 2) {
            __atomic_exchange(st, &two, &old, 2);
            if (old == 0) return;
        }
        lust_futex_wait(st, 2);
        s = lust_lock_spin(st, 1);
    }
})

/* 1 when the lock was taken. */
int lust_mutex_trylock(uint32_t *st) LUST_BODY({
    uint32_t zero = 0, one = 1;
    return __atomic_compare_exchange(st, &zero, &one, 0, 2, 0);
})

void lust_mutex_unlock(uint32_t *st) LUST_BODY({
    uint32_t zero = 0, old;
    __atomic_exchange(st, &zero, &old, 3);
    if (old == 2) lust_futex_wake(st, 1);
})

/* RwLock: st is the reader count, or LUST_RW_WRITER while written; st[1]
   (wn) counts sleepers. Every step is SeqCst, so an unlock that reads
   wn == 0 happens before a sleeper's increment, and that sleeper's futex
   wait then sees the changed state and returns at once. */
#define LUST_RW_WRITER 0xffffffffu
void lust_rw_read(uint32_t *st) LUST_BODY({
    for (int spun = 0;;) {
        uint32_t s;
        __atomic_load(st, &s, 5);
        if (s < LUST_RW_WRITER - 1) {
            uint32_t n = s + 1;
            if (__atomic_compare_exchange(st, &s, &n, 0, 5, 5)) return;
            continue;
        }
        /* Written: spin once (as std's spin_read) before sleeping. */
        if (!spun) {
            spun = 1;
            if (lust_lock_spin(st, LUST_RW_WRITER) != LUST_RW_WRITER) continue;
        }
        __atomic_fetch_add(&st[1], 1, 5);
        lust_futex_wait(st, s);
        __atomic_fetch_sub(&st[1], 1, 5);
        spun = 0;
    }
})

int lust_rw_tryread(uint32_t *st) LUST_BODY({
    uint32_t s;
    __atomic_load(st, &s, 5);
    while (s < LUST_RW_WRITER - 1) {
        uint32_t n = s + 1;
        if (__atomic_compare_exchange(st, &s, &n, 0, 5, 5)) return 1;
    }
    return 0;
})

void lust_rw_read_unlock(uint32_t *st) LUST_BODY({
    uint32_t w;
    if (__atomic_fetch_sub(st, 1, 5) == 1) {
        __atomic_load(&st[1], &w, 5);
        if (w) lust_futex_wake(st, 0x7fffffff);
    }
})

void lust_rw_write(uint32_t *st) LUST_BODY({
    for (int spun = 0;;) {
        uint32_t s = 0, wr = LUST_RW_WRITER;
        if (__atomic_compare_exchange(st, &s, &wr, 0, 5, 5)) return;
        /* Held: spin once (as std's spin_write) until it is free, then try again. */
        if (!spun) {
            spun = 1;
            uint32_t t;
            for (int i = 0; i < 100; i++) {
                __atomic_load(st, &t, 0);
                if (t == 0) break;
                lust_lock_pause();
            }
            continue;
        }
        __atomic_fetch_add(&st[1], 1, 5);
        lust_futex_wait(st, s);
        __atomic_fetch_sub(&st[1], 1, 5);
        spun = 0;
    }
})

int lust_rw_trywrite(uint32_t *st) LUST_BODY({
    uint32_t s = 0, wr = LUST_RW_WRITER;
    return __atomic_compare_exchange(st, &s, &wr, 0, 5, 5);
})

void lust_rw_write_unlock(uint32_t *st) LUST_BODY({
    uint32_t zero = 0, w;
    __atomic_store(st, &zero, 5);
    __atomic_load(&st[1], &w, 5);
    if (w) lust_futex_wake(st, 0x7fffffff);
})

/* ---------- Threads: spawn, join, current (pthreads) ----------

   A `JoinHandle<T>` points at a packet the generated code allocates:
   { lust_JoinHdr h; T ret; Env env; } (cgen/sync.rs). The spawned thread
   runs h.run (a generated trampoline that calls the closure and stores
   its result), then gives up its reference. The handle and the thread
   each hold one reference (h.rc); whichever lets go last drops the result
   (h.drop_ret) and frees the packet. `join` waits, takes the result, and
   frees the packet. A `Thread` is a counted lust_ThreadInfo; the current
   thread's lives in a pthread key (no C _Thread_local), whose destructor
   gives up the thread's reference at thread exit. */
typedef struct lust_ThreadInfo {
    uint64_t rc;
    uint64_t id;
    const uint8_t *name;
    uint64_t name_len;
    /* A Builder name's owned copy (0 for a static name). */
    uint8_t *name_buf;
    /* A spawned thread's stack overflow window and alternate signal
       stack (panic.c `lust_thread_guard_init`); 0 for the main thread. */
    uintptr_t guard_lo, guard_hi;
    void *alt;
} lust_ThreadInfo;

/* A `thread::Scope`: the count of its live packets. The scope's end
   waits until it is 0; a packet counts down when it is freed, after its
   result dropped, so no scoped thread touches borrowed data after. */
typedef struct lust_Scope {
    uint32_t live;
    uint32_t panicked; /* a thread of the scope panicked and nobody joined it */
} lust_Scope;

typedef struct lust_JoinHdr {
    uintptr_t t; /* pthread_t on POSIX, a HANDLE as a word on Windows */
    lust_ThreadInfo *th;
    uint32_t rc;
    uint32_t done;
    void (*run)(struct lust_JoinHdr *);
    void (*drop_ret)(struct lust_JoinHdr *);
    lust_Scope *scope; /* 0 for thread::spawn */
    uint32_t panicked; /* the thread ended by a panic; `payload` is its Box<dyn Any + Send> */
    lust_dyn payload;
} lust_JoinHdr;

/* A JoinHdr's thread id as the pthread calls take it. The field is an
   unsigned long on every target (pthread_t is a word on glibc and a
   pointer on Darwin, both 8 bytes, so the packet layout cgen lays out
   is the same); on Darwin the calls cast it to the real pthread_t. */
#ifdef __APPLE__
#define LUST_PTHREAD_ID_P(p) ((pthread_t *)(void *)(p))
#define LUST_PTHREAD_ID(v) ((pthread_t)(uintptr_t)(v))
#else
#define LUST_PTHREAD_ID_P(p) (p)
#define LUST_PTHREAD_ID(v) (v)
#endif

#ifdef LUST_IMPL
/* Hand pthread declarations for tcc on Linux; on Darwin runtime.h
   included the real <pthread.h> and these would clash with it, and
   on Windows runtime.h maps these names to its Win32 wrappers.
   The thread word is uintptr_t: a HANDLE on Windows, where the
   32-bit long cannot hold one (same size as unsigned long here). */
#if !defined(__APPLE__) && !defined(_WIN32)
int pthread_create(uintptr_t *t, const void *attr, void *(*start)(void *), void *arg);
int pthread_join(uintptr_t t, void **ret);
int pthread_detach(uintptr_t t);
int pthread_key_create(unsigned int *key, void (*dtor)(void *));
void *pthread_getspecific(unsigned int key);
int pthread_setspecific(unsigned int key, const void *v);
int pthread_once(int *once, void (*init)(void));
#endif
static lust_pthread_key_t lust_cur_key;
static lust_pthread_once_t lust_cur_once = LUST_PTHREAD_ONCE_INIT;
/* ThreadId(1) is the main thread; spawned threads count from 2 in spawn
   order, as std assigns them. */
static uint64_t lust_next_tid = 2;
static lust_ThreadInfo lust_main_info = {1, 1, (const uint8_t *)"main", 4, 0};

static void lust_thread_info_release(void *p) {
    lust_ThreadInfo *t = (lust_ThreadInfo *)p;
    if (t && t != &lust_main_info && __atomic_sub_fetch(&t->rc, 1, 4) == 0) {
        free(t->name_buf);
        free(t);
    }
}
static int lust_cur_ready;
static void lust_cur_key_init(void) {
    pthread_key_create(&lust_cur_key, lust_thread_info_release);
    int one = 1;
    __atomic_store(&lust_cur_ready, &one, 3);
}

/* The calling thread's name for the panic hook: "main", the Builder's
   name, or "<unnamed>" (panic.c). */
static void lust_cur_thread_name(const uint8_t **p, uint64_t *n) {
    int ready;
    __atomic_load(&lust_cur_ready, &ready, 2);
    lust_ThreadInfo *t = ready ? (lust_ThreadInfo *)pthread_getspecific(lust_cur_key) : 0;
    if (!t) t = &lust_main_info;
    if (t->name) { *p = t->name; *n = t->name_len; }
    else { *p = (const uint8_t *)"<unnamed>"; *n = 9; }
}

#if defined(__linux__) || defined(__APPLE__)
/* The stack overflow handler's view of the calling thread (panic.c): a
   spawned thread's guard window and its name, "<unknown>" when it has
   none, as std's handler prints it. The main thread keeps the defaults. */
static void lust_cur_thread_guard(uintptr_t *lo, uintptr_t *hi, const uint8_t **name, uint64_t *n) {
    int ready;
    __atomic_load(&lust_cur_ready, &ready, 2);
    lust_ThreadInfo *t = ready ? (lust_ThreadInfo *)pthread_getspecific(lust_cur_key) : 0;
    if (!t || t == &lust_main_info || !t->guard_hi) return;
    *lo = t->guard_lo;
    *hi = t->guard_hi;
    if (t->name) { *name = t->name; *n = t->name_len; }
    else { *name = (const uint8_t *)"<unknown>"; *n = 9; }
}
#endif

/* Drops a packet's result: the value, or the payload of a panic. */
static void lust_packet_drop_result(lust_JoinHdr *h) {
    if (!h->panicked) { h->drop_ret(h); return; }
    if (h->payload.vt[0]) ((void (*)(void *))h->payload.vt[0])(h->payload.data);
    lust_dealloc(h->payload.data, (uint64_t)(uintptr_t)h->payload.vt[1], (uint64_t)(uintptr_t)h->payload.vt[2]);
}

/* Frees a packet whose result was moved out or dropped; a scoped one
   then counts down its scope. */
static void lust_packet_free(lust_JoinHdr *h) {
    lust_Scope *sc = h->scope;
    uint32_t one = 1;
    if (sc && h->panicked) __atomic_store(&sc->panicked, &one, 5);
    lust_thread_info_release(h->th);
    free(h);
    if (sc && __atomic_sub_fetch(&sc->live, 1, 5) == 0) lust_futex_wake(&sc->live, 0x7fffffff);
}

static void *lust_thread_entry(void *p) {
    lust_JoinHdr *h = (lust_JoinHdr *)p;
    lust_ThreadInfo *self = h->th;
    lust_thread_guard_init(&self->guard_lo, &self->guard_hi, &self->alt);
    pthread_setspecific(lust_cur_key, h->th);
#ifdef __APPLE__
    /* Darwin's pthread_setname_np names only the calling thread, so a
       Builder name is set here, as std sets it in the spawned thread
       on macOS (the parent-side call below is Linux's two-arg form). */
    if (self->name) {
        char nm[64];
        uint64_t n = self->name_len < 63 ? self->name_len : 63;
        uint64_t i = 0;
        for (; i < n && self->name[i] != 0; i++) nm[i] = (char)self->name[i];
        nm[i] = 0;
        pthread_setname_np(nm);
    }
#endif
    /* A panic that reached the thread's root ends the thread; its payload
       is the join's Err (std's spawn wrapper catches it). In mode 2 the
       root is a catch point. */
    lust_exc ex;
    if (lust_unwind_mode == 2) {
        if (lust_unw_try((void (*)(void *))h->run, h)) {
            lust_unw_take_any(&ex);
            h->payload = lust_exc_box(&ex);
            h->panicked = 1;
        }
    } else {
        h->run(h);
        if (lust_unwind_mode && lust_unw_pending && lust_unw_take(&ex)) {
            h->payload = lust_exc_box(&ex);
            h->panicked = 1;
        }
    }
    void *alt = self->alt;
    uint32_t one = 1;
    __atomic_store(&h->done, &one, 3);
    if (__atomic_sub_fetch(&h->rc, 1, 4) == 0) {
        lust_packet_drop_result(h);
        lust_packet_free(h);
    }
    lust_thread_guard_fini(alt);
    return 0;
}
#endif

/* Starts the thread for a filled packet (run, drop_ret, scope, ret, env). */
void lust_thread_spawn(lust_JoinHdr *h, lust_loc loc) LUST_BODY({
    if (h->scope) __atomic_add_fetch(&h->scope->live, 1, 5);
    pthread_once(&lust_cur_once, lust_cur_key_init);
    lust_ThreadInfo *t = (lust_ThreadInfo *)calloc(1, sizeof(lust_ThreadInfo));
    if (!t) lust_oom();
    t->rc = 2; /* the handle's (h->th) and the running thread's (its key) */
    t->id = __atomic_fetch_add(&lust_next_tid, 1, 0);
    t->name = 0;
    t->name_len = 0;
    t->name_buf = 0;
    h->th = t;
    h->rc = 2;
    h->done = 0;
    h->panicked = 0;
    if (pthread_create(LUST_PTHREAD_ID_P(&h->t), 0, lust_thread_entry, h) != 0) lust_panic_cstr_owned("failed to spawn thread", loc);
})

/* A `thread::Builder` value (cgen/sync.rs lays it out): the
   name as a String, the stack size in bytes (0 = default), and
   whether a name was set (an empty name is Some("")). */
typedef struct lust_ThreadBuilder {
    lust_String name;
    uint64_t stack;
    uint8_t has_name;
    uint8_t has_stack;
} lust_ThreadBuilder;

#if !defined(__APPLE__) && !defined(_WIN32)
int pthread_attr_init(void *attr);
int pthread_attr_destroy(void *attr);
int pthread_attr_setstacksize(void *attr, uint64_t size);
int pthread_setname_np(uintptr_t t, const char *name);
#endif

/* `Builder::spawn`: lust_thread_spawn with the builder's name
   and stack size. 0, or the errno of the failed call (the caller
   builds std's io::Error from it). The name bytes are copied:
   the ThreadInfo owns them. An interior NUL truncates the OS
   thread name; the Thread::name value keeps the full string, as
   std's does (its CString would fail there: see the check for
   the panic on a NUL in the caller). */
int lust_thread_spawn_builder(lust_JoinHdr *h, const lust_ThreadBuilder *b) LUST_BODY({
    if (h->scope) __atomic_add_fetch(&h->scope->live, 1, 5);
    pthread_once(&lust_cur_once, lust_cur_key_init);
    lust_ThreadInfo *t = (lust_ThreadInfo *)calloc(1, sizeof(lust_ThreadInfo));
    if (!t) lust_oom();
    t->rc = 2;
    t->id = __atomic_fetch_add(&lust_next_tid, 1, 0);
    t->name = 0;
    t->name_len = 0;
    t->name_buf = 0;
    if (b->has_name) {
        uint8_t *copy = (uint8_t *)malloc(b->name.len ? b->name.len : 1);
        if (!copy) lust_oom();
        for (uint64_t i = 0; i < b->name.len; i++) copy[i] = b->name.ptr[i];
        t->name = copy;
        t->name_len = b->name.len;
        t->name_buf = copy;
    }
    h->th = t;
    h->rc = 2;
    h->done = 0;
    h->panicked = 0;
    /* pthread_attr_t is opaque and platform-sized; a zeroed
       64-byte block covers glibc's (56 bytes) on the targets
       lust runs on. On Darwin the real pthread_attr_t stands here:
       a zeroed block is not a valid Darwin attr (it holds a
       signature word pthread_attr_init writes). */
#ifdef __APPLE__
    pthread_attr_t attr;
    void *attrp = 0;
    if (b->has_stack) {
        pthread_attr_init(&attr);
        uint64_t sz = b->stack < 16384 ? 16384 : b->stack;
        int e2 = pthread_attr_setstacksize(&attr, (size_t)sz);
        if (e2 != 0) {
            pthread_attr_destroy(&attr);
            lust_thread_info_release(t);
            lust_thread_info_release(t);
            if (h->scope) __atomic_sub_fetch(&h->scope->live, 1, 5);
            return e2;
        }
        attrp = &attr;
    }
#else
    uint64_t attr[8] = {0, 0, 0, 0, 0, 0, 0, 0};
    void *attrp = 0;
#ifndef _WIN32
    if (b->has_stack) {
        pthread_attr_init(attr);
        uint64_t sz = b->stack < 16384 ? 16384 : b->stack;
        int e2 = pthread_attr_setstacksize(attr, sz);
        if (e2 != 0) {
            pthread_attr_destroy(attr);
            lust_thread_info_release(t);
            lust_thread_info_release(t);
            if (h->scope) __atomic_sub_fetch(&h->scope->live, 1, 5);
            return e2;
        }
        attrp = attr;
    }
#endif
#endif
    int r = pthread_create(LUST_PTHREAD_ID_P(&h->t), attrp, lust_thread_entry, h);
#ifndef _WIN32
    if (attrp) pthread_attr_destroy(attrp);
#endif
    if (r != 0) {
        lust_thread_info_release(t);
        lust_thread_info_release(t);
        if (h->scope) __atomic_sub_fetch(&h->scope->live, 1, 5);
        return r;
    }
#ifndef __APPLE__
    if (b->has_name) {
        char nm[16];
        uint64_t n = b->name.len < 15 ? b->name.len : 15;
        uint64_t i = 0;
        for (; i < n && b->name.ptr[i] != 0; i++) nm[i] = (char)b->name.ptr[i];
        nm[i] = 0;
        #ifndef _WIN32

        pthread_setname_np(h->t, nm);

        #endif
    }
#endif
    return 0;
})

/* ---------- `thread::available_parallelism` ----------
   A port of std 1.99's Linux code (library/std/src/sys/thread/unix.rs:
   `available_parallelism` and `mod cgroups`), step for step, so the
   answer is rustc's on the same box: min(affinity count, cgroup quota),
   the quota rounded down and at least 1, sysconf as the fallback. Paths
   follow Rust's `PathBuf` push/pop/starts_with/strip_prefix on Unix. */
#ifdef LUST_IMPL
int access(const char *path, int mode);
long sysconf(int name);
#if defined(__APPLE__)
#define LUST_SC_NPROCESSORS_ONLN 58
#else
#define LUST_SC_NPROCESSORS_ONLN 84
#endif

/* A growable byte path (`PathBuf`). */
typedef struct { char *p; size_t n, cap; } lust_pb;

static void lust_pb_add(lust_pb *b, const char *s, size_t n) {
    if (b->n + n + 1 > b->cap) {
        b->cap = (b->n + n + 1) * 2;
        b->p = (char *)realloc(b->p, b->cap);
    }
    memcpy(b->p + b->n, s, n);
    b->n += n;
    b->p[b->n] = 0;
}

/* `PathBuf::push`: an absolute path replaces; else a separator first
   when the buffer is not empty and does not end in one. */
static void lust_pb_push(lust_pb *b, const char *s, size_t n) {
    int need_sep = b->n > 0 && b->p[b->n - 1] != '/';
    if (n > 0 && s[0] == '/') b->n = 0;
    else if (need_sep) lust_pb_add(b, "/", 1);
    lust_pb_add(b, s, n);
}

/* Bytes before the body of a path: the root `/`, or a leading `.` that
   is its own component (`Components::len_before_body`). */
static size_t lust_path_front(const char *p, size_t n) {
    if (n > 0 && p[0] == '/') return 1;
    if (n > 0 && p[0] == '.' && (n == 1 || p[1] == '/')) return 1;
    return 0;
}

/* The last body component of p[lb..end) from the back: its start; *sep
   gets the index of the separator before it (or lb when there is none). */
static size_t lust_path_back(const char *p, size_t lb, size_t end, size_t *cut) {
    size_t s = end;
    while (s > lb && p[s - 1] != '/') s--;
    *cut = s > lb ? s - 1 : lb;
    return s;
}

static int lust_path_skip(const char *c, size_t n) { return n == 0 || (n == 1 && c[0] == '.'); }

/* The end of a path slice after `Components::trim_right`. */
static size_t lust_path_trim_right(const char *p, size_t lb, size_t end) {
    while (end > lb) {
        size_t cut, s = lust_path_back(p, lb, end, &cut);
        if (!lust_path_skip(p + s, end - s)) break;
        end = cut;
    }
    return end;
}

/* `PathBuf::pop`: 0 when the last component is the root or there is none. */
static int lust_pb_pop(lust_pb *b) {
    size_t lb = lust_path_front(b->p, b->n), end = b->n;
    for (;;) {
        if (end <= lb) return 0;
        size_t cut, s = lust_path_back(b->p, lb, end, &cut);
        int skip = lust_path_skip(b->p + s, end - s);
        end = cut;
        if (!skip) break;
    }
    b->n = lust_path_trim_right(b->p, lb, end);
    b->p[b->n] = 0;
    return 1;
}

/* One forward component of a path: kind 0 root, 1 cur dir, 2 normal
   (`..` is a normal string here: it compares equal only to `..`). */
typedef struct { const char *p; size_t n, i; int started; } lust_pcomps;

static int lust_pcomp_next(lust_pcomps *c, int *kind, const char **s, size_t *len) {
    if (!c->started) {
        c->started = 1;
        if (c->n > 0 && c->p[0] == '/') { c->i = 1; *kind = 0; *s = c->p; *len = 1; return 1; }
        if (c->n > 0 && c->p[0] == '.' && (c->n == 1 || c->p[1] == '/')) { c->i = 1; *kind = 1; *s = c->p; *len = 1; return 1; }
    }
    while (c->i < c->n) {
        size_t a = c->i;
        while (c->i < c->n && c->p[c->i] != '/') c->i++;
        size_t e = c->i;
        if (c->i < c->n) c->i++;
        if (!lust_path_skip(c->p + a, e - a)) { *kind = 2; *s = c->p + a; *len = e - a; return 1; }
    }
    return 0;
}

/* `Path::strip_prefix` (`starts_with` when `rest` is null): 1 when every
   component of `base` matches the front of `p`; *rest is the remainder
   as `Components::as_path` gives it (both ends trimmed). */
static int lust_path_strip(const char *p, size_t n, const char *base, size_t bn, const char **rest, size_t *rest_n) {
    lust_pcomps a = {p, n, 0, 0}, b = {base, bn, 0, 0};
    int ka, kb;
    const char *sa, *sb;
    size_t la, lbn;
    while (lust_pcomp_next(&b, &kb, &sb, &lbn)) {
        if (!lust_pcomp_next(&a, &ka, &sa, &la) || ka != kb || la != lbn || memcmp(sa, sb, la) != 0) return 0;
    }
    if (rest) {
        size_t i = a.started ? a.i : 0;
        /* trim_left: separators and `.` components before the next one,
           once a component was taken (an untouched iterator keeps all). */
        for (; a.started;) {
            while (i < n && p[i] == '/') i++;
            if (i < n && p[i] == '.' && (i + 1 == n || p[i + 1] == '/')) { i++; continue; }
            break;
        }
        size_t end = lust_path_trim_right(p, i, n);
        *rest = p + i;
        *rest_n = end > i ? end - i : 0;
    }
    return 1;
}

static int lust_path_starts(const char *p, size_t n, const char *base) {
    return lust_path_strip(p, n, base, strlen(base), 0, 0);
}

/* `File::open(path)` then `read_to_string` (or `read_to_end` when
   `text` is 0). 1 on success with the bytes in *out (malloc'd). */
static int lust_read_file(const char *path, int text, char **out, size_t *len) {
    FILE *f = fopen(path, "re");
    if (!f) return 0;
    size_t cap = 256, n = 0;
    char *buf = (char *)malloc(cap);
    for (;;) {
        if (n == cap) buf = (char *)realloc(buf, cap *= 2);
        size_t got = fread(buf + n, 1, cap - n, f);
        n += got;
        if (got == 0) break;
    }
    int bad = ferror(f);
    fclose(f);
    uint64_t up;
    uint8_t el;
    if (bad || (text && !lust_utf8_check((const uint8_t *)buf, n, &up, &el))) {
        free(buf);
        return 0;
    }
    *out = buf;
    *len = n;
    return 1;
}

/* `str::parse::<usize>`: an optional `+`, then one or more ASCII digits,
   with no overflow. */
static int lust_parse_usize(const char *s, size_t n, uint64_t *v) {
    if (n > 0 && s[0] == '+') { s++; n--; }
    if (n == 0) return 0;
    uint64_t r = 0;
    for (size_t i = 0; i < n; i++) {
        if (s[i] < '0' || s[i] > '9') return 0;
        uint64_t d = (uint64_t)(s[i] - '0');
        if (r > (UINT64_MAX - d) / 10) return 0;
        r = r * 10 + d;
    }
    *v = r;
    return 1;
}

static int lust_path_exists(const lust_pb *b) { return access(b->p, 0) == 0; }

/* `quota_v2`: the smallest cpu.max quota of the cgroup and its parents. */
static uint64_t lust_quota_v2(const char *group, size_t gn) {
    uint64_t quota = UINT64_MAX;
    const char *mount = "/sys/fs/cgroup";
    lust_pb path = {0, 0, 0};
    lust_pb_push(&path, mount, strlen(mount));
    lust_pb_push(&path, group, gn);
    lust_pb_push(&path, "cgroup.controllers", 18);
    if (!lust_path_exists(&path)) { free(path.p); return UINT64_MAX; }
    lust_pb_pop(&path);
    while (lust_path_starts(path.p, path.n, mount)) {
        lust_pb_push(&path, "cpu.max", 7);
        char *buf;
        size_t n;
        if (lust_read_file(path.p, 1, &buf, &n)) {
            /* `read_buf.lines().next()?`, then two ' '-split fields; a
               missing one ends the whole walk (the `?` leaves the try block). */
            if (n == 0) { free(buf); break; }
            size_t e = 0;
            while (e < n && buf[e] != '\n') e++;
            if (e < n && e > 0 && buf[e - 1] == '\r') e--; /* `\r` only before `\n` */
            size_t sp = 0;
            while (sp < e && buf[sp] != ' ') sp++;
            if (sp == e) { free(buf); break; }
            size_t pe = sp + 1;
            while (pe < e && buf[pe] != ' ') pe++;
            uint64_t limit, period;
            if (lust_parse_usize(buf, sp, &limit) && lust_parse_usize(buf + sp + 1, pe - sp - 1, &period) && period > 0) {
                uint64_t q = limit / period;
                if (q < quota) quota = q;
            }
            free(buf);
        }
        lust_pb_pop(&path);
        lust_pb_pop(&path);
    }
    free(path.p);
    return quota;
}

/* `parse_file` of quota_v1: <dir>/<name> trimmed, as a usize. */
static int lust_v1_file(lust_pb *path, const char *name, uint64_t *v) {
    lust_pb_push(path, name, strlen(name));
    char *buf;
    size_t n;
    int ok = lust_read_file(path->p, 1, &buf, &n);
    lust_pb_pop(path);
    if (!ok) return 0;
    lust_str t = lust_str_trim((lust_str){(uint8_t *)buf, n});
    ok = lust_parse_usize((const char *)t.ptr, t.len, v);
    free(buf);
    return ok;
}

/* Field `idx` of `s` split on ' '. */
static void lust_field(const char *s, size_t n, size_t idx, const char **f, size_t *fn) {
    size_t a = 0, k = 0;
    for (size_t i = 0; i <= n; i++) {
        if (i == n || s[i] == ' ') {
            if (k++ == idx) { *f = s + a; *fn = i - a; return; }
            a = i + 1;
        }
    }
    *f = s + n;
    *fn = 0;
}

/* `find_mountpoint`: a cgroup v1 mount with the cpu controller whose
   root holds `group`. 1 with *mount (malloc'd) and the group path
   below it; 0 for std's None. */
static int lust_v1_mountpoint(const char *group, size_t gn, char **mount, const char **sub, size_t *sub_n) {
    char *buf;
    size_t n;
    /* read_line fails on bytes that are not UTF-8: read all of it, and
       stop at the first line that is not valid. */
    if (!lust_read_file("/proc/self/mountinfo", 0, &buf, &n)) return 0;
    int found = 0;
    size_t at = 0;
    while (at < n) {
        size_t e = at;
        while (e < n && buf[e] != '\n') e++;
        size_t next = e < n ? e + 1 : e;
        uint64_t up;
        uint8_t el;
        if (!lust_utf8_check((const uint8_t *)buf + at, next - at, &up, &el)) break;
        lust_str line = lust_str_trim((lust_str){(uint8_t *)buf + at, e - at});
        at = next;
        /* Fields split on ' ': sub_path = [3], mount_point = [4],
           mount_opts = last, filesystem_type = third from last. */
        const char *L = (const char *)line.ptr;
        size_t k = 1;
        for (size_t i = 0; i < line.len; i++) k += L[i] == ' ';
        if (k < 8) break;
        const char *sp, *mp, *opts, *fs;
        size_t spn, mpn, optn, fsn;
        lust_field(L, line.len, 3, &sp, &spn);
        lust_field(L, line.len, 4, &mp, &mpn);
        lust_field(L, line.len, k - 1, &opts, &optn);
        lust_field(L, line.len, k - 3, &fs, &fsn);
        int cpu = 0;
        for (size_t i = 0, b = 0; i <= optn; i++) {
            if (i == optn || opts[i] == ',') {
                if (i - b == 3 && memcmp(opts + b, "cpu", 3) == 0) cpu = 1;
                b = i + 1;
            }
        }
        if (fsn != 6 || memcmp(fs, "cgroup", 6) != 0 || !cpu) continue;
        const char *rel;
        size_t reln;
        if (!lust_path_strip(sp, spn, "/", 1, &rel, &reln)) break;
        const char *rest;
        size_t restn;
        if (!lust_path_strip(group, gn, rel, reln, &rest, &restn)) continue;
        *mount = (char *)malloc(mpn + 1);
        memcpy(*mount, mp, mpn);
        (*mount)[mpn] = 0;
        *sub = rest;
        *sub_n = restn;
        found = 1;
        break;
    }
    free(buf);
    return found;
}

/* `quota_v1`: the first cpu-controller mount that holds the cgroup,
   walked up to the mount's root. */
static uint64_t lust_quota_v1(const char *group, size_t gn) {
    uint64_t quota = UINT64_MAX;
    lust_pb path = {0, 0, 0};
    for (int m = 0; m < 3; m++) {
        char *owned = 0;
        const char *mount, *g = group;
        size_t g_n = gn;
        if (m == 0) mount = "/sys/fs/cgroup/cpu";
        else if (m == 1) mount = "/sys/fs/cgroup/cpu,cpuacct";
        else if (lust_v1_mountpoint(group, gn, &owned, &g, &g_n)) mount = owned;
        else continue;
        path.n = 0;
        lust_pb_push(&path, mount, strlen(mount));
        lust_pb_push(&path, g, g_n);
        if (!lust_path_exists(&path)) { free(owned); continue; }
        while (lust_path_starts(path.p, path.n, mount)) {
            uint64_t limit, period;
            int has_l = lust_v1_file(&path, "cpu.cfs_quota_us", &limit);
            int has_p = lust_v1_file(&path, "cpu.cfs_period_us", &period);
            if (has_l && has_p && period > 0 && limit / period < quota) quota = limit / period;
            lust_pb_pop(&path);
        }
        free(owned);
        break;
    }
    free(path.p);
    return quota;
}

/* `cgroups::quota`: the CPU quota in whole cores (rounded down), or
   UINT64_MAX when there is none or it cannot be read. */
static uint64_t lust_cgroup_quota(void) {
    char *buf;
    size_t n;
    if (!lust_read_file("/proc/self/cgroup", 0, &buf, &n)) return UINT64_MAX;
    /* The fold over the lines: (path, version) of the last v1 line with
       the cpu controller, else of the last v2 line; a matching line
       with no third field resets it (the `?` in the closure). */
    int have = 0, v1 = 0;
    size_t ps = 0, pn = 0;
    for (size_t at = 0;;) {
        size_t e = at;
        while (e < n && buf[e] != '\n') e++;
        const char *c1 = memchr(buf + at, ':', e - at);
        if (c1) {
            const char *f1 = c1 + 1;
            const char *c2 = memchr(f1, ':', (size_t)(buf + e - f1));
            size_t f1n = (size_t)((c2 ? c2 : buf + e) - f1);
            int ver = 0; /* 2: v2, 1: v1 */
            if (f1n == 0) ver = 2;
            else {
                uint64_t up;
                uint8_t el;
                if (lust_utf8_check((const uint8_t *)f1, f1n, &up, &el)) {
                    for (size_t i = 0, b = 0; i <= f1n; i++) {
                        if (i == f1n || f1[i] == ',') {
                            if (i - b == 3 && memcmp(f1 + b, "cpu", 3) == 0) ver = 1;
                            b = i + 1;
                        }
                    }
                }
            }
            if (ver && !(have && ver == 2)) {
                if (!c2) have = 0;
                else {
                    size_t f2 = (size_t)(c2 + 1 - buf), f2n = e - f2;
                    if (f2n == 0) {
                        free(buf);
                        lust_panic_std("range start index 1 out of range for slice of length 0", "std/src/sys/thread/unix.rs:843:31");
                        return UINT64_MAX;
                    }
                    have = 1;
                    v1 = ver == 1;
                    ps = f2 + 1;
                    pn = f2n - 1;
                }
            }
        }
        if (e >= n) break;
        at = e + 1;
    }
    uint64_t q = UINT64_MAX;
    if (have) q = v1 ? lust_quota_v1(buf + ps, pn) : lust_quota_v2(buf + ps, pn);
    free(buf);
    return q;
}

#endif

/* `thread::available_parallelism` on Linux: the count (> 0), or 0 with
   *err an errno (`last_os_error`) or -1 (`UNKNOWN_THREAD_COUNT`). */
uint64_t lust_avail_parallelism(int32_t *err) LUST_BODY({
    *err = 0;
    uint64_t quota = UINT64_MAX;
#if defined(__linux__)
    quota = lust_cgroup_quota();
    if (lust_unw_pending && lust_unw_mine()) return 1;
    if (quota < 1) quota = 1;
#ifdef LUST_SYS_SCHED_GETAFFINITY
    /* glibc's cpu_set_t is 128 bytes; the wrapper zeroes what the
       kernel does not write, as the zeroed mask here. */
    uint64_t mask[16] = {0};
    if (syscall(LUST_SYS_SCHED_GETAFFINITY, 0, sizeof mask, mask) >= 0) {
        uint64_t count = 0;
        for (int i = 0; i < 16; i++) count += (uint64_t)__builtin_popcountll(mask[i]);
        if (count > quota) count = quota;
        if (count > 0) return count;
    }
#endif
#endif
#ifdef _WIN32
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    long cpus = (long)si.dwNumberOfProcessors;
#else
    long cpus = sysconf(LUST_SC_NPROCESSORS_ONLN);
#endif
    if (cpus == -1) {
        *err = errno;
        return 0;
    }
    if (cpus == 0) {
        *err = -1;
        return 0;
    }
    return (uint64_t)cpus < quota ? (uint64_t)cpus : quota;
})

/* Waits for the thread; the caller then moves the result out and calls
   lust_join_free. */
void lust_thread_join(lust_JoinHdr *h) LUST_BODY({ pthread_join(LUST_PTHREAD_ID(h->t), 0); })

void lust_join_free(lust_JoinHdr *h) LUST_BODY({ lust_packet_free(h); })

/* A dropped JoinHandle detaches its thread. */
void lust_join_drop(lust_JoinHdr *h) LUST_BODY({
    pthread_detach(LUST_PTHREAD_ID(h->t));
    if (__atomic_sub_fetch(&h->rc, 1, 4) == 0) {
        lust_packet_drop_result(h);
        lust_packet_free(h);
    }
})

int lust_join_is_finished(lust_JoinHdr *h) LUST_BODY({
    uint32_t d;
    __atomic_load(&h->done, &d, 2);
    return d != 0;
})

/* `thread::current()`: a new reference to this thread's info. */
lust_ThreadInfo *lust_thread_current(void) LUST_BODY({
    pthread_once(&lust_cur_once, lust_cur_key_init);
    lust_ThreadInfo *t = (lust_ThreadInfo *)pthread_getspecific(lust_cur_key);
    if (!t) return &lust_main_info;
    __atomic_add_fetch(&t->rc, 1, 0);
    return t;
})

lust_ThreadInfo *lust_thread_clone(lust_ThreadInfo *t) LUST_BODY({
    if (t != &lust_main_info) __atomic_add_fetch(&t->rc, 1, 0);
    return t;
})

void lust_thread_drop(lust_ThreadInfo *t) LUST_BODY({ lust_thread_info_release(t); })

void lust_thread_yield(void) LUST_BODY({ sched_yield(); })

/* The end of `thread::scope`: waits for every packet of the scope. */
void lust_scope_wait(lust_Scope *sc) LUST_BODY({
    for (;;) {
        uint32_t n;
        __atomic_load(&sc->live, &n, 5);
        if (n == 0) return;
        lust_futex_wait(&sc->live, n);
    }
})

/* ---------- mpsc channels ----------

   One lust_Chan per channel, shared by every Sender/SyncSender and the
   Receiver (each of those is a lust_Chan*). A futex mutex guards it; `seq`
   is a condition word (waiters sleep on its value, every change bumps it
   and wakes all, if `sleepers`, the threads that sleep on it, is not 0:
   both change only under the lock). Values move in and out by memcpy of
   `esize` bytes.
   `cap` is -1 for `channel()` and the bound for `sync_channel(n)`; a
   bound of 0 is a rendezvous: a sender places its value only while a
   receiver waits, then waits until that value is taken. A rendezvous
   sender that waits counts itself in `tx_waiting`, so `try_recv` and an
   expired `recv_timeout` still pair with it, as std's zero-capacity
   channel does; such a receiver counts in `rx_claim`, which `try_send`
   does not see (it pairs only with a blocked receiver). The channel is
   freed when the last sender and the receiver are gone; values still
   queued then drop through `drop_elem`. */
typedef struct lust_Chan {
    uint32_t lock;
    uint32_t seq;
    uint32_t sleepers;
    uint64_t senders;
    uint32_t rx_alive;
    uint32_t rx_waiting;
    uint32_t tx_waiting;
    uint32_t rx_claim;
    int64_t cap;
    uint64_t esize;
    uint64_t ealign;
    uint8_t *buf;
    uint64_t head, len, bufcap;
    uint64_t taken;
    void (*drop_elem)(void *);
} lust_Chan;

#ifdef LUST_IMPL
/* Lock held. Without a sleeper a change makes no futex call: each send and
   recv woke all before, with no one to wake (tsgo: thousands per run). */
static void lust_chan_changed(lust_Chan *c) {
    __atomic_add_fetch(&c->seq, 1, 5);
    if (c->sleepers) lust_futex_wake(&c->seq, 0x7fffffff);
}
/* Sleeps until the channel changes; the lock is dropped meanwhile. A change
   between the unlock and the sleep sees this sleeper and bumps `seq`, so the
   futex wait returns at once. */
static void lust_chan_wait(lust_Chan *c) {
    uint32_t s;
    c->sleepers++;
    __atomic_load(&c->seq, &s, 5);
    lust_mutex_unlock(&c->lock);
    lust_futex_wait(&c->seq, s);
    lust_mutex_lock(&c->lock);
    c->sleepers--;
}
static void lust_chan_push(lust_Chan *c, const void *v) {
    if (c->esize == 0) { c->len++; return; }
    if (c->len == c->bufcap) {
        uint64_t nc = c->bufcap ? c->bufcap * 2 : 4;
        uint8_t *nb = (uint8_t *)lust_alloc(nc * c->esize, c->ealign);
        for (uint64_t i = 0; i < c->len; i++) memcpy(nb + i * c->esize, c->buf + ((c->head + i) % c->bufcap) * c->esize, c->esize);
        if (c->bufcap && c->esize) free(c->buf);
        c->buf = nb;
        c->bufcap = nc;
        c->head = 0;
    }
    memcpy(c->buf + ((c->head + c->len) % c->bufcap) * c->esize, v, c->esize);
    c->len++;
}
static void lust_chan_pop(lust_Chan *c, void *out) {
    if (c->esize == 0) { c->len--; c->taken++; return; }
    memcpy(out, c->buf + c->head * c->esize, c->esize);
    c->head = (c->head + 1) % c->bufcap;
    c->len--;
    c->taken++;
}
/* Drops the queued values and frees the channel (lock held, last user). */
static void lust_chan_drain(lust_Chan *c) {
    if (c->drop_elem)
        for (uint64_t i = 0; i < c->len; i++) c->drop_elem(c->esize ? c->buf + ((c->head + i) % c->bufcap) * c->esize : (uint8_t *)(uintptr_t)c->ealign);
    c->len = 0;
}
static void lust_chan_free(lust_Chan *c) {
    lust_chan_drain(c);
    if (c->bufcap && c->esize) free(c->buf);
    free(c);
}
#endif

#ifdef LUST_IMPL
/* A receiver that does not block (`try_recv`, an expired
   `recv_timeout`) on a rendezvous channel with a waiting sender: that
   sender is committed (std pairs with it at once), so wait for its
   value and take it. The lock is held on entry and released here. */
static void lust_chan_claim(lust_Chan *c, void *out) {
    c->rx_claim++;
    lust_chan_changed(c);
    while (c->len == 0) lust_chan_wait(c);
    lust_chan_pop(c, out);
    c->rx_claim--;
    lust_chan_changed(c);
    lust_mutex_unlock(&c->lock);
}
#endif

lust_Chan *lust_chan_new(uint64_t esize, uint64_t ealign, int64_t cap, void (*drop_elem)(void *)) LUST_BODY({
    lust_Chan *c = (lust_Chan *)calloc(1, sizeof(lust_Chan));
    if (!c) lust_oom();
    c->senders = 1;
    c->rx_alive = 1;
    c->cap = cap;
    c->esize = esize;
    c->ealign = ealign;
    c->drop_elem = drop_elem;
    return c;
})

/* 0 sent; 1 the receiver is gone (the value stays with the caller). */
int lust_chan_send(lust_Chan *c, const void *v) LUST_BODY({
    lust_mutex_lock(&c->lock);
    if (c->cap == 0) {
        c->tx_waiting++;
        while (c->rx_alive && (c->rx_waiting + c->rx_claim == 0 || c->len > 0)) lust_chan_wait(c);
        c->tx_waiting--;
        if (!c->rx_alive) { lust_mutex_unlock(&c->lock); return 1; }
        uint64_t ticket = c->taken;
        lust_chan_push(c, v);
        lust_chan_changed(c);
        while (c->taken == ticket && c->rx_alive) lust_chan_wait(c);
        lust_mutex_unlock(&c->lock);
        return 0;
    }
    while (c->rx_alive && c->cap > 0 && c->len >= (uint64_t)c->cap) lust_chan_wait(c);
    if (!c->rx_alive) { lust_mutex_unlock(&c->lock); return 1; }
    lust_chan_push(c, v);
    lust_chan_changed(c);
    lust_mutex_unlock(&c->lock);
    return 0;
})

/* try_send: 0 sent; 1 full (the value stays with the caller);
   2 the receiver is gone (the value stays with the caller). A
   rendezvous channel (cap 0) sends only into a waiting receiver
   with nothing queued, as std's does. */
int lust_chan_try_send(lust_Chan *c, const void *v) LUST_BODY({
    lust_mutex_lock(&c->lock);
    if (!c->rx_alive) { lust_mutex_unlock(&c->lock); return 2; }
    if (c->cap == 0) {
        if (c->rx_waiting == 0 || c->len > 0) { lust_mutex_unlock(&c->lock); return 1; }
    } else if (c->cap > 0 && c->len >= (uint64_t)c->cap) {
        lust_mutex_unlock(&c->lock);
        return 1;
    }
    lust_chan_push(c, v);
    lust_chan_changed(c);
    lust_mutex_unlock(&c->lock);
    return 0;
})

/* 0 received into out; 1 every sender is gone and nothing is queued.
   `block` 0 is try_recv: 1 means empty, 2 disconnected. */
int lust_chan_recv(lust_Chan *c, void *out, int block) LUST_BODY({
    lust_mutex_lock(&c->lock);
    c->rx_waiting++;
    lust_chan_changed(c);
    for (;;) {
        if (c->len > 0) {
            lust_chan_pop(c, out);
            c->rx_waiting--;
            lust_chan_changed(c);
            lust_mutex_unlock(&c->lock);
            return 0;
        }
        if (c->senders == 0) { c->rx_waiting--; lust_mutex_unlock(&c->lock); return block ? 1 : 2; }
        if (!block) {
            c->rx_waiting--;
            if (c->cap == 0 && c->tx_waiting > 0) { lust_chan_claim(c, out); return 0; }
            lust_mutex_unlock(&c->lock);
            return 1;
        }
        lust_chan_wait(c);
    }
})

lust_Chan *lust_chan_clone_sender(lust_Chan *c) LUST_BODY({
    lust_mutex_lock(&c->lock);
    c->senders++;
    lust_mutex_unlock(&c->lock);
    return c;
})

void lust_chan_drop_sender(lust_Chan *c) LUST_BODY({
    lust_mutex_lock(&c->lock);
    if (--c->senders == 0) {
        if (!c->rx_alive) { lust_chan_free(c); return; }
        lust_chan_changed(c);
    }
    lust_mutex_unlock(&c->lock);
})

void lust_chan_drop_receiver(lust_Chan *c) LUST_BODY({
    lust_mutex_lock(&c->lock);
    c->rx_alive = 0;
    if (c->senders == 0) { lust_chan_free(c); return; }
    /* Queued values drop now, as std's receiver drop does. */
    lust_chan_drain(c);
    lust_chan_changed(c);
    lust_mutex_unlock(&c->lock);
})

/* ---------- Condvar, Barrier, OnceLock ----------

   A Condvar is a sequence word: a waiter reads it, unlocks the mutex,
   sleeps while it is unchanged, and locks again; a notify bumps it and
   wakes one or all (spurious wakeups are allowed, as std documents).
   A Barrier is { lock, seq, count, generation, n }: the n-th arrival
   starts a new generation, wakes the others, and is the leader. A
   OnceLock<T> is { state, T }: 0 empty, 1 being set, 2 set, 3 being set
   with a thread waiting (std's QUEUED): only then does the end of the set
   wake (it woke always before: one futex call per init, 23,380 on tsgo's
   effect check). */
void lust_cv_wait(uint32_t *cv, uint32_t *m) LUST_BODY({
    uint32_t s;
    __atomic_load(cv, &s, 5);
    lust_mutex_unlock(m);
    lust_futex_wait(cv, s);
    lust_mutex_lock(m);
})

void lust_cv_notify(uint32_t *cv, int all) LUST_BODY({
    __atomic_add_fetch(cv, 1, 5);
    lust_futex_wake(cv, all ? 0x7fffffff : 1);
})

/* `Condvar::wait_timeout`: like lust_cv_wait, but 1 when the
   duration elapsed with no notify seen (std's timed_out: true
   only when the timeout is known to have elapsed). The deadline
   is monotonic, as std's is on Linux; the futex wait takes the
   remaining time (a relative timeout, CLOCK_MONOTONIC). */
#if defined(__linux__)
#if defined(__x86_64__)
#define LUST_SYS_CLOCK_GETTIME 228
#elif defined(__aarch64__)
#define LUST_SYS_CLOCK_GETTIME 113
#endif
#endif

static void lust_mono_now(long ts[2]) LUST_BODY({
#ifdef _WIN32
    LARGE_INTEGER freq, now;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&now);
    ts[0] = (long)(now.QuadPart / freq.QuadPart);
    ts[1] = (long)(((now.QuadPart % freq.QuadPart) * 1000000000) / freq.QuadPart);
#elif defined(LUST_SYS_CLOCK_GETTIME)
    syscall(LUST_SYS_CLOCK_GETTIME, 1 /* CLOCK_MONOTONIC */, ts);
#elif defined(__APPLE__)
    /* struct timespec is two longs on Darwin, as ts is. std's
       Instant on Apple is CLOCK_UPTIME_RAW (mach_absolute_time),
       the clock its timeouts are measured against. */
    clock_gettime(CLOCK_UPTIME_RAW, (void *)ts);
#else
    ts[0] = 0;
    ts[1] = 0;
#endif
})

/* `Instant::now()` for `Condvar::wait_timeout_while` (cgen/sync.rs). */
void lust_cv_start(long ts[2]) LUST_BODY({ lust_mono_now(ts); })

/* std's `dur.checked_sub(start.elapsed())`: 1 and the time left in
   `*rs`/`*rn`, or 0 when the elapsed time is past `dur`. */
int lust_cv_left(const long start[2], uint64_t secs, uint32_t nanos, uint64_t *rs, uint32_t *rn) LUST_BODY({
    long now[2];
    lust_mono_now(now);
    uint64_t es = (uint64_t)(now[0] - start[0]);
    long en = now[1] - start[1];
    if (en < 0) {
        es -= 1;
        en += 1000000000L;
    }
    if (es > secs || (es == secs && (uint32_t)en > nanos)) return 0;
    uint64_t s = secs - es;
    long n = (long)nanos - en;
    if (n < 0) {
        s -= 1;
        n += 1000000000L;
    }
    *rs = s;
    *rn = (uint32_t)n;
    return 1;
})

int lust_cv_wait_timeout(uint32_t *cv, uint32_t *m, uint64_t secs, uint32_t nanos) LUST_BODY({
    long dl[2];
    lust_mono_now(dl);
    dl[0] += (long)secs;
    dl[1] += (long)nanos;
    if (dl[1] >= 1000000000L) {
        dl[0] += 1;
        dl[1] -= 1000000000L;
    }
    uint32_t s;
    __atomic_load(cv, &s, 5);
    lust_mutex_unlock(m);
    int timed = 0;
    for (;;) {
        uint32_t cur;
        __atomic_load(cv, &cur, 5);
        if (cur != s) break;
        long now[2];
        lust_mono_now(now);
        long rs = dl[0] - now[0];
        long rn = dl[1] - now[1];
        if (rn < 0) {
            rs -= 1;
            rn += 1000000000L;
        }
        if (rs < 0) {
            timed = 1;
            break;
        }
        lust_futex_wait_for(cv, s, rs, rn);
    }
    lust_mutex_lock(m);
    return timed;
})

/* `Receiver::recv_timeout`: 0 received into out; 1 timed out; 2 every
   sender is gone and nothing is queued. std's order: a queued value
   first, then disconnection, then the deadline (`Instant::now() +
   timeout`, monotonic). A deadline past what `Instant` holds (tv_sec
   overflows i64) is std's plain `recv`. */
int lust_chan_recv_timeout(lust_Chan *c, void *out, uint64_t secs, uint32_t nanos) LUST_BODY({
    long dl[2];
    lust_mono_now(dl);
    if (secs > (uint64_t)(0x7fffffffffffffffL - dl[0])) return lust_chan_recv(c, out, 1) ? 2 : 0;
    dl[0] += (long)secs;
    dl[1] += (long)nanos;
    if (dl[1] >= 1000000000L) {
        if (dl[0] == 0x7fffffffffffffffL) return lust_chan_recv(c, out, 1) ? 2 : 0;
        dl[0] += 1;
        dl[1] -= 1000000000L;
    }
    lust_mutex_lock(&c->lock);
    c->rx_waiting++;
    lust_chan_changed(c);
    for (;;) {
        if (c->len > 0) {
            lust_chan_pop(c, out);
            c->rx_waiting--;
            lust_chan_changed(c);
            lust_mutex_unlock(&c->lock);
            return 0;
        }
        if (c->senders == 0) { c->rx_waiting--; lust_mutex_unlock(&c->lock); return 2; }
        long now[2];
        lust_mono_now(now);
        long rs = dl[0] - now[0];
        long rn = dl[1] - now[1];
        if (rn < 0) {
            rs -= 1;
            rn += 1000000000L;
        }
        if (rs < 0 || (rs == 0 && rn == 0)) {
            c->rx_waiting--;
            if (c->cap == 0 && c->tx_waiting > 0) { lust_chan_claim(c, out); return 0; }
            lust_mutex_unlock(&c->lock);
            return 1;
        }
        uint32_t s;
        c->sleepers++;
        __atomic_load(&c->seq, &s, 5);
        lust_mutex_unlock(&c->lock);
        lust_futex_wait_for(&c->seq, s, rs, rn);
        lust_mutex_lock(&c->lock);
        c->sleepers--;
    }
})

typedef struct lust_Barrier {
    uint32_t lock;
    uint32_t seq;
    uint64_t count;
    uint64_t gen;
    uint64_t n;
} lust_Barrier;

/* 1 for the leader (the arrival that releases the others). */
int lust_barrier_wait(lust_Barrier *b) LUST_BODY({
    lust_mutex_lock(&b->lock);
    uint64_t g = b->gen;
    if (++b->count < b->n) {
        while (b->gen == g) {
            uint32_t s;
            __atomic_load(&b->seq, &s, 5);
            lust_mutex_unlock(&b->lock);
            lust_futex_wait(&b->seq, s);
            lust_mutex_lock(&b->lock);
        }
        lust_mutex_unlock(&b->lock);
        return 0;
    }
    b->count = 0;
    b->gen++;
    lust_cv_notify(&b->seq, 1);
    lust_mutex_unlock(&b->lock);
    return 1;
})

/* 1 when the caller must set the value (state is now 1); 0 when it is
   set (after waiting out another thread's set). */
int lust_once_begin(uint32_t *st) LUST_BODY({
    for (;;) {
        uint32_t zero = 0, one = 1, three = 3, s;
        if (__atomic_compare_exchange(st, &zero, &one, 0, 2, 2)) return 1;
        __atomic_load(st, &s, 2);
        if (s == 2) return 0;
        if (s == 0) continue;
        /* Being set: say a thread waits (1 -> 3), then sleep while it is so. */
        if (s == 1 && !__atomic_compare_exchange(st, &s, &three, 0, 2, 2)) continue;
        lust_futex_wait(st, 3);
    }
})

void lust_once_finish(uint32_t *st) LUST_BODY({
    uint32_t two = 2, old;
    __atomic_exchange(st, &two, &old, 3);
    if (old == 3) lust_futex_wake(st, 0x7fffffff);
})

/* A set whose init closure panicked (panic=unwind): the lock is empty
   again, and one waiting thread becomes the next setter, as in std. */
void lust_once_abort(uint32_t *st) LUST_BODY({
    uint32_t zero = 0, old;
    __atomic_exchange(st, &zero, &old, 3);
    if (old == 3) lust_futex_wake(st, 0x7fffffff);
})

/* `get_or_init` under unwind tables (runtime/panic.c mode 2): the init block's
   cleanup variable. When the init panicked (still armed), it drops a by-ref
   closure's env (std drops `f` inside the call) and empties the lock again. */
struct lust_once_guard { uint32_t *st; void *env; void (*drop)(void *); int32_t armed; };
void lust_once_guard_end(struct lust_once_guard *g) LUST_BODY({
    if (!g->armed) return;
    if (g->drop) g->drop(g->env);
    lust_once_abort(g->st);
})

int lust_once_is_done(uint32_t *st) LUST_BODY({
    uint32_t s;
    __atomic_load(st, &s, 2);
    return s == 2;
})

/* ---------- Duration and thread::sleep ----------

   A Duration is { uint64_t secs; uint32_t nanos; } (nanos < 1e9). */
typedef struct lust_Duration {
    uint64_t secs;
    uint32_t nanos;
} lust_Duration;

/* `Duration::new(secs, nanos)`: carries whole seconds out of nanos;
   panics as std on overflow. */
lust_Duration lust_dur_new(uint64_t secs, uint32_t nanos, lust_loc loc) LUST_BODY({
    lust_Duration d;
    uint64_t extra = nanos / 1000000000u;
    (void)loc;
    if (secs > UINT64_MAX - extra) lust_panic_std("overflow in Duration::new", "core/src/time.rs:201:18");
    d.secs = secs + extra;
    d.nanos = nanos % 1000000000u;
    return d;
})

/* secs * per_sec + nanos / nanos_per as a u128 (as_millis and kin). */
lust_u128 lust_dur_as(lust_Duration d, uint64_t per_sec, uint64_t nanos_per) LUST_BODY({
    uint64_t a = d.secs, b = per_sec;
    uint64_t alo = a & 0xffffffffu, ahi = a >> 32, blo = b & 0xffffffffu, bhi = b >> 32;
    uint64_t ll = alo * blo, lh = alo * bhi, hl = ahi * blo, hh = ahi * bhi;
    uint64_t mid = (ll >> 32) + (lh & 0xffffffffu) + (hl & 0xffffffffu);
    lust_u128 r;
    r.lo = (ll & 0xffffffffu) | (mid << 32);
    r.hi = hh + (lh >> 32) + (hl >> 32) + (mid >> 32);
    lust_u128 add;
    add.lo = d.nanos / nanos_per;
    add.hi = 0;
    return lust_u128_add(r, add);
})

#ifdef LUST_IMPL
#if defined(__linux__) && defined(__x86_64__)
#define LUST_SYS_NANOSLEEP 35
#elif defined(__linux__) && defined(__aarch64__)
#define LUST_SYS_NANOSLEEP 101
#endif
#endif

/* `thread::sleep`: nanosleep through syscall (no <time.h> in the runtime
   text), resumed after a signal. On Darwin, libc nanosleep (runtime.h
   included <time.h> there), the same loop. */
void lust_thread_sleep(lust_Duration d) LUST_BODY({
#ifdef _WIN32
    while (d.secs > 0 || d.nanos > 0) {
        uint64_t ms = d.secs > 4000000 ? 4000000000ull : d.secs * 1000 + d.nanos / 1000000;
        Sleep((DWORD)ms);
        if (d.secs > 4000000) d.secs -= 4000000; else { d.secs = 0; d.nanos = 0; }
    }
#elif defined(LUST_SYS_NANOSLEEP)
    long ts[2], rem[2];
    while (d.secs > 0 || d.nanos > 0) {
        uint64_t s = d.secs > 0x7fffffff ? 0x7fffffff : d.secs;
        ts[0] = (long)s;
        ts[1] = (long)d.nanos;
        d.secs -= s;
        d.nanos = 0;
        while (syscall(LUST_SYS_NANOSLEEP, ts, rem) != 0) { ts[0] = rem[0]; ts[1] = rem[1]; }
    }
#elif defined(__APPLE__)
    long ts[2], rem[2];
    while (d.secs > 0 || d.nanos > 0) {
        uint64_t s = d.secs > 0x7fffffff ? 0x7fffffff : d.secs;
        ts[0] = (long)s;
        ts[1] = (long)d.nanos;
        d.secs -= s;
        d.nanos = 0;
        while (nanosleep((void *)ts, (void *)rem) != 0) { ts[0] = rem[0]; ts[1] = rem[1]; }
    }
#else
    (void)d;
    sched_yield();
#endif
})

/* The std platform crate's syscalls (src/runtime/sys.h, W-SHIM). */
/* The std platform crate's runtime (docs/ARCH.md sections 3.1 and 3.7,
   package W-SHIM): the C behind the `sys_*` intrinsics of src/ty/lang.rs,
   called from library/std/src/platform.rs and its modules. A `&[u8]`
   argument (SigTy::Bytes) arrives as a pointer and a length; `&mut
   String` and `&mut Vec<u8>` arrive as pointers to the runtime structs.
   OS errors return as errno values, as std's `io::Error::last_os_error`
   reads them.

   Declarations here are in every unit; bodies (sys.c) only in the
   runtime unit (LUST_IMPL), like deps.h. */
#ifndef LUST_RT_SYS_H
#define LUST_RT_SYS_H

/* struct stat time fields by name: Linux spells them st_atim and kin,
   Darwin st_atimespec and kin, and only Darwin's stat carries the
   birth time in the stat itself (Linux reads it through statx). The
   sys*.c files below read times through these spellings. */
#ifdef __APPLE__
#define LUST_ST_ATIME(st) (st).st_atimespec
#define LUST_ST_MTIME(st) (st).st_mtimespec
#define LUST_ST_CTIME(st) (st).st_ctimespec
#define LUST_ST_BTIME(st) (st).st_birthtimespec
#else
#define LUST_ST_ATIME(st) (st).st_atim
#define LUST_ST_MTIME(st) (st).st_mtim
#define LUST_ST_CTIME(st) (st).st_ctim
#endif

/* Standard streams: writes go through the C stdio streams `print!` and
   `eprint!` use (stderr is flushed after each write, as Rust's stderr
   is unbuffered). */
int64_t lust_sys_write_std(int32_t fd, const uint8_t *p, uint64_t len);
int32_t lust_sys_flush_std(int32_t fd);

/* The text of a `fmt::Arguments` value (fmt.h), formatted now, as a
   Vec<u8> (std's `io::Write::write_fmt`). A fmt impl error panics as
   std's does. */
lust_Vec lust_sys_fmt_arguments_bytes(lust_Arguments args);

/* Byte views of text (OsStr, Path): a `&[u8]` return comes back as a
   lust_str (cgen rebuilds the slice value from its ptr and len). */
lust_str lust_sys_str_as_bytes(lust_str s);
lust_str lust_sys_bytes_as_str(const uint8_t *p, uint64_t len);
lust_String lust_sys_string_from_utf8_unchecked(lust_Vec v);
uint64_t lust_sys_utf8_valid_up_to(const uint8_t *p, uint64_t len);
void lust_sys_utf8_lossy(const uint8_t *p, uint64_t len, lust_String *out);

/* Environment: getenv into a Vec<u8>; 0 when unset or the key has NUL. */
uint8_t lust_sys_getenv(const uint8_t *k, uint64_t klen, lust_Vec *out);

/* Environment and process state: `environ` and `argv` entries each
   with a NUL terminator; getcwd, chdir, readlink. Path arguments with
   a NUL byte return -1 (no syscall); other failures return errno. */
void lust_sys_environ(lust_Vec *out);
void lust_sys_argv(lust_Vec *out);
int32_t lust_sys_getcwd(lust_Vec *out);
int32_t lust_sys_chdir(const uint8_t *p, uint64_t len);
int32_t lust_sys_symlink(const uint8_t *a, uint64_t alen, const uint8_t *b, uint64_t blen);
int32_t lust_sys_readlink(const uint8_t *p, uint64_t len, lust_Vec *out);

/* Files and directories (std::fs): read a whole file into the Vec,
   write (create or truncate, 0666; -2 for a zero-length write), mkdir
   (op 0), unlink (op 1), rmdir (op 2), rename, stat or lstat as 8-byte
   fields, realpath, the names of a directory, and remove_dir_all. Same
   returns as above: 0, errno, or -1 for a path with a NUL byte. */
int32_t lust_sys_read_file(const uint8_t *p, uint64_t len, lust_Vec *out);
int32_t lust_sys_write_file(const uint8_t *p, uint64_t len, const uint8_t *d, uint64_t dlen);
int32_t lust_sys_path_op(const uint8_t *p, uint64_t len, int32_t op);
int32_t lust_sys_rename(const uint8_t *a, uint64_t alen, const uint8_t *b, uint64_t blen);
int32_t lust_sys_stat(const uint8_t *p, uint64_t len, uint8_t follow, lust_Vec *out);
int32_t lust_sys_realpath(const uint8_t *p, uint64_t len, lust_Vec *out);
int32_t lust_sys_read_dir(const uint8_t *p, uint64_t len, lust_Vec *out);
int32_t lust_sys_remove_dir_all(const uint8_t *p, uint64_t len);

/* The statx birth time behind `Metadata::created` (sys.c):
   1 with the seconds and nanoseconds in the out args when the
   filesystem reports one, else 0. */
int32_t lust_sys_btime_path(const char *path, int32_t follow, int64_t *sec, int64_t *nsec);
int32_t lust_sys_btime_fd(int32_t fd, int64_t *sec, int64_t *nsec);

uint32_t lust_sys_getpid(void);

/* The running executable's path appended to the Vec (`env::current_exe`):
   /proc/self/exe on Linux, _NSGetExecutablePath on Darwin (no NUL
   appended). Returns 0 or the errno of the failed call, as std's
   last_os_error forms read it. */
int32_t lust_sys_current_exe(lust_Vec *out);

/* The OS text of an error code, as std's `error_string` (strerror). */
void lust_sys_os_error_text(int32_t code, lust_String *out);

#ifdef LUST_IMPL
#ifdef _WIN32
/* Bodies of the std platform intrinsics declared in sys.h, for
   Windows (rel-win). Spliced instead of sys.c under _WIN32 (see
   cgen::runtime_source). Paths cross from Rust as UTF-8 bytes (lust's
   OsStr is bytes today; full WTF-8 over UTF-16 is a later slice) and
   go to the wide Win32 calls. Errors return as GetLastError codes,
   as std's io::Error::last_os_error reads them on Windows; the text
   comes from FormatMessageW. A path with a NUL byte returns -1, as
   on Linux. */

int32_t lust_stdout_write_soft(const uint8_t *p, uint64_t n); /* panic.c */
int32_t lust_stdout_flush_soft(void);

int64_t lust_sys_write_std(int32_t fd, const uint8_t *p, uint64_t len) {
    if (len == 0) return 0;
    if (fd != 2) {
        int32_t e = lust_stdout_write_soft(p, len);
        return e ? -(int64_t)e : (int64_t)len;
    }
    HANDLE h = GetStdHandle((DWORD)-12);
    uint64_t left = len;
    const uint8_t *q = p;
    while (left) {
        DWORD done = 0;
        DWORD want = (DWORD)(left > 0x7fffffff ? 0x7fffffff : left);
        if (!WriteFile(h, q, want, &done, 0)) return -(int64_t)GetLastError();
        if (done == 0) break;
        q += done;
        left -= done;
    }
    return (int64_t)(len - left);
}

int32_t lust_sys_flush_std(int32_t fd) {
    if (fd != 2) return lust_stdout_flush_soft();
    return 0; /* stderr is unbuffered here, as in std */
}

void lust_sys_os_error_text(int32_t code, lust_String *out) {
    WCHAR buf[512];
    DWORD n = FormatMessageW(0x1000 /* FROM_SYSTEM */ | 0x200 /* IGNORE_INSERTS */, 0, (DWORD)code, 0x409, buf, 512, 0);
    if (n == 0) n = FormatMessageW(0x1000 | 0x200, 0, (DWORD)code, 0, buf, 512, 0);
    while (n > 0 && (buf[n - 1] == L'\r' || buf[n - 1] == L'\n' || buf[n - 1] == L'.')) n--;
    if (n == 0) {
        lust_string_push_cstr(out, "Unknown error");
        return;
    }
    int need = WideCharToMultiByte(65001 /* UTF-8 */, 0, buf, (int)n, 0, 0, 0, 0);
    char *u = malloc((size_t)need + 1);
    if (!u) lust_oom();
    WideCharToMultiByte(65001, 0, buf, (int)n, u, need, 0, 0);
    u[need] = 0;
    lust_string_push_cstr(out, u);
    free(u);
}

lust_Vec lust_sys_fmt_arguments_bytes(lust_Arguments args) {
    lust_String s = lust_string_with_capacity(0);
    lust_sink k;
    lust_sink_string(&k, &s);
    if (lust_args_write(&args, &k)) lust_fmt_failed(2, 0);
    lust_Vec v;
    v.ptr = s.ptr;
    v.len = s.len;
    v.cap = s.cap;
    return v;
}

lust_str lust_sys_str_as_bytes(lust_str s) { return s; }

lust_str lust_sys_bytes_as_str(const uint8_t *p, uint64_t len) {
    lust_str s;
    s.ptr = (uint8_t *)p;
    s.len = len;
    return s;
}

lust_String lust_sys_string_from_utf8_unchecked(lust_Vec v) {
    lust_String s;
    s.ptr = (uint8_t *)v.ptr;
    s.len = v.len;
    s.cap = v.cap;
    return s;
}

/* Appends `n` bytes to a Vec<u8>. */
static void lust_sys_push(lust_Vec *out, const void *p, uint64_t n) {
    lust_vec_reserve(out, n, 1, 1);
    memcpy((uint8_t *)out->ptr + out->len, p, (size_t)n);
    out->len += n;
}

/* A path as a wide string: malloc'd, or NULL for a NUL byte. */
static WCHAR *lust_sys_wide(const uint8_t *p, uint64_t len) {
    if (memchr(p, 0, (size_t)len)) return NULL;
    int n = MultiByteToWideChar(65001, 0, (const char *)p, (int)len, 0, 0);
    WCHAR *w = malloc(sizeof(WCHAR) * ((size_t)n + 1));
    if (!w) lust_oom();
    MultiByteToWideChar(65001, 0, (const char *)p, (int)len, w, n);
    w[n] = 0;
    return w;
}

/* Appends a wide string as UTF-8 bytes (no terminator). */
static void lust_sys_push_wide(lust_Vec *out, const WCHAR *w, int n) {
    int need = WideCharToMultiByte(65001, 0, w, n, 0, 0, 0, 0);
    char *u = malloc((size_t)need + 1);
    if (!u) lust_oom();
    WideCharToMultiByte(65001, 0, w, n, u, need, 0, 0);
    lust_sys_push(out, u, (uint64_t)need);
    free(u);
}

static void lust_sys_push_wide0(lust_Vec *out, const WCHAR *w) {
    int n = 0;
    while (w[n]) n++;
    lust_sys_push_wide(out, w, n);
    uint8_t z = 0;
    lust_sys_push(out, &z, 1);
}

uint8_t lust_sys_getenv(const uint8_t *k, uint64_t klen, lust_Vec *out) {
    WCHAR *key = lust_sys_wide(k, klen);
    if (!key) return 0;
    DWORD n = GetEnvironmentVariableW(key, 0, 0);
    if (n == 0) { free(key); return 0; }
    WCHAR *v = malloc(sizeof(WCHAR) * n);
    if (!v) lust_oom();
    GetEnvironmentVariableW(key, v, n);
    free(key);
    lust_sys_push_wide(out, v, (int)n - 1);
    free(v);
    return 1;
}

void lust_sys_environ(lust_Vec *out) {
    WCHAR *e = GetEnvironmentStringsW();
    if (!e) return;
    for (WCHAR *p = e; *p; p++) {
        lust_sys_push_wide0(out, p);
        while (*p) p++;
    }
    FreeEnvironmentStringsW(e);
}

void lust_sys_argv(lust_Vec *out) {
    int argc = 0;
    WCHAR **argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    if (!argv) return;
    for (int i = 0; i < argc; i++) lust_sys_push_wide0(out, argv[i]);
    LocalFree(argv);
}

int32_t lust_sys_getcwd(lust_Vec *out) {
    DWORD n = GetCurrentDirectoryW(0, 0);
    if (n == 0) return (int32_t)GetLastError();
    WCHAR *buf = malloc(sizeof(WCHAR) * n);
    if (!buf) lust_oom();
    if (GetCurrentDirectoryW(n, buf) == 0) { int32_t e = (int32_t)GetLastError(); free(buf); return e; }
    lust_sys_push_wide(out, buf, (int)n - 1);
    free(buf);
    return 0;
}

int32_t lust_sys_chdir(const uint8_t *p, uint64_t len) {
    WCHAR *w = lust_sys_wide(p, len);
    if (!w) return -1;
    int r = SetCurrentDirectoryW(w) ? 0 : (int)GetLastError();
    free(w);
    return r;
}

int32_t lust_sys_symlink(const uint8_t *a, uint64_t alen, const uint8_t *b, uint64_t blen) {
    WCHAR *x = lust_sys_wide(a, alen);
    if (!x) return -1;
    WCHAR *y = lust_sys_wide(b, blen);
    if (!y) { free(x); return -1; }
    /* 2 is SYMBOLIC_LINK_FLAG_ALLOW_UNPRIVILEGED_CREATE. The dir bit
       (1) needs the target kind; std's symlink_dir sets it. This
       intrinsic serves fs::symlink's Unix form, which std on Windows
       splits into symlink_file/dir: file form here (gap noted). */
    int r = CreateSymbolicLinkW(y, x, 2) ? 0 : (int)GetLastError();
    free(x);
    free(y);
    return r;
}

/* The final path of an open handle as UTF-8, with the \\?\ prefix
   std's canonicalize keeps (goport strips it itself). */
static int32_t lust_sys_final_path(HANDLE h, lust_Vec *out) {
    WCHAR buf[1024];
    DWORD n = GetFinalPathNameByHandleW(h, buf, 1024, 0);
    if (n == 0) return (int32_t)GetLastError();
    if (n < 1024) { lust_sys_push_wide(out, buf, (int)n); return 0; }
    WCHAR *big = malloc(sizeof(WCHAR) * (n + 1));
    if (!big) lust_oom();
    n = GetFinalPathNameByHandleW(h, big, n + 1, 0);
    if (n == 0) { int32_t e = (int32_t)GetLastError(); free(big); return e; }
    lust_sys_push_wide(out, big, (int)n);
    free(big);
    return 0;
}

int32_t lust_sys_readlink(const uint8_t *p, uint64_t len, lust_Vec *out) {
    /* env::current_exe reads /proc/self/exe through this intrinsic. */
    if (len == 14 && memcmp(p, "/proc/self/exe", 14) == 0) {
        WCHAR buf[1024];
        DWORD n = GetModuleFileNameW(0, buf, 1024);
        if (n == 0) return (int32_t)GetLastError();
        lust_sys_push_wide(out, buf, (int)n);
        return 0;
    }
    WCHAR *w = lust_sys_wide(p, len);
    if (!w) return -1;
    HANDLE h = CreateFileW(w, 0, 7, 0, 3 /* OPEN_EXISTING */, 0x200000 /* BACKUP_SEMANTICS */ | 0x2000000 /* OPEN_REPARSE_POINT */, 0);
    free(w);
    if (h == INVALID_HANDLE_VALUE) return (int32_t)GetLastError();
    int32_t r = lust_sys_final_path(h, out);
    CloseHandle(h);
    return r;
}

int32_t lust_sys_read_file(const uint8_t *p, uint64_t len, lust_Vec *out) {
    WCHAR *w = lust_sys_wide(p, len);
    if (!w) return -1;
    HANDLE h = CreateFileW(w, 0x80000000u /* GENERIC_READ */, 7, 0, 3, 0x200000, 0);
    free(w);
    if (h == INVALID_HANDLE_VALUE) return (int32_t)GetLastError();
    uint8_t buf[65536];
    for (;;) {
        DWORD n = 0;
        if (!ReadFile(h, buf, sizeof buf, &n, 0)) { int32_t e = (int32_t)GetLastError(); CloseHandle(h); return e; }
        if (n == 0) break;
        lust_sys_push(out, buf, n);
    }
    CloseHandle(h);
    return 0;
}

int32_t lust_sys_write_file(const uint8_t *p, uint64_t len, const uint8_t *d, uint64_t dlen) {
    WCHAR *w = lust_sys_wide(p, len);
    if (!w) return -1;
    HANDLE h = CreateFileW(w, 0x40000000u /* GENERIC_WRITE */, 0, 0, 2 /* CREATE_ALWAYS */, 0x200000, 0);
    free(w);
    if (h == INVALID_HANDLE_VALUE) return (int32_t)GetLastError();
    while (dlen > 0) {
        DWORD n = 0;
        DWORD want = (DWORD)(dlen > 0x7fffffff ? 0x7fffffff : dlen);
        if (!WriteFile(h, d, want, &n, 0)) { int32_t e = (int32_t)GetLastError(); CloseHandle(h); return e; }
        if (n == 0) { CloseHandle(h); return -2; }
        d += n;
        dlen -= n;
    }
    CloseHandle(h);
    return 0;
}

int32_t lust_sys_path_op(const uint8_t *p, uint64_t len, int32_t op) {
    WCHAR *w = lust_sys_wide(p, len);
    if (!w) return -1;
    int code = op & 0xff;
    int ok;
    if (code == 0 || code == 3) ok = CreateDirectoryW(w, 0);
    else if (code == 1) ok = DeleteFileW(w);
    else if (code == 4) { /* chmod: only the read-only bit exists here */
        DWORD at = GetFileAttributesW(w);
        if (at == 0xFFFFFFFFu) { int32_t e = (int32_t)GetLastError(); free(w); return e; }
        at = ((op >> 8) & 0200) ? (at & ~1u) : (at | 1u);
        ok = SetFileAttributesW(w, at);
    } else ok = RemoveDirectoryW(w);
    int32_t r = ok ? 0 : (int32_t)GetLastError();
    free(w);
    return r;
}

int32_t lust_sys_rename(const uint8_t *a, uint64_t alen, const uint8_t *b, uint64_t blen) {
    WCHAR *x = lust_sys_wide(a, alen);
    if (!x) return -1;
    WCHAR *y = lust_sys_wide(b, blen);
    if (!y) { free(x); return -1; }
    int r = MoveFileExW(x, y, 1 /* REPLACE_EXISTING */) ? 0 : (int)GetLastError();
    free(x);
    free(y);
    return r;
}

int32_t lust_sys_btime_path(const char *path, int32_t follow, int64_t *sec, int64_t *nsec) {
    (void)path; (void)follow; (void)sec; (void)nsec;
    return 0; /* filled from the stat fields below */
}

int32_t lust_sys_btime_fd(int32_t fd, int64_t *sec, int64_t *nsec) {
    (void)fd; (void)sec; (void)nsec;
    return 0;
}

/* A FILETIME to (Unix seconds, nanoseconds). */
static void lust_sys_ft(FILETIME ft, uint64_t *sec, uint64_t *nsec) {
    uint64_t t = ((uint64_t)ft.dwHighDateTime << 32) | ft.dwLowDateTime;
    if (t < 116444736000000000ull) { *sec = 0; *nsec = 0; return; }
    t -= 116444736000000000ull;
    *sec = t / 10000000ull;
    *nsec = (t % 10000000ull) * 100ull;
}

/* The 19 stat fields sys.c writes, from handle info. The mode is the
   Unix kind bits fs.rs reads (dir, regular, symlink for a reparse
   point) with 0755/0644; std on Windows has no mode, so only the
   kind and the read-only bit can match. Field 4 (uid slot) carries
   the raw file attributes for os::windows::fs::MetadataExt. */
void lust_sys_stat_fields(lust_Vec *out, DWORD attrs, uint64_t size, FILETIME ct, FILETIME at, FILETIME mt, uint64_t ino) {
    uint64_t cs, cn, as, an, ms, mn;
    lust_sys_ft(ct, &cs, &cn);
    lust_sys_ft(at, &as, &an);
    lust_sys_ft(mt, &ms, &mn);
    uint64_t mode = (attrs & 0x10) ? 0040755 : (attrs & 0x400) ? 0120777 : 0100644;
    if (attrs & 1) mode &= ~0222u;
    uint64_t f[19] = {mode, size, ms, mn, attrs, 0, 1, ino, 0, as, an, cs, cn, 0, 4096, 0, cs, cn, 1};
    for (int i = 0; i < 19; i++) {
        uint8_t b[8];
        for (int k = 0; k < 8; k++) b[k] = (uint8_t)(f[i] >> (8 * k));
        lust_sys_push(out, b, 8);
    }
}

int32_t lust_sys_stat(const uint8_t *p, uint64_t len, uint8_t follow, lust_Vec *out) {
    WCHAR *w = lust_sys_wide(p, len);
    if (!w) return -1;
    DWORD flags = 0x200000; /* BACKUP_SEMANTICS: dirs open too */
    if (!follow) flags |= 0x2000000; /* OPEN_REPARSE_POINT */
    HANDLE h = CreateFileW(w, 0, 7, 0, 3, flags, 0);
    free(w);
    if (h == INVALID_HANDLE_VALUE) return (int32_t)GetLastError();
    BY_HANDLE_FILE_INFORMATION info;
    if (!GetFileInformationByHandle(h, &info)) { int32_t e = (int32_t)GetLastError(); CloseHandle(h); return e; }
    CloseHandle(h);
    uint64_t size = ((uint64_t)info.nFileSizeHigh << 32) | info.nFileSizeLow;
    uint64_t ino = ((uint64_t)info.nFileIndexHigh << 32) | info.nFileIndexLow;
    lust_sys_stat_fields(out, info.dwFileAttributes, size, info.ftCreationTime, info.ftLastAccessTime, info.ftLastWriteTime, ino);
    return 0;
}

int32_t lust_sys_realpath(const uint8_t *p, uint64_t len, lust_Vec *out) {
    WCHAR *w = lust_sys_wide(p, len);
    if (!w) return -1;
    HANDLE h = CreateFileW(w, 0, 7, 0, 3, 0x200000, 0);
    free(w);
    if (h == INVALID_HANDLE_VALUE) return (int32_t)GetLastError();
    int32_t r = lust_sys_final_path(h, out);
    CloseHandle(h);
    return r;
}

int32_t lust_sys_read_dir(const uint8_t *p, uint64_t len, lust_Vec *out) {
    WCHAR *w = lust_sys_wide(p, len);
    if (!w) return -1;
    size_t wl = 0;
    while (w[wl]) wl++;
    WCHAR *pat = malloc(sizeof(WCHAR) * (wl + 3));
    if (!pat) lust_oom();
    memcpy(pat, w, sizeof(WCHAR) * wl);
    pat[wl] = L'\\';
    pat[wl + 1] = L'*';
    pat[wl + 2] = 0;
    free(w);
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW(pat, &fd);
    free(pat);
    if (h == INVALID_HANDLE_VALUE) {
        DWORD e = GetLastError();
        return e == 2 /* empty dir reads as no entries on Windows */ ? (int32_t)e : (int32_t)e;
    }
    for (;;) {
        if (!(fd.cFileName[0] == L'.' && (fd.cFileName[1] == 0 || (fd.cFileName[1] == L'.' && fd.cFileName[2] == 0))))
            lust_sys_push_wide0(out, fd.cFileName);
        if (!FindNextFileW(h, &fd)) break;
    }
    FindClose(h);
    return 0;
}

int32_t lust_sys_remove_dir_all(const uint8_t *p, uint64_t len) {
    WCHAR *w = lust_sys_wide(p, len);
    if (!w) return -1;
    /* std removes the tree depth first; SHFileOperation is shell32.
       A simple recursive walk here: delete children, then the dir. */
    DWORD at = GetFileAttributesW(w);
    if (at == 0xFFFFFFFFu) { int32_t e = (int32_t)GetLastError(); free(w); return e; }
    if (!(at & 0x10) || (at & 0x400)) {
        int r = DeleteFileW(w) ? 0 : (int)GetLastError();
        free(w);
        return r == 0 && (at & 0x400) ? 0 : (at & 0x10) ? r : 267 /* ENOTDIR as std maps it */;
    }
    size_t wl = 0;
    while (w[wl]) wl++;
    WCHAR *pat = malloc(sizeof(WCHAR) * (wl + 3));
    if (!pat) lust_oom();
    memcpy(pat, w, sizeof(WCHAR) * wl);
    pat[wl] = L'\\';
    pat[wl + 1] = L'*';
    pat[wl + 2] = 0;
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW(pat, &fd);
    free(pat);
    if (h != INVALID_HANDLE_VALUE) {
        for (;;) {
            if (!(fd.cFileName[0] == L'.' && (fd.cFileName[1] == 0 || (fd.cFileName[1] == L'.' && fd.cFileName[2] == 0)))) {
                /* Build child path bytes (UTF-8) and recurse. */
                lust_Vec child = {0, 0, 0};
                lust_sys_push_wide(&child, w, (int)wl);
                uint8_t slash = '\\';
                lust_sys_push(&child, &slash, 1);
                lust_sys_push_wide0(&child, fd.cFileName);
                if ((fd.dwFileAttributes & 0x10) && !(fd.dwFileAttributes & 0x400))
                    lust_sys_remove_dir_all((const uint8_t *)child.ptr, child.len - 1);
                else {
                    WCHAR *cw = lust_sys_wide((const uint8_t *)child.ptr, child.len - 1);
                    if (cw) { DeleteFileW(cw); free(cw); }
                }
                free(child.ptr);
            }
            if (!FindNextFileW(h, &fd)) break;
        }
        FindClose(h);
    }
    int r = RemoveDirectoryW(w) ? 0 : (int)GetLastError();
    free(w);
    return r;
}

uint32_t lust_sys_getpid(void) { return (uint32_t)GetCurrentProcessId(); }
/* The length of the valid UTF-8 sequence at p[i..], or 0 when it is
   invalid; `*bad` gets the length of the maximal invalid subpart then
   (core::str::Utf8Chunks: at least 1, at most 3). */
static uint64_t lust_sys_utf8_seq(const uint8_t *p, uint64_t i, uint64_t len, uint64_t *bad) {
    uint8_t b = p[i];
    *bad = 1;
    if (b < 0x80) return 1;
    uint64_t need;
    uint8_t lo = 0x80, hi = 0xBF;
    if (b >= 0xC2 && b <= 0xDF) need = 2;
    else if (b == 0xE0) { need = 3; lo = 0xA0; }
    else if (b >= 0xE1 && b <= 0xEC) need = 3;
    else if (b == 0xED) { need = 3; hi = 0x9F; }
    else if (b >= 0xEE && b <= 0xEF) need = 3;
    else if (b == 0xF0) { need = 4; lo = 0x90; }
    else if (b >= 0xF1 && b <= 0xF3) need = 4;
    else if (b == 0xF4) { need = 4; hi = 0x8F; }
    else return 0;
    for (uint64_t k = 1; k < need; k++) {
        if (i + k >= len) return 0;
        uint8_t c = p[i + k];
        if (c < (k == 1 ? lo : 0x80) || c > (k == 1 ? hi : 0xBF)) return 0;
        *bad = k + 1;
    }
    return need;
}

uint64_t lust_sys_utf8_valid_up_to(const uint8_t *p, uint64_t len) {
    uint64_t i = 0, bad;
    while (i < len) {
        uint64_t n = lust_sys_utf8_seq(p, i, len, &bad);
        if (n == 0) return i;
        i += n;
    }
    return len;
}

void lust_sys_utf8_lossy(const uint8_t *p, uint64_t len, lust_String *out) {
    uint64_t i = 0, start = 0, bad;
    while (i < len) {
        uint64_t n = lust_sys_utf8_seq(p, i, len, &bad);
        if (n) { i += n; continue; }
        lust_string_push_bytes(out, p + start, i - start);
        lust_string_push_bytes(out, "\xEF\xBF\xBD", 3);
        i += bad;
        start = i;
    }
    lust_string_push_bytes(out, p + start, len - start);
}

#else
/* Bodies of the std platform intrinsics declared in sys.h (W-SHIM). */
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#ifdef __linux__
#include <sys/syscall.h>
#endif

extern char **environ;

int32_t lust_stdout_write_soft(const uint8_t *p, uint64_t n); /* panic.c */
int32_t lust_stdout_flush_soft(void);

int64_t lust_sys_write_std(int32_t fd, const uint8_t *p, uint64_t len) {
    FILE *f = fd == 2 ? stderr : stdout;
    if (len == 0) return 0;
    /* Stdout shares print!'s LineWriter (W-PANIC, panic.c). */
    if (fd != 2) {
        int32_t e = lust_stdout_write_soft(p, len);
        return e ? -(int64_t)e : (int64_t)len;
    }
    size_t n = fwrite(p, 1, (size_t)len, f);
    if (n < len) {
        int e = errno ? errno : 5; /* EIO when stdio gives no reason */
        clearerr(f);
        if (n == 0) return -(int64_t)e;
    }
    if (fd == 2 && fflush(stderr) != 0) {
        int e = errno ? errno : 5;
        clearerr(stderr);
        return -(int64_t)e;
    }
    return (int64_t)n;
}

int32_t lust_sys_flush_std(int32_t fd) {
    if (fd != 2) return lust_stdout_flush_soft();
    FILE *f = stderr;
    if (fflush(f) != 0) {
        int e = errno ? errno : 5;
        clearerr(f);
        return e;
    }
    return 0;
}

void lust_sys_os_error_text(int32_t code, lust_String *out) {
    lust_string_push_cstr(out, strerror(code));
}

lust_Vec lust_sys_fmt_arguments_bytes(lust_Arguments args) {
    lust_String s = lust_string_with_capacity(0);
    lust_sink k;
    lust_sink_string(&k, &s);
    if (lust_args_write(&args, &k)) lust_fmt_failed(2, 0);
    lust_Vec v;
    v.ptr = s.ptr;
    v.len = s.len;
    v.cap = s.cap;
    return v;
}

lust_str lust_sys_str_as_bytes(lust_str s) { return s; }

lust_str lust_sys_bytes_as_str(const uint8_t *p, uint64_t len) {
    lust_str s;
    s.ptr = (uint8_t *)p;
    s.len = len;
    return s;
}

lust_String lust_sys_string_from_utf8_unchecked(lust_Vec v) {
    lust_String s;
    s.ptr = (uint8_t *)v.ptr;
    s.len = v.len;
    s.cap = v.cap;
    return s;
}

/* The length of the valid UTF-8 sequence at p[i..], or 0 when it is
   invalid; `*bad` gets the length of the maximal invalid subpart then
   (core::str::Utf8Chunks: at least 1, at most 3). */
static uint64_t lust_sys_utf8_seq(const uint8_t *p, uint64_t i, uint64_t len, uint64_t *bad) {
    uint8_t b = p[i];
    *bad = 1;
    if (b < 0x80) return 1;
    uint64_t need;
    uint8_t lo = 0x80, hi = 0xBF;
    if (b >= 0xC2 && b <= 0xDF) need = 2;
    else if (b == 0xE0) { need = 3; lo = 0xA0; }
    else if (b >= 0xE1 && b <= 0xEC) need = 3;
    else if (b == 0xED) { need = 3; hi = 0x9F; }
    else if (b >= 0xEE && b <= 0xEF) need = 3;
    else if (b == 0xF0) { need = 4; lo = 0x90; }
    else if (b >= 0xF1 && b <= 0xF3) need = 4;
    else if (b == 0xF4) { need = 4; hi = 0x8F; }
    else return 0;
    for (uint64_t k = 1; k < need; k++) {
        if (i + k >= len) return 0;
        uint8_t c = p[i + k];
        if (c < (k == 1 ? lo : 0x80) || c > (k == 1 ? hi : 0xBF)) return 0;
        *bad = k + 1;
    }
    return need;
}

uint64_t lust_sys_utf8_valid_up_to(const uint8_t *p, uint64_t len) {
    uint64_t i = 0, bad;
    while (i < len) {
        uint64_t n = lust_sys_utf8_seq(p, i, len, &bad);
        if (n == 0) return i;
        i += n;
    }
    return len;
}

void lust_sys_utf8_lossy(const uint8_t *p, uint64_t len, lust_String *out) {
    uint64_t i = 0, start = 0, bad;
    while (i < len) {
        uint64_t n = lust_sys_utf8_seq(p, i, len, &bad);
        if (n) { i += n; continue; }
        lust_string_push_bytes(out, p + start, i - start);
        lust_string_push_bytes(out, "\xEF\xBF\xBD", 3);
        i += bad;
        start = i;
    }
    lust_string_push_bytes(out, p + start, len - start);
}

uint8_t lust_sys_getenv(const uint8_t *k, uint64_t klen, lust_Vec *out) {
    char *key = malloc(klen + 1);
    if (!key) lust_oom();
    for (uint64_t i = 0; i < klen; i++) {
        if (k[i] == 0) { free(key); return 0; }
        key[i] = (char)k[i];
    }
    key[klen] = 0;
    const char *v = getenv(key);
    free(key);
    if (!v) return 0;
    uint64_t n = strlen(v);
    lust_vec_reserve(out, n, 1, 1);
    memcpy((uint8_t *)out->ptr + out->len, v, n);
    out->len += n;
    return 1;
}

/* Appends the bytes of a C string and a NUL terminator. */
static void lust_sys_push_cstr0(lust_Vec *out, const char *s) {
    uint64_t n = strlen(s) + 1;
    lust_vec_reserve(out, n, 1, 1);
    memcpy((uint8_t *)out->ptr + out->len, s, n);
    out->len += n;
}

/* A path or name as a C string: malloc'd, or NULL when it holds a NUL
   byte (std's "file name contained an unexpected NUL byte"). */
static char *lust_sys_cstr(const uint8_t *p, uint64_t len) {
    if (memchr(p, 0, len)) return NULL;
    char *s = malloc(len + 1);
    if (!s) lust_oom();
    memcpy(s, p, len);
    s[len] = 0;
    return s;
}

void lust_sys_environ(lust_Vec *out) {
    for (char **e = environ; e && *e; e++) lust_sys_push_cstr0(out, *e);
}

void lust_sys_argv(lust_Vec *out) {
    for (int i = 0; i < lust_argc; i++) lust_sys_push_cstr0(out, lust_argv[i]);
}

int32_t lust_sys_getcwd(lust_Vec *out) {
    uint64_t cap = 512;
    for (;;) {
        char *buf = malloc(cap);
        if (!buf) lust_oom();
        if (getcwd(buf, cap)) {
            uint64_t n = strlen(buf);
            lust_vec_reserve(out, n, 1, 1);
            memcpy((uint8_t *)out->ptr + out->len, buf, n);
            out->len += n;
            free(buf);
            return 0;
        }
        int e = errno;
        free(buf);
        if (e != ERANGE) return e;
        cap *= 2;
    }
}

int32_t lust_sys_chdir(const uint8_t *p, uint64_t len) {
    char *s = lust_sys_cstr(p, len);
    if (!s) return -1;
    int r = chdir(s);
    int e = errno;
    free(s);
    return r == 0 ? 0 : e;
}

int32_t lust_sys_symlink(const uint8_t *a, uint64_t alen, const uint8_t *b, uint64_t blen) {
    char *x = lust_sys_cstr(a, alen);
    if (!x) return -1;
    char *y = lust_sys_cstr(b, blen);
    if (!y) {
        free(x);
        return -1;
    }
    int r = symlink(x, y);
    int e = errno;
    free(x);
    free(y);
    return r == 0 ? 0 : e;
}

int32_t lust_sys_readlink(const uint8_t *p, uint64_t len, lust_Vec *out) {
    char *s = lust_sys_cstr(p, len);
    if (!s) return -1;
    uint64_t cap = 256;
    for (;;) {
        char *buf = malloc(cap);
        if (!buf) lust_oom();
        ssize_t n = readlink(s, buf, cap);
        if (n < 0) {
            int e = errno;
            free(buf);
            free(s);
            return e;
        }
        if ((uint64_t)n < cap) {
            lust_vec_reserve(out, (uint64_t)n, 1, 1);
            memcpy((uint8_t *)out->ptr + out->len, buf, (size_t)n);
            out->len += (uint64_t)n;
            free(buf);
            free(s);
            return 0;
        }
        free(buf);
        cap *= 2;
    }
}

/* Appends `n` bytes to a Vec<u8>. */
static void lust_sys_push(lust_Vec *out, const void *p, uint64_t n) {
    lust_vec_reserve(out, n, 1, 1);
    memcpy((uint8_t *)out->ptr + out->len, p, (size_t)n);
    out->len += n;
}

/* As std's fs::read: the Vec gets the size fstat reports, and the bytes are read straight
   into its spare capacity. When it is full, a read into a small buffer finds the end
   without growing it (std's small_probe_read); bytes past the reported size (a file that
   grew, or one whose size reads as 0) grow the Vec as usual. */
int32_t lust_sys_read_file(const uint8_t *p, uint64_t len, lust_Vec *out) {
    char *s = lust_sys_cstr(p, len);
    if (!s) return -1;
    int fd = open(s, O_RDONLY | O_CLOEXEC);
    int e = errno;
    free(s);
    if (fd < 0) return e;
    struct stat st;
    if (fstat(fd, &st) == 0 && st.st_size > 0) lust_vec_reserve_exact(out, (uint64_t)st.st_size, 1, 1);
    for (;;) {
        uint8_t probe[32];
        uint64_t room = out->cap - out->len;
        ssize_t n = room ? read(fd, (uint8_t *)out->ptr + out->len, room > 0x7ffff000 ? 0x7ffff000 : (size_t)room)
                         : read(fd, probe, sizeof probe);
        if (n < 0) {
            if (errno == EINTR) continue;
            e = errno;
            close(fd);
            return e;
        }
        if (n == 0) break;
        if (room) out->len += (uint64_t)n;
        else lust_sys_push(out, probe, (uint64_t)n);
    }
    close(fd);
    return 0;
}

int32_t lust_sys_write_file(const uint8_t *p, uint64_t len, const uint8_t *d, uint64_t dlen) {
    char *s = lust_sys_cstr(p, len);
    if (!s) return -1;
    int fd = open(s, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0666);
    int e = errno;
    free(s);
    if (fd < 0) return e;
    while (dlen > 0) {
        ssize_t n = write(fd, d, dlen > 0x7ffff000 ? 0x7ffff000 : (size_t)dlen);
        if (n < 0) {
            if (errno == EINTR) continue;
            e = errno;
            close(fd);
            return e;
        }
        if (n == 0) {
            close(fd);
            return -2; /* WriteZero */
        }
        d += n;
        dlen -= (uint64_t)n;
    }
    close(fd);
    return 0;
}

/* One path syscall: 0, errno, or -1 for a NUL byte. `op`: 0 mkdir
   (0777), 1 unlink, 2 rmdir, 3 | mode << 8 mkdir with that mode
   (`DirBuilder`; the kernel keeps only the low 12 bits anyway). */
int32_t lust_sys_path_op(const uint8_t *p, uint64_t len, int32_t op) {
    char *s = lust_sys_cstr(p, len);
    if (!s) return -1;
    int code = op & 0xff;
    int r;
    if (code == 4) {
        /* std's `fs::set_permissions`: chmod, retried on EINTR (cvt_r).
           The kernel keeps only the S_IALLUGO bits, the ones passed. */
        do r = chmod(s, (mode_t)((op >> 8) & 07777)); while (r != 0 && errno == EINTR);
    } else {
        r = code == 0 ? mkdir(s, 0777) : code == 1 ? unlink(s) : code == 3 ? mkdir(s, (mode_t)((op >> 8) & 07777)) : rmdir(s);
    }
    int e = errno;
    free(s);
    return r == 0 ? 0 : e;
}

int32_t lust_sys_rename(const uint8_t *a, uint64_t alen, const uint8_t *b, uint64_t blen) {
    char *x = lust_sys_cstr(a, alen);
    if (!x) return -1;
    char *y = lust_sys_cstr(b, blen);
    if (!y) {
        free(x);
        return -1;
    }
    int r = rename(x, y);
    int e = errno;
    free(x);
    free(y);
    return r == 0 ? 0 : e;
}

/* The birth time behind `Metadata::created`. On Linux std reads it
   through statx with AT_STATX_SYNC_AS_STAT: 1 when the filesystem
   reports one (STATX_BTIME in the mask). The kernel's struct statx
   (stable ABI, 256 bytes) is spelled out as in sysx.c, with its own
   name. On Darwin every stat carries st_birthtimespec and std
   returns it as the created time, so one is always reported. */
#ifdef __APPLE__
int32_t lust_sys_btime_path(const char *path, int32_t follow, int64_t *sec, int64_t *nsec) {
    struct stat st;
    if ((follow ? stat(path, &st) : lstat(path, &st)) != 0) return 0;
    *sec = (int64_t)LUST_ST_BTIME(st).tv_sec;
    *nsec = (int64_t)LUST_ST_BTIME(st).tv_nsec;
    return 1;
}

int32_t lust_sys_btime_fd(int32_t fd, int64_t *sec, int64_t *nsec) {
    struct stat st;
    if (fstat(fd, &st) != 0) return 0;
    *sec = (int64_t)LUST_ST_BTIME(st).tv_sec;
    *nsec = (int64_t)LUST_ST_BTIME(st).tv_nsec;
    return 1;
}
#else
struct lust_btime_time {
    int64_t tv_sec;
    uint32_t tv_nsec;
    int32_t reserved;
};
struct lust_btime_statx {
    uint32_t stx_mask;
    uint32_t stx_blksize;
    uint64_t stx_attributes;
    uint32_t stx_nlink;
    uint32_t stx_uid;
    uint32_t stx_gid;
    uint16_t stx_mode;
    uint16_t spare0[1];
    uint64_t stx_ino;
    uint64_t stx_size;
    uint64_t stx_blocks;
    uint64_t stx_attributes_mask;
    struct lust_btime_time stx_atime;
    struct lust_btime_time stx_btime;
    struct lust_btime_time stx_ctime;
    struct lust_btime_time stx_mtime;
    uint32_t stx_rdev_major;
    uint32_t stx_rdev_minor;
    uint32_t stx_dev_major;
    uint32_t stx_dev_minor;
    uint64_t stx_mnt_id;
    uint32_t stx_dio_mem_align;
    uint32_t stx_dio_offset_align;
    uint64_t spare3[12];
};
#ifndef LUST_SYS_statx
#define LUST_SYS_statx 332
#endif

static int32_t lust_btime_read(int32_t dirfd, const char *path, int32_t flags, int64_t *sec, int64_t *nsec) {
    struct lust_btime_statx stx;
    long r = syscall(LUST_SYS_statx, dirfd, path, flags, 0x800 /* STATX_BTIME */, &stx);
    if (r != 0 || !(stx.stx_mask & 0x800)) return 0;
    *sec = stx.stx_btime.tv_sec;
    *nsec = stx.stx_btime.tv_nsec;
    return 1;
}

int32_t lust_sys_btime_path(const char *path, int32_t follow, int64_t *sec, int64_t *nsec) {
    /* AT_STATX_SYNC_AS_STAT (0x800) in the high flags is 0; the
       nofollow bit is AT_SYMLINK_NOFOLLOW (0x100). */
    return lust_btime_read(AT_FDCWD, path, follow ? 0 : 0x100, sec, nsec);
}

int32_t lust_sys_btime_fd(int32_t fd, int64_t *sec, int64_t *nsec) {
    return lust_btime_read(fd, "", 0x1000 /* AT_EMPTY_PATH */, sec, nsec);
}

#endif

/* stat (follow != 0) or lstat into 8-byte little-endian fields of the
   Vec: mode, size, mtime seconds, mtime nanoseconds, uid, gid, nlink,
   ino, dev, atime s, atime ns, ctime s, ctime ns, blocks, blksize, rdev,
   btime s, btime ns, has-btime (Metadata::created). */
int32_t lust_sys_stat(const uint8_t *p, uint64_t len, uint8_t follow, lust_Vec *out) {
    char *s = lust_sys_cstr(p, len);
    if (!s) return -1;
    struct stat st;
    int r = follow ? stat(s, &st) : lstat(s, &st);
    int e = errno;
    if (r != 0) {
        free(s);
        return e;
    }
    int64_t bsec = 0, bnsec = 0;
    int32_t has_btime = lust_sys_btime_path(s, follow, &bsec, &bnsec);
    free(s);
    uint64_t f[19] = {st.st_mode, (uint64_t)st.st_size, (uint64_t)LUST_ST_MTIME(st).tv_sec, (uint64_t)LUST_ST_MTIME(st).tv_nsec, st.st_uid, st.st_gid,
                      (uint64_t)st.st_nlink, (uint64_t)st.st_ino, (uint64_t)st.st_dev, (uint64_t)LUST_ST_ATIME(st).tv_sec,
                      (uint64_t)LUST_ST_ATIME(st).tv_nsec, (uint64_t)LUST_ST_CTIME(st).tv_sec, (uint64_t)LUST_ST_CTIME(st).tv_nsec, (uint64_t)st.st_blocks,
                      (uint64_t)st.st_blksize, (uint64_t)st.st_rdev, (uint64_t)bsec, (uint64_t)bnsec, (uint64_t)has_btime};
    for (int i = 0; i < 19; i++) {
        uint8_t b[8];
        for (int k = 0; k < 8; k++) b[k] = (uint8_t)(f[i] >> (8 * k));
        lust_sys_push(out, b, 8);
    }
    return 0;
}

int32_t lust_sys_realpath(const uint8_t *p, uint64_t len, lust_Vec *out) {
    char *s = lust_sys_cstr(p, len);
    if (!s) return -1;
    char *r = realpath(s, NULL);
    int e = errno;
    free(s);
    if (!r) return e;
    lust_sys_push(out, r, strlen(r));
    free(r);
    return 0;
}

/* The names in a directory except `.` and `..`, each with a NUL
   terminator, in readdir order. */
int32_t lust_sys_read_dir(const uint8_t *p, uint64_t len, lust_Vec *out) {
    char *s = lust_sys_cstr(p, len);
    if (!s) return -1;
    DIR *d = opendir(s);
    int e = errno;
    free(s);
    if (!d) return e;
    for (;;) {
        errno = 0;
        struct dirent *ent = readdir(d);
        if (!ent) {
            e = errno;
            closedir(d);
            return e;
        }
        const char *n = ent->d_name;
        if (n[0] == '.' && (n[1] == 0 || (n[1] == '.' && n[2] == 0))) continue;
        lust_sys_push(out, n, strlen(n) + 1);
    }
}

/* std's remove_dir_all on Linux: a symlink is unlinked; a directory is
   emptied depth first (children that vanish meanwhile are fine) and
   removed; anything else fails with ENOTDIR. */
static int lust_sys_rm_tree(int parent, const char *name) {
    int fd = openat(parent, name, O_RDONLY | O_CLOEXEC | O_DIRECTORY | O_NOFOLLOW);
    if (fd < 0) {
        int e = errno;
        if (e == ENOTDIR || e == ELOOP) return unlinkat(parent, name, 0) == 0 || errno == ENOENT ? 0 : errno;
        return e;
    }
    DIR *d = fdopendir(fd);
    if (!d) {
        int e = errno;
        close(fd);
        return e;
    }
    for (;;) {
        errno = 0;
        struct dirent *ent = readdir(d);
        if (!ent) {
            int e = errno;
            if (e) {
                closedir(d);
                return e;
            }
            break;
        }
        const char *n = ent->d_name;
        if (n[0] == '.' && (n[1] == 0 || (n[1] == '.' && n[2] == 0))) continue;
        int e = lust_sys_rm_tree(dirfd(d), n);
        if (e && e != ENOENT) {
            closedir(d);
            return e;
        }
    }
    closedir(d);
    if (unlinkat(parent, name, AT_REMOVEDIR) != 0 && errno != ENOENT) return errno;
    return 0;
}

int32_t lust_sys_remove_dir_all(const uint8_t *p, uint64_t len) {
    char *s = lust_sys_cstr(p, len);
    if (!s) return -1;
    struct stat st;
    int e = 0;
    if (lstat(s, &st) != 0) e = errno;
    else if (S_ISLNK(st.st_mode)) e = unlink(s) == 0 ? 0 : errno;
    else {
        int fd = open(s, O_RDONLY | O_CLOEXEC | O_DIRECTORY | O_NOFOLLOW);
        if (fd < 0) e = errno;
        else {
            close(fd);
            e = lust_sys_rm_tree(AT_FDCWD, s);
        }
    }
    free(s);
    return e;
}

uint32_t lust_sys_getpid(void) { return (uint32_t)getpid(); }

/* `env::current_exe`: std reads /proc/self/exe on Linux and
   _NSGetExecutablePath on Darwin (two calls: the size with a NULL
   buffer, then the path, its trailing NUL left off). */
#ifdef __APPLE__
int _NSGetExecutablePath(char *buf, uint32_t *bufsize);

int32_t lust_sys_current_exe(lust_Vec *out) {
    uint32_t cap = 0;
    _NSGetExecutablePath(NULL, &cap);
    if (cap == 0) return errno ? errno : EIO;
    char *buf = malloc(cap);
    if (!buf) lust_oom();
    if (_NSGetExecutablePath(buf, &cap) != 0) {
        int e = errno ? errno : EIO;
        free(buf);
        return e;
    }
    lust_sys_push(out, buf, cap - 1);
    free(buf);
    return 0;
}
#else
int32_t lust_sys_current_exe(lust_Vec *out) {
    return lust_sys_readlink((const uint8_t *)"/proc/self/exe", 14, out);
}
#endif
#endif

#endif

#endif

/* The std platform crate's fd and process calls (src/runtime/sysio.h,
   W-SHIM phase 2). */
/* The std platform crate's fd and process runtime (W-SHIM phase 2):
   the C behind the `sys_fd_*`, `sys_stdin_*`, and `sys_proc_*`
   intrinsics of src/ty/lang.rs, called from library/std/src/io.rs,
   fs.rs, and process_os.rs. A `&[u8]` argument (SigTy::Bytes) arrives
   as a pointer and a length; `&mut Vec<u8>` arrives as a pointer to
   the runtime struct. OS errors return as errno values (positive),
   or as -errno where the value is a count.

   Declarations here are in every unit; bodies (sysio.c) only in the
   runtime unit (LUST_IMPL), like sys.h. */
#ifndef LUST_RT_SYSIO_H
#define LUST_RT_SYSIO_H

/* One read(2) of up to `max` bytes from `fd`, appended to the Vec:
   the count read, or -errno. Lust reads through a staging Vec because
   the read target is a caller byte buffer (`Read::read`). */
int64_t lust_sys_fd_read(int32_t fd, uint64_t max, lust_Vec *out);
/* One write(2) of the bytes to `fd`: the count written, or -errno. */
int64_t lust_sys_fd_write(int32_t fd, const uint8_t *p, uint64_t len);
/* close(2): 0, or errno. */
int32_t lust_sys_fd_close(int32_t fd);
/* dup(2) with FD_CLOEXEC: the new fd, or -errno. */
int32_t lust_sys_fd_dup(int32_t fd);
/* fsync(2): 0, or errno. */
int32_t lust_sys_fd_sync(int32_t fd);
/* fdatasync(2): 0, or errno. */
int32_t lust_sys_fd_sync_data(int32_t fd);
/* ftruncate(2) to `len`: 0, or errno. */
int32_t lust_sys_fd_truncate(int32_t fd, uint64_t len);
/* lseek(2) `off` from `whence` (0 start, 1 current, 2 end): the new
   position, or -errno. */
int64_t lust_sys_fd_seek(int32_t fd, int64_t off, int32_t whence);
/* pread of up to max bytes at off, appended to out: the count or -errno. */
int64_t lust_sys_fd_pread(int32_t fd, uint64_t max, int64_t off, lust_Vec *out);
/* pwrite of the bytes at off: the count or -errno. */
int64_t lust_sys_fd_pwrite(int32_t fd, const uint8_t *p, uint64_t len, int64_t off);
/* isatty: 1 or 0. */
int32_t lust_sys_fd_isatty(int32_t fd);
/* fstat(2) as 8-byte little-endian fields appended to the Vec (the
   same layout as lust_sys_stat): 0, or errno. */
int32_t lust_sys_fd_stat(int32_t fd, lust_Vec *out);
/* open(2) of a path with std's flags for `flags` (see sysio.c) and
   mode 0666: the fd, -errno, or -1 for a path with a NUL byte as an
   errno of 0 is impossible, so -1 reads back as the NUL error only
   when the caller checked the path for NUL itself. Callers check. */
int32_t lust_sys_fd_open(const uint8_t *p, uint64_t len, int32_t flags);
/* lust_sys_fd_open plus std's custom flags (OR'd in) and creation mode,
   retried on EINTR as std's open_c: the fd or -errno. */
int32_t lust_sys_fd_open_ext(const uint8_t *p, uint64_t len, int32_t flags, int32_t custom, uint32_t mode);

/* Stdin (fd 0) through one process-wide buffer, as std's stdin: bytes
   a lock buffered stay available to later reads. read appends up to
   `max` bytes (from the buffer, else one read(2)): the count, or
   -errno. fill appends the buffered bytes without consuming them
   (one read(2) first when the buffer is empty): the count, or
   -errno. consume drops up to `n` buffered bytes. */
int64_t lust_sys_stdin_read(uint64_t max, lust_Vec *out);
int64_t lust_sys_stdin_fill(lust_Vec *out);
void lust_sys_stdin_consume(uint64_t n);

/* Spawning (std::process): posix_spawnp of `prog` with the packed
   argument, environment, and working-directory bytes the Rust side
   built (formats in sysio.c and process_os.rs). stdio spec per stream
   (stdin, stdout, stderr), packed into `stdio` as three bytes plus a
   byte that says the working directory is set: 0 inherit, 1 null,
   2 pipe, 3 the fd in that stream's slot of `fds` (three packed
   8-byte little-endian fds). On success, appends four 8-byte fields
   to `out`: the pid, then the parent ends of the stdin, stdout, and
   stderr pipes (-1 when not piped). Returns 0, errno, or -1 for a
   NUL byte in any string. */
int32_t lust_sys_proc_spawn(const uint8_t *prog, uint64_t proglen, const uint8_t *args, uint64_t argslen,
                            const uint8_t *env, uint64_t envlen, const uint8_t *cwd, uint64_t cwdlen, uint32_t stdio,
                            const uint8_t *fds, uint64_t fdslen, lust_Vec *out);
/* std's `CommandExt::exec` in this process (no fork): with the same
   packed inputs as lust_sys_proc_spawn, dup2 the configured stdio,
   chdir, SIGPIPE back to its default, then execvp with `environ`
   swapped for the packed environment when it changed (restored when
   the exec fails). Returns only on failure: the errno. */
int32_t lust_sys_proc_exec(const uint8_t *prog, uint64_t proglen, const uint8_t *args, uint64_t argslen,
                           const uint8_t *env, uint64_t envlen, const uint8_t *cwd, uint64_t cwdlen, uint32_t stdio,
                           const uint8_t *fds, uint64_t fdslen);
/* waitpid(2) on `pid` (blocking when `block`): the raw wait status,
   -2 when a non-blocking wait finds the child still running, or
   -errno. */
int64_t lust_sys_proc_wait(uint32_t pid, uint8_t block);
/* kill(2) with SIGKILL: 0, or errno. */
int32_t lust_sys_proc_kill(uint32_t pid);
/* Reads two fds to EOF with poll(2), appending to the two Vecs (a fd
   of -1 is skipped): 0, or errno of the first failed read. Used by
   `Command::output`, which must drain both pipes at once. */
int32_t lust_sys_fd_read_both(int32_t fd1, lust_Vec *out1, int32_t fd2, lust_Vec *out2);

#ifdef LUST_IMPL
#ifdef _WIN32
/* Bodies of the fd and process intrinsics declared in sysio.h, for
   Windows (rel-win). Spliced instead of sysio.c under _WIN32.
   The Rust side speaks small integer fds; a table maps them to
   HANDLEs (0, 1, 2 are the standard handles; a spawned child's pid
   maps to its process handle the same way). Errors return as
   GetLastError codes. Process spawn is CreateProcessW with std's
   argument quoting; the wait status word the Rust side reads is
   the Unix shape lust's std uses on every target, so an exit code
   travels as (code & 0xff) << 8 (codes over 255 truncate: a gap
   until lust's std grows a Windows ExitStatus). */

static void lust_sysio_push(lust_Vec *out, const void *p, uint64_t n) {
    if (n == 0) return;
    lust_vec_reserve(out, n, 1, 1);
    memcpy((uint8_t *)out->ptr + out->len, p, (size_t)n);
    out->len += n;
}

typedef struct { HANDLE h; int append; } lust_win_fd;
static lust_win_fd *lust_win_fds;
static uint64_t lust_win_fds_len, lust_win_fds_cap;

static HANDLE lust_win_handle(int32_t fd) {
    if (fd == 0) return GetStdHandle((DWORD)-10);
    if (fd == 1) return GetStdHandle((DWORD)-11);
    if (fd == 2) return GetStdHandle((DWORD)-12);
    if (fd < 3 || (uint64_t)fd >= lust_win_fds_len + 3) return INVALID_HANDLE_VALUE;
    return lust_win_fds[fd - 3].h;
}

static int32_t lust_win_fd_new(HANDLE h, int append) {
    for (uint64_t i = 0; i < lust_win_fds_len; i++) {
        if (lust_win_fds[i].h == INVALID_HANDLE_VALUE) {
            lust_win_fds[i].h = h;
            lust_win_fds[i].append = append;
            return (int32_t)(i + 3);
        }
    }
    if (lust_win_fds_len == lust_win_fds_cap) {
        lust_win_fds_cap = lust_win_fds_cap ? lust_win_fds_cap * 2 : 64;
        lust_win_fds = realloc(lust_win_fds, (size_t)lust_win_fds_cap * sizeof *lust_win_fds);
        if (!lust_win_fds) lust_oom();
    }
    lust_win_fds[lust_win_fds_len].h = h;
    lust_win_fds[lust_win_fds_len].append = append;
    return (int32_t)(lust_win_fds_len++ + 3);
}

int64_t lust_sys_fd_read(int32_t fd, uint64_t max, lust_Vec *out) {
    HANDLE h = lust_win_handle(fd);
    if (h == INVALID_HANDLE_VALUE) return -(int64_t)6; /* ERROR_INVALID_HANDLE */
    if (max == 0) return 0;
    uint8_t *tmp = malloc((size_t)max);
    if (!tmp) lust_oom();
    DWORD n = 0;
    DWORD want = (DWORD)(max > 0x7fffffff ? 0x7fffffff : max);
    if (!ReadFile(h, tmp, want, &n, 0)) {
        DWORD e = GetLastError();
        free(tmp);
        if (e == 109 /* ERROR_BROKEN_PIPE: EOF on a pipe */) return 0;
        return -(int64_t)e;
    }
    lust_sysio_push(out, tmp, n);
    free(tmp);
    return (int64_t)n;
}

int64_t lust_sys_fd_write(int32_t fd, const uint8_t *p, uint64_t len) {
    HANDLE h = lust_win_handle(fd);
    if (h == INVALID_HANDLE_VALUE) return -(int64_t)6;
    if (fd >= 3 && lust_win_fds[fd - 3].append && GetFileType(h) == 1 /* DISK */) {
        LARGE_INTEGER z = {0};
        SetFilePointerEx(h, z, 0, 2 /* FILE_END */);
    }
    DWORD n = 0;
    DWORD want = (DWORD)(len > 0x7fffffff ? 0x7fffffff : len);
    if (!WriteFile(h, p, want, &n, 0)) return -(int64_t)GetLastError();
    return (int64_t)n;
}

int32_t lust_sys_fd_close(int32_t fd) {
    if (fd < 3) return 0;
    HANDLE h = lust_win_handle(fd);
    if (h == INVALID_HANDLE_VALUE) return 6;
    lust_win_fds[fd - 3].h = INVALID_HANDLE_VALUE;
    return CloseHandle(h) ? 0 : (int32_t)GetLastError();
}

int32_t lust_sys_fd_dup(int32_t fd) {
    HANDLE h = lust_win_handle(fd);
    if (h == INVALID_HANDLE_VALUE) return -6;
    HANDLE copy = INVALID_HANDLE_VALUE;
    if (!DuplicateHandle(GetCurrentProcess(), h, GetCurrentProcess(), &copy, 0, 0, 2 /* SAME_ACCESS */))
        return -(int32_t)GetLastError();
    return lust_win_fd_new(copy, fd >= 3 ? lust_win_fds[fd - 3].append : 0);
}

int32_t lust_sys_fd_sync(int32_t fd) {
    HANDLE h = lust_win_handle(fd);
    if (h == INVALID_HANDLE_VALUE) return 6;
    return FlushFileBuffers(h) ? 0 : (int32_t)GetLastError();
}

int32_t lust_sys_fd_sync_data(int32_t fd) { return lust_sys_fd_sync(fd); }

int32_t lust_sys_fd_truncate(int32_t fd, uint64_t len) {
    HANDLE h = lust_win_handle(fd);
    if (h == INVALID_HANDLE_VALUE) return 6;
    LARGE_INTEGER at, save;
    at.QuadPart = (int64_t)len;
    if (!SetFilePointerEx(h, at, &save, 0)) return (int32_t)GetLastError();
    /* save holds the target; move there, set EOF, move back */
    LARGE_INTEGER zero = {0}, cur;
    if (!SetFilePointerEx(h, zero, &cur, 1 /* CURRENT */)) return (int32_t)GetLastError();
    if (!SetFilePointerEx(h, at, 0, 0)) return (int32_t)GetLastError();
    if (!SetEndOfFile(h)) { int32_t e = (int32_t)GetLastError(); SetFilePointerEx(h, cur, 0, 0); return e; }
    SetFilePointerEx(h, cur, 0, 0);
    return 0;
}

int64_t lust_sys_fd_seek(int32_t fd, int64_t off, int32_t whence) {
    HANDLE h = lust_win_handle(fd);
    if (h == INVALID_HANDLE_VALUE) return -(int64_t)6;
    LARGE_INTEGER at, out;
    at.QuadPart = off;
    if (!SetFilePointerEx(h, at, &out, (DWORD)whence)) return -(int64_t)GetLastError();
    return (int64_t)out.QuadPart;
}

int64_t lust_sys_fd_pread(int32_t fd, uint64_t max, int64_t off, lust_Vec *out) {
    HANDLE h = lust_win_handle(fd);
    if (h == INVALID_HANDLE_VALUE) return -(int64_t)6;
    uint8_t *tmp = max ? malloc((size_t)max) : malloc(1);
    if (!tmp) lust_oom();
    OVERLAPPED ov = {0};
    ov.Offset = (DWORD)(uint64_t)off;
    ov.OffsetHigh = (DWORD)((uint64_t)off >> 32);
    DWORD n = 0;
    DWORD want = (DWORD)(max > 0x7fffffff ? 0x7fffffff : max);
    if (!ReadFile(h, tmp, want, &n, &ov)) {
        DWORD e = GetLastError();
        free(tmp);
        if (e == 38 /* ERROR_HANDLE_EOF */) return 0;
        return -(int64_t)e;
    }
    lust_sysio_push(out, tmp, n);
    free(tmp);
    return (int64_t)n;
}

int64_t lust_sys_fd_pwrite(int32_t fd, const uint8_t *p, uint64_t len, int64_t off) {
    HANDLE h = lust_win_handle(fd);
    if (h == INVALID_HANDLE_VALUE) return -(int64_t)6;
    OVERLAPPED ov = {0};
    ov.Offset = (DWORD)(uint64_t)off;
    ov.OffsetHigh = (DWORD)((uint64_t)off >> 32);
    DWORD n = 0;
    DWORD want = (DWORD)(len > 0x7fffffff ? 0x7fffffff : len);
    if (!WriteFile(h, p, want, &n, &ov)) return -(int64_t)GetLastError();
    return (int64_t)n;
}

int32_t lust_sys_fd_isatty(int32_t fd) {
    HANDLE h = lust_win_handle(fd);
    if (h == INVALID_HANDLE_VALUE) return 0;
    DWORD mode;
    return GetConsoleMode(h, &mode) ? 1 : 0;
}

void lust_sys_stat_fields(lust_Vec *out, DWORD attrs, uint64_t size, FILETIME ct, FILETIME at, FILETIME mt, uint64_t ino); /* syswin.c */

int32_t lust_sys_fd_stat(int32_t fd, lust_Vec *out) {
    HANDLE h = lust_win_handle(fd);
    if (h == INVALID_HANDLE_VALUE) return 6;
    BY_HANDLE_FILE_INFORMATION info;
    if (!GetFileInformationByHandle(h, &info)) return (int32_t)GetLastError();
    uint64_t size = ((uint64_t)info.nFileSizeHigh << 32) | info.nFileSizeLow;
    uint64_t ino = ((uint64_t)info.nFileIndexHigh << 32) | info.nFileIndexLow;
    /* The field writer lives in syswin.c; declared there as static,
       so the fields are written again here through it. */
    lust_sys_stat_fields(out, info.dwFileAttributes, size, info.ftCreationTime, info.ftLastAccessTime, info.ftLastWriteTime, ino);
    return 0;
}

/* flags as in sysio.c: bits 0-1 access, bit 2 create, bit 3 trunc,
   bit 4 append, bit 5 excl. */
static int32_t lust_win_open(const uint8_t *p, uint64_t len, int32_t flags) {
    WCHAR *w = lust_sys_wide(p, len);
    if (!w) return -87; /* ERROR_INVALID_PARAMETER for a NUL path */
    DWORD access = (flags & 3) == 0 ? 0x80000000u : (flags & 3) == 1 ? 0x40000000u : (0x80000000u | 0x40000000u);
    DWORD disp;
    if ((flags & 4) && (flags & 32)) disp = 1; /* CREATE_NEW */
    else if ((flags & 4) && (flags & 8)) disp = 2; /* CREATE_ALWAYS */
    else if (flags & 4) disp = 4; /* OPEN_ALWAYS */
    else if (flags & 8) disp = 5; /* TRUNCATE_EXISTING */
    else disp = 3; /* OPEN_EXISTING */
    HANDLE h = CreateFileW(w, access, 7, 0, disp, 0x200000 /* BACKUP_SEMANTICS */, 0);
    free(w);
    if (h == INVALID_HANDLE_VALUE) return -(int32_t)GetLastError();
    return lust_win_fd_new(h, (flags & 16) != 0);
}

int32_t lust_sys_fd_open(const uint8_t *p, uint64_t len, int32_t flags) {
    return lust_win_open(p, len, flags);
}

int32_t lust_sys_fd_open_ext(const uint8_t *p, uint64_t len, int32_t flags, int32_t custom, uint32_t mode) {
    (void)custom; (void)mode; /* Unix open flags and mode: no Windows form */
    return lust_win_open(p, len, flags);
}

static uint8_t lust_sysio_stdin_buf[8192];
static uint64_t lust_sysio_stdin_pos, lust_sysio_stdin_cap;

int64_t lust_sys_stdin_read(uint64_t max, lust_Vec *out) {
    if (max == 0) return 0;
    if (lust_sysio_stdin_pos < lust_sysio_stdin_cap) {
        uint64_t avail = lust_sysio_stdin_cap - lust_sysio_stdin_pos;
        uint64_t n = avail < max ? avail : max;
        lust_sysio_push(out, lust_sysio_stdin_buf + lust_sysio_stdin_pos, n);
        lust_sysio_stdin_pos += n;
        return (int64_t)n;
    }
    lust_sysio_stdin_pos = lust_sysio_stdin_cap = 0;
    return lust_sys_fd_read(0, max, out);
}

int64_t lust_sys_stdin_fill(lust_Vec *out) {
    if (lust_sysio_stdin_pos >= lust_sysio_stdin_cap) {
        int64_t n = lust_sys_fd_read(0, sizeof lust_sysio_stdin_buf, out);
        if (n <= 0) return n;
        /* Bytes went to out, not the buffer: report them as filled
           and mark them consumed by the caller's copy (out already
           holds them; consume() then has nothing to drop). */
        return n;
    }
    uint64_t avail = lust_sysio_stdin_cap - lust_sysio_stdin_pos;
    lust_sysio_push(out, lust_sysio_stdin_buf + lust_sysio_stdin_pos, avail);
    return (int64_t)avail;
}

void lust_sys_stdin_consume(uint64_t n) {
    uint64_t avail = lust_sysio_stdin_cap - lust_sysio_stdin_pos;
    lust_sysio_stdin_pos += n < avail ? n : avail;
}

int32_t lust_sys_fd_read_both(int32_t fd1, lust_Vec *out1, int32_t fd2, lust_Vec *out2) {
    /* No poll on pipes without overlapped io: read one to EOF, then
       the other. Command::output can deadlock when the child fills
       the second pipe while this reads the first (gap: needs two
       reader threads, next slice). */
    int32_t err = 0;
    int32_t fds[2] = {fd1, fd2};
    lust_Vec *outs[2] = {out1, out2};
    for (int i = 0; i < 2; i++) {
        if (fds[i] < 0) continue;
        for (;;) {
            int64_t n = lust_sys_fd_read(fds[i], 65536, outs[i]);
            if (n < 0) { if (!err) err = (int32_t)-n; break; }
            if (n == 0) break;
        }
    }
    return err;
}

/* Spawned children by pid: the Rust side waits and kills by pid. */
typedef struct { uint32_t pid; HANDLE h; } lust_win_child;
static lust_win_child *lust_win_children;
static uint64_t lust_win_children_len, lust_win_children_cap;

static HANDLE lust_win_child_handle(uint32_t pid) {
    for (uint64_t i = 0; i < lust_win_children_len; i++)
        if (lust_win_children[i].pid == pid) return lust_win_children[i].h;
    return INVALID_HANDLE_VALUE;
}

int64_t lust_sys_proc_wait(uint32_t pid, uint8_t block) {
    HANDLE h = lust_win_child_handle(pid);
    if (h == INVALID_HANDLE_VALUE) return -(int64_t)6;
    DWORD r = WaitForSingleObject(h, block ? 0xFFFFFFFFu : 0);
    if (r == 0x102 /* WAIT_TIMEOUT */) return -2;
    if (r != 0) return -(int64_t)GetLastError();
    DWORD code = 0;
    GetExitCodeProcess(h, &code);
    return (int64_t)(((uint64_t)code & 0xff) << 8);
}

int32_t lust_sys_proc_kill(uint32_t pid) {
    HANDLE h = lust_win_child_handle(pid);
    if (h == INVALID_HANDLE_VALUE) return 6;
    return TerminateProcess(h, 1) ? 0 : (int32_t)GetLastError();
}

static void lust_sysio_push_u64(lust_Vec *out, uint64_t v) {
    uint8_t b[8];
    for (int k = 0; k < 8; k++) b[k] = (uint8_t)(v >> (8 * k));
    lust_sysio_push(out, b, 8);
}

/* std's Windows argument quoting: quote when empty or holding a
   space, tab or quote; backslashes double before a quote. */
static void lust_win_quote_arg(lust_Vec *cmd, const WCHAR *a, int n) {
    int quote = n == 0;
    for (int i = 0; i < n; i++) if (a[i] == L' ' || a[i] == L'\t' || a[i] == L'"') quote = 1;
    WCHAR q = L'"', bs = L'\\';
    if (quote) lust_sysio_push(cmd, &q, 2);
    int run = 0;
    for (int i = 0; i < n; i++) {
        if (a[i] == L'\\') { run++; continue; }
        if (a[i] == L'"') {
            for (int k = 0; k < run * 2 + 1; k++) lust_sysio_push(cmd, &bs, 2);
            run = 0;
        } else {
            for (int k = 0; k < run; k++) lust_sysio_push(cmd, &bs, 2);
            run = 0;
        }
        lust_sysio_push(cmd, &a[i], 2);
    }
    if (quote) {
        for (int k = 0; k < run * 2; k++) lust_sysio_push(cmd, &bs, 2);
        lust_sysio_push(cmd, &q, 2);
    } else {
        for (int k = 0; k < run; k++) lust_sysio_push(cmd, &bs, 2);
    }
}

int32_t lust_sys_proc_spawn(const uint8_t *prog, uint64_t proglen, const uint8_t *args, uint64_t argslen,
                            const uint8_t *env, uint64_t envlen, const uint8_t *cwd, uint64_t cwdlen, uint32_t stdio,
                            const uint8_t *fds, uint64_t fdslen, lust_Vec *out) {
    if (argslen == 0 || envlen == 0) return 87;
    /* Command line: the program, then each packed arg, quoted. */
    lust_Vec cmd = {0, 0, 0};
    WCHAR *pw = lust_sys_wide(prog, proglen);
    if (!pw) return -1;
    int pn = 0;
    while (pw[pn]) pn++;
    lust_win_quote_arg(&cmd, pw, pn);
    uint64_t start = 0;
    int first = 1;
    for (uint64_t i = 0; i < argslen; i++) {
        if (args[i] != 0) continue;
        if (!first) {
            WCHAR sp = L' ';
            lust_sysio_push(&cmd, &sp, 2);
            WCHAR *aw = lust_sys_wide(args + start, i - start);
            if (!aw) { free(pw); free(cmd.ptr); return -1; }
            int an = 0;
            while (aw[an]) an++;
            lust_win_quote_arg(&cmd, aw, an);
            free(aw);
        }
        first = 0;
        start = i + 1;
    }
    WCHAR z = 0;
    lust_sysio_push(&cmd, &z, 2);
    /* Environment: packed K=V strings after a flag byte, or inherit. */
    void *envblock = 0;
    lust_Vec envv = {0, 0, 0};
    if (env[0] != 0) {
        uint64_t s0 = 1;
        for (uint64_t i = 1; i < envlen; i++) {
            if (env[i] != 0) continue;
            WCHAR *ew = lust_sys_wide(env + s0, i - s0);
            if (!ew) { free(pw); free(cmd.ptr); return -1; }
            int en = 0;
            while (ew[en]) en++;
            lust_sysio_push(&envv, ew, (uint64_t)(en + 1) * 2);
            free(ew);
            s0 = i + 1;
        }
        lust_sysio_push(&envv, &z, 2);
        envblock = envv.ptr;
    }
    WCHAR *cwdw = 0;
    if ((stdio >> 6) & 1) {
        cwdw = lust_sys_wide(cwd, cwdlen);
        if (!cwdw) { free(pw); free(cmd.ptr); free(envv.ptr); return -1; }
    }
    int spec[3] = {(int)(stdio & 3), (int)((stdio >> 2) & 3), (int)((stdio >> 4) & 3)};
    HANDLE child_io[3];
    int32_t parent_fd[3] = {-1, -1, -1};
    HANDLE close_after[3] = {0, 0, 0};
    SECURITY_ATTRIBUTES sa = {sizeof sa, 0, 1}; /* inheritable */
    for (int i = 0; i < 3; i++) {
        if (spec[i] == 0) {
            child_io[i] = GetStdHandle(i == 0 ? (DWORD)-10 : i == 1 ? (DWORD)-11 : (DWORD)-12);
        } else if (spec[i] == 1) {
            child_io[i] = CreateFileW(L"NUL", i == 0 ? 0x80000000u : 0x40000000u, 7, &sa, 3, 0, 0);
            close_after[i] = child_io[i];
        } else if (spec[i] == 2) {
            HANDLE rd = INVALID_HANDLE_VALUE, wr = INVALID_HANDLE_VALUE;
            CreatePipe(&rd, &wr, &sa, 0);
            if (i == 0) { child_io[i] = rd; parent_fd[i] = lust_win_fd_new(wr, 0); SetHandleInformation(wr, 1, 0); }
            else { child_io[i] = wr; parent_fd[i] = lust_win_fd_new(rd, 0); SetHandleInformation(rd, 1, 0); }
            close_after[i] = child_io[i];
        } else {
            uint64_t v = 0;
            if (fdslen >= (uint64_t)(i + 1) * 8)
                for (int k = 0; k < 8; k++) v |= (uint64_t)fds[i * 8 + k] << (8 * k);
            HANDLE src = lust_win_handle((int32_t)(int64_t)v);
            HANDLE dup = INVALID_HANDLE_VALUE;
            DuplicateHandle(GetCurrentProcess(), src, GetCurrentProcess(), &dup, 0, 1, 2);
            child_io[i] = dup;
            close_after[i] = dup;
        }
    }
    STARTUPINFOW si = {0};
    si.cb = sizeof si;
    si.dwFlags = 0x100; /* STARTF_USESTDHANDLES */
    si.hStdInput = child_io[0];
    si.hStdOutput = child_io[1];
    si.hStdError = child_io[2];
    PROCESS_INFORMATION pi = {0};
    int ok = CreateProcessW(pw, (WCHAR *)cmd.ptr, 0, 0, 1, 0x400 /* CREATE_UNICODE_ENVIRONMENT */, envblock, cwdw, &si, &pi);
    int32_t err = ok ? 0 : (int32_t)GetLastError();
    for (int i = 0; i < 3; i++) if (close_after[i] && close_after[i] != INVALID_HANDLE_VALUE) CloseHandle(close_after[i]);
    free(pw);
    free(cmd.ptr);
    free(envv.ptr);
    free(cwdw);
    if (!ok) return err;
    CloseHandle(pi.hThread);
    if (lust_win_children_len == lust_win_children_cap) {
        lust_win_children_cap = lust_win_children_cap ? lust_win_children_cap * 2 : 32;
        lust_win_children = realloc(lust_win_children, (size_t)lust_win_children_cap * sizeof *lust_win_children);
        if (!lust_win_children) lust_oom();
    }
    lust_win_children[lust_win_children_len].pid = (uint32_t)pi.dwProcessId;
    lust_win_children[lust_win_children_len].h = pi.hProcess;
    lust_win_children_len++;
    lust_sysio_push_u64(out, (uint64_t)pi.dwProcessId);
    for (int i = 0; i < 3; i++) lust_sysio_push_u64(out, (uint64_t)(int64_t)parent_fd[i]);
    return 0;
}

int32_t lust_sys_proc_exec(const uint8_t *prog, uint64_t proglen, const uint8_t *args, uint64_t argslen,
                           const uint8_t *env, uint64_t envlen, const uint8_t *cwd, uint64_t cwdlen, uint32_t stdio,
                           const uint8_t *fds, uint64_t fdslen) {
    (void)prog; (void)proglen; (void)args; (void)argslen; (void)env; (void)envlen;
    (void)cwd; (void)cwdlen; (void)stdio; (void)fds; (void)fdslen;
    return 50; /* ERROR_NOT_SUPPORTED: exec has no Windows form */
}

#else
/* Bodies of the fd and process intrinsics declared in sysio.h
   (W-SHIM phase 2). */
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <spawn.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

extern char **environ;

/* glibc exposes pipe2 only under a feature macro this unit does not
   set; declare it (the symbol is always in libc). Darwin has no
   pipe2: pipe plus the two flags this file passes, set right after
   (not atomic, as everywhere before pipe2 existed; a fork+exec in
   another thread in between could inherit the fds for a moment). */
#ifdef __APPLE__
static int lust_pipe2(int fds[2], int flags) {
    if (pipe(fds) != 0) return -1;
    for (int i = 0; i < 2; i++) {
        if (flags & O_CLOEXEC) fcntl(fds[i], F_SETFD, FD_CLOEXEC);
        if (flags & O_NONBLOCK) fcntl(fds[i], F_SETFL, O_NONBLOCK);
    }
    return 0;
}
#else
int pipe2(int pipefd[2], int flags);
static int lust_pipe2(int fds[2], int flags) { return pipe2(fds, flags); }
#endif

/* Appends `n` bytes to a Vec<u8>. */
static void lust_sysio_push(lust_Vec *out, const void *p, uint64_t n) {
    if (n == 0) return;
    lust_vec_reserve(out, n, 1, 1);
    memcpy((uint8_t *)out->ptr + out->len, p, (size_t)n);
    out->len += n;
}

/* One read into a fresh heap buffer, appended to the Vec. A zero
   max still makes the syscall (its error, or 0), as std and rustix do. */
int64_t lust_sys_fd_read(int32_t fd, uint64_t max, lust_Vec *out) {
    if (max == 0) {
        uint8_t none;
        ssize_t z = read(fd, &none, 0);
        return z < 0 ? -(int64_t)errno : (int64_t)z;
    }
    uint8_t *tmp = malloc((size_t)max);
    if (!tmp) lust_oom();
    ssize_t n = read(fd, tmp, (size_t)max);
    if (n < 0) {
        int e = errno;
        free(tmp);
        return -(int64_t)e;
    }
    lust_sysio_push(out, tmp, (uint64_t)n);
    free(tmp);
    return (int64_t)n;
}

int64_t lust_sys_fd_write(int32_t fd, const uint8_t *p, uint64_t len) {
    ssize_t n = write(fd, p, (size_t)len);
    if (n < 0) return -(int64_t)errno;
    return (int64_t)n;
}

int32_t lust_sys_fd_close(int32_t fd) { return close(fd) == 0 ? 0 : errno; }

int32_t lust_sys_fd_dup(int32_t fd) {
    int n = fcntl(fd, F_DUPFD_CLOEXEC, 0);
    return n < 0 ? -errno : n;
}

/* On Darwin std's sync_all and sync_data are both fcntl(F_FULLFSYNC)
   (std sys/fs/unix.rs os_fsync/os_datasync for target_vendor apple):
   a plain fsync there does not ask the drive to flush. */
#ifdef __APPLE__
#define LUST_F_FULLFSYNC 51
int32_t lust_sys_fd_sync(int32_t fd) { return fcntl(fd, LUST_F_FULLFSYNC) == 0 ? 0 : errno; }

int32_t lust_sys_fd_sync_data(int32_t fd) { return fcntl(fd, LUST_F_FULLFSYNC) == 0 ? 0 : errno; }
#else
int32_t lust_sys_fd_sync(int32_t fd) { return fsync(fd) == 0 ? 0 : errno; }

int32_t lust_sys_fd_sync_data(int32_t fd) { return fdatasync(fd) == 0 ? 0 : errno; }
#endif

int32_t lust_sys_fd_truncate(int32_t fd, uint64_t len) { return ftruncate(fd, (off_t)len) == 0 ? 0 : errno; }

int64_t lust_sys_fd_seek(int32_t fd, int64_t off, int32_t whence) {
    off_t r = lseek(fd, (off_t)off, whence == 0 ? SEEK_SET : whence == 1 ? SEEK_CUR : SEEK_END);
    return r < 0 ? -(int64_t)errno : (int64_t)r;
}

int64_t lust_sys_fd_pread(int32_t fd, uint64_t max, int64_t off, lust_Vec *out) {
    uint8_t none;
    uint8_t *tmp = max ? malloc((size_t)max) : &none;
    if (!tmp) lust_oom();
    ssize_t n = pread(fd, tmp, (size_t)max, (off_t)off);
    if (n < 0) {
        int e = errno;
        if (max) free(tmp);
        return -(int64_t)e;
    }
    lust_sysio_push(out, tmp, (uint64_t)n);
    if (max) free(tmp);
    return (int64_t)n;
}

int64_t lust_sys_fd_pwrite(int32_t fd, const uint8_t *p, uint64_t len, int64_t off) {
    ssize_t n = pwrite(fd, p, (size_t)len, (off_t)off);
    if (n < 0) return -(int64_t)errno;
    return (int64_t)n;
}

int32_t lust_sys_fd_isatty(int32_t fd) { return isatty(fd) ? 1 : 0; }

/* The stat fields of sys.c's lust_sys_stat, for an open fd. */
int32_t lust_sys_fd_stat(int32_t fd, lust_Vec *out) {
    struct stat st;
    if (fstat(fd, &st) != 0) return errno;
    int64_t bsec = 0, bnsec = 0;
    int32_t has_btime = lust_sys_btime_fd(fd, &bsec, &bnsec);
    uint64_t f[19] = {st.st_mode, (uint64_t)st.st_size, (uint64_t)LUST_ST_MTIME(st).tv_sec, (uint64_t)LUST_ST_MTIME(st).tv_nsec, st.st_uid, st.st_gid,
                      (uint64_t)st.st_nlink, (uint64_t)st.st_ino, (uint64_t)st.st_dev, (uint64_t)LUST_ST_ATIME(st).tv_sec,
                      (uint64_t)LUST_ST_ATIME(st).tv_nsec, (uint64_t)LUST_ST_CTIME(st).tv_sec, (uint64_t)LUST_ST_CTIME(st).tv_nsec, (uint64_t)st.st_blocks,
                      (uint64_t)st.st_blksize, (uint64_t)st.st_rdev, (uint64_t)bsec, (uint64_t)bnsec, (uint64_t)has_btime};
    for (int i = 0; i < 19; i++) {
        uint8_t b[8];
        for (int k = 0; k < 8; k++) b[k] = (uint8_t)(f[i] >> (8 * k));
        lust_sysio_push(out, b, 8);
    }
    return 0;
}

/* flags: bits 0-1 access (0 O_RDONLY, 1 O_WRONLY, 2 O_RDWR), bit 2
   O_CREAT, bit 3 O_TRUNC, bit 4 O_APPEND, bit 5 O_EXCL. Always
   O_CLOEXEC, mode 0666, as std opens files on Linux. */
int32_t lust_sys_fd_open(const uint8_t *p, uint64_t len, int32_t flags) {
    char *s = malloc(len + 1);
    if (!s) lust_oom();
    memcpy(s, p, len);
    s[len] = 0;
    int f = (flags & 3) | O_CLOEXEC;
    if (flags & 4) f |= O_CREAT;
    if (flags & 8) f |= O_TRUNC;
    if (flags & 16) f |= O_APPEND;
    if (flags & 32) f |= O_EXCL;
    int fd = open(s, f, 0666);
    int e = errno;
    free(s);
    return fd < 0 ? -e : fd;
}

/* lust_sys_fd_open with std's OpenOptionsExt parts: `custom` flags
   (the access mode bits already cleared) and the creation `mode`. */
int32_t lust_sys_fd_open_ext(const uint8_t *p, uint64_t len, int32_t flags, int32_t custom, uint32_t mode) {
    char *s = malloc(len + 1);
    if (!s) lust_oom();
    memcpy(s, p, len);
    s[len] = 0;
    int f = (flags & 3) | O_CLOEXEC | custom;
    if (flags & 4) f |= O_CREAT;
    if (flags & 8) f |= O_TRUNC;
    if (flags & 16) f |= O_APPEND;
    if (flags & 32) f |= O_EXCL;
    int fd;
    do {
        fd = open(s, f, mode);
    } while (fd < 0 && errno == EINTR);
    int e = errno;
    free(s);
    return fd < 0 ? -e : fd;
}

/* Stdin: one process-wide buffer, as std's stdin. The buffer fills
   with a single read of up to 8192 bytes (std's stdin buffer size is
   also 8192 on Linux through BufReader::DEFAULT_BUF_SIZE, behind a
   line-read shim that only changes how much a terminal read asks
   for; byte streams see the same data in the same order). */
static uint8_t lust_sysio_stdin_buf[8192];
static uint64_t lust_sysio_stdin_pos, lust_sysio_stdin_cap;

int64_t lust_sys_stdin_read(uint64_t max, lust_Vec *out) {
    if (max == 0) return 0;
    if (lust_sysio_stdin_pos < lust_sysio_stdin_cap) {
        uint64_t avail = lust_sysio_stdin_cap - lust_sysio_stdin_pos;
        uint64_t n = avail < max ? avail : max;
        lust_sysio_push(out, lust_sysio_stdin_buf + lust_sysio_stdin_pos, n);
        lust_sysio_stdin_pos += n;
        return (int64_t)n;
    }
    lust_sysio_stdin_pos = lust_sysio_stdin_cap = 0;
    return lust_sys_fd_read(0, max, out);
}

int64_t lust_sys_stdin_fill(lust_Vec *out) {
    if (lust_sysio_stdin_pos >= lust_sysio_stdin_cap) {
        ssize_t n = read(0, lust_sysio_stdin_buf, sizeof lust_sysio_stdin_buf);
        if (n < 0) return -(int64_t)errno;
        lust_sysio_stdin_pos = 0;
        lust_sysio_stdin_cap = (uint64_t)n;
    }
    uint64_t avail = lust_sysio_stdin_cap - lust_sysio_stdin_pos;
    lust_sysio_push(out, lust_sysio_stdin_buf + lust_sysio_stdin_pos, avail);
    return (int64_t)avail;
}

void lust_sys_stdin_consume(uint64_t n) {
    uint64_t avail = lust_sysio_stdin_cap - lust_sysio_stdin_pos;
    lust_sysio_stdin_pos += n < avail ? n : avail;
}

/* Reads one fd that poll says is ready; appends one chunk. Returns 1
   at EOF, 0 on data, or errno. */
static int lust_sysio_read_chunk(int32_t fd, lust_Vec *out, uint8_t *tmp) {
    ssize_t n = read(fd, tmp, 65536);
    if (n < 0) return errno == EINTR ? 0 : errno;
    if (n == 0) return 1;
    lust_sysio_push(out, tmp, (uint64_t)n);
    return 0;
}

int32_t lust_sys_fd_read_both(int32_t fd1, lust_Vec *out1, int32_t fd2, lust_Vec *out2) {
    uint8_t *tmp = malloc(65536);
    if (!tmp) lust_oom();
    int err = 0, done1 = fd1 < 0, done2 = fd2 < 0;
    while (!done1 || !done2) {
        struct pollfd pf[2] = {{fd1, POLLIN, 0}, {fd2, POLLIN, 0}};
        if (done1) pf[0].fd = -1;
        if (done2) pf[1].fd = -1;
        if (poll(pf, 2, -1) < 0) {
            if (errno == EINTR) continue;
            err = errno;
            break;
        }
        for (int i = 0; i < 2; i++) {
            if (!(pf[i].revents & (POLLIN | POLLHUP | POLLERR))) continue;
            int r = lust_sysio_read_chunk(pf[i].fd, i == 0 ? out1 : out2, tmp);
            if (r == 1) {
                if (i == 0) done1 = 1; else done2 = 1;
            } else if (r != 0) {
                if (i == 0) done1 = 1; else done2 = 1;
                if (!err) err = r;
            }
        }
    }
    free(tmp);
    return err;
}

int64_t lust_sys_proc_wait(uint32_t pid, uint8_t block) {
    int st;
    for (;;) {
        pid_t r = waitpid((pid_t)pid, &st, block ? 0 : WNOHANG);
        if (r < 0 && errno == EINTR) continue;
        if (r < 0) return -(int64_t)errno;
        if (r == 0) return -2;
        return (int64_t)st;
    }
}

int32_t lust_sys_proc_kill(uint32_t pid) { return kill((pid_t)pid, SIGKILL) == 0 ? 0 : errno; }

/* glibc's PATH-searching exec with an explicit environment; declared
   here because no feature macro exposes it in this unit. Darwin has
   no execvpe: the one caller runs in a forked child about to exec,
   so swapping environ and calling execvp is the same call there
   (the PATH search then reads the child's environment, as std's
   spawn searches it). */
#ifdef __APPLE__
static int lust_execvpe(const char *file, char *const argv[], char *const envp[]) {
    environ = (char **)envp;
    return execvp(file, argv);
}
#else
int execvpe(const char *file, char *const argv[], char *const envp[]);
static int lust_execvpe(const char *file, char *const argv[], char *const envp[]) { return execvpe(file, argv, envp); }
#endif

/* Splits NUL-terminated packed strings (the argv and env formats of
   sysio.h) into a malloc'd, NULL-terminated array. The strings
   themselves are copied, so the packed bytes may be freed. */
static char **lust_sysio_split(const uint8_t *p, uint64_t len) {
    uint64_t count = 0;
    for (uint64_t i = 0; i < len; i++)
        if (p[i] == 0) count++;
    char **arr = malloc((count + 1) * sizeof *arr);
    if (!arr) lust_oom();
    uint64_t at = 0, start = 0;
    for (uint64_t i = 0; i < len; i++) {
        if (p[i] != 0) continue;
        arr[at] = malloc(i - start + 1);
        if (!arr[at]) lust_oom();
        memcpy(arr[at], p + start, i - start);
        arr[at][i - start] = 0;
        at++;
        start = i + 1;
    }
    arr[at] = NULL;
    return arr;
}

static void lust_sysio_free_split(char **arr) {
    if (!arr) return;
    for (uint64_t i = 0; arr[i]; i++) free(arr[i]);
    free(arr);
}

/* Appends one 8-byte little-endian value to the Vec. */
static void lust_sysio_push_u64(lust_Vec *out, uint64_t v) {
    uint8_t b[8];
    for (int k = 0; k < 8; k++) b[k] = (uint8_t)(v >> (8 * k));
    lust_sysio_push(out, b, 8);
}

/* Spawns `prog` with fork and execvpe, as std's Command::spawn does
   on Linux: the child's stdio is set up from the specs, then the
   working directory, then exec (with PATH search through the
   child's environment when the program has no slash). An error in
   the child before exec (chdir, dup, exec itself) travels back
   through a close-on-exec pipe and becomes the spawn error, the
   errno std reports. `stdio` packs three 2-bit specs (stdin,
   stdout, stderr) and bit 6 for a working directory; spec 0 inherit,
   1 /dev/null, 2 pipe, 3 the fd in that stream's slot of the packed
   `fds` (three 8-byte little-endian values). */
int32_t lust_sys_proc_spawn(const uint8_t *prog, uint64_t proglen, const uint8_t *args, uint64_t argslen,
                            const uint8_t *env, uint64_t envlen, const uint8_t *cwd, uint64_t cwdlen, uint32_t stdio,
                            const uint8_t *fds, uint64_t fdslen, lust_Vec *out) {
    if (argslen == 0 || envlen == 0) return EINVAL;
    char *prog_s = malloc(proglen + 1);
    if (!prog_s) lust_oom();
    memcpy(prog_s, prog, proglen);
    prog_s[proglen] = 0;
    char **argv = lust_sysio_split(args, argslen);
    char **envp = env[0] == 0 ? environ : lust_sysio_split(env + 1, envlen - 1);
    int have_cwd = (stdio >> 6) & 1;
    char *cwd_s = NULL;
    if (have_cwd) {
        cwd_s = malloc(cwdlen + 1);
        if (!cwd_s) lust_oom();
        memcpy(cwd_s, cwd, cwdlen);
        cwd_s[cwdlen] = 0;
    }
    int spec[3] = {(int)(stdio & 3), (int)((stdio >> 2) & 3), (int)((stdio >> 4) & 3)};
    int srcfd[3] = {-1, -1, -1};
    for (int i = 0; i < 3; i++) {
        if (spec[i] != 3) continue;
        if (fdslen < (uint64_t)(i + 1) * 8) return EINVAL;
        uint64_t v = 0;
        for (int k = 0; k < 8; k++) v |= (uint64_t)fds[i * 8 + k] << (8 * k);
        srcfd[i] = (int)(int64_t)v;
    }
    int pipes[3][2] = {{-1, -1}, {-1, -1}, {-1, -1}};
    int err = 0;
    for (int i = 0; i < 3 && !err; i++) {
        if (spec[i] == 2 && lust_pipe2(pipes[i], O_CLOEXEC) != 0) err = errno;
    }
    int errpipe[2] = {-1, -1};
    if (!err && lust_pipe2(errpipe, O_CLOEXEC) != 0) err = errno;
    if (err) {
        for (int i = 0; i < 3; i++) {
            if (pipes[i][0] >= 0) close(pipes[i][0]);
            if (pipes[i][1] >= 0) close(pipes[i][1]);
        }
        if (errpipe[0] >= 0) close(errpipe[0]);
        if (errpipe[1] >= 0) close(errpipe[1]);
        if (envp != environ) lust_sysio_free_split(envp);
        lust_sysio_free_split(argv);
        free(prog_s);
        free(cwd_s);
        return err;
    }
    /* Order parent and child output as rustc's line-buffered stdout
       does: text printed before the spawn is out before an
       inheriting child writes. (A partial line with no newline also
       goes out; rustc would hold it.) */
    if (spec[1] == 0 || spec[2] == 0) fflush(stdout);
    pid_t pid = fork();
    if (pid == 0) {
        /* The child: set up, report any error through errpipe, exec. */
        close(errpipe[0]);
        int target_of[3] = {0, 1, 2};
        for (int i = 0; i < 3; i++) {
            int dest = target_of[i];
            if (spec[i] == 0) continue;
            int src = srcfd[i];
            if (spec[i] == 1) {
                src = open("/dev/null", i == 0 ? O_RDONLY : O_WRONLY);
                if (src < 0) goto child_err;
            } else if (spec[i] == 2) {
                src = pipes[i][i == 0 ? 0 : 1];
            }
            if (src != dest) {
                if (dup2(src, dest) < 0) goto child_err;
            } else {
                /* The fd already is the target but is close-on-exec. */
                int fl = fcntl(src, F_GETFD);
                if (fl >= 0) fcntl(src, F_SETFD, fl & ~FD_CLOEXEC);
            }
        }
        for (int i = 0; i < 3; i++) {
            if (pipes[i][0] > 2) close(pipes[i][0]);
            if (pipes[i][1] > 2) close(pipes[i][1]);
        }
        if (have_cwd && chdir(cwd_s) != 0) goto child_err;
        signal(SIGPIPE, SIG_DFL);
        lust_execvpe(prog_s, argv, envp);
    child_err: {
            int e = errno;
            const uint8_t *p = (const uint8_t *)&e;
            uint64_t left = sizeof e;
            while (left > 0) {
                ssize_t n = write(errpipe[1], p, left);
                if (n <= 0) break;
                p += n;
                left -= (uint64_t)n;
            }
            _exit(127);
        }
    }
    int fork_err = pid < 0 ? errno : 0;
    close(errpipe[1]);
    for (int i = 0; i < 3; i++) {
        if (pipes[i][i == 0 ? 0 : 1] >= 0) close(pipes[i][i == 0 ? 0 : 1]);
    }
    if (pid < 0) {
        close(errpipe[0]);
        for (int i = 0; i < 3; i++) {
            if (pipes[i][i == 0 ? 1 : 0] >= 0) close(pipes[i][i == 0 ? 1 : 0]);
        }
        if (envp != environ) lust_sysio_free_split(envp);
        lust_sysio_free_split(argv);
        free(prog_s);
        free(cwd_s);
        return fork_err;
    }
    /* Read the error pipe: EOF means exec succeeded. */
    int child_err = 0;
    {
        uint8_t buf[sizeof(int)];
        uint64_t got = 0;
        for (;;) {
            ssize_t n = read(errpipe[0], buf + got, sizeof buf - got);
            if (n < 0 && errno == EINTR) continue;
            if (n <= 0) break;
            got += (uint64_t)n;
            if (got == sizeof buf) break;
        }
        close(errpipe[0]);
        if (got == sizeof buf) memcpy(&child_err, buf, sizeof buf);
    }
    if (envp != environ) lust_sysio_free_split(envp);
    lust_sysio_free_split(argv);
    free(prog_s);
    free(cwd_s);
    if (child_err) {
        int st;
        while (waitpid(pid, &st, 0) < 0 && errno == EINTR) {
        }
        for (int i = 0; i < 3; i++) {
            if (pipes[i][i == 0 ? 1 : 0] >= 0) close(pipes[i][i == 0 ? 1 : 0]);
        }
        return child_err;
    }
    lust_sysio_push_u64(out, (uint64_t)pid);
    for (int i = 0; i < 3; i++) lust_sysio_push_u64(out, (uint64_t)(int64_t)(spec[i] == 2 ? pipes[i][i == 0 ? 1 : 0] : -1));
    return 0;
}

int32_t lust_sys_proc_exec(const uint8_t *prog, uint64_t proglen, const uint8_t *args, uint64_t argslen,
                           const uint8_t *env, uint64_t envlen, const uint8_t *cwd, uint64_t cwdlen, uint32_t stdio,
                           const uint8_t *fds, uint64_t fdslen) {
    if (argslen == 0 || envlen == 0) return EINVAL;
    int spec[3] = {(int)(stdio & 3), (int)((stdio >> 2) & 3), (int)((stdio >> 4) & 3)};
    /* std's setup_io first: every stream's fd, then the dup2s. Our
       ends of pipes and the /dev/null fds close when this returns. */
    int theirs[3] = {-1, -1, -1}, ours[3] = {-1, -1, -1}, own[3] = {0, 0, 0};
    int err = 0;
    for (int i = 0; i < 3 && !err; i++) {
        if (spec[i] == 1) {
            theirs[i] = open("/dev/null", (i == 0 ? O_RDONLY : O_WRONLY) | O_CLOEXEC);
            if (theirs[i] < 0) err = errno;
            own[i] = 1;
        } else if (spec[i] == 2) {
            int pp[2];
            if (lust_pipe2(pp, O_CLOEXEC) != 0) {
                err = errno;
            } else {
                theirs[i] = pp[i == 0 ? 0 : 1];
                ours[i] = pp[i == 0 ? 1 : 0];
                own[i] = 1;
            }
        } else if (spec[i] == 3) {
            if (fdslen < (uint64_t)(i + 1) * 8) {
                err = EINVAL;
            } else {
                uint64_t v = 0;
                for (int k = 0; k < 8; k++) v |= (uint64_t)fds[i * 8 + k] << (8 * k);
                theirs[i] = (int)(int64_t)v;
            }
        }
    }
    for (int i = 0; i < 3 && !err; i++) {
        if (theirs[i] < 0) continue;
        while (dup2(theirs[i], i) < 0) {
            if (errno != EINTR) {
                err = errno;
                break;
            }
        }
    }
    char *prog_s = NULL, *cwd_s = NULL;
    char **argv = NULL, **envp = NULL;
    if (!err) {
        int have_cwd = (stdio >> 6) & 1;
        if (have_cwd) {
            cwd_s = malloc(cwdlen + 1);
            if (!cwd_s) lust_oom();
            memcpy(cwd_s, cwd, cwdlen);
            cwd_s[cwdlen] = 0;
            if (chdir(cwd_s) != 0) err = errno;
        }
    }
    if (!err) {
        signal(SIGPIPE, SIG_DFL);
        prog_s = malloc(proglen + 1);
        if (!prog_s) lust_oom();
        memcpy(prog_s, prog, proglen);
        prog_s[proglen] = 0;
        argv = lust_sysio_split(args, argslen);
        char **saved = environ;
        if (env[0] != 0) {
            envp = lust_sysio_split(env + 1, envlen - 1);
            environ = envp;
        }
        execvp(prog_s, argv);
        err = errno;
        environ = saved;
    }
    for (int i = 0; i < 3; i++) {
        if (own[i] && theirs[i] >= 0) close(theirs[i]);
        if (ours[i] >= 0) close(ours[i]);
    }
    if (envp) lust_sysio_free_split(envp);
    if (argv) lust_sysio_free_split(argv);
    free(prog_s);
    free(cwd_s);
    return err;
}

#endif

#endif

#endif

/* The socket calls behind std::net (src/runtime/sysnet.h,
   w-cinterop). */
/* The socket runtime (w-cinterop): the C behind the `sys_net_*`
   intrinsics of src/ty/lang.rs, called from library/std/src/net.rs.
   A socket address crosses as one 48-byte record of six 8-byte
   little-endian fields: family (4 or 6), port (host order), the
   address bytes in the next two fields (network octet order from the
   low byte), flowinfo, and scope id. Output addresses append one
   record to the Vec. OS errors return as errno (positive), or as
   -errno where the value is a count or an fd.

   Declarations here are in every unit; bodies (sysnet.c) only in the
   runtime unit (LUST_IMPL), like sysio.h. */
#ifndef LUST_RT_SYSNET_H
#define LUST_RT_SYSNET_H

/* Resolves a host name with getaddrinfo (AF_UNSPEC, SOCK_STREAM, as
   std's lookup): appends one address record per result, with `port`
   set on each, and returns the count. On failure returns -1 and the
   Vec holds the gai_strerror text instead. */
int32_t lust_sys_net_resolve(const uint8_t *host, uint64_t hostlen, uint64_t port, lust_Vec *out);
/* socket + SO_REUSEADDR + bind + listen(128) for one address record:
   the fd or -errno. On success the local address record is appended. */
int32_t lust_sys_net_tcp_bind(const uint8_t *rec, uint64_t len, lust_Vec *out);
/* socket + bind for one address record (UDP): the fd or -errno. */
int32_t lust_sys_net_udp_bind(const uint8_t *rec, uint64_t len, lust_Vec *out);
/* socket + connect to one address record (TCP): the fd or -errno. */
int32_t lust_sys_net_tcp_connect(const uint8_t *rec, uint64_t len, lust_Vec *out);
/* socket + nonblocking connect + poll(timeout_us) for one record:
   the fd in blocking mode, -errno, or -10000 when the poll timed
   out. The local address record is appended on success. */
int32_t lust_sys_net_tcp_connect_timeout(const uint8_t *rec, uint64_t len, int64_t timeout_us, lust_Vec *out);
/* connect(2) of an existing fd to an address record: 0 or errno. */
int32_t lust_sys_net_connect_fd(int32_t fd, const uint8_t *rec, uint64_t len);
/* accept4 with SOCK_CLOEXEC: the new fd or -errno; the peer record
   is appended on success. */
int32_t lust_sys_net_accept(int32_t fd, lust_Vec *out);
/* getsockname (peer=0) or getpeername (peer=1): 0 or errno; the
   address record is appended on success. */
int32_t lust_sys_net_addr_of(int32_t fd, int32_t peer, lust_Vec *out);
/* shutdown(2): how is 0 read, 1 write, 2 both. 0 or errno. */
int32_t lust_sys_net_shutdown(int32_t fd, int32_t how);
/* One socket option by number: 0 nodelay, 1 ttl, 2 broadcast,
   3 nonblocking, 4 read timeout, 5 write timeout (timeouts in
   microseconds, 0 is none). Set returns 0 or errno; get returns
   the value (a bool as 0/1, a count, microseconds) or -errno. */
int32_t lust_sys_net_setopt(int32_t fd, int32_t opt, int64_t val);
int64_t lust_sys_net_getopt(int32_t fd, int32_t opt);
/* sendto(2); an empty address record is a plain send(2): the count
   sent, or -errno. */
int64_t lust_sys_net_sendto(int32_t fd, const uint8_t *p, uint64_t len, const uint8_t *rec, uint64_t rlen);
/* recvfrom(2) of up to `max` bytes appended to `out`, with the
   source address record appended to `addrout`: the count, or
   -errno. `flags` bit 0 is MSG_PEEK. */
int64_t lust_sys_net_recvfrom(int32_t fd, uint64_t max, int32_t flags, lust_Vec *out, lust_Vec *addrout);
/* Unix domain sockets (std::os::unix::net). A path crosses as
   bytes plus an abstract flag (1 = abstract name, no leading NUL
   in the bytes). An address record out is one u64 kind (0 unnamed,
   1 pathname, 2 abstract) then the name bytes (no NULs). */
/* socketpair(AF_UNIX, SOCK_STREAM): the first fd or -errno; the
   second fd appended as one u64 field. */
int32_t lust_sys_net_unix_pair(lust_Vec *out);
/* socket + bind + listen(128) at a unix path: the fd or -errno. */
int32_t lust_sys_net_unix_bind(const uint8_t *p, uint64_t len, int32_t abstract);
/* socket + connect to a unix path: the fd or -errno. */
int32_t lust_sys_net_unix_connect(const uint8_t *p, uint64_t len, int32_t abstract);
/* accept4 on a unix listener: the new fd or -errno; the peer
   address record is appended. */
int32_t lust_sys_net_unix_accept(int32_t fd, lust_Vec *out);
/* getsockname (peer=0) or getpeername (peer=1) of a unix socket:
   0 or errno; the address record is appended. */
int32_t lust_sys_net_unix_addr(int32_t fd, int32_t peer, lust_Vec *out);

#ifdef LUST_IMPL
#ifdef _WIN32
/* Socket intrinsics for Windows (rel-win): not built yet.
   Spliced instead of sysnet.c under _WIN32. tsgo's hot path uses
   no sockets (LSP runs on stdio and named pipes); every call here
   fails with ERROR_NOT_SUPPORTED until the Winsock slice lands.
   A program that opens a socket on Windows therefore differs from
   rustc: this file must gain real bodies before such a program is
   in scope (see REPORT.md). */
#define LUST_NET_NOSUP 50
int32_t lust_sys_net_resolve(const uint8_t *host, uint64_t hostlen, uint64_t port, lust_Vec *out) { (void)host; (void)hostlen; (void)port; const char *t = "name resolution not supported"; lust_vec_reserve(out, 29, 1, 1); memcpy((uint8_t*)out->ptr + out->len, t, 29); out->len += 29; return -1; }
int32_t lust_sys_net_tcp_bind(const uint8_t *rec, uint64_t len, lust_Vec *out) { (void)rec; (void)len; (void)out; return -LUST_NET_NOSUP; }
int32_t lust_sys_net_udp_bind(const uint8_t *rec, uint64_t len, lust_Vec *out) { (void)rec; (void)len; (void)out; return -LUST_NET_NOSUP; }
int32_t lust_sys_net_tcp_connect(const uint8_t *rec, uint64_t len, lust_Vec *out) { (void)rec; (void)len; (void)out; return -LUST_NET_NOSUP; }
int32_t lust_sys_net_tcp_connect_timeout(const uint8_t *rec, uint64_t len, int64_t timeout_us, lust_Vec *out) { (void)rec; (void)len; (void)timeout_us; (void)out; return -LUST_NET_NOSUP; }
int32_t lust_sys_net_connect_fd(int32_t fd, const uint8_t *rec, uint64_t len) { (void)fd; (void)rec; (void)len; return LUST_NET_NOSUP; }
int32_t lust_sys_net_accept(int32_t fd, lust_Vec *out) { (void)fd; (void)out; return -LUST_NET_NOSUP; }
int32_t lust_sys_net_addr_of(int32_t fd, int32_t peer, lust_Vec *out) { (void)fd; (void)peer; (void)out; return LUST_NET_NOSUP; }
int32_t lust_sys_net_shutdown(int32_t fd, int32_t how) { (void)fd; (void)how; return LUST_NET_NOSUP; }
int32_t lust_sys_net_setopt(int32_t fd, int32_t opt, int64_t val) { (void)fd; (void)opt; (void)val; return LUST_NET_NOSUP; }
int64_t lust_sys_net_getopt(int32_t fd, int32_t opt) { (void)fd; (void)opt; return -LUST_NET_NOSUP; }
int64_t lust_sys_net_sendto(int32_t fd, const uint8_t *p, uint64_t len, const uint8_t *rec, uint64_t rlen) { (void)fd; (void)p; (void)len; (void)rec; (void)rlen; return -LUST_NET_NOSUP; }
int64_t lust_sys_net_recvfrom(int32_t fd, uint64_t max, int32_t flags, lust_Vec *out, lust_Vec *addrout) { (void)fd; (void)max; (void)flags; (void)out; (void)addrout; return -LUST_NET_NOSUP; }
int32_t lust_sys_net_unix_pair(lust_Vec *out) { (void)out; return -LUST_NET_NOSUP; }
int32_t lust_sys_net_unix_bind(const uint8_t *p, uint64_t len, int32_t abstract) { (void)p; (void)len; (void)abstract; return -LUST_NET_NOSUP; }
int32_t lust_sys_net_unix_connect(const uint8_t *p, uint64_t len, int32_t abstract) { (void)p; (void)len; (void)abstract; return -LUST_NET_NOSUP; }
int32_t lust_sys_net_unix_accept(int32_t fd, lust_Vec *out) { (void)fd; (void)out; return -LUST_NET_NOSUP; }
int32_t lust_sys_net_unix_addr(int32_t fd, int32_t peer, lust_Vec *out) { (void)fd; (void)peer; (void)out; return LUST_NET_NOSUP; }

#else
/* Bodies of the socket intrinsics declared in sysnet.h
   (w-cinterop). */
#include <poll.h>
#include <time.h>
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

/* glibc exposes accept4 only under _GNU_SOURCE, which this unit does not set (as with
   pipe2 in sysio.c). gcc 14 makes the implicit declaration an error. Darwin has
   neither accept4 nor the SOCK_CLOEXEC/SOCK_NONBLOCK type flags: the flags are
   defined away in the create calls and set with fcntl right after, through
   lust_sock_after_create (not atomic; a fork+exec in another thread in between
   could inherit the fd for a moment, as with pipe2 in sysio.c). */
#ifdef __APPLE__
#ifndef SOCK_CLOEXEC
#define SOCK_CLOEXEC 0
#endif
#ifndef SOCK_NONBLOCK
#define SOCK_NONBLOCK 0
#endif
static void lust_sock_after_create(int fd, int nonblock) {
    if (fd < 0) return;
    fcntl(fd, F_SETFD, FD_CLOEXEC);
    if (nonblock) {
        int fl = fcntl(fd, F_GETFL, 0);
        if (fl >= 0) fcntl(fd, F_SETFL, fl | O_NONBLOCK);
    }
}
static int lust_accept_cloexec(int fd, struct sockaddr *addr, socklen_t *len) {
    int n = accept(fd, addr, len);
    lust_sock_after_create(n, 0);
    return n;
}
#else
int accept4(int fd, struct sockaddr *addr, socklen_t *len, int flags);
static void lust_sock_after_create(int fd, int nonblock) {
    (void)fd;
    (void)nonblock;
}
static int lust_accept_cloexec(int fd, struct sockaddr *addr, socklen_t *len) {
    return accept4(fd, addr, len, SOCK_CLOEXEC);
}
#endif

/* The family of a socket, for the TTL option: SO_DOMAIN on Linux
   (std's way); Darwin has no SO_DOMAIN, and getsockname reports the
   family of a bound or unbound socket there. 0 with errno set when
   neither works. */
static int lust_sock_family(int fd) {
#ifdef __APPLE__
    struct sockaddr_storage ss;
    socklen_t ll = sizeof ss;
    if (getsockname(fd, (struct sockaddr *)&ss, &ll) != 0) return 0;
    return ss.ss_family;
#else
    int fam = 0;
    socklen_t ll = sizeof fam;
    if (getsockopt(fd, SOL_SOCKET, SO_DOMAIN, &fam, &ll) != 0) return 0;
    return fam;
#endif
}

/* Appends `n` bytes to a Vec<u8> (the sysio.c shape). */
static void lust_sysnet_push(lust_Vec *out, const void *p, uint64_t n) {
    if (n == 0) return;
    lust_vec_reserve(out, n, 1, 1);
    memcpy((uint8_t *)out->ptr + out->len, p, (size_t)n);
    out->len += n;
}

static void lust_sysnet_put64(lust_Vec *out, uint64_t v) {
    uint8_t b[8];
    for (int i = 0; i < 8; i++) b[i] = (uint8_t)(v >> (8 * i));
    lust_sysnet_push(out, b, 8);
}

static uint64_t lust_sysnet_get64(const uint8_t *p) {
    uint64_t v = 0;
    for (int i = 0; i < 8; i++) v |= (uint64_t)p[i] << (8 * i);
    return v;
}

/* One sockaddr as an address record appended to `out`. */
static void lust_sysnet_push_addr(lust_Vec *out, const struct sockaddr *sa) {
    uint8_t bytes[16];
    memset(bytes, 0, sizeof bytes);
    if (sa->sa_family == AF_INET) {
        const struct sockaddr_in *s = (const struct sockaddr_in *)sa;
        memcpy(bytes, &s->sin_addr, 4);
        lust_sysnet_put64(out, 4);
        lust_sysnet_put64(out, ntohs(s->sin_port));
        lust_sysnet_put64(out, lust_sysnet_get64(bytes));
        lust_sysnet_put64(out, lust_sysnet_get64(bytes + 8));
        lust_sysnet_put64(out, 0);
        lust_sysnet_put64(out, 0);
    } else if (sa->sa_family == AF_INET6) {
        const struct sockaddr_in6 *s = (const struct sockaddr_in6 *)sa;
        memcpy(bytes, &s->sin6_addr, 16);
        lust_sysnet_put64(out, 6);
        lust_sysnet_put64(out, ntohs(s->sin6_port));
        lust_sysnet_put64(out, lust_sysnet_get64(bytes));
        lust_sysnet_put64(out, lust_sysnet_get64(bytes + 8));
        lust_sysnet_put64(out, s->sin6_flowinfo);
        lust_sysnet_put64(out, s->sin6_scope_id);
    }
}

/* An address record as a sockaddr. Returns the length, or 0 for a
   bad record. */
static socklen_t lust_sysnet_read_addr(const uint8_t *rec, uint64_t len, struct sockaddr_storage *ss) {
    if (len < 48) return 0;
    uint64_t fam = lust_sysnet_get64(rec);
    uint16_t port = (uint16_t)lust_sysnet_get64(rec + 8);
    uint8_t bytes[16];
    for (int i = 0; i < 8; i++) bytes[i] = rec[16 + i];
    for (int i = 0; i < 8; i++) bytes[8 + i] = rec[24 + i];
    memset(ss, 0, sizeof *ss);
    if (fam == 4) {
        struct sockaddr_in *s = (struct sockaddr_in *)ss;
        s->sin_family = AF_INET;
        s->sin_port = htons(port);
        memcpy(&s->sin_addr, bytes, 4);
        return sizeof *s;
    }
    if (fam == 6) {
        struct sockaddr_in6 *s = (struct sockaddr_in6 *)ss;
        s->sin6_family = AF_INET6;
        s->sin6_port = htons(port);
        memcpy(&s->sin6_addr, bytes, 16);
        s->sin6_flowinfo = (uint32_t)lust_sysnet_get64(rec + 32);
        s->sin6_scope_id = (uint32_t)lust_sysnet_get64(rec + 40);
        return sizeof *s;
    }
    return 0;
}

static int lust_sysnet_family(const uint8_t *rec, uint64_t len) {
    if (len < 48) return -1;
    uint64_t fam = lust_sysnet_get64(rec);
    return fam == 4 ? AF_INET : fam == 6 ? AF_INET6 : -1;
}

/* Dual stack on a fresh v6 socket, as std binds on Unix. */
static void lust_sysnet_v6only_off(int fd, int fam) {
    if (fam != AF_INET6) return;
    int off = 0;
    setsockopt(fd, IPPROTO_IPV6, IPV6_V6ONLY, &off, sizeof off);
}

int32_t lust_sys_net_resolve(const uint8_t *host, uint64_t hostlen, uint64_t port, lust_Vec *out) {
    char *name = malloc((size_t)hostlen + 1);
    if (!name) lust_oom();
    memcpy(name, host, (size_t)hostlen);
    name[hostlen] = 0;
    if (memchr(name, 0, (size_t)hostlen)) {
        const char *msg = gai_strerror(EAI_NONAME);
        lust_sysnet_push(out, msg, strlen(msg));
        free(name);
        return -1;
    }
    struct addrinfo hints;
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    struct addrinfo *res = 0;
    int rc = getaddrinfo(name, 0, &hints, &res);
    free(name);
    if (rc != 0) {
        const char *msg = gai_strerror(rc);
        lust_sysnet_push(out, msg, strlen(msg));
        return -1;
    }
    int32_t n = 0;
    for (struct addrinfo *ai = res; ai; ai = ai->ai_next) {
        if (ai->ai_family == AF_INET) {
            ((struct sockaddr_in *)ai->ai_addr)->sin_port = htons((uint16_t)port);
        } else if (ai->ai_family == AF_INET6) {
            ((struct sockaddr_in6 *)ai->ai_addr)->sin6_port = htons((uint16_t)port);
        } else {
            continue;
        }
        lust_sysnet_push_addr(out, ai->ai_addr);
        n++;
    }
    freeaddrinfo(res);
    return n;
}

static int32_t lust_sysnet_bind(const uint8_t *rec, uint64_t len, lust_Vec *out, int type, int listen_backlog) {
    int fam = lust_sysnet_family(rec, len);
    if (fam < 0) return -EINVAL;
    int fd = socket(fam, type | SOCK_CLOEXEC, 0);
    if (fd < 0) return -errno;
    lust_sock_after_create(fd, 0);
    if (listen_backlog >= 0) {
        int on = 1;
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof on);
    }
    lust_sysnet_v6only_off(fd, fam);
    struct sockaddr_storage ss;
    socklen_t sl = lust_sysnet_read_addr(rec, len, &ss);
    if (bind(fd, (struct sockaddr *)&ss, sl) != 0) {
        int e = errno;
        close(fd);
        return -e;
    }
    if (listen_backlog >= 0 && listen(fd, listen_backlog) != 0) {
        int e = errno;
        close(fd);
        return -e;
    }
    struct sockaddr_storage local;
    socklen_t ll = sizeof local;
    if (getsockname(fd, (struct sockaddr *)&local, &ll) == 0) lust_sysnet_push_addr(out, (struct sockaddr *)&local);
    return fd;
}

int32_t lust_sys_net_tcp_bind(const uint8_t *rec, uint64_t len, lust_Vec *out) {
    return lust_sysnet_bind(rec, len, out, SOCK_STREAM, 128);
}

int32_t lust_sys_net_udp_bind(const uint8_t *rec, uint64_t len, lust_Vec *out) {
    return lust_sysnet_bind(rec, len, out, SOCK_DGRAM, -1);
}

int32_t lust_sys_net_tcp_connect(const uint8_t *rec, uint64_t len, lust_Vec *out) {
    int fam = lust_sysnet_family(rec, len);
    if (fam < 0) return -EINVAL;
    int fd = socket(fam, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (fd < 0) return -errno;
    lust_sock_after_create(fd, 0);
    struct sockaddr_storage ss;
    socklen_t sl = lust_sysnet_read_addr(rec, len, &ss);
    if (connect(fd, (struct sockaddr *)&ss, sl) != 0) {
        int e = errno;
        close(fd);
        return -e;
    }
    struct sockaddr_storage local;
    socklen_t ll = sizeof local;
    if (getsockname(fd, (struct sockaddr *)&local, &ll) == 0) lust_sysnet_push_addr(out, (struct sockaddr *)&local);
    return fd;
}

/* connect with a timeout in microseconds: a nonblocking connect
   and a poll, as std's connect_timeout does. Returns the fd in
   blocking mode, -errno, or -10000 when the poll itself timed
   out (std reports that as its own TimedOut error, not an OS
   error). EINTR in poll gives back the time left. */
int32_t lust_sys_net_tcp_connect_timeout(const uint8_t *rec, uint64_t len, int64_t timeout_us, lust_Vec *out) {
    int fam = lust_sysnet_family(rec, len);
    if (fam < 0) return -EINVAL;
    int fd = socket(fam, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK, 0);
    if (fd < 0) return -errno;
    lust_sock_after_create(fd, 1);
    struct sockaddr_storage ss;
    socklen_t sl = lust_sysnet_read_addr(rec, len, &ss);
    if (connect(fd, (struct sockaddr *)&ss, sl) != 0) {
        if (errno != EINPROGRESS) {
            int e = errno;
            close(fd);
            return -e;
        }
        struct timespec start;
        clock_gettime(CLOCK_MONOTONIC, &start);
        int64_t left = timeout_us;
        for (;;) {
            struct pollfd pfd;
            pfd.fd = fd;
            pfd.events = POLLOUT;
            pfd.revents = 0;
            int ms = left >= 1000 ? (int)((left + 999) / 1000 > INT32_MAX ? INT32_MAX : (left + 999) / 1000) : 1;
            int r = poll(&pfd, 1, ms);
            if (r > 0) break;
            if (r == 0) {
                close(fd);
                return -10000;
            }
            if (errno != EINTR) {
                int e = errno;
                close(fd);
                return -e;
            }
            struct timespec now;
            clock_gettime(CLOCK_MONOTONIC, &now);
            int64_t used = (int64_t)(now.tv_sec - start.tv_sec) * 1000000 + (now.tv_nsec - start.tv_nsec) / 1000;
            if (used >= timeout_us) {
                close(fd);
                return -10000;
            }
            left = timeout_us - used;
        }
        int err = 0;
        socklen_t el = sizeof err;
        if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &el) != 0) err = errno;
        if (err != 0) {
            close(fd);
            return -err;
        }
    }
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags >= 0) fcntl(fd, F_SETFL, flags & ~O_NONBLOCK);
    struct sockaddr_storage local;
    socklen_t ll = sizeof local;
    if (getsockname(fd, (struct sockaddr *)&local, &ll) == 0) lust_sysnet_push_addr(out, (struct sockaddr *)&local);
    return fd;
}

int32_t lust_sys_net_connect_fd(int32_t fd, const uint8_t *rec, uint64_t len) {
    struct sockaddr_storage ss;
    socklen_t sl = lust_sysnet_read_addr(rec, len, &ss);
    if (sl == 0) return EINVAL;
    return connect(fd, (struct sockaddr *)&ss, sl) == 0 ? 0 : errno;
}

int32_t lust_sys_net_accept(int32_t fd, lust_Vec *out) {
    struct sockaddr_storage ss;
    socklen_t ll = sizeof ss;
    int n = lust_accept_cloexec(fd, (struct sockaddr *)&ss, &ll);
    if (n < 0) return -errno;
    lust_sysnet_push_addr(out, (struct sockaddr *)&ss);
    return n;
}

int32_t lust_sys_net_addr_of(int32_t fd, int32_t peer, lust_Vec *out) {
    struct sockaddr_storage ss;
    socklen_t ll = sizeof ss;
    int rc = peer ? getpeername(fd, (struct sockaddr *)&ss, &ll) : getsockname(fd, (struct sockaddr *)&ss, &ll);
    if (rc != 0) return errno;
    lust_sysnet_push_addr(out, (struct sockaddr *)&ss);
    return 0;
}

int32_t lust_sys_net_shutdown(int32_t fd, int32_t how) {
    return shutdown(fd, how == 0 ? SHUT_RD : how == 1 ? SHUT_WR : SHUT_RDWR) == 0 ? 0 : errno;
}

int32_t lust_sys_net_setopt(int32_t fd, int32_t opt, int64_t val) {
    int v = (int)val;
    switch (opt) {
        case 0: return setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &v, sizeof v) == 0 ? 0 : errno;
        case 1: {
            /* std checks the ttl it read back on Linux happens in the
               Rust side only for values it sets; the syscall is plain. */
            int fam = lust_sock_family(fd);
            if (fam == 0) return errno;
            if (fam == AF_INET6) return setsockopt(fd, IPPROTO_IPV6, IPV6_UNICAST_HOPS, &v, sizeof v) == 0 ? 0 : errno;
            return setsockopt(fd, IPPROTO_IP, IP_TTL, &v, sizeof v) == 0 ? 0 : errno;
        }
        case 2: return setsockopt(fd, SOL_SOCKET, SO_BROADCAST, &v, sizeof v) == 0 ? 0 : errno;
        case 3: {
            int flags = fcntl(fd, F_GETFL, 0);
            if (flags < 0) return errno;
            return fcntl(fd, F_SETFL, val ? flags | O_NONBLOCK : flags & ~O_NONBLOCK) == 0 ? 0 : errno;
        }
        case 4:
        case 5: {
            struct timeval tv;
            tv.tv_sec = (time_t)(val / 1000000);
            tv.tv_usec = (suseconds_t)(val % 1000000);
            return setsockopt(fd, SOL_SOCKET, opt == 4 ? SO_RCVTIMEO : SO_SNDTIMEO, &tv, sizeof tv) == 0 ? 0 : errno;
        }
        default: return EINVAL;
    }
}

int64_t lust_sys_net_getopt(int32_t fd, int32_t opt) {
    int v = 0;
    socklen_t ll = sizeof v;
    switch (opt) {
        case 0: return getsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &v, &ll) == 0 ? v : -(int64_t)errno;
        case 1: {
            int fam = lust_sock_family(fd);
            if (fam == 0) return -(int64_t)errno;
            if (fam == AF_INET6) return getsockopt(fd, IPPROTO_IPV6, IPV6_UNICAST_HOPS, &v, &ll) == 0 ? v : -(int64_t)errno;
            return getsockopt(fd, IPPROTO_IP, IP_TTL, &v, &ll) == 0 ? v : -(int64_t)errno;
        }
        case 2: return getsockopt(fd, SOL_SOCKET, SO_BROADCAST, &v, &ll) == 0 ? v : -(int64_t)errno;
        case 3: {
            int flags = fcntl(fd, F_GETFL, 0);
            return flags < 0 ? -(int64_t)errno : (flags & O_NONBLOCK) != 0;
        }
        case 4:
        case 5: {
            struct timeval tv;
            socklen_t tl = sizeof tv;
            if (getsockopt(fd, SOL_SOCKET, opt == 4 ? SO_RCVTIMEO : SO_SNDTIMEO, &tv, &tl) != 0) return -(int64_t)errno;
            return (int64_t)tv.tv_sec * 1000000 + (int64_t)tv.tv_usec;
        }
        default: return -(int64_t)EINVAL;
    }
}

int64_t lust_sys_net_sendto(int32_t fd, const uint8_t *p, uint64_t len, const uint8_t *rec, uint64_t rlen) {
    ssize_t n;
    if (rlen == 0) {
        n = send(fd, p, (size_t)len, MSG_NOSIGNAL);
    } else {
        struct sockaddr_storage ss;
        socklen_t sl = lust_sysnet_read_addr(rec, rlen, &ss);
        if (sl == 0) return -(int64_t)EINVAL;
        n = sendto(fd, p, (size_t)len, MSG_NOSIGNAL, (struct sockaddr *)&ss, sl);
    }
    return n < 0 ? -(int64_t)errno : (int64_t)n;
}

int64_t lust_sys_net_recvfrom(int32_t fd, uint64_t max, int32_t flags, lust_Vec *out, lust_Vec *addrout) {
    if (max == 0) return 0;
    uint8_t *tmp = malloc((size_t)max);
    if (!tmp) lust_oom();
    struct sockaddr_storage ss;
    socklen_t ll = sizeof ss;
    ssize_t n = recvfrom(fd, tmp, (size_t)max, flags & 1 ? MSG_PEEK : 0, (struct sockaddr *)&ss, &ll);
    if (n < 0) {
        int e = errno;
        free(tmp);
        return -(int64_t)e;
    }
    lust_sysnet_push(out, tmp, (uint64_t)n);
    free(tmp);
    lust_sysnet_push_addr(addrout, (struct sockaddr *)&ss);
    return (int64_t)n;
}

/* ---- Unix domain sockets (sysnet.h has the record forms) ---- */

/* One sockaddr_un and its length from path bytes + abstract flag.
   The Rust side checked the SUN_LEN limits. */
static socklen_t lust_sysnet_unix_addr(const uint8_t *p, uint64_t len, int32_t abstract, struct sockaddr_un *un) {
    memset(un, 0, sizeof *un);
    un->sun_family = AF_UNIX;
    socklen_t sl;
    if (abstract) {
        memcpy(un->sun_path + 1, p, (size_t)len);
        sl = (socklen_t)(offsetof(struct sockaddr_un, sun_path) + 1 + len);
    } else {
        memcpy(un->sun_path, p, (size_t)len);
        sl = (socklen_t)(offsetof(struct sockaddr_un, sun_path) + len + 1);
    }
#ifdef __APPLE__
    /* Darwin's sockaddr_un carries its length in sun_len (its first
       byte, before sun_family); the byte count here also covers that
       byte on Darwin, where sa_family_t is one byte. */
    un->sun_len = (unsigned char)sl;
#endif
    return sl;
}

/* One unix address record out: kind u64 then the name bytes. */
static void lust_sysnet_push_unix_addr(lust_Vec *out, const struct sockaddr_un *un, socklen_t ll) {
    uint64_t off = offsetof(struct sockaddr_un, sun_path);
    if (ll <= off) {
        lust_sysnet_put64(out, 0);
        return;
    }
    uint64_t n = ll - off;
    if (un->sun_path[0] == 0) {
        if (n <= 1) {
            lust_sysnet_put64(out, 0);
            return;
        }
        lust_sysnet_put64(out, 2);
        lust_sysnet_push(out, un->sun_path + 1, n - 1);
        return;
    }
    uint64_t sl = 0;
    while (sl < n && un->sun_path[sl] != 0) sl++;
    lust_sysnet_put64(out, 1);
    lust_sysnet_push(out, un->sun_path, sl);
}

int32_t lust_sys_net_unix_pair(lust_Vec *out) {
    int fds[2];
    if (socketpair(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0, fds) != 0) return -errno;
    lust_sock_after_create(fds[0], 0);
    lust_sock_after_create(fds[1], 0);
    lust_sysnet_put64(out, (uint64_t)(uint32_t)fds[1]);
    return fds[0];
}

int32_t lust_sys_net_unix_bind(const uint8_t *p, uint64_t len, int32_t abstract) {
    int fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (fd < 0) return -errno;
    lust_sock_after_create(fd, 0);
    struct sockaddr_un un;
    socklen_t sl = lust_sysnet_unix_addr(p, len, abstract, &un);
    if (bind(fd, (struct sockaddr *)&un, sl) != 0 || listen(fd, 128) != 0) {
        int e = errno;
        close(fd);
        return -e;
    }
    return fd;
}

int32_t lust_sys_net_unix_connect(const uint8_t *p, uint64_t len, int32_t abstract) {
    int fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (fd < 0) return -errno;
    lust_sock_after_create(fd, 0);
    struct sockaddr_un un;
    socklen_t sl = lust_sysnet_unix_addr(p, len, abstract, &un);
    if (connect(fd, (struct sockaddr *)&un, sl) != 0) {
        int e = errno;
        close(fd);
        return -e;
    }
    return fd;
}

int32_t lust_sys_net_unix_accept(int32_t fd, lust_Vec *out) {
    struct sockaddr_un un;
    socklen_t ll = sizeof un;
    int n = lust_accept_cloexec(fd, (struct sockaddr *)&un, &ll);
    if (n < 0) return -errno;
    lust_sysnet_push_unix_addr(out, &un, ll);
    return n;
}

int32_t lust_sys_net_unix_addr(int32_t fd, int32_t peer, lust_Vec *out) {
    struct sockaddr_un un;
    socklen_t ll = sizeof un;
    int rc = peer ? getpeername(fd, (struct sockaddr *)&un, &ll) : getsockname(fd, (struct sockaddr *)&un, &ll);
    if (rc != 0) return errno;
    lust_sysnet_push_unix_addr(out, &un, ll);
    return 0;
}

#endif

#endif

#endif

/* The Unix calls behind the rustix adapter (src/runtime/sysx.h,
   w-cinterop2). */
/* The Unix calls behind the rustix adapter (w-cinterop2): the C
   behind the `sys_x_*` intrinsics of src/ty/lang.rs, called from
   library/deps/rustix. Paths cross as (ptr, len) byte strings and
   are copied to a NUL-terminated buffer here; an empty path with
   a real dirfd stays empty (AT_EMPTY_PATH callers pass the flag).
   OS errors return as errno (positive), or as -errno where the
   value is an fd or a flag word. Stat records are 8-byte
   little-endian fields appended to the out Vec (sysx.c lists
   them).

   Declarations here are in every unit; bodies (sysx.c) only in
   the runtime unit (LUST_IMPL), like sysnet.h. */
#ifndef LUST_RT_SYSX_H
#define LUST_RT_SYSX_H

/* kill(2): 0 or errno. */
int32_t lust_sys_x_kill(int32_t pid, int32_t sig);
/* getppid(2). */
int32_t lust_sys_x_getppid(void);
/* prctl(PR_SET_PDEATHSIG, sig): 0 or errno. */
int32_t lust_sys_x_prctl_deathsig(int32_t sig);
/* waitid(2) with the raw idtype, id and options: on success appends
   si_pid, si_uid, si_signo, si_status and si_code as five i64 (all 0
   when WNOHANG found no child); 0 or errno. */
int32_t lust_sys_x_waitid(int32_t idtype, int32_t id, int32_t options, lust_Vec *out);
/* pthread_sigmask(how, set, NULL) with `set` as a bit mask of the
   signals 1..64 (bit n-1 is signal n): 0 or errno. For nix. */
int32_t lust_sys_x_sigmask(int32_t how, uint64_t set);
/* prctl THP disable: set (mode 1) returns 0 or -errno; get
   (mode 0) returns 0 or 1, or -errno. */
int32_t lust_sys_x_prctl_thp(int32_t mode, int32_t val);
/* getrlimit: appends current and maximum as two u64 (RLIM_INFINITY
   is UINT64_MAX); 0 or errno. */
int32_t lust_sys_x_getrlimit(int32_t resource, lust_Vec *out);
/* setrlimit: 0 or errno. */
int32_t lust_sys_x_setrlimit(int32_t resource, uint64_t current, uint64_t maximum);
/* openat(2) with the raw Linux flags and mode: the fd or -errno. */
int32_t lust_sys_x_openat(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, uint32_t mode);
/* fstatat(2): appends the 16-field stat record; 0 or errno. */
int32_t lust_sys_x_statat(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, lust_Vec *out);
/* fstat(2): appends the 16-field stat record; 0 or errno. */
int32_t lust_sys_x_fstat(int32_t fd, lust_Vec *out);
/* statx(2): appends the 23-field statx record; 0 or errno. */
int32_t lust_sys_x_statx(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, uint32_t mask, lust_Vec *out);
/* faccessat2 (faccessat fallback without AT_EACCESS): 0 or errno. */
int32_t lust_sys_x_accessat(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t mode, int32_t flags);
/* utimensat(2) with both times as (sec, nsec): 0 or errno. */
int32_t lust_sys_x_utimensat(int32_t dirfd, const uint8_t *p, uint64_t len, int64_t a_sec, int64_t a_nsec, int64_t m_sec, int64_t m_nsec, int32_t flags);
/* mknodat(2): 0 or errno. */
int32_t lust_sys_x_mknodat(int32_t dirfd, const uint8_t *p, uint64_t len, uint32_t mode, uint64_t dev);
/* fcntl(F_GETFL): the flags or -errno. */
int32_t lust_sys_x_fcntl_getfl(int32_t fd);
/* fcntl(F_SETFL): 0 or errno. */
int32_t lust_sys_x_fcntl_setfl(int32_t fd, int32_t flags);
/* ioctl(TIOCGWINSZ): appends row, col, xpixel, ypixel as u16
   little-endian pairs (8 bytes); 0 or errno. */
int32_t lust_sys_x_winsize(int32_t fd, lust_Vec *out);
/* Signal registry behind the signal-hook adapter. Actions by
   kind: 0 set *flag to 1, 1 emulate the default action when
   *flag is set, 2 store value in the u64 at flag, 3 _exit(value)
   when *flag is set, 4 write the signal byte to a pipe fd.
   Register returns 0 or errno. */
/* Registers one action of a kind on a signal. */
int32_t lust_sys_sig_register(int32_t sig, int32_t kind, void *flag, uint64_t value);
/* Registers a pipe write end on a signal: 0 or errno. */
int32_t lust_sys_sig_register_pipe(int32_t sig, int32_t write_fd);
/* Removes every pipe action with this write end. */
void lust_sys_sig_unregister_pipe(int32_t write_fd);
/* pipe2 for a Signals instance: read end nonblocking, both
   CLOEXEC; appends the write fd as one u64, returns the read fd
   or -errno. */
int32_t lust_sys_sig_pipe(lust_Vec *out);
/* Waits for bytes on a Signals pipe, then drains what is there
   into `out`: the byte count, or -errno. */
int32_t lust_sys_sig_poll_read(int32_t fd, lust_Vec *out);
/* One nonblocking read of a Signals pipe into `out`: the byte
   count (0 when nothing waits), or -errno. */
int32_t lust_sys_sig_read_now(int32_t fd, lust_Vec *out);
/* raise(sig): 0 or errno. */
int32_t lust_sys_sig_raise(int32_t sig);
/* Restores SIG_DFL, unblocks, and raises; only returns (with an
   errno) when the restore itself fails, else aborts. */
int32_t lust_sys_sig_restore_raise(int32_t sig);
/* _exit(status). */
void lust_sys_sig_exit(int32_t status);
/* abort(). */
void lust_sys_sig_abort(void);
/* pipe2(2) with the raw Linux flags: appends the two fds as 8-byte
   fields; 0 or errno. */
int32_t lust_sys_x_pipe(int32_t flags, lust_Vec *out);
/* dup2(2): the new fd or -errno. */
int32_t lust_sys_x_dup2(int32_t oldfd, int32_t newfd);
/* poll(2) over `recs`: one 8-byte field per fd (fd in the low 32
   bits, events at bit 32, revents at bit 48), revents written
   back in place. Returns the ready count or -errno. A timeout
   of (sec, nsec) with sec<0 waits without a limit. */
int32_t lust_sys_x_poll(lust_Vec *recs, int64_t sec, int64_t nsec);
/* inotify_init1(2) with the raw Linux flags: the fd or -errno. */
int32_t lust_sys_x_inotify_init1(int32_t flags);
/* inotify_add_watch(2): the watch descriptor or -errno. */
int32_t lust_sys_x_inotify_add_watch(int32_t fd, const uint8_t *p, uint64_t len, uint32_t mask);
/* inotify_rm_watch(2): 0 or errno. */
int32_t lust_sys_x_inotify_rm_watch(int32_t fd, int32_t wd);
/* One getdents64 call of at most `max` bytes: the raw records
   are appended to `out`; the byte count or -errno. */
int64_t lust_sys_x_getdents(int32_t fd, uint64_t max, lust_Vec *out);
/* statvfs(2): appends the 11-field statvfs record (bsize,
   frsize, blocks, bfree, bavail, files, ffree, favail, fsid,
   flag, namemax) as u64s; 0 or errno. */
int32_t lust_sys_x_statvfs(const uint8_t *p, uint64_t len, lust_Vec *out);
/* fstatvfs(2): the same record for an fd; 0 or errno. */
int32_t lust_sys_x_fstatvfs(int32_t fd, lust_Vec *out);
/* fanotify_init(2) with the raw Linux flags (nix adapter):
   the fd or -errno. */
int32_t lust_sys_x_fanotify_init(uint32_t flags, uint32_t event_f_flags);
/* fanotify_mark(2): a path of length 0 with has_path 0 passes
   NULL as the pathname; 0 or errno. */
int32_t lust_sys_x_fanotify_mark(int32_t fd, uint32_t flags, uint64_t mask, int32_t dirfd, int32_t has_path, const uint8_t *p, uint64_t len);
/* name_to_handle_at(2) with the real crate's sizing loop:
   appends handle_type and the mount id (a full u64 field,
   for AT_HANDLE_MNT_ID_UNIQUE) and then the handle bytes;
   0 or errno. */
int32_t lust_sys_x_name_to_handle_at(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, lust_Vec *out);
/* open_by_handle_at(2) over a handle (type, bytes): the fd
   or -errno. */
int32_t lust_sys_x_open_by_handle_at(int32_t mount_fd, int32_t handle_type, const uint8_t *p, uint64_t len, int32_t flags);
/* kqueue(2) (the nix adapter's sys::event, Darwin): the fd or
   -errno. -ENOSYS off Darwin. */
int32_t lust_sys_x_kqueue(void);
/* kevent(2) over 48-byte records (ident u64, filter i64, flags
   u64, fflags u64, data i64, udata i64, all little-endian):
   `changes` is the changelist bytes, `events` a Vec whose length
   is the eventlist capacity in bytes and whose first records are
   overwritten with the returned events. has_timeout 0 waits
   without a limit. Returns the event count or -errno. */
int32_t lust_sys_x_kevent(int32_t fd, const uint8_t *changes, uint64_t clen, lust_Vec *events, int32_t has_timeout, int64_t sec, int64_t nsec);

#ifdef LUST_IMPL
#ifdef _WIN32
/* Linux-only intrinsics (rustix, signal-hook, nix adapters) for
   Windows (rel-win). Spliced instead of sysx.c under _WIN32.
   Real here: pipes (CreatePipe), console size, exit and abort.
   The rest fail with ERROR_NOT_SUPPORTED (50): their crates
   (rustix, signal-hook) keep tsgo's Windows build a reject at
   the Rust level until Windows adapters land; see REPORT.md. */
#define LUST_X_NOSUP 50

static void lust_sysx_push_u64(lust_Vec *out, uint64_t v) {
    lust_vec_reserve(out, 8, 1, 1);
    uint8_t *b = (uint8_t *)out->ptr + out->len;
    for (int k = 0; k < 8; k++) b[k] = (uint8_t)(v >> (8 * k));
    out->len += 8;
}

int32_t lust_sys_x_pipe(int32_t flags, lust_Vec *out) {
    (void)flags;
    HANDLE rd = INVALID_HANDLE_VALUE, wr = INVALID_HANDLE_VALUE;
    if (!CreatePipe(&rd, &wr, 0, 0)) return (int32_t)GetLastError();
    lust_sysx_push_u64(out, (uint64_t)lust_win_fd_new(rd, 0));
    lust_sysx_push_u64(out, (uint64_t)lust_win_fd_new(wr, 0));
    return 0;
}

int32_t lust_sys_x_winsize(int32_t fd, lust_Vec *out) {
    HANDLE h = lust_win_handle(fd);
    CONSOLE_SCREEN_BUFFER_INFO info;
    if (h == INVALID_HANDLE_VALUE || !GetConsoleScreenBufferInfo(h, &info)) return (int32_t)GetLastError();
    lust_sysx_push_u64(out, (uint64_t)(info.srWindow.Bottom - info.srWindow.Top + 1));
    lust_sysx_push_u64(out, (uint64_t)(info.srWindow.Right - info.srWindow.Left + 1));
    lust_sysx_push_u64(out, 0);
    lust_sysx_push_u64(out, 0);
    return 0;
}

void lust_sys_sig_exit(int32_t status) { ExitProcess((UINT)status); }
void lust_sys_sig_abort(void) { abort(); }

int32_t lust_sys_x_kill(int32_t pid, int32_t sig) { (void)pid; (void)sig; return LUST_X_NOSUP; }
int32_t lust_sys_x_prctl_deathsig(int32_t sig) { (void)sig; return LUST_X_NOSUP; }
int32_t lust_sys_x_waitid(int32_t idtype, int32_t id, int32_t options, lust_Vec *out) { (void)idtype; (void)id; (void)options; (void)out; return LUST_X_NOSUP; }
int32_t lust_sys_x_sigmask(int32_t how, uint64_t set) { (void)how; (void)set; return LUST_X_NOSUP; }
int32_t lust_sys_x_prctl_thp(int32_t mode, int32_t val) { (void)mode; (void)val; return LUST_X_NOSUP; }
int32_t lust_sys_x_getrlimit(int32_t resource, lust_Vec *out) { (void)resource; (void)out; return LUST_X_NOSUP; }
int32_t lust_sys_x_setrlimit(int32_t resource, uint64_t current, uint64_t maximum) { (void)resource; (void)current; (void)maximum; return LUST_X_NOSUP; }
int32_t lust_sys_x_openat(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, uint32_t mode) { (void)dirfd; (void)p; (void)len; (void)flags; (void)mode; return LUST_X_NOSUP; }
int32_t lust_sys_x_statat(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, lust_Vec *out) { (void)dirfd; (void)p; (void)len; (void)flags; (void)out; return LUST_X_NOSUP; }
int32_t lust_sys_x_fstat(int32_t fd, lust_Vec *out) { (void)fd; (void)out; return LUST_X_NOSUP; }
int32_t lust_sys_x_statx(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, uint32_t mask, lust_Vec *out) { (void)dirfd; (void)p; (void)len; (void)flags; (void)mask; (void)out; return LUST_X_NOSUP; }
int32_t lust_sys_x_accessat(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t mode, int32_t flags) { (void)dirfd; (void)p; (void)len; (void)mode; (void)flags; return LUST_X_NOSUP; }
int32_t lust_sys_x_utimensat(int32_t dirfd, const uint8_t *p, uint64_t len, int64_t a_sec, int64_t a_nsec, int64_t m_sec, int64_t m_nsec, int32_t flags) { (void)dirfd; (void)p; (void)len; (void)a_sec; (void)a_nsec; (void)m_sec; (void)m_nsec; (void)flags; return LUST_X_NOSUP; }
int32_t lust_sys_x_mknodat(int32_t dirfd, const uint8_t *p, uint64_t len, uint32_t mode, uint64_t dev) { (void)dirfd; (void)p; (void)len; (void)mode; (void)dev; return LUST_X_NOSUP; }
int32_t lust_sys_x_fcntl_getfl(int32_t fd) { (void)fd; return LUST_X_NOSUP; }
int32_t lust_sys_x_fcntl_setfl(int32_t fd, int32_t flags) { (void)fd; (void)flags; return LUST_X_NOSUP; }
int32_t lust_sys_sig_register(int32_t sig, int32_t kind, void *flag, uint64_t value) { (void)sig; (void)kind; (void)flag; (void)value; return LUST_X_NOSUP; }
int32_t lust_sys_sig_register_pipe(int32_t sig, int32_t write_fd) { (void)sig; (void)write_fd; return LUST_X_NOSUP; }
int32_t lust_sys_sig_pipe(lust_Vec *out) { (void)out; return LUST_X_NOSUP; }
int32_t lust_sys_sig_poll_read(int32_t fd, lust_Vec *out) { (void)fd; (void)out; return LUST_X_NOSUP; }
int32_t lust_sys_sig_read_now(int32_t fd, lust_Vec *out) { (void)fd; (void)out; return LUST_X_NOSUP; }
int32_t lust_sys_sig_raise(int32_t sig) { (void)sig; return LUST_X_NOSUP; }
int32_t lust_sys_sig_restore_raise(int32_t sig) { (void)sig; return LUST_X_NOSUP; }
int32_t lust_sys_x_dup2(int32_t oldfd, int32_t newfd) { (void)oldfd; (void)newfd; return LUST_X_NOSUP; }
int32_t lust_sys_x_poll(lust_Vec *recs, int64_t sec, int64_t nsec) { (void)recs; (void)sec; (void)nsec; return LUST_X_NOSUP; }
int32_t lust_sys_x_inotify_init1(int32_t flags) { (void)flags; return LUST_X_NOSUP; }
int32_t lust_sys_x_inotify_add_watch(int32_t fd, const uint8_t *p, uint64_t len, uint32_t mask) { (void)fd; (void)p; (void)len; (void)mask; return LUST_X_NOSUP; }
int32_t lust_sys_x_inotify_rm_watch(int32_t fd, int32_t wd) { (void)fd; (void)wd; return LUST_X_NOSUP; }
int32_t lust_sys_x_statvfs(const uint8_t *p, uint64_t len, lust_Vec *out) { (void)p; (void)len; (void)out; return LUST_X_NOSUP; }
int32_t lust_sys_x_fstatvfs(int32_t fd, lust_Vec *out) { (void)fd; (void)out; return LUST_X_NOSUP; }
int32_t lust_sys_x_fanotify_init(uint32_t flags, uint32_t event_f_flags) { (void)flags; (void)event_f_flags; return LUST_X_NOSUP; }
int32_t lust_sys_x_fanotify_mark(int32_t fd, uint32_t flags, uint64_t mask, int32_t dirfd, int32_t has_path, const uint8_t *p, uint64_t len) { (void)fd; (void)flags; (void)mask; (void)dirfd; (void)has_path; (void)p; (void)len; return LUST_X_NOSUP; }
int32_t lust_sys_x_name_to_handle_at(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, lust_Vec *out) { (void)dirfd; (void)p; (void)len; (void)flags; (void)out; return LUST_X_NOSUP; }
int32_t lust_sys_x_open_by_handle_at(int32_t mount_fd, int32_t handle_type, const uint8_t *p, uint64_t len, int32_t flags) { (void)mount_fd; (void)handle_type; (void)p; (void)len; (void)flags; return LUST_X_NOSUP; }
int32_t lust_sys_x_getppid(void) { return 0; }
int64_t lust_sys_x_getdents(int32_t fd, uint64_t max, lust_Vec *out) { (void)fd; (void)max; (void)out; return -LUST_X_NOSUP; }
void lust_sys_sig_unregister_pipe(int32_t write_fd) { (void)write_fd; }

#else
/* The Unix calls behind the rustix adapter: see sysx.h. Included
   only under LUST_IMPL, after the runtime's own includes. The
   Linux-only calls (inotify, fanotify, prctl, statx, getdents64,
   the handle calls) compile only on Linux; off Linux their bodies
   return ENOSYS so every program still links, and the rustix
   adapter leaves those items out off Linux so a program that uses
   one rejects at compile time instead of meeting the stub. */
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <poll.h>
#ifdef __linux__
#include <sys/fanotify.h>
#include <sys/inotify.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#endif
#include <sys/ioctl.h>
#include <sys/statvfs.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>

/* pipe2 with the caller's O_CLOEXEC/O_NONBLOCK flag bits (the
   target's values, from the rustix adapter): the call itself on
   Linux, pipe plus fcntl on Darwin, as in sysio.c. */
#ifdef __APPLE__
static int lust_sysx_pipe2(int fds[2], int flags) {
    if (pipe(fds) != 0) return -1;
    for (int i = 0; i < 2; i++) {
        if (flags & O_CLOEXEC) fcntl(fds[i], F_SETFD, FD_CLOEXEC);
        if (flags & O_NONBLOCK) fcntl(fds[i], F_SETFL, O_NONBLOCK);
    }
    return 0;
}
#else
static int lust_sysx_pipe2(int fds[2], int flags) { return pipe2(fds, flags); }
#endif

/* Appends `n` bytes to a Vec<u8> (the sysnet.c shape). */
static void lust_sysx_push(lust_Vec *out, const void *p, uint64_t n) {
    if (n == 0) return;
    lust_vec_reserve(out, n, 1, 1);
    memcpy((uint8_t *)out->ptr + out->len, p, (size_t)n);
    out->len += n;
}

/* Pushes one u64 to `out` little-endian. */
static void lust_sysx_u64(lust_Vec *out, uint64_t v) {
    uint8_t b[8];
    for (int k = 0; k < 8; k++) b[k] = (uint8_t)(v >> (8 * k));
    lust_sysx_push(out, b, 8);
}

/* A NUL-terminated copy of a (ptr, len) path, or NULL on OOM. */
static char *lust_sysx_path(const uint8_t *p, uint64_t len) {
    char *s = (char *)malloc(len + 1);
    if (!s) return NULL;
    memcpy(s, p, len);
    s[len] = 0;
    return s;
}

int32_t lust_sys_x_kill(int32_t pid, int32_t sig) {
    return kill((pid_t)pid, sig) == 0 ? 0 : errno;
}

int32_t lust_sys_x_getppid(void) {
    return (int32_t)getppid();
}

int32_t lust_sys_x_waitid(int32_t idtype, int32_t id, int32_t options, lust_Vec *out) {
    siginfo_t info;
    memset(&info, 0, sizeof info);
    if (waitid((idtype_t)idtype, (id_t)id, &info, options) != 0) return errno;
    lust_sysx_u64(out, (uint64_t)(int64_t)info.si_pid);
    lust_sysx_u64(out, (uint64_t)(int64_t)info.si_uid);
    lust_sysx_u64(out, (uint64_t)(int64_t)info.si_signo);
    lust_sysx_u64(out, (uint64_t)(int64_t)info.si_status);
    lust_sysx_u64(out, (uint64_t)(int64_t)info.si_code);
    return 0;
}

int32_t lust_sys_x_sigmask(int32_t how, uint64_t set) {
    sigset_t s;
    sigemptyset(&s);
    for (int n = 1; n <= 64; n++) {
        if (set >> (n - 1) & 1) sigaddset(&s, n);
    }
    return pthread_sigmask(how, &s, NULL);
}

int32_t lust_sys_x_prctl_deathsig(int32_t sig) {
#ifdef __linux__
    return prctl(PR_SET_PDEATHSIG, (unsigned long)sig, 0, 0, 0) == 0 ? 0 : errno;
#else
    (void)sig;
    return ENOSYS;
#endif
}

#ifndef PR_GET_THP_DISABLE
#define PR_GET_THP_DISABLE 41
#endif
#ifndef PR_SET_THP_DISABLE
#define PR_SET_THP_DISABLE 42
#endif

int32_t lust_sys_x_prctl_thp(int32_t mode, int32_t val) {
#ifdef __linux__
    if (mode == 1) {
        return prctl(PR_SET_THP_DISABLE, val != 0, 0, 0, 0) == 0 ? 0 : -errno;
    }
    int r = prctl(PR_GET_THP_DISABLE, 0, 0, 0, 0);
    return r < 0 ? -errno : r;
#else
    (void)mode;
    (void)val;
    return -ENOSYS;
#endif
}

int32_t lust_sys_x_getrlimit(int32_t resource, lust_Vec *out) {
    struct rlimit rl;
    if (getrlimit((int)resource, &rl) != 0) return errno;
    lust_sysx_u64(out, (uint64_t)rl.rlim_cur);
    lust_sysx_u64(out, (uint64_t)rl.rlim_max);
    return 0;
}

int32_t lust_sys_x_setrlimit(int32_t resource, uint64_t current, uint64_t maximum) {
    struct rlimit rl;
    rl.rlim_cur = (rlim_t)current;
    rl.rlim_max = (rlim_t)maximum;
    return setrlimit((int)resource, &rl) == 0 ? 0 : errno;
}

int32_t lust_sys_x_openat(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, uint32_t mode) {
    char *s = lust_sysx_path(p, len);
    if (!s) return -ENOMEM;
    int fd = openat(dirfd, s, flags, (mode_t)mode);
    int e = errno;
    free(s);
    return fd < 0 ? -e : fd;
}

/* The 16-field stat record: dev, ino, nlink, mode, uid, gid,
   rdev, size, blksize, blocks, atime sec/nsec, mtime sec/nsec,
   ctime sec/nsec (signed fields cross as their u64 bits). */
static void lust_sysx_stat_rec(lust_Vec *out, const struct stat *st) {
    uint64_t f[16] = {(uint64_t)st->st_dev, (uint64_t)st->st_ino, (uint64_t)st->st_nlink,
                      (uint64_t)st->st_mode, (uint64_t)st->st_uid, (uint64_t)st->st_gid,
                      (uint64_t)st->st_rdev, (uint64_t)st->st_size, (uint64_t)st->st_blksize,
                      (uint64_t)st->st_blocks, (uint64_t)LUST_ST_ATIME(*st).tv_sec, (uint64_t)LUST_ST_ATIME(*st).tv_nsec,
                      (uint64_t)LUST_ST_MTIME(*st).tv_sec, (uint64_t)LUST_ST_MTIME(*st).tv_nsec,
                      (uint64_t)LUST_ST_CTIME(*st).tv_sec, (uint64_t)LUST_ST_CTIME(*st).tv_nsec};
    for (int i = 0; i < 16; i++) lust_sysx_u64(out, f[i]);
}

int32_t lust_sys_x_statat(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, lust_Vec *out) {
    char *s = lust_sysx_path(p, len);
    if (!s) return ENOMEM;
    struct stat st;
    int r = fstatat(dirfd, s, &st, flags);
    int e = errno;
    free(s);
    if (r != 0) return e;
    lust_sysx_stat_rec(out, &st);
    return 0;
}

int32_t lust_sys_x_fstat(int32_t fd, lust_Vec *out) {
    struct stat st;
    if (fstat(fd, &st) != 0) return errno;
    lust_sysx_stat_rec(out, &st);
    return 0;
}

#ifdef __linux__
/* The kernel's struct statx (stable ABI, 256 bytes), spelled
   out because tcc's headers do not expose glibc's. Field order
   is the kernel's: atime, btime, ctime, mtime. */
struct lust_statx_time {
    int64_t tv_sec;
    uint32_t tv_nsec;
    int32_t reserved;
};
struct lust_statx {
    uint32_t stx_mask;
    uint32_t stx_blksize;
    uint64_t stx_attributes;
    uint32_t stx_nlink;
    uint32_t stx_uid;
    uint32_t stx_gid;
    uint16_t stx_mode;
    uint16_t spare0[1];
    uint64_t stx_ino;
    uint64_t stx_size;
    uint64_t stx_blocks;
    uint64_t stx_attributes_mask;
    struct lust_statx_time stx_atime;
    struct lust_statx_time stx_btime;
    struct lust_statx_time stx_ctime;
    struct lust_statx_time stx_mtime;
    uint32_t stx_rdev_major;
    uint32_t stx_rdev_minor;
    uint32_t stx_dev_major;
    uint32_t stx_dev_minor;
    uint64_t stx_mnt_id;
    uint32_t stx_dio_mem_align;
    uint32_t stx_dio_offset_align;
    uint64_t spare3[12];
};
#ifndef SYS_statx
#define SYS_statx 332
#endif

/* The statx record: mask, blksize, attributes, nlink, uid, gid,
   mode, ino, size, blocks, atime sec/nsec, mtime sec/nsec,
   ctime sec/nsec, btime sec/nsec, rdev major/minor, dev
   major/minor. */
int32_t lust_sys_x_statx(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, uint32_t mask, lust_Vec *out) {
    char *s = lust_sysx_path(p, len);
    if (!s) return ENOMEM;
    struct lust_statx stx;
    long r = syscall(SYS_statx, dirfd, s, flags, mask, &stx);
    int e = errno;
    free(s);
    if (r != 0) return e;
    uint64_t f[23] = {stx.stx_mask, stx.stx_blksize, stx.stx_attributes, stx.stx_nlink,
                      stx.stx_uid, stx.stx_gid, stx.stx_mode, stx.stx_ino,
                      stx.stx_size, stx.stx_blocks, stx.stx_attributes_mask, (uint64_t)stx.stx_atime.tv_sec, stx.stx_atime.tv_nsec,
                      (uint64_t)stx.stx_mtime.tv_sec, stx.stx_mtime.tv_nsec, (uint64_t)stx.stx_ctime.tv_sec,
                      stx.stx_ctime.tv_nsec, (uint64_t)stx.stx_btime.tv_sec, stx.stx_btime.tv_nsec,
                      stx.stx_rdev_major, stx.stx_rdev_minor, stx.stx_dev_major, stx.stx_dev_minor};
    for (int i = 0; i < 23; i++) lust_sysx_u64(out, f[i]);
    return 0;
}
#else
int32_t lust_sys_x_statx(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, uint32_t mask, lust_Vec *out) {
    (void)dirfd; (void)p; (void)len; (void)flags; (void)mask; (void)out;
    return ENOSYS;
}
#endif

int32_t lust_sys_x_accessat(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t mode, int32_t flags) {
    char *s = lust_sysx_path(p, len);
    if (!s) return ENOMEM;
#ifdef SYS_faccessat2
    long r = syscall(SYS_faccessat2, dirfd, s, mode, flags);
    int e = errno;
    if (r != 0 && e == ENOSYS) {
        r = faccessat(dirfd, s, mode, flags & AT_EACCESS);
        e = errno;
    }
#else
    long r = faccessat(dirfd, s, mode, flags & AT_EACCESS);
    int e = errno;
#endif
    free(s);
    return r == 0 ? 0 : e;
}

int32_t lust_sys_x_utimensat(int32_t dirfd, const uint8_t *p, uint64_t len, int64_t a_sec, int64_t a_nsec, int64_t m_sec, int64_t m_nsec, int32_t flags) {
    char *s = lust_sysx_path(p, len);
    if (!s) return ENOMEM;
    struct timespec ts[2] = {{(time_t)a_sec, (long)a_nsec}, {(time_t)m_sec, (long)m_nsec}};
    int r = utimensat(dirfd, s, ts, flags);
    int e = errno;
    free(s);
    return r == 0 ? 0 : e;
}

int32_t lust_sys_x_mknodat(int32_t dirfd, const uint8_t *p, uint64_t len, uint32_t mode, uint64_t dev) {
    char *s = lust_sysx_path(p, len);
    if (!s) return ENOMEM;
    int r = mknodat(dirfd, s, (mode_t)mode, (dev_t)dev);
    int e = errno;
    free(s);
    return r == 0 ? 0 : e;
}

int32_t lust_sys_x_fcntl_getfl(int32_t fd) {
    int r = fcntl(fd, F_GETFL);
    return r < 0 ? -errno : r;
}

int32_t lust_sys_x_fcntl_setfl(int32_t fd, int32_t flags) {
    return fcntl(fd, F_SETFL, flags) == 0 ? 0 : errno;
}

int32_t lust_sys_x_pipe(int32_t flags, lust_Vec *out) {
    int fds[2];
    if (lust_sysx_pipe2(fds, flags) != 0) return errno;
    lust_sysx_u64(out, (uint64_t)(uint32_t)fds[0]);
    lust_sysx_u64(out, (uint64_t)(uint32_t)fds[1]);
    return 0;
}

int32_t lust_sys_x_dup2(int32_t oldfd, int32_t newfd) {
    int r = dup2(oldfd, newfd);
    return r < 0 ? -errno : r;
}

int32_t lust_sys_x_poll(lust_Vec *recs, int64_t sec, int64_t nsec) {
    uint64_t n = recs->len / 8;
    struct pollfd stack_fds[16];
    struct pollfd *fds = stack_fds;
    if (n > 16) {
        fds = (struct pollfd *)malloc((size_t)n * sizeof(struct pollfd));
        if (!fds) return -ENOMEM;
    }
    const uint8_t *bytes = (const uint8_t *)recs->ptr;
    for (uint64_t i = 0; i < n; i++) {
        uint64_t v = 0;
        for (int k = 0; k < 8; k++) v |= (uint64_t)bytes[i * 8 + k] << (8 * k);
        fds[i].fd = (int)(uint32_t)v;
        fds[i].events = (short)(v >> 32);
        fds[i].revents = 0;
    }
    int timeout_ms = -1;
    if (sec >= 0) {
        int64_t ms = sec * 1000 + nsec / 1000000 + (nsec % 1000000 != 0 ? 1 : 0);
        timeout_ms = ms > INT32_MAX ? INT32_MAX : (int)ms;
    }
    int r = poll(fds, (nfds_t)n, timeout_ms);
    int e = errno;
    if (r >= 0) {
        uint8_t *out = (uint8_t *)recs->ptr;
        for (uint64_t i = 0; i < n; i++) {
            uint16_t rev = (uint16_t)fds[i].revents;
            out[i * 8 + 6] = (uint8_t)(rev & 0xff);
            out[i * 8 + 7] = (uint8_t)(rev >> 8);
        }
    }
    if (fds != stack_fds) free(fds);
    return r < 0 ? -e : r;
}

int32_t lust_sys_x_winsize(int32_t fd, lust_Vec *out) {
    struct winsize ws;
    if (ioctl(fd, TIOCGWINSZ, &ws) != 0) return errno;
    uint16_t f[4] = {ws.ws_row, ws.ws_col, ws.ws_xpixel, ws.ws_ypixel};
    uint8_t b[8];
    for (int i = 0; i < 4; i++) {
        b[2 * i] = (uint8_t)(f[i] & 0xff);
        b[2 * i + 1] = (uint8_t)(f[i] >> 8);
    }
    lust_sysx_push(out, b, 8);
    return 0;
}

/* ---- Signal registry (signal-hook adapter) ---- */

#define LUST_SIG_MAX 64
#define LUST_SIG_ACTIONS 24

struct lust_sig_action {
    int32_t kind;
    volatile uint8_t *flag;
    uint64_t value;
    int32_t pipe_fd;
};

static struct lust_sig_action lust_sig_actions[LUST_SIG_MAX + 1][LUST_SIG_ACTIONS];
static volatile sig_atomic_t lust_sig_counts[LUST_SIG_MAX + 1];
static int lust_sig_installed[LUST_SIG_MAX + 1];

/* The Term case of emulate_default_handler, shared with the
   conditional-default action. Async-signal-safe calls only. */
static void lust_sig_emulate_term(int sig) {
    struct sigaction dfl;
    memset(&dfl, 0, sizeof dfl);
    dfl.sa_handler = SIG_DFL;
    sigaction(sig, &dfl, NULL);
    sigset_t set;
    sigemptyset(&set);
    sigaddset(&set, sig);
    pthread_sigmask(SIG_UNBLOCK, &set, NULL);
    raise(sig);
    abort();
}

/* The default-action kind of a signal, upstream's table:
   0 ignore, 1 stop, 2 terminate, -1 unknown. */
static int lust_sig_default_kind(int sig) {
    switch (sig) {
        case SIGCHLD:
        case SIGCONT:
        case SIGURG:
        case SIGWINCH:
        case SIGIO:
            return 0;
        case SIGSTOP:
        case SIGTSTP:
        case SIGTTIN:
        case SIGTTOU:
            return 1;
        case SIGHUP:
        case SIGINT:
        case SIGQUIT:
        case SIGILL:
        case SIGTRAP:
        case SIGABRT:
        case SIGBUS:
        case SIGFPE:
        case SIGKILL:
        case SIGUSR1:
        case SIGSEGV:
        case SIGUSR2:
        case SIGPIPE:
        case SIGALRM:
        case SIGTERM:
        case SIGPROF:
        case SIGSYS:
        case SIGVTALRM:
        case SIGXCPU:
        case SIGXFSZ:
            return 2;
        default:
            return -1;
    }
}

static void lust_sig_handler(int sig) {
    int saved = errno;
    if (sig >= 1 && sig <= LUST_SIG_MAX) {
        int n = (int)lust_sig_counts[sig];
        for (int i = 0; i < n; i++) {
            struct lust_sig_action *a = &lust_sig_actions[sig][i];
            switch (a->kind) {
                case 0:
                    *a->flag = 1;
                    break;
                case 1:
                    if (*a->flag) {
                        int kind = lust_sig_default_kind(sig);
                        if (kind == 2) lust_sig_emulate_term(sig);
                        else if (kind == 1) raise(SIGSTOP);
                    }
                    break;
                case 2:
                    *(volatile uint64_t *)a->flag = a->value;
                    break;
                case 3:
                    if (*a->flag) _exit((int)a->value);
                    break;
                case 4: {
                    uint8_t b = (uint8_t)sig;
                    ssize_t unused = write(a->pipe_fd, &b, 1);
                    (void)unused;
                    break;
                }
                default:
                    break;
            }
        }
    }
    errno = saved;
}

/* Installs the shared handler for one signal, once. */
static int lust_sig_install(int sig) {
    if (lust_sig_installed[sig]) return 0;
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = lust_sig_handler;
    sa.sa_flags = SA_RESTART;
    sigemptyset(&sa.sa_mask);
    if (sigaction(sig, &sa, NULL) != 0) return errno;
    lust_sig_installed[sig] = 1;
    return 0;
}

int32_t lust_sys_sig_register(int32_t sig, int32_t kind, void *flag, uint64_t value) {
    if (sig < 1 || sig > LUST_SIG_MAX) return EINVAL;
    int n = (int)lust_sig_counts[sig];
    if (n >= LUST_SIG_ACTIONS) return ENOMEM;
    int e = lust_sig_install(sig);
    if (e) return e;
    lust_sig_actions[sig][n].kind = kind;
    lust_sig_actions[sig][n].flag = (volatile uint8_t *)flag;
    lust_sig_actions[sig][n].value = value;
    lust_sig_actions[sig][n].pipe_fd = -1;
    lust_sig_counts[sig] = n + 1;
    return 0;
}

int32_t lust_sys_sig_register_pipe(int32_t sig, int32_t write_fd) {
    if (sig < 1 || sig > LUST_SIG_MAX) return EINVAL;
    int n = (int)lust_sig_counts[sig];
    if (n >= LUST_SIG_ACTIONS) return ENOMEM;
    int e = lust_sig_install(sig);
    if (e) return e;
    lust_sig_actions[sig][n].kind = 4;
    lust_sig_actions[sig][n].flag = NULL;
    lust_sig_actions[sig][n].value = 0;
    lust_sig_actions[sig][n].pipe_fd = write_fd;
    lust_sig_counts[sig] = n + 1;
    return 0;
}

void lust_sys_sig_unregister_pipe(int32_t write_fd) {
    for (int sig = 1; sig <= LUST_SIG_MAX; sig++) {
        int n = (int)lust_sig_counts[sig];
        int w = 0;
        for (int i = 0; i < n; i++) {
            if (lust_sig_actions[sig][i].kind == 4 && lust_sig_actions[sig][i].pipe_fd == write_fd) continue;
            lust_sig_actions[sig][w] = lust_sig_actions[sig][i];
            w++;
        }
        lust_sig_counts[sig] = w;
    }
}

int32_t lust_sys_sig_pipe(lust_Vec *out) {
    int fds[2];
    if (lust_sysx_pipe2(fds, O_CLOEXEC | O_NONBLOCK) != 0) return -errno;
    lust_sysx_u64(out, (uint64_t)(uint32_t)fds[1]);
    return fds[0];
}

int32_t lust_sys_sig_poll_read(int32_t fd, lust_Vec *out) {
    struct pollfd pfd;
    pfd.fd = fd;
    pfd.events = POLLIN;
    pfd.revents = 0;
    int r;
    do {
        r = poll(&pfd, 1, -1);
    } while (r < 0 && errno == EINTR);
    if (r < 0) return -errno;
    uint8_t buf[128];
    ssize_t n = read(fd, buf, sizeof buf);
    if (n < 0) return errno == EAGAIN ? 0 : -errno;
    lust_sysx_push(out, buf, (uint64_t)n);
    return (int32_t)n;
}

int32_t lust_sys_sig_read_now(int32_t fd, lust_Vec *out) {
    uint8_t buf[128];
    ssize_t n = read(fd, buf, sizeof buf);
    if (n < 0) return errno == EAGAIN ? 0 : -errno;
    lust_sysx_push(out, buf, (uint64_t)n);
    return (int32_t)n;
}

int32_t lust_sys_sig_raise(int32_t sig) {
    return raise(sig) == 0 ? 0 : errno;
}

int32_t lust_sys_sig_restore_raise(int32_t sig) {
    struct sigaction dfl;
    memset(&dfl, 0, sizeof dfl);
    dfl.sa_handler = SIG_DFL;
    if (sigaction(sig, &dfl, NULL) != 0) return errno;
    lust_sig_installed[sig] = 0;
    lust_sig_counts[sig] = 0;
    sigset_t set;
    sigemptyset(&set);
    sigaddset(&set, sig);
    pthread_sigmask(SIG_UNBLOCK, &set, NULL);
    raise(sig);
    abort();
    return 0;
}

void lust_sys_sig_exit(int32_t status) {
    _exit(status);
}

void lust_sys_sig_abort(void) {
    abort();
}

#ifdef __linux__
int32_t lust_sys_x_inotify_init1(int32_t flags) {
    int fd = inotify_init1(flags);
    return fd < 0 ? -errno : fd;
}

int32_t lust_sys_x_inotify_add_watch(int32_t fd, const uint8_t *p, uint64_t len, uint32_t mask) {
    char *s = lust_sysx_path(p, len);
    if (!s) return -ENOMEM;
    int wd = inotify_add_watch(fd, s, mask);
    int e = errno;
    free(s);
    return wd < 0 ? -e : wd;
}

int32_t lust_sys_x_inotify_rm_watch(int32_t fd, int32_t wd) {
    return inotify_rm_watch(fd, wd) == 0 ? 0 : errno;
}
#else
int32_t lust_sys_x_inotify_init1(int32_t flags) {
    (void)flags;
    return -ENOSYS;
}

int32_t lust_sys_x_inotify_add_watch(int32_t fd, const uint8_t *p, uint64_t len, uint32_t mask) {
    (void)fd; (void)p; (void)len; (void)mask;
    return -ENOSYS;
}

int32_t lust_sys_x_inotify_rm_watch(int32_t fd, int32_t wd) {
    (void)fd; (void)wd;
    return ENOSYS;
}
#endif

#ifdef __linux__
int64_t lust_sys_x_getdents(int32_t fd, uint64_t max, lust_Vec *out) {
    if (max == 0) {
        /* The kernel answers EINVAL for a zero-size buffer. */
        long r = syscall(SYS_getdents64, fd, (void *)0, (size_t)0);
        return r < 0 ? -errno : (int64_t)r;
    }
    uint8_t *buf = (uint8_t *)malloc((size_t)max);
    if (!buf) return -ENOMEM;
    long r = syscall(SYS_getdents64, fd, buf, (size_t)max);
    int e = errno;
    if (r > 0) lust_sysx_push(out, buf, (uint64_t)r);
    free(buf);
    return r < 0 ? -e : (int64_t)r;
}
#else
int64_t lust_sys_x_getdents(int32_t fd, uint64_t max, lust_Vec *out) {
    (void)fd; (void)max; (void)out;
    return -ENOSYS;
}
#endif

/* The 11-field statvfs record: bsize, frsize, blocks, bfree,
   bavail, files, ffree, favail, fsid, flag, namemax. */
static void lust_sysx_statvfs_rec(lust_Vec *out, const struct statvfs *st) {
    uint64_t f[11] = {(uint64_t)st->f_bsize, (uint64_t)st->f_frsize, (uint64_t)st->f_blocks,
                      (uint64_t)st->f_bfree, (uint64_t)st->f_bavail, (uint64_t)st->f_files,
                      (uint64_t)st->f_ffree, (uint64_t)st->f_favail, (uint64_t)st->f_fsid,
                      (uint64_t)st->f_flag, (uint64_t)st->f_namemax};
    for (int i = 0; i < 11; i++) lust_sysx_u64(out, f[i]);
}

int32_t lust_sys_x_statvfs(const uint8_t *p, uint64_t len, lust_Vec *out) {
    char *s = lust_sysx_path(p, len);
    if (!s) return ENOMEM;
    struct statvfs st;
    int r = statvfs(s, &st);
    int e = errno;
    free(s);
    if (r != 0) return e;
    lust_sysx_statvfs_rec(out, &st);
    return 0;
}

int32_t lust_sys_x_fstatvfs(int32_t fd, lust_Vec *out) {
    struct statvfs st;
    if (fstatvfs(fd, &st) != 0) return errno;
    lust_sysx_statvfs_rec(out, &st);
    return 0;
}

#ifdef __linux__
int32_t lust_sys_x_fanotify_init(uint32_t flags, uint32_t event_f_flags) {
    int fd = fanotify_init(flags, event_f_flags);
    return fd < 0 ? -errno : fd;
}

int32_t lust_sys_x_fanotify_mark(int32_t fd, uint32_t flags, uint64_t mask, int32_t dirfd, int32_t has_path, const uint8_t *p, uint64_t len) {
    char *s = NULL;
    if (has_path) {
        s = lust_sysx_path(p, len);
        if (!s) return ENOMEM;
    }
    int r = fanotify_mark(fd, flags, mask, dirfd, s);
    int e = errno;
    free(s);
    return r != 0 ? e : 0;
}
#else
int32_t lust_sys_x_fanotify_init(uint32_t flags, uint32_t event_f_flags) {
    (void)flags; (void)event_f_flags;
    return -ENOSYS;
}

int32_t lust_sys_x_fanotify_mark(int32_t fd, uint32_t flags, uint64_t mask, int32_t dirfd, int32_t has_path, const uint8_t *p, uint64_t len) {
    (void)fd; (void)flags; (void)mask; (void)dirfd; (void)has_path; (void)p; (void)len;
    return ENOSYS;
}
#endif

#ifdef __linux__
/* struct file_handle with a `cap`-byte handle tail. */
struct lust_sysx_fhandle {
    uint32_t handle_bytes;
    int32_t handle_type;
    uint8_t f_handle[];
};

int32_t lust_sys_x_name_to_handle_at(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, lust_Vec *out) {
    char *s = lust_sysx_path(p, len);
    if (!s) return ENOMEM;
    struct lust_sysx_fhandle probe;
    probe.handle_bytes = 0;
    probe.handle_type = 0;
    uint64_t mount_id = 0;
    long r = syscall(SYS_name_to_handle_at, dirfd, s, &probe, &mount_id, flags);
    int e = errno;
    if (r == 0 || e != EOVERFLOW || probe.handle_bytes == 0) {
        free(s);
        return r == 0 ? EOVERFLOW : e;
    }
    uint32_t want = probe.handle_bytes;
    int32_t handle_type = probe.handle_type;
    for (;;) {
        struct lust_sysx_fhandle *h = (struct lust_sysx_fhandle *)calloc(1, sizeof(*h) + want);
        if (!h) {
            free(s);
            return ENOMEM;
        }
        h->handle_bytes = want;
        h->handle_type = handle_type;
        r = syscall(SYS_name_to_handle_at, dirfd, s, h, &mount_id, flags);
        e = errno;
        uint32_t got = h->handle_bytes;
        handle_type = h->handle_type;
        if (r == 0) {
            lust_sysx_u64(out, (uint64_t)(uint32_t)handle_type);
            lust_sysx_u64(out, mount_id);
            lust_sysx_push(out, h->f_handle, got);
            free(h);
            free(s);
            return 0;
        }
        free(h);
        if (e != EOVERFLOW) {
            free(s);
            return e;
        }
        want = got;
    }
}

int32_t lust_sys_x_open_by_handle_at(int32_t mount_fd, int32_t handle_type, const uint8_t *p, uint64_t len, int32_t flags) {
    struct lust_sysx_fhandle *h = (struct lust_sysx_fhandle *)calloc(1, sizeof(*h) + len);
    if (!h) return -ENOMEM;
    h->handle_bytes = (uint32_t)len;
    h->handle_type = handle_type;
    memcpy(h->f_handle, p, len);
    long r = syscall(SYS_open_by_handle_at, mount_fd, h, flags);
    int e = errno;
    free(h);
    return r < 0 ? -e : (int32_t)r;
}
#else
int32_t lust_sys_x_name_to_handle_at(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, lust_Vec *out) {
    (void)dirfd; (void)p; (void)len; (void)flags; (void)out;
    return ENOSYS;
}

int32_t lust_sys_x_open_by_handle_at(int32_t mount_fd, int32_t handle_type, const uint8_t *p, uint64_t len, int32_t flags) {
    (void)mount_fd; (void)handle_type; (void)p; (void)len; (void)flags;
    return -ENOSYS;
}

#endif
#endif

/* kqueue/kevent for the nix adapter's sys::event (Darwin only; the
   adapter's event module exists only there, as upstream's). Records
   cross as 48-byte little-endian fields (sysx.h), translated to and
   from struct kevent here so its layout stays the C compiler's. */
#ifdef __APPLE__
#include <sys/event.h>
#include <sys/time.h>

static uint64_t lust_sysx_rec_u64(const uint8_t *p) {
    uint64_t v = 0;
    for (int k = 0; k < 8; k++) v |= (uint64_t)p[k] << (8 * k);
    return v;
}

static void lust_sysx_rec_put(uint8_t *p, const struct kevent *ev) {
    uint64_t f[6] = {(uint64_t)ev->ident, (uint64_t)(int64_t)ev->filter, ev->flags, ev->fflags,
                     (uint64_t)(int64_t)ev->data, (uint64_t)(int64_t)(uintptr_t)ev->udata};
    for (int i = 0; i < 6; i++)
        for (int k = 0; k < 8; k++) p[i * 8 + k] = (uint8_t)(f[i] >> (8 * k));
}

int32_t lust_sys_x_kqueue(void) {
    int fd = kqueue();
    return fd < 0 ? -errno : fd;
}

int32_t lust_sys_x_kevent(int32_t fd, const uint8_t *changes, uint64_t clen, lust_Vec *events, int32_t has_timeout, int64_t sec, int64_t nsec) {
    if (clen % 48 != 0 || events->len % 48 != 0) return -EINVAL;
    uint64_t nch = clen / 48, nev = events->len / 48;
    struct kevent stack_ch[8], stack_ev[8];
    struct kevent *ch = stack_ch, *ev = stack_ev;
    if (nch > 8) {
        ch = (struct kevent *)malloc((size_t)nch * sizeof *ch);
        if (!ch) return -ENOMEM;
    }
    if (nev > 8) {
        ev = (struct kevent *)malloc((size_t)nev * sizeof *ev);
        if (!ev) {
            if (ch != stack_ch) free(ch);
            return -ENOMEM;
        }
    }
    for (uint64_t i = 0; i < nch; i++) {
        const uint8_t *r = changes + i * 48;
        memset(&ch[i], 0, sizeof ch[i]);
        ch[i].ident = (uintptr_t)lust_sysx_rec_u64(r);
        ch[i].filter = (int16_t)(int64_t)lust_sysx_rec_u64(r + 8);
        ch[i].flags = (uint16_t)lust_sysx_rec_u64(r + 16);
        ch[i].fflags = (uint32_t)lust_sysx_rec_u64(r + 24);
        ch[i].data = (intptr_t)(int64_t)lust_sysx_rec_u64(r + 32);
        ch[i].udata = (void *)(uintptr_t)lust_sysx_rec_u64(r + 40);
    }
    struct timespec ts;
    ts.tv_sec = (time_t)sec;
    ts.tv_nsec = (long)nsec;
    int n = kevent(fd, ch, (int)nch, ev, (int)nev, has_timeout ? &ts : NULL);
    int e = errno;
    if (n > 0) {
        uint8_t *out = (uint8_t *)events->ptr;
        for (int i = 0; i < n; i++) lust_sysx_rec_put(out + (uint64_t)i * 48, &ev[i]);
    }
    if (ch != stack_ch) free(ch);
    if (ev != stack_ev) free(ev);
    return n < 0 ? -e : n;
}
#else
int32_t lust_sys_x_kqueue(void) { return -ENOSYS; }

int32_t lust_sys_x_kevent(int32_t fd, const uint8_t *changes, uint64_t clen, lust_Vec *events, int32_t has_timeout, int64_t sec, int64_t nsec) {
    (void)fd; (void)changes; (void)clen; (void)events; (void)has_timeout; (void)sec; (void)nsec;
    return -ENOSYS;
}
#endif

#endif

#endif

/* Std runtime hooks for time and fmt (src/runtime/stdc.h, W-STD-C). */
/* Std runtime hooks of package W-STD-C: the C behind the time and fmt
   intrinsics of src/ty/lang.rs that std source (library/core and
   library/std time modules) calls.

   Declarations here are in every unit; bodies (stdc.c) only in the
   runtime unit (LUST_IMPL), like deps.h. */
#ifndef LUST_RT_STDC_H
#define LUST_RT_STDC_H

/* Clock readings for `Instant::now` (CLOCK_MONOTONIC) and
   `SystemTime::now` (CLOCK_REALTIME): `lo` is tv_sec as i64 bits, `hi`
   is tv_nsec. A clock_gettime failure aborts, as std's unwrap panics. */
lust_u128 lust_clock_now_raw(void);
lust_u128 lust_system_time_raw(void);

/* `Formatter`'s alignment as `rt::Alignment` encodes it: 0 left,
   1 right, 2 center, 3 unknown (none written). */
uint32_t lust_fmt_align(lust_Formatter *f);

#ifdef LUST_IMPL
#ifndef _WIN32
#include <time.h>
#endif

#ifdef _WIN32
/* QueryPerformanceCounter as a (sec, nsec) pair, and the system
   FILETIME (100 ns ticks since 1601) shifted to the Unix epoch. */
lust_u128 lust_clock_now_raw(void) {
    LARGE_INTEGER freq, now;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&now);
    lust_u128 r;
    r.lo = (uint64_t)(now.QuadPart / freq.QuadPart);
    r.hi = (uint64_t)(((now.QuadPart % freq.QuadPart) * 1000000000) / freq.QuadPart);
    return r;
}

lust_u128 lust_system_time_raw(void) {
    FILETIME ft;
    GetSystemTimeAsFileTime(&ft);
    uint64_t ticks = ((uint64_t)ft.dwHighDateTime << 32) | ft.dwLowDateTime;
    ticks -= 116444736000000000ull;
    lust_u128 r;
    r.lo = ticks / 10000000ull;
    r.hi = (ticks % 10000000ull) * 100ull;
    return r;
}

uint32_t lust_fmt_align(lust_Formatter *f) {
    return f->align;
}
#else
/* One clock reading as the u128 the time intrinsics return. */
static lust_u128 lust_clock_read(clockid_t clock) {
    struct timespec ts;
    if (clock_gettime(clock, &ts) != 0) {
        abort();
    }
    lust_u128 r;
    r.lo = (uint64_t)(int64_t)ts.tv_sec;
    r.hi = (uint64_t)ts.tv_nsec;
    return r;
}

lust_u128 lust_clock_now_raw(void) {
#ifdef __APPLE__
    /* std's Instant on Apple is CLOCK_UPTIME_RAW. */
    return lust_clock_read(CLOCK_UPTIME_RAW);
#else
    return lust_clock_read(CLOCK_MONOTONIC);
#endif
}

lust_u128 lust_system_time_raw(void) {
    return lust_clock_read(CLOCK_REALTIME);
}

uint32_t lust_fmt_align(lust_Formatter *f) {
    return f->align;
}
#endif

#endif

#endif

