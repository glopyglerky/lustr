typedef signed char int8_t; typedef unsigned char uint8_t; typedef short int16_t; typedef unsigned short uint16_t;
typedef int int32_t; typedef unsigned int uint32_t;
#ifdef __INT64_TYPE__
typedef __INT64_TYPE__ int64_t; typedef unsigned __INT64_TYPE__ uint64_t;
#else
typedef long long int64_t; typedef unsigned long long uint64_t;
#endif
#ifdef __SIZE_TYPE__
typedef __SIZE_TYPE__ size_t; typedef __PTRDIFF_TYPE__ ptrdiff_t; typedef __UINTPTR_TYPE__ uintptr_t; typedef __INTPTR_TYPE__ intptr_t;
#else
typedef unsigned long size_t; typedef long ptrdiff_t; typedef unsigned long uintptr_t; typedef long intptr_t;
#endif
#define INT64_MIN (-9223372036854775807LL-1)
#ifndef NULL
#define NULL ((void*)0)
#endif
extern const char *lust_file;
extern const uint32_t *lust_fn_line;
extern const char *const *lust_files;
extern const uint32_t *lust_slot_file;
static const uint32_t lines[3] = {7,11,19};
void lust_loc_init(void) {
  lust_file = "/home/runner/work/lustr/lustr/compiler/native/tests/pass/unicode_props_hash.rs";
  lust_fn_line = lines;
  lust_files = 0;
  lust_slot_file = 0;
}
