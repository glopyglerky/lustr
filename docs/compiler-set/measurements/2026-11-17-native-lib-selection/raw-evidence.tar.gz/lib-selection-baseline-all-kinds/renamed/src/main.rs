fn main(){let _:u32="wrong bin";}
